<?php


include_once "\125\x74\151\x6c\151\x74\151\145\x73\56\x70\150\160";
class MetadataReader
{
    private $identityProviders;
    private $serviceProviders;
    public function __construct(DOMNode $fO = NULL)
    {
        $this->identityProviders = array();
        $this->serviceProviders = array();
        $N8 = Utilities::xpQuery($fO, "\56\57\x73\141\155\x6c\x5f\x6d\145\x74\141\144\141\x74\x61\72\105\x6e\164\x69\164\x69\145\163\104\x65\163\143\162\x69\x70\164\x6f\x72");
        if (!empty($N8)) {
            goto MW;
        }
        $Rq = Utilities::xpQuery($fO, "\56\57\x73\141\x6d\x6c\x5f\x6d\145\164\141\x64\x61\x74\x61\x3a\x45\156\x74\x69\164\x79\x44\x65\163\x63\162\x69\160\x74\x6f\162");
        goto Bw;
        MW:
        $Rq = Utilities::xpQuery($N8[0], "\56\57\163\x61\x6d\154\x5f\x6d\145\x74\141\144\x61\164\141\x3a\x45\x6e\x74\151\164\171\x44\145\163\143\162\x69\x70\164\x6f\x72");
        Bw:
        foreach ($Rq as $ty) {
            $dk = Utilities::xpQuery($ty, "\x2e\57\163\x61\x6d\154\x5f\x6d\x65\x74\141\144\141\164\x61\x3a\111\104\x50\123\x53\x4f\x44\x65\x73\x63\162\151\160\x74\157\x72");
            if (!(isset($dk) && !empty($dk))) {
                goto lf;
            }
            array_push($this->identityProviders, new IdentityProviders($ty));
            lf:
            Zz:
        }
        lb:
    }
    public function getIdentityProviders()
    {
        return $this->identityProviders;
    }
    public function getServiceProviders()
    {
        return $this->serviceProviders;
    }
}
class IdentityProviders
{
    private $idpName;
    private $entityID;
    private $loginDetails;
    private $logoutDetails;
    private $signingCertificate;
    private $encryptionCertificate;
    private $signedRequest;
    private $loginbinding;
    private $logoutbinding;
    public function __construct(DOMElement $fO = NULL)
    {
        $this->idpName = '';
        $this->loginDetails = array();
        $this->logoutDetails = array();
        $this->signingCertificate = array();
        $this->encryptionCertificate = array();
        if (!$fO->hasAttribute("\x65\x6e\164\x69\164\171\111\x44")) {
            goto BO;
        }
        $this->entityID = $fO->getAttribute("\x65\156\x74\x69\x74\171\111\x44");
        BO:
        if (!$fO->hasAttribute("\127\141\156\x74\101\165\x74\x68\156\122\145\161\x75\x65\x73\164\x73\123\151\x67\156\x65\144")) {
            goto ug;
        }
        $this->signedRequest = $fO->getAttribute("\x57\x61\x6e\164\x41\165\164\x68\156\122\145\x71\x75\x65\x73\164\x73\123\x69\x67\x6e\145\144");
        ug:
        $dk = Utilities::xpQuery($fO, "\x2e\x2f\x73\x61\x6d\154\137\x6d\x65\164\141\144\x61\164\x61\72\111\104\x50\x53\x53\117\x44\145\163\x63\x72\x69\x70\164\x6f\x72");
        if (count($dk) > 1) {
            goto hI;
        }
        if (empty($dk)) {
            goto Zm;
        }
        goto aF;
        hI:
        throw new Exception("\115\x6f\x72\x65\40\x74\x68\141\156\40\x6f\156\x65\x20\x3c\x49\x44\x50\x53\123\x4f\x44\x65\x73\143\x72\151\160\x74\157\162\76\40\151\x6e\40\x3c\105\x6e\164\x69\164\x79\x44\x65\163\143\162\x69\x70\x74\157\x72\x3e\56");
        goto aF;
        Zm:
        throw new Exception("\115\151\x73\x73\x69\156\x67\x20\x72\x65\161\x75\151\162\145\144\x20\74\x49\x44\120\123\x53\117\104\145\x73\x63\x72\151\x70\164\x6f\x72\76\40\x69\x6e\40\74\105\x6e\164\151\164\171\x44\x65\163\x63\x72\151\x70\164\x6f\x72\x3e\x2e");
        aF:
        $wR = $dk[0];
        $iw = Utilities::xpQuery($fO, "\56\x2f\163\x61\x6d\x6c\137\155\145\x74\141\x64\x61\x74\x61\72\105\170\164\145\x6e\163\151\157\156\x73");
        if (!$iw) {
            goto hA;
        }
        $this->parseInfo($wR);
        hA:
        $this->parseSSOService($wR);
        $this->parseSLOService($wR);
        $this->parsex509Certificate($wR);
    }
    private function parseInfo($fO)
    {
        $e5 = Utilities::xpQuery($fO, "\x2e\x2f\x6d\x64\x75\x69\72\125\111\111\156\x66\157\x2f\x6d\x64\165\x69\72\x44\x69\x73\160\154\x61\x79\x4e\x61\x6d\x65");
        foreach ($e5 as $zY) {
            if (!($zY->hasAttribute("\170\x6d\154\x3a\154\141\x6e\147") && $zY->getAttribute("\x78\x6d\154\72\154\x61\156\147") == "\x65\156")) {
                goto Pq;
            }
            $this->idpName = $zY->textContent;
            Pq:
            k4:
        }
        vL:
    }
    private function parseSSOService($fO)
    {
        $Od = Utilities::xpQuery($fO, "\x2e\57\163\141\x6d\154\x5f\x6d\145\x74\141\144\x61\164\141\72\x53\151\156\x67\x6c\x65\x53\151\147\x6e\x4f\156\123\145\162\166\x69\x63\145");
        $Ol = 0;
        foreach ($Od as $nR) {
            $II = str_replace("\x75\162\156\72\x6f\x61\x73\x69\163\72\156\x61\155\x65\163\x3a\164\143\x3a\x53\x41\115\114\72\x32\56\x30\x3a\142\151\x6e\x64\151\x6e\x67\163\x3a", '', $nR->getAttribute("\x42\151\x6e\144\151\156\x67"));
            $this->loginDetails = array_merge($this->loginDetails, array($II => $nR->getAttribute("\114\x6f\x63\141\x74\151\x6f\x6e")));
            if (!($II == "\110\124\x54\120\x2d\x52\x65\x64\151\162\145\143\x74")) {
                goto Ae;
            }
            $Ol = 1;
            $this->loginbinding = "\110\x74\x74\x70\x52\x65\144\151\x72\145\x63\164";
            Ae:
            Cv:
        }
        V_:
        if ($Ol) {
            goto wn;
        }
        $this->loginbinding = "\x48\x74\x74\160\120\157\x73\164";
        wn:
    }
    private function parseSLOService($fO)
    {
        $Ol = 0;
        $EX = Utilities::xpQuery($fO, "\x2e\57\x73\141\x6d\x6c\137\x6d\145\164\141\144\141\x74\x61\x3a\x53\151\x6e\147\x6c\x65\x4c\157\147\x6f\x75\x74\x53\x65\x72\166\x69\143\x65");
        foreach ($EX as $PN) {
            $II = str_replace("\165\162\x6e\72\x6f\141\163\151\x73\72\156\x61\x6d\145\x73\x3a\x74\143\x3a\x53\101\115\x4c\x3a\x32\56\x30\x3a\x62\151\156\x64\x69\156\147\x73\72", '', $PN->getAttribute("\102\x69\x6e\x64\x69\156\x67"));
            $this->logoutDetails = array_merge($this->logoutDetails, array($II => $PN->getAttribute("\x4c\x6f\143\141\x74\x69\157\156")));
            if (!($II == "\110\x54\124\x50\x2d\122\145\144\151\x72\x65\x63\164")) {
                goto we;
            }
            $Ol = 1;
            $this->logoutbinding = "\x48\164\x74\x70\x52\145\x64\x69\162\x65\x63\164";
            we:
            ys:
        }
        ux:
        if (!empty($this->logoutbinding)) {
            goto I0;
        }
        $this->logoutbinding = "\x48\x74\164\x70\120\x6f\163\x74";
        I0:
    }
    private function parsex509Certificate($fO)
    {
        foreach (Utilities::xpQuery($fO, "\56\57\x73\x61\x6d\x6c\x5f\155\145\x74\x61\x64\141\164\x61\72\x4b\x65\x79\104\x65\x73\x63\162\x69\160\164\x6f\162") as $zv) {
            if ($zv->hasAttribute("\x75\163\x65")) {
                goto bk;
            }
            $this->parseSigningCertificate($zv);
            goto uo;
            bk:
            if ($zv->getAttribute("\x75\x73\x65") == "\x65\x6e\143\162\x79\x70\164\x69\157\156") {
                goto qx;
            }
            $this->parseSigningCertificate($zv);
            goto rn;
            qx:
            $this->parseEncryptionCertificate($zv);
            rn:
            uo:
            fA:
        }
        tT:
    }
    private function parseSigningCertificate($fO)
    {
        $go = Utilities::xpQuery($fO, "\56\57\144\x73\72\113\145\x79\x49\156\x66\x6f\57\x64\x73\72\130\x35\x30\x39\104\x61\x74\x61\x2f\144\x73\72\130\65\60\x39\x43\145\x72\x74\x69\x66\x69\143\x61\x74\x65");
        $NR = trim($go[0]->textContent);
        $NR = str_replace(array("\15", "\xa", "\x9", "\x20"), '', $NR);
        if (empty($go)) {
            goto ab;
        }
        array_push($this->signingCertificate, $NR);
        ab:
    }
    private function parseEncryptionCertificate($fO)
    {
        $go = Utilities::xpQuery($fO, "\56\57\144\163\72\113\145\171\x49\x6e\x66\157\x2f\144\163\72\x58\x35\60\x39\x44\x61\x74\141\57\x64\163\72\130\x35\60\x39\103\145\162\164\x69\146\151\143\141\x74\145");
        $NR = trim($go[0]->textContent);
        $NR = str_replace(array("\15", "\12", "\11", "\x20"), '', $NR);
        if (empty($go)) {
            goto z2;
        }
        array_push($this->encryptionCertificate, $NR);
        z2:
    }
    public function getIdpName()
    {
        return $this->idpName;
    }
    public function getEntityID()
    {
        return $this->entityID;
    }
    public function getLoginURL($II)
    {
        return $this->loginDetails[$II];
    }
    public function getLogoutURL($II)
    {
        return $this->logoutDetails[$II];
    }
    public function getLoginDetails()
    {
        return $this->loginDetails;
    }
    public function getLogoutDetails()
    {
        return $this->logoutDetails;
    }
    public function getSigningCertificate()
    {
        return $this->signingCertificate;
    }
    public function getEncryptionCertificate()
    {
        return $this->encryptionCertificate[0];
    }
    public function isRequestSigned()
    {
        return $this->signedRequest;
    }
    public function getBindingLogin()
    {
        return $this->loginbinding;
    }
    public function getBindingLogout()
    {
        return $this->logoutbinding;
    }
}
class ServiceProviders
{
}
