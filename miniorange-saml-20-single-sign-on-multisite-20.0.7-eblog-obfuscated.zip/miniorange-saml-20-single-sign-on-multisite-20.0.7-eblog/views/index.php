<?php


if (defined("\127\120\x49\116\103")) {
    goto OUG;
}
die;
OUG:
