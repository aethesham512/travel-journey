<?php


include "\x41\x73\163\x65\162\x74\151\157\x6e\56\160\150\160";
class SAML2_Response
{
    private $assertions;
    private $destination;
    private $certificates;
    private $signatureData;
    public function __construct(DOMElement $fO = NULL, $CO)
    {
        $this->assertions = array();
        $this->certificates = array();
        if (!($fO === NULL)) {
            goto vjU;
        }
        return;
        vjU:
        $SE = Utilities::validateElement($fO);
        if (!($SE !== FALSE)) {
            goto ams;
        }
        $this->certificates = $SE["\103\145\162\164\x69\x66\151\143\141\x74\145\163"];
        $this->signatureData = $SE;
        ams:
        if (!$fO->hasAttribute("\x44\145\x73\x74\x69\x6e\x61\x74\x69\x6f\x6e")) {
            goto nIC;
        }
        $this->destination = $fO->getAttribute("\x44\x65\x73\164\x69\x6e\x61\164\151\157\156");
        nIC:
        $Qh = $fO->firstChild;
        Q0C:
        if (!($Qh !== NULL)) {
            goto c2T;
        }
        if (!($Qh->namespaceURI !== "\165\162\x6e\72\x6f\x61\x73\x69\163\72\156\x61\x6d\145\163\x3a\164\x63\72\123\101\x4d\x4c\x3a\62\56\x30\72\x61\163\163\145\x72\x74\x69\x6f\x6e")) {
            goto v9t;
        }
        goto ZSk;
        v9t:
        if (!($Qh->localName === "\101\x73\163\x65\162\x74\151\x6f\156" || $Qh->localName === "\105\156\143\x72\x79\x70\x74\x65\x64\101\163\163\x65\x72\x74\x69\157\156")) {
            goto RGG;
        }
        $this->assertions[] = new SAML2_Assertion($Qh, $CO);
        RGG:
        ZSk:
        $Qh = $Qh->nextSibling;
        goto Q0C;
        c2T:
    }
    public function getAssertions()
    {
        return $this->assertions;
    }
    public function setAssertions(array $EY)
    {
        $this->assertions = $EY;
    }
    public function getDestination()
    {
        return $this->destination;
    }
    public function getCertificates()
    {
        return $this->certificates;
    }
    public function getSignatureData()
    {
        return $this->signatureData;
    }
}
