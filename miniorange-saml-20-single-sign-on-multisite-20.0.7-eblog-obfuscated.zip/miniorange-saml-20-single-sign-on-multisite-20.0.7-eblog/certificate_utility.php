<?php


class CertificateUtility
{
    public static function generate_certificate($TQ, $y4, $yI)
    {
        $Rm = openssl_pkey_new();
        $J8 = openssl_csr_new($TQ, $Rm, $y4);
        $VZ = openssl_csr_sign($J8, null, $Rm, $yI, $y4, time());
        openssl_csr_export($J8, $qp);
        openssl_x509_export($VZ, $zc);
        openssl_pkey_export($Rm, $Gj);
        vw:
        if (!(($i0 = openssl_error_string()) !== false)) {
            goto YP;
        }
        error_log("\103\145\x72\164\151\146\151\143\x61\164\x65\125\x74\x69\x6c\x69\x74\x79\72\40\x45\162\x72\x6f\x72\40\x67\x65\x6e\145\x72\x61\x74\x69\156\147\x20\x63\145\162\164\151\146\151\x63\x61\x74\145\x2e\40" . $i0);
        goto vw;
        YP:
        $vi = array("\160\165\142\154\151\x63\x5f\153\x65\171" => $zc, "\x70\162\x69\166\141\164\x65\x5f\153\x65\x79" => $Gj);
        return $vi;
    }
}
