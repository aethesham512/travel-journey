<?php


if (defined("\127\120\x49\116\x43")) {
    goto ou_;
}
die;
ou_:
