<?php


include_once dirname(__FILE__) . "\x2f\125\x74\151\x6c\x69\164\151\x65\x73\x2e\x70\150\160";
include_once dirname(__FILE__) . "\x2f\x52\145\x73\160\157\156\x73\x65\56\160\150\160";
include_once dirname(__FILE__) . "\57\114\x6f\x67\157\x75\x74\122\145\161\x75\x65\163\164\x2e\160\x68\160";
require_once dirname(__FILE__) . "\57\151\156\143\154\x75\144\x65\x73\x2f\x6c\151\142\x2f\145\156\x63\162\171\160\x74\151\x6f\156\x2e\x70\150\160";
include_once "\170\155\154\x73\145\x63\x6c\151\142\x73\x2e\x70\150\160";
use RobRichards\XMLSecLibs\XMLSecurityKey;
use RobRichards\XMLSecLibs\XMLSecurityDSig;
use RobRichards\XMLSecLibs\XMLSecEnc;
class mo_login_wid extends WP_Widget
{
    public function __construct()
    {
        $n6 = get_site_option("\x73\141\x6d\154\x5f\151\144\145\x6e\x74\x69\164\x79\137\156\x61\155\145");
        parent::__construct("\123\x61\155\154\137\114\x6f\147\x69\x6e\137\127\x69\x64\147\x65\164", "\x4c\x6f\147\151\156\40\167\x69\164\x68\40" . $n6, array("\144\145\163\x63\x72\x69\x70\164\x69\157\156" => __("\x54\150\151\163\40\151\163\40\141\40\155\151\156\151\x4f\162\x61\x6e\x67\145\40\x53\101\115\x4c\40\154\157\x67\x69\x6e\40\x77\151\x64\147\x65\164\x2e", "\x6d\157\x73\x61\155\154")));
    }
    public function widget($hm, $AW)
    {
        extract($hm);
        $bF = apply_filters("\167\151\144\147\145\x74\x5f\x74\151\164\x6c\145", $AW["\167\x69\x64\x5f\164\x69\164\154\x65"]);
        echo $hm["\x62\145\146\x6f\162\145\x5f\167\151\144\147\x65\x74"];
        if (empty($bF)) {
            goto z1;
        }
        echo $hm["\142\145\x66\x6f\x72\145\x5f\x74\x69\164\154\x65"] . $bF . $hm["\x61\x66\x74\x65\x72\137\164\x69\164\154\x65"];
        z1:
        $this->loginForm();
        echo $hm["\x61\146\x74\x65\162\x5f\167\151\x64\147\145\164"];
    }
    public function update($LW, $Vk)
    {
        $AW = array();
        $AW["\x77\151\144\x5f\x74\x69\164\x6c\145"] = strip_tags($LW["\x77\x69\x64\137\164\151\164\x6c\145"]);
        return $AW;
    }
    public function form($AW)
    {
        $bF = '';
        if (!array_key_exists("\x77\151\144\x5f\x74\151\164\x6c\145", $AW)) {
            goto Qo;
        }
        $bF = $AW["\x77\151\x64\x5f\164\x69\164\154\145"];
        Qo:
        echo "\15\xa\x9\x9\x3c\160\x3e\x3c\x6c\x61\x62\x65\x6c\40\146\157\162\75\42" . $this->get_field_id("\167\151\144\x5f\x74\x69\164\154\x65") . "\x20\42\76" . _e("\124\x69\x74\154\x65\72") . "\40\x3c\x2f\154\141\142\x65\x6c\76\xd\xa\11\11\11\x3c\x69\156\160\x75\x74\40\143\x6c\x61\x73\x73\75\x22\x77\151\144\145\x66\141\164\42\x20\151\x64\x3d\x22" . $this->get_field_id("\x77\151\x64\x5f\x74\151\164\x6c\x65") . "\x22\40\x6e\141\155\145\x3d\x22" . $this->get_field_name("\x77\x69\144\137\164\151\164\x6c\145") . "\x22\40\x74\x79\x70\x65\x3d\42\x74\145\170\x74\42\40\x76\x61\154\x75\145\x3d\x22" . $bF . "\42\x20\x2f\x3e\15\xa\11\x9\74\57\x70\76";
    }
    public function loginForm()
    {
        global $post;
        $h6 = get_site_option("\x73\141\x6d\x6c\137\x73\x73\x6f\137\x73\x65\x74\164\151\x6e\147\x73");
        $nV = get_current_blog_id();
        $GY = Utilities::get_active_sites();
        if (in_array($nV, $GY)) {
            goto Xc;
        }
        return;
        Xc:
        if (!(empty($h6[$nV]) && !empty($h6["\104\x45\x46\101\x55\x4c\124"]))) {
            goto DT;
        }
        $h6[$nV] = $h6["\104\x45\106\101\125\114\x54"];
        DT:
        if (!is_user_logged_in()) {
            goto JS;
        }
        $current_user = wp_get_current_user();
        $oG = "\110\x65\x6c\154\x6f\x2c";
        if (empty($h6[$nV]["\155\x6f\137\163\x61\155\x6c\x5f\143\165\163\164\x6f\x6d\137\147\162\145\145\164\x69\x6e\x67\137\164\x65\170\x74"])) {
            goto Vf;
        }
        $oG = $h6[$nV]["\x6d\x6f\137\x73\141\x6d\x6c\x5f\x63\x75\x73\164\157\x6d\x5f\x67\x72\145\x65\164\x69\156\x67\137\x74\145\x78\x74"];
        Vf:
        $Sa = '';
        if (empty($h6[$nV]["\155\x6f\x5f\163\x61\155\154\137\x67\162\x65\x65\x74\x69\156\x67\137\156\x61\155\x65"])) {
            goto uR;
        }
        switch ($h6[$nV]["\155\x6f\x5f\x73\141\155\154\137\x67\162\145\x65\x74\151\x6e\147\x5f\x6e\x61\155\x65"]) {
            case "\125\x53\105\x52\116\101\115\105":
                $Sa = $current_user->user_login;
                goto u1;
            case "\105\x4d\101\111\x4c":
                $Sa = $current_user->user_email;
                goto u1;
            case "\106\116\x41\115\x45":
                $Sa = $current_user->user_firstname;
                goto u1;
            case "\114\x4e\101\x4d\x45":
                $Sa = $current_user->user_lastname;
                goto u1;
            case "\106\x4e\x41\x4d\x45\137\x4c\116\x41\115\x45":
                $Sa = $current_user->user_firstname . "\40" . $current_user->user_lastname;
                goto u1;
            case "\x4c\116\101\x4d\x45\x5f\106\x4e\x41\x4d\105":
                $Sa = $current_user->user_lastname . "\x20" . $current_user->user_firstname;
                goto u1;
            default:
                $Sa = $current_user->user_login;
        }
        U5:
        u1:
        uR:
        if (!empty(trim($Sa))) {
            goto Lj;
        }
        $Sa = $current_user->user_login;
        Lj:
        $mD = $oG . "\x20" . $Sa;
        $l8 = "\114\157\147\157\165\x74";
        if (empty($h6[$nV]["\x6d\x6f\x5f\x73\141\155\x6c\x5f\143\x75\x73\x74\157\155\x5f\154\157\x67\x6f\x75\164\x5f\x74\145\170\x74"])) {
            goto f7;
        }
        $l8 = $h6[$nV]["\155\157\137\x73\x61\x6d\x6c\137\143\x75\163\164\157\x6d\137\x6c\157\147\x6f\165\x74\137\164\145\170\x74"];
        f7:
        echo $mD . "\40\174\40\74\141\40\x68\x72\145\x66\75\42" . wp_logout_url(home_url()) . "\x22\40\x74\151\x74\154\x65\75\x22\154\157\x67\x6f\165\x74\x22\40\x3e" . $l8 . "\74\x2f\x61\x3e\74\x2f\x6c\x69\x3e";
        goto J8;
        JS:
        echo "\xd\12\11\11\x9\x3c\x73\x63\162\x69\x70\164\76\xd\xa\x9\x9\11\11\146\x75\156\143\x74\151\x6f\156\x20\163\165\x62\155\x69\x74\123\141\x6d\154\106\x6f\162\155\x28\x29\173\40\x64\x6f\143\x75\155\145\x6e\164\x2e\147\145\x74\105\154\145\155\x65\x6e\x74\x42\x79\x49\144\50\x22\154\157\x67\x69\156\42\x29\56\x73\x75\142\x6d\151\x74\x28\x29\73\40\x7d\xd\xa\x9\11\11\x3c\57\x73\143\162\x69\x70\x74\x3e\xd\12\x9\x9\11\74\146\157\162\x6d\40\156\141\x6d\x65\75\42\154\157\x67\x69\x6e\42\40\x69\144\75\42\x6c\x6f\x67\x69\x6e\42\40\x6d\145\164\150\x6f\x64\x3d\42\x70\157\163\x74\42\40\141\x63\164\151\x6f\x6e\x3d\x22\x22\76\15\xa\x9\x9\x9\x9\x3c\151\156\160\x75\x74\x20\x74\x79\160\145\x3d\x22\150\x69\144\x64\x65\x6e\42\x20\156\x61\155\x65\75\x22\x6f\160\164\151\157\156\42\x20\166\x61\154\165\145\x3d\x22\163\141\x6d\154\137\165\x73\x65\x72\137\154\157\x67\151\x6e\42\40\x2f\76\xd\xa\xd\xa\x9\x9\11\11\74\146\157\156\164\x20\163\151\x7a\x65\x3d\42\x2b\61\42\x20\163\x74\x79\x6c\145\75\42\x76\145\162\164\x69\x63\x61\154\55\141\154\151\147\156\x3a\164\x6f\x70\73\42\x3e\40\x3c\57\146\x6f\156\x74\x3e";
        $YJ = get_site_option("\x73\x61\x6d\154\137\x69\x64\145\156\x74\151\x74\171\x5f\156\141\x6d\145");
        $iv = get_site_option("\x73\x61\155\154\137\x78\x35\60\71\137\x63\145\162\x74\151\146\151\x63\141\x74\145");
        if (!empty($YJ) && !empty($iv)) {
            goto f1;
        }
        echo "\120\x6c\x65\x61\163\145\x20\143\x6f\156\x66\151\x67\x75\x72\x65\x20\x74\150\x65\x20\x6d\151\x6e\x69\x4f\x72\x61\x6e\147\x65\x20\x53\101\115\x4c\40\x50\154\x75\x67\151\156\x20\146\x69\x72\x73\x74\x2e";
        goto x5;
        f1:
        $Kx = "\x4c\157\147\151\x6e\40\167\151\164\150\x20\x23\43\x49\104\120\43\43";
        if (empty($h6[$nV]["\x6d\157\137\x73\141\x6d\154\137\143\x75\163\x74\157\x6d\137\x6c\157\x67\x69\x6e\137\x74\145\170\164"])) {
            goto fR;
        }
        $Kx = $h6[$nV]["\x6d\157\137\x73\141\155\154\x5f\143\165\163\x74\157\x6d\x5f\x6c\157\147\151\156\x5f\164\145\x78\x74"];
        fR:
        $Kx = str_replace("\43\x23\x49\x44\x50\43\x23", $YJ, $Kx);
        $n9 = false;
        if (!(isset($h6[$nV]["\x6d\x6f\x5f\163\x61\155\x6c\137\165\163\145\x5f\x62\165\164\x74\x6f\156\137\x61\x73\137\167\x69\144\147\145\164"]) && $h6[$nV]["\x6d\x6f\x5f\x73\x61\x6d\154\137\x75\163\x65\x5f\x62\x75\x74\164\x6f\156\137\141\x73\137\x77\151\144\147\145\x74"] == "\x74\162\165\x65")) {
            goto pG;
        }
        $n9 = true;
        pG:
        if (!$n9) {
            goto W4;
        }
        $E5 = isset($h6[$nV]["\155\x6f\137\163\141\x6d\154\x5f\x62\x75\x74\x74\157\156\137\x77\151\144\x74\150"]) ? $h6[$nV]["\155\x6f\137\163\141\x6d\154\137\x62\165\164\164\x6f\156\x5f\x77\x69\x64\x74\150"] : "\x31\60\x30";
        $Ng = isset($h6[$nV]["\x6d\x6f\137\163\141\x6d\154\137\x62\x75\x74\x74\x6f\156\x5f\x68\145\151\x67\150\x74"]) ? $h6[$nV]["\155\x6f\137\x73\x61\155\x6c\137\x62\165\164\164\x6f\156\137\x68\x65\151\147\x68\164"] : "\65\x30";
        $Px = isset($h6[$nV]["\x6d\157\x5f\163\141\155\154\x5f\142\165\x74\x74\x6f\x6e\137\x73\151\x7a\145"]) ? $h6[$nV]["\x6d\157\x5f\x73\x61\155\x6c\x5f\142\x75\164\x74\x6f\x6e\x5f\163\x69\x7a\145"] : "\x35\x30";
        $sP = isset($h6[$nV]["\x6d\157\137\163\141\155\154\x5f\142\x75\x74\164\x6f\156\137\x63\165\x72\166\145"]) ? $h6[$nV]["\x6d\x6f\x5f\163\x61\x6d\154\x5f\142\165\164\164\157\x6e\x5f\143\165\x72\166\145"] : "\65";
        $sZ = isset($h6[$nV]["\x6d\x6f\x5f\163\141\x6d\154\x5f\142\165\164\164\x6f\156\x5f\143\157\154\x6f\162"]) ? $h6[$nV]["\x6d\x6f\x5f\163\141\155\x6c\x5f\142\165\x74\164\x6f\x6e\137\x63\157\x6c\x6f\162"] : "\x30\x30\70\65\x62\x61";
        $U7 = isset($h6[$nV]["\155\x6f\137\163\141\x6d\154\x5f\x62\x75\x74\x74\x6f\156\x5f\164\150\145\x6d\145"]) ? $h6[$nV]["\155\x6f\137\163\x61\155\154\x5f\x62\x75\x74\x74\x6f\156\137\x74\150\145\155\x65"] : "\x6c\157\x6e\x67\142\x75\164\x74\157\156";
        $fa = isset($h6[$nV]["\x6d\x6f\137\163\x61\x6d\x6c\x5f\x62\x75\x74\x74\157\x6e\137\x74\145\x78\164"]) ? $h6[$nV]["\155\157\x5f\x73\141\x6d\154\x5f\x62\165\164\164\x6f\156\137\x74\x65\x78\x74"] : (get_site_option("\x73\x61\x6d\154\137\151\144\145\156\x74\151\x74\x79\x5f\x6e\x61\155\145") ? get_site_option("\163\x61\155\x6c\137\151\144\145\x6e\x74\x69\164\171\x5f\156\141\155\x65") : "\x4c\157\147\x69\x6e");
        $dp = isset($h6[$nV]["\x6d\157\x5f\163\x61\x6d\154\x5f\x66\157\156\x74\137\x63\x6f\154\157\162"]) ? $h6[$nV]["\x6d\x6f\x5f\163\141\x6d\154\137\146\157\x6e\x74\x5f\x63\157\154\157\x72"] : "\x66\x66\x66\x66\x66\146";
        $QQ = isset($h6[$nV]["\x6d\x6f\137\163\x61\155\x6c\x5f\x66\157\156\x74\x5f\x73\x69\x7a\x65"]) ? $h6[$nV]["\155\157\137\163\x61\x6d\x6c\x5f\x66\x6f\156\164\137\163\151\x7a\x65"] : "\x32\60";
        $Hs = isset($h6[$nV]["\163\x73\157\x5f\142\165\x74\x74\x6f\x6e\x5f\x6c\157\x67\x69\x6e\137\x66\x6f\x72\x6d\x5f\x70\157\x73\151\x74\151\x6f\x6e"]) ? $h6[$nV]["\x73\163\x6f\x5f\x62\x75\164\164\157\x6e\137\154\157\147\x69\x6e\137\x66\x6f\x72\x6d\x5f\160\x6f\x73\151\164\151\157\x6e"] : "\141\x62\x6f\166\145";
        $Kx = "\74\151\156\x70\x75\164\x20\x74\x79\160\x65\75\x22\142\x75\164\x74\157\156\x22\40\156\141\x6d\145\x3d\42\155\x6f\x5f\x73\141\155\x6c\137\x77\160\137\x73\163\x6f\137\142\165\x74\x74\157\156\x22\x20\166\141\x6c\x75\x65\75\42" . $fa . "\x22\40\163\x74\x79\x6c\x65\75\42";
        $NQ = '';
        if ($U7 == "\x6c\x6f\156\147\x62\x75\x74\164\x6f\x6e") {
            goto B7;
        }
        if ($U7 == "\x63\151\162\143\x6c\x65") {
            goto ld;
        }
        if ($U7 == "\157\x76\x61\x6c") {
            goto OG;
        }
        if ($U7 == "\163\161\165\x61\162\145") {
            goto WN;
        }
        goto Sm;
        ld:
        $NQ = $NQ . "\167\151\144\164\150\72" . $Px . "\160\x78\73";
        $NQ = $NQ . "\x68\x65\x69\147\150\164\x3a" . $Px . "\x70\170\x3b";
        $NQ = $NQ . "\142\x6f\162\144\145\162\55\x72\x61\x64\x69\x75\163\x3a\x39\71\71\x70\x78\73";
        goto Sm;
        OG:
        $NQ = $NQ . "\167\x69\x64\x74\x68\72" . $Px . "\x70\x78\73";
        $NQ = $NQ . "\x68\x65\x69\147\150\x74\x3a" . $Px . "\x70\170\73";
        $NQ = $NQ . "\x62\157\x72\x64\145\162\x2d\x72\x61\144\151\165\x73\x3a\65\160\x78\73";
        goto Sm;
        WN:
        $NQ = $NQ . "\167\x69\x64\164\x68\72" . $Px . "\160\170\x3b";
        $NQ = $NQ . "\150\145\151\147\x68\x74\x3a" . $Px . "\x70\x78\73";
        $NQ = $NQ . "\x62\x6f\x72\x64\x65\162\x2d\162\x61\x64\151\165\x73\x3a\60\160\170\x3b";
        Sm:
        goto gk;
        B7:
        $NQ = $NQ . "\167\151\x64\x74\150\x3a" . $E5 . "\x70\x78\73";
        $NQ = $NQ . "\x68\x65\x69\147\x68\164\72" . $Ng . "\x70\170\73";
        $NQ = $NQ . "\142\157\162\144\145\x72\x2d\x72\x61\144\151\x75\163\x3a" . $sP . "\x70\x78\x3b";
        gk:
        $NQ = $NQ . "\x62\141\x63\x6b\x67\162\x6f\x75\x6e\144\55\143\x6f\x6c\x6f\x72\x3a\43" . $sZ . "\73";
        $NQ = $NQ . "\x62\x6f\x72\144\145\x72\x2d\143\157\x6c\x6f\162\72\164\x72\141\156\x73\x70\141\162\x65\156\164\73";
        $NQ = $NQ . "\143\x6f\154\x6f\x72\x3a\x23" . $dp . "\73";
        $NQ = $NQ . "\146\157\156\164\55\x73\x69\x7a\145\72" . $QQ . "\160\170\73";
        $NQ = $NQ . "\160\x61\144\x64\x69\156\147\72\x30\x70\x78\73";
        $Kx = $Kx . $NQ . "\x22\57\x3e";
        W4:
        echo "\x20\74\141\x20\150\162\145\x66\x3d\42\x23\42\x20\157\x6e\103\x6c\x69\143\x6b\75\42\163\x75\142\155\x69\x74\x53\x61\155\x6c\106\157\162\155\x28\x29\42\x3e";
        echo $Kx;
        echo "\x3c\57\141\76\x3c\x2f\x66\157\162\x6d\76\x20";
        x5:
        if ($this->mo_saml_check_empty_or_null_val(get_site_option("\155\157\137\x73\141\x6d\154\x5f\162\x65\144\151\162\x65\x63\x74\x5f\145\162\x72\157\x72\x5f\143\x6f\x64\145"))) {
            goto uB;
        }
        echo "\x3c\x64\x69\x76\x3e\74\x2f\144\x69\x76\76\x3c\144\151\166\x20\164\151\164\154\145\x3d\42\114\x6f\x67\x69\x6e\40\105\x72\162\157\162\x22\x3e\74\x66\x6f\156\164\x20\143\157\154\x6f\x72\x3d\42\x72\x65\x64\x22\76\127\145\x20\x63\157\x75\154\x64\40\x6e\x6f\164\x20\163\151\x67\x6e\40\x79\x6f\165\40\151\x6e\56\x20\x50\x6c\145\x61\163\x65\x20\143\157\x6e\x74\141\x63\x74\x20\171\157\165\162\x20\x41\144\155\151\156\151\x73\x74\x72\141\x74\x6f\162\56\74\x2f\x66\157\156\164\76\74\57\x64\x69\x76\76";
        delete_site_option("\x6d\157\x5f\163\141\x6d\154\x5f\x72\x65\x64\151\x72\145\143\164\137\x65\x72\162\157\x72\x5f\x63\157\144\x65");
        delete_site_option("\155\x6f\137\163\x61\x6d\x6c\137\x72\x65\144\151\x72\x65\x63\164\137\145\x72\x72\x6f\x72\x5f\162\145\x61\163\157\x6e");
        uB:
        echo "\x3c\141\40\150\162\145\x66\x3d\x22\x68\x74\164\x70\72\x2f\x2f\155\151\x6e\151\x6f\x72\x61\x6e\x67\x65\56\x63\157\155\x2f\167\x6f\x72\144\160\162\x65\x73\x73\55\x6c\x64\141\x70\x2d\x6c\x6f\147\151\156\42\x20\x73\x74\x79\154\145\x3d\42\x64\x69\163\x70\x6c\x61\171\x3a\x6e\157\156\x65\x22\x3e\114\157\147\x69\x6e\x20\x74\x6f\40\127\x6f\162\x64\x50\162\145\x73\x73\x20\165\x73\x69\x6e\147\x20\114\104\101\120\74\57\141\x3e\xd\12\x9\x9\11\x9\74\141\x20\150\162\x65\x66\x3d\42\150\x74\164\160\x3a\x2f\57\x6d\151\156\151\157\x72\x61\x6e\x67\x65\56\143\157\x6d\57\143\154\x6f\x75\x64\x2d\x69\144\x65\x6e\x74\x69\x74\x79\x2d\x62\162\157\x6b\x65\162\x2d\x73\x65\x72\166\x69\x63\145\42\x20\163\164\x79\154\x65\75\42\x64\151\163\160\x6c\141\171\72\x6e\157\x6e\x65\x22\76\x43\154\x6f\165\x64\40\111\144\x65\x6e\164\x69\164\x79\x20\x62\162\x6f\x6b\145\x72\x20\163\145\x72\x76\x69\143\x65\x3c\x2f\141\x3e\15\12\11\x9\x9\x9\x3c\141\40\x68\162\145\146\x3d\42\x68\164\x74\x70\72\57\x2f\x6d\x69\x6e\151\x6f\162\141\156\147\145\x2e\x63\x6f\x6d\x2f\x73\x74\162\x6f\156\x67\x5f\x61\x75\164\x68\42\x20\x73\164\x79\154\x65\x3d\x22\144\151\163\160\154\x61\171\72\x6e\157\156\x65\x3b\42\76\74\x2f\141\x3e\15\12\x9\11\11\11\x3c\x61\x20\150\162\145\x66\x3d\x22\x68\164\x74\x70\x3a\x2f\57\x6d\x69\156\x69\157\x72\141\x6e\147\145\56\143\157\x6d\x2f\163\x69\156\x67\x6c\145\x2d\x73\x69\x67\156\x2d\x6f\156\x2d\163\163\157\42\x20\163\x74\171\x6c\145\x3d\42\144\151\x73\160\154\141\171\72\x6e\x6f\x6e\x65\73\42\x3e\x3c\x2f\141\76\xd\12\x9\11\x9\x9\74\x61\x20\150\x72\x65\x66\x3d\x22\x68\x74\x74\160\72\57\57\x6d\151\156\x69\x6f\x72\x61\156\147\145\x2e\143\157\x6d\57\x66\x72\141\x75\144\42\x20\163\164\x79\x6c\x65\x3d\x22\x64\151\163\x70\154\141\x79\72\156\157\x6e\145\73\42\76\74\x2f\141\76\15\12\xd\12\x9\11\x9\74\x2f\165\x6c\76\15\xa\11\11\x3c\x2f\146\x6f\x72\155\x3e";
        J8:
    }
    public function mo_saml_check_empty_or_null_val($Fh)
    {
        if (!(!isset($Fh) || empty($Fh))) {
            goto F5;
        }
        return true;
        F5:
        return false;
    }
    function mo_saml_logout($v0)
    {
        $user = get_user_by("\151\144", $v0);
        $ii = get_site_option("\x73\141\155\154\137\x6c\157\147\x6f\x75\164\137\x75\162\x6c");
        $IN = get_site_option("\163\141\x6d\x6c\137\x6c\x6f\x67\157\165\x74\137\x62\151\156\144\x69\156\x67\x5f\x74\x79\x70\x65");
        $current_user = $user;
        $Ll = get_user_meta($current_user->ID, "\155\x6f\x5f\x73\141\x6d\154\137\151\144\160\137\x6c\x6f\x67\x69\x6e");
        $Ll = isset($Ll[0]) ? $Ll[0] : '';
        $Fj = wp_get_referer();
        if (!empty($Fj)) {
            goto x3;
        }
        $Fj = !empty(get_site_option("\x6d\157\x5f\x73\141\155\x6c\x5f\x73\x70\137\x62\141\163\145\137\x75\x72\x6c")) ? get_site_option("\x6d\157\137\x73\x61\x6d\x6c\137\x73\x70\x5f\x62\141\x73\145\x5f\x75\162\x6c") : get_network_site_url();
        x3:
        if (empty($ii)) {
            goto qS;
        }
        if (!(!session_id() || session_id() == '' || !isset($_SESSION))) {
            goto hp;
        }
        session_start();
        hp:
        if (isset($_SESSION["\x6d\x6f\137\163\141\x6d\154\137\x6c\x6f\147\157\x75\x74\x5f\162\145\x71\x75\145\x73\164"])) {
            goto b3;
        }
        if ($Ll == "\164\162\x75\145") {
            goto TG;
        }
        goto uq;
        b3:
        self::createLogoutResponseAndRedirect($ii, $IN);
        exit;
        goto uq;
        TG:
        delete_user_meta($current_user->ID, "\155\157\x5f\163\x61\x6d\x6c\137\151\144\160\x5f\154\157\x67\x69\156");
        $SY = get_user_meta($current_user->ID, "\x6d\157\137\163\141\x6d\154\x5f\156\141\155\x65\137\x69\x64");
        $EV = get_user_meta($current_user->ID, "\x6d\x6f\137\163\x61\155\x6c\137\163\x65\x73\x73\151\x6f\x6e\x5f\x69\156\x64\x65\x78");
        mo_saml_create_logout_request($SY, $EV, $ii, $IN, $Fj);
        uq:
        qS:
        wp_redirect($Fj);
        exit;
    }
    function createLogoutResponseAndRedirect($ii, $IN)
    {
        $C3 = get_site_option("\x6d\x6f\137\163\x61\155\x6c\x5f\163\x70\137\142\x61\x73\x65\x5f\165\162\x6c");
        if (!empty($C3)) {
            goto vU;
        }
        $C3 = get_network_site_url();
        vU:
        $nX = $_SESSION["\x6d\157\137\x73\x61\x6d\x6c\x5f\x6c\x6f\x67\157\165\164\137\x72\x65\161\165\145\163\x74"];
        $Gh = $_SESSION["\155\157\x5f\163\x61\155\x6c\x5f\x6c\x6f\147\157\165\164\137\x72\x65\x6c\x61\171\x5f\163\164\x61\x74\145"];
        unset($_SESSION["\155\x6f\137\x73\141\x6d\154\137\x6c\157\147\157\x75\164\137\x72\x65\x71\165\145\x73\x74"]);
        unset($_SESSION["\155\x6f\x5f\x73\x61\x6d\154\137\x6c\x6f\147\x6f\165\x74\137\162\x65\154\141\171\137\163\164\x61\x74\145"]);
        $QJ = new DOMDocument();
        $QJ->loadXML($nX);
        $nX = $QJ->firstChild;
        if (!($nX->localName == "\x4c\x6f\x67\157\x75\x74\x52\x65\161\x75\x65\x73\164")) {
            goto L2;
        }
        $TY = new SAML2_LogoutRequest($nX);
        $BG = get_site_option("\155\x6f\137\163\141\155\x6c\x5f\163\160\x5f\x65\156\x74\151\x74\171\137\151\x64");
        if (!empty($BG)) {
            goto E2;
        }
        $BG = $C3 . "\x2f\167\x70\x2d\143\x6f\x6e\164\x65\x6e\x74\x2f\160\x6c\165\147\151\156\x73\x2f\155\x69\156\x69\157\x72\x61\x6e\147\145\55\163\141\155\x6c\55\62\60\x2d\x73\x69\156\x67\x6c\145\x2d\x73\x69\x67\156\55\x6f\156\57";
        E2:
        $dz = $ii;
        $fu = Utilities::createLogoutResponse($TY->getId(), $BG, $dz, $IN);
        if (empty($IN) || $IN == "\110\164\x74\160\x52\x65\x64\x69\x72\x65\143\x74") {
            goto C2;
        }
        if (!(get_site_option("\163\141\155\x6c\137\162\x65\x71\x75\x65\163\164\x5f\163\x69\x67\x6e\145\144") == "\165\156\143\x68\x65\x63\x6b\x65\x64")) {
            goto zT;
        }
        $nF = base64_encode($fu);
        Utilities::postSAMLResponse($ii, $nF, $Gh);
        exit;
        zT:
        $ni = '';
        $w0 = '';
        $nF = Utilities::signXML($fu, "\123\x74\x61\x74\165\x73");
        Utilities::postSAMLResponse($ii, $nF, $Gh);
        goto zL;
        C2:
        $bQ = $ii;
        if (strpos($ii, "\77") !== false) {
            goto of;
        }
        $bQ .= "\x3f";
        goto lO;
        of:
        $bQ .= "\x26";
        lO:
        if (!(get_site_option("\163\x61\x6d\154\137\x72\x65\161\165\x65\x73\164\x5f\x73\x69\147\156\145\144") == "\165\x6e\143\150\145\x63\x6b\145\144")) {
            goto dd;
        }
        $bQ .= "\123\101\115\x4c\122\145\163\x70\x6f\x6e\x73\145\75" . $fu . "\46\122\x65\154\141\x79\x53\164\141\x74\x65\x3d" . urlencode($Gh);
        header("\114\157\x63\x61\164\x69\157\156\x3a\x20" . $bQ);
        exit;
        dd:
        $bQ .= "\123\x41\x4d\114\x52\145\x73\160\x6f\x6e\x73\145\75" . $fu . "\46\x52\x65\x6c\141\x79\x53\164\x61\164\x65\75" . urlencode($Gh);
        header("\114\x6f\143\141\x74\151\157\156\72\40" . $bQ);
        exit;
        zL:
        L2:
    }
}
function mo_saml_create_logout_request($SY, $EV, $ii, $IN, $Fj)
{
    $C3 = get_site_option("\155\x6f\x5f\163\141\155\x6c\137\163\160\137\142\x61\x73\x65\x5f\165\162\154");
    if (!empty($C3)) {
        goto sH;
    }
    $C3 = get_network_site_url();
    sH:
    $BG = get_site_option("\x6d\157\137\163\x61\155\154\x5f\163\x70\137\x65\156\x74\151\164\x79\137\x69\x64");
    if (!empty($BG)) {
        goto Nh;
    }
    $BG = $C3 . "\57\167\160\55\143\157\x6e\164\145\156\x74\57\x70\x6c\165\x67\x69\x6e\x73\57\155\151\x6e\x69\x6f\x72\x61\156\147\145\55\163\141\155\154\x2d\62\60\x2d\163\151\156\x67\154\145\x2d\x73\x69\x67\x6e\55\x6f\x6e\57";
    Nh:
    $dz = $ii;
    $fw = $Fj;
    if (!empty($fw)) {
        goto L8;
    }
    $fw = saml_get_current_page_url();
    if (!strpos($fw, "\77")) {
        goto Dj;
    }
    $fw = get_network_site_url();
    Dj:
    L8:
    $fw = mo_saml_relaystate_url($fw);
    $pz = Utilities::createLogoutRequest($SY, $BG, $dz, $EV, $IN);
    if (empty($IN) || $IN == "\x48\164\164\160\122\145\x64\x69\x72\x65\x63\164") {
        goto gA;
    }
    if (!(get_site_option("\163\x61\155\154\137\x72\x65\161\x75\x65\x73\x74\137\x73\x69\147\156\x65\144") == "\165\156\143\x68\x65\143\153\x65\144")) {
        goto bN;
    }
    $nF = base64_encode($pz);
    Utilities::postSAMLRequest($ii, $nF, $fw);
    exit;
    bN:
    $ni = '';
    $w0 = '';
    $nF = Utilities::signXML($pz, "\116\x61\155\145\111\104\x50\157\x6c\x69\143\x79");
    Utilities::postSAMLRequest($ii, $nF, $fw);
    goto YM;
    gA:
    $bQ = $ii;
    if (strpos($ii, "\x3f") !== false) {
        goto cu;
    }
    $bQ .= "\77";
    goto zu;
    cu:
    $bQ .= "\x26";
    zu:
    if (!(get_site_option("\163\x61\155\x6c\x5f\162\x65\161\165\145\x73\x74\137\x73\x69\x67\x6e\x65\144") == "\x75\156\x63\x68\x65\143\x6b\145\144")) {
        goto Bt;
    }
    $bQ .= "\123\101\115\114\x52\x65\161\165\x65\x73\164\75" . $pz . "\x26\x52\x65\154\x61\171\123\164\141\x74\x65\75" . urlencode($fw);
    header("\x4c\x6f\x63\x61\164\151\157\x6e\72\40" . $bQ);
    exit;
    Bt:
    $pz = "\x53\101\115\x4c\122\145\161\x75\145\x73\164\x3d" . $pz . "\x26\x52\145\154\141\171\123\x74\141\164\145\75" . urlencode($fw) . "\46\123\151\147\x41\154\147\x3d" . urlencode(XMLSecurityKey::RSA_SHA256);
    $yP = array("\x74\x79\160\145" => "\160\x72\x69\x76\x61\x74\x65");
    $xk = new XMLSecurityKey(XMLSecurityKey::RSA_SHA256, $yP);
    $rW = get_site_option("\155\157\137\163\x61\x6d\x6c\x5f\143\x75\x72\162\145\156\164\137\x63\x65\162\x74\x5f\160\162\151\x76\x61\164\x65\x5f\x6b\145\171");
    $xk->loadKey($rW, FALSE);
    $FR = new XMLSecurityDSig();
    $GX = $xk->signData($pz);
    $GX = base64_encode($GX);
    $bQ .= $pz . "\46\123\x69\x67\156\141\164\165\x72\x65\x3d" . urlencode($GX);
    header("\x4c\157\143\141\164\x69\x6f\156\x3a" . $bQ);
    exit;
    YM:
}
function mo_login_validate()
{
    if (!(isset($_REQUEST["\157\160\164\x69\x6f\x6e"]) && $_REQUEST["\157\160\x74\151\x6f\156"] == "\155\157\x73\141\x6d\x6c\137\x6d\145\164\x61\x64\141\x74\141")) {
        goto Uj;
    }
    miniorange_generate_metadata();
    Uj:
    if (!mo_saml_is_customer_license_verified()) {
        goto jm;
    }
    if (!(isset($_REQUEST["\x6f\160\164\x69\157\156"]) && $_REQUEST["\157\x70\164\151\157\x6e"] == "\x73\141\155\154\x5f\165\163\145\x72\137\x6c\x6f\x67\151\156" || isset($_REQUEST["\x6f\x70\x74\151\x6f\156"]) && $_REQUEST["\x6f\160\x74\151\157\x6e"] == "\x74\x65\163\164\x43\157\156\146\151\x67" || isset($_REQUEST["\x6f\160\164\x69\157\x6e"]) && $_REQUEST["\x6f\160\x74\x69\x6f\x6e"] == "\x67\145\x74\x73\x61\x6d\154\x72\x65\x71\165\145\163\x74" || isset($_REQUEST["\x6f\x70\164\151\157\x6e"]) && $_REQUEST["\157\x70\x74\151\x6f\156"] == "\x67\x65\164\163\x61\x6d\154\162\145\163\x70\157\x6e\x73\x65")) {
        goto E8;
    }
    if (mo_saml_is_sp_configured()) {
        goto TT;
    }
    if (!is_user_logged_in()) {
        goto Z0;
    }
    if (!isset($_REQUEST["\162\x65\144\x69\162\145\143\164\x5f\164\157"])) {
        goto kI;
    }
    $HE = htmlspecialchars($_REQUEST["\x72\145\x64\x69\x72\x65\143\x74\137\x74\157"]);
    wp_safe_redirect($HE);
    exit;
    kI:
    Z0:
    goto m0;
    TT:
    if (!(is_user_logged_in() and $_REQUEST["\x6f\x70\x74\x69\x6f\x6e"] == "\x73\x61\x6d\x6c\137\165\x73\x65\x72\137\154\157\x67\151\x6e")) {
        goto jh;
    }
    if (!isset($_REQUEST["\162\145\x64\x69\x72\145\143\164\137\164\x6f"])) {
        goto p6;
    }
    $HE = htmlspecialchars($_REQUEST["\x72\145\144\x69\162\x65\143\x74\x5f\164\157"]);
    wp_safe_redirect($HE);
    exit;
    p6:
    return;
    jh:
    $C3 = get_site_option("\x6d\x6f\137\163\x61\x6d\154\x5f\163\x70\137\142\x61\163\x65\137\x75\162\x6c");
    if (!empty($C3)) {
        goto O3;
    }
    $C3 = get_network_site_url();
    O3:
    $h6 = get_site_option("\163\x61\x6d\154\137\x73\x73\x6f\137\x73\x65\x74\164\x69\156\x67\163");
    $nV = get_current_blog_id();
    $GY = Utilities::get_active_sites();
    if (in_array($nV, $GY)) {
        goto II;
    }
    return;
    II:
    if (!(empty($h6[$nV]) && !empty($h6["\104\x45\106\x41\125\x4c\124"]))) {
        goto mn;
    }
    $h6[$nV] = $h6["\104\x45\x46\x41\125\114\x54"];
    mn:
    if ($_REQUEST["\157\x70\x74\x69\x6f\156"] == "\164\145\x73\x74\103\x6f\156\146\151\x67" and array_key_exists("\156\145\167\x63\x65\162\164", $_REQUEST)) {
        goto lZ;
    }
    if ($_REQUEST["\x6f\160\x74\151\157\x6e"] == "\164\x65\163\164\x43\x6f\x6e\x66\151\x67") {
        goto ht;
    }
    if ($_REQUEST["\157\160\x74\x69\x6f\x6e"] == "\147\x65\164\163\141\155\154\162\145\161\165\x65\163\164") {
        goto D8;
    }
    if ($_REQUEST["\157\x70\164\x69\x6f\156"] == "\147\x65\x74\x73\x61\x6d\154\162\x65\163\160\157\x6e\163\x65") {
        goto yj;
    }
    if (!empty($h6[$nV]["\155\x6f\x5f\x73\141\155\154\137\162\145\154\141\171\x5f\x73\164\x61\x74\x65"])) {
        goto nO;
    }
    if (isset($_REQUEST["\162\x65\x64\151\162\x65\x63\164\137\164\157"])) {
        goto IU;
    }
    $fw = saml_get_current_page_url();
    goto JP;
    IU:
    $fw = $_REQUEST["\x72\x65\x64\x69\162\x65\143\164\137\x74\157"];
    JP:
    goto QX;
    nO:
    $fw = $h6[$nV]["\155\157\x5f\x73\141\x6d\x6c\137\x72\145\x6c\x61\x79\137\x73\164\141\x74\145"];
    QX:
    goto eC;
    yj:
    $fw = "\144\151\163\x70\x6c\x61\171\x53\101\115\114\122\145\x73\x70\157\156\x73\x65";
    eC:
    goto pw;
    D8:
    $fw = "\144\151\163\x70\154\141\x79\x53\x41\x4d\x4c\122\x65\161\165\x65\163\164";
    pw:
    goto tu;
    ht:
    $fw = "\164\x65\163\164\x56\x61\x6c\x69\144\x61\x74\145";
    tu:
    goto il;
    lZ:
    $fw = "\x74\145\163\164\116\x65\x77\103\145\x72\x74\x69\146\x69\143\141\164\145";
    il:
    $p0 = get_site_option("\x73\x61\155\x6c\137\x6c\157\x67\151\156\x5f\x75\x72\x6c");
    $Gd = !empty(get_site_option("\163\x61\155\154\x5f\154\157\147\151\156\x5f\142\151\x6e\x64\x69\156\147\x5f\x74\171\x70\x65")) ? get_site_option("\163\141\155\154\137\x6c\x6f\147\x69\x6e\x5f\142\x69\156\x64\151\x6e\x67\x5f\164\x79\160\145") : "\110\x74\x74\x70\120\157\163\x74";
    $h6 = get_site_option("\x73\x61\x6d\154\137\x73\163\157\x5f\163\x65\164\x74\x69\x6e\147\163");
    $nV = get_current_blog_id();
    $GY = Utilities::get_active_sites();
    if (in_array($nV, $GY)) {
        goto NG;
    }
    return;
    NG:
    if (!(empty($h6[$nV]) && !empty($h6["\x44\105\x46\x41\125\114\x54"]))) {
        goto cF;
    }
    $h6[$nV] = $h6["\104\x45\x46\101\x55\114\x54"];
    cF:
    $tP = isset($h6[$nV]["\155\157\137\163\141\155\x6c\x5f\146\157\162\143\x65\x5f\x61\x75\164\x68\x65\156\x74\151\143\x61\x74\x69\x6f\x6e"]) ? $h6[$nV]["\x6d\x6f\137\x73\141\155\154\137\146\157\162\143\145\x5f\x61\165\164\x68\x65\x6e\164\151\x63\141\x74\x69\157\156"] : '';
    $vW = $C3 . "\x2f";
    $BG = get_site_option("\155\x6f\x5f\163\141\155\154\137\x73\x70\137\x65\156\x74\x69\x74\171\137\x69\144");
    $KA = get_site_option("\x73\141\155\154\x5f\156\141\x6d\145\151\x64\x5f\146\157\162\x6d\141\164");
    if (!empty($KA)) {
        goto lS;
    }
    $KA = "\x31\56\x31\x3a\x6e\141\155\145\151\x64\55\x66\157\162\x6d\141\x74\72\x75\156\x73\x70\x65\x63\151\146\x69\145\x64";
    lS:
    if (!empty($BG)) {
        goto Fi;
    }
    $BG = $C3 . "\x2f\x77\x70\55\x63\157\x6e\x74\x65\156\164\x2f\160\154\165\147\x69\x6e\163\x2f\155\151\x6e\151\157\x72\x61\x6e\x67\145\x2d\x73\x61\x6d\x6c\x2d\62\60\55\x73\x69\x6e\x67\x6c\x65\55\163\151\147\x6e\55\x6f\156\x2f";
    Fi:
    $pz = Utilities::createAuthnRequest($vW, $BG, $p0, $tP, $Gd, $KA);
    if (!($fw == "\x64\x69\x73\x70\x6c\x61\171\123\x41\115\x4c\x52\145\161\x75\145\x73\x74")) {
        goto eX;
    }
    mo_saml_show_SAML_log(Utilities::createAuthnRequest($vW, $BG, $p0, $tP, "\110\164\164\x70\120\x6f\x73\x74", $KA), $fw);
    eX:
    $bQ = htmlspecialchars_decode($p0);
    if (strpos($p0, "\x3f") !== false) {
        goto lQ;
    }
    $bQ .= "\77";
    goto uk;
    lQ:
    $bQ .= "\x26";
    uk:
    $fw = mo_saml_relaystate_url($fw);
    if ($Gd == "\110\x74\164\160\122\145\144\151\162\145\x63\164") {
        goto XQ;
    }
    if (!(get_site_option("\163\141\x6d\154\137\162\145\161\x75\145\163\x74\137\x73\x69\x67\156\145\144") == "\165\x6e\143\150\x65\143\x6b\145\144")) {
        goto OF;
    }
    $nF = base64_encode($pz);
    Utilities::postSAMLRequest($p0, $nF, $fw);
    exit;
    OF:
    $ni = '';
    $w0 = '';
    if ($_REQUEST["\x6f\x70\x74\151\x6f\x6e"] == "\x74\x65\163\x74\103\157\x6e\x66\x69\x67" && array_key_exists("\156\145\167\143\x65\x72\x74", $_REQUEST)) {
        goto hM;
    }
    $nF = Utilities::signXML($pz, "\x4e\x61\x6d\145\x49\104\120\157\x6c\151\143\x79");
    goto DH;
    hM:
    $nF = Utilities::signXML($pz, "\x4e\x61\155\145\111\x44\120\x6f\x6c\x69\x63\171", true);
    DH:
    Utilities::postSAMLRequest($p0, $nF, $fw);
    update_site_option("\x6d\x6f\137\163\141\x6d\x6c\137\x6e\x65\167\x5f\x63\x65\162\164\x5f\x74\x65\163\x74", true);
    goto JO;
    XQ:
    if (!(get_site_option("\163\x61\155\154\137\x72\145\161\x75\145\x73\164\137\x73\x69\x67\156\145\144") == "\165\156\143\150\145\143\153\145\x64")) {
        goto Ek;
    }
    $bQ .= "\x53\x41\115\114\x52\x65\161\165\x65\x73\x74\75" . $pz . "\46\x52\x65\x6c\x61\171\123\164\141\164\x65\75" . urlencode($fw);
    header("\114\x6f\143\x61\x74\151\157\156\72\40" . $bQ);
    exit;
    Ek:
    $pz = "\123\x41\x4d\x4c\122\145\161\x75\145\163\164\x3d" . $pz . "\x26\x52\x65\x6c\x61\x79\x53\x74\x61\164\145\75" . urlencode($fw) . "\46\x53\x69\147\x41\x6c\147\x3d" . urlencode(XMLSecurityKey::RSA_SHA256);
    $yP = array("\x74\x79\160\x65" => "\x70\x72\151\166\141\x74\145");
    $xk = new XMLSecurityKey(XMLSecurityKey::RSA_SHA256, $yP);
    if ($_REQUEST["\x6f\x70\x74\151\x6f\156"] == "\164\145\x73\164\103\157\156\x66\x69\x67" && array_key_exists("\x6e\x65\x77\x63\145\162\164", $_REQUEST)) {
        goto VD;
    }
    $rW = get_site_option("\x6d\x6f\x5f\x73\141\x6d\x6c\137\143\165\x72\162\145\156\x74\137\143\145\162\164\x5f\x70\162\151\166\x61\x74\145\137\x6b\x65\171");
    goto Dy;
    VD:
    $rW = file_get_contents(plugin_dir_path(__FILE__) . "\162\145\x73\x6f\x75\162\x63\x65\x73" . DIRECTORY_SEPARATOR . mo_options_enum_default_sp_certificate::SP_Private_Key);
    Dy:
    $xk->loadKey($rW, FALSE);
    $FR = new XMLSecurityDSig();
    $GX = $xk->signData($pz);
    $GX = base64_encode($GX);
    $bQ .= $pz . "\46\123\x69\x67\156\x61\164\165\x72\145\75" . urlencode($GX);
    header("\114\x6f\143\141\164\x69\x6f\x6e\72\x20" . $bQ);
    exit;
    JO:
    m0:
    E8:
    if (!(array_key_exists("\x53\x41\115\114\x52\145\163\160\157\156\163\x65", $_REQUEST) && !empty($_REQUEST["\123\101\x4d\114\x52\x65\163\160\x6f\156\x73\x65"]))) {
        goto k_;
    }
    if (array_key_exists("\x52\145\x6c\x61\x79\123\x74\141\x74\145", $_POST) && !empty($_POST["\x52\x65\154\x61\171\123\164\141\164\145"]) && $_POST["\x52\145\154\141\171\123\x74\141\164\x65"] != "\57") {
        goto Zo;
    }
    $C5 = '';
    goto k0;
    Zo:
    $C5 = $_POST["\122\145\154\x61\x79\x53\164\x61\164\145"];
    k0:
    $C5 = mo_saml_parse_url($C5);
    $C3 = get_site_option("\155\x6f\137\x73\x61\x6d\154\x5f\163\160\137\142\141\163\x65\137\165\162\154");
    if (!empty($C3)) {
        goto KK;
    }
    $C3 = get_network_site_url();
    KK:
    $BS = $_REQUEST["\123\101\x4d\x4c\122\x65\163\160\x6f\156\x73\x65"];
    $BS = base64_decode($BS);
    if (!($C5 == "\144\151\x73\160\x6c\x61\x79\x53\x41\115\x4c\x52\145\163\x70\x6f\156\x73\145")) {
        goto ui;
    }
    mo_saml_show_SAML_log($BS, $C5);
    ui:
    if (!(array_key_exists("\x53\x41\115\x4c\x52\145\x73\x70\x6f\156\163\x65", $_GET) && !empty($_GET["\123\101\x4d\114\122\x65\163\x70\157\156\163\145"]))) {
        goto yQ;
    }
    $BS = gzinflate($BS);
    yQ:
    $QJ = new DOMDocument();
    $QJ->loadXML($BS);
    $Xv = $QJ->firstChild;
    $Bl = $QJ->documentElement;
    $OE = new DOMXpath($QJ);
    $OE->registerNamespace("\x73\141\x6d\154\x70", "\x75\162\156\x3a\x6f\141\163\151\x73\72\x6e\x61\155\x65\x73\72\164\x63\x3a\123\101\x4d\x4c\x3a\x32\56\x30\x3a\x70\162\157\164\157\x63\157\154");
    $OE->registerNamespace("\x73\x61\x6d\x6c", "\x75\162\156\72\157\x61\x73\x69\x73\72\x6e\x61\x6d\145\163\72\164\x63\x3a\x53\101\x4d\114\x3a\x32\56\x30\72\141\x73\163\x65\x72\164\151\157\156");
    if ($Xv->localName == "\x4c\x6f\147\x6f\x75\164\x52\145\x73\x70\x6f\156\163\145") {
        goto Xl;
    }
    $DE = $OE->query("\x2f\x73\141\x6d\154\x70\72\122\x65\163\x70\x6f\x6e\163\145\x2f\x73\x61\155\x6c\160\x3a\123\x74\141\x74\165\x73\x2f\x73\x61\155\154\x70\72\x53\x74\x61\164\165\x73\103\157\x64\x65", $Bl);
    $ot = isset($DE) ? $DE->item(0)->getAttribute("\x56\141\x6c\x75\145") : '';
    $cb = explode("\x3a", $ot);
    if (!array_key_exists(7, $cb)) {
        goto yo;
    }
    $DE = $cb[7];
    yo:
    $EJ = $OE->query("\57\x73\141\x6d\x6c\160\x3a\x52\145\163\x70\x6f\156\x73\x65\x2f\163\141\155\x6c\x70\72\123\164\141\x74\165\x73\57\163\141\155\x6c\x70\x3a\123\x74\x61\x74\x75\x73\x4d\145\163\x73\141\147\x65", $Bl);
    $pd = isset($EJ) ? $EJ->item(0) : '';
    if (empty($pd)) {
        goto an;
    }
    $pd = $pd->nodeValue;
    an:
    if (array_key_exists("\122\145\x6c\x61\x79\x53\x74\141\164\145", $_POST) && !empty($_POST["\x52\x65\x6c\x61\171\123\x74\x61\164\145"]) && $_POST["\122\x65\154\x61\x79\x53\x74\x61\x74\145"] != "\x2f") {
        goto JQ;
    }
    $C5 = '';
    goto st;
    JQ:
    $C5 = $_POST["\122\x65\154\141\171\123\164\141\164\145"];
    $C5 = mo_saml_parse_url($C5);
    st:
    if (!($DE != "\x53\x75\143\x63\x65\x73\x73")) {
        goto NZ;
    }
    show_status_error($DE, $C5, $pd);
    NZ:
    if (!($C5 !== "\x74\145\163\164\126\x61\154\x69\144\x61\x74\x65" && $C5 !== "\x74\145\163\x74\116\x65\167\x43\x65\162\164\151\x66\x69\143\141\164\145")) {
        goto rV;
    }
    $Fn = parse_url($C5, PHP_URL_HOST);
    $pH = parse_url($C3, PHP_URL_HOST);
    $Qc = parse_url(get_current_base_url(), PHP_URL_HOST);
    if (!empty($C5)) {
        goto U0;
    }
    $C5 = "\x2f";
    goto b1;
    U0:
    $C5 = mo_saml_parse_url($C5);
    b1:
    if (!(!empty($Fn) && $Fn != $Qc)) {
        goto it;
    }
    Utilities::postSAMLResponse($C5, $_REQUEST["\123\x41\x4d\x4c\x52\145\163\160\157\x6e\163\145"], mo_saml_relaystate_url($C5));
    it:
    rV:
    $JK = maybe_unserialize(get_site_option("\x73\141\155\x6c\137\170\x35\x30\x39\x5f\x63\145\162\x74\x69\146\151\143\x61\164\x65"));
    update_site_option("\x6d\x6f\137\x73\141\x6d\x6c\x5f\x72\x65\x73\160\x6f\x6e\163\145", base64_encode($BS));
    foreach ($JK as $xk => $Fh) {
        if (@openssl_x509_read($Fh)) {
            goto rY;
        }
        unset($JK[$xk]);
        rY:
        jU:
    }
    jD:
    $vW = $C3 . "\57";
    if ($C5 == "\x74\x65\163\x74\116\x65\x77\x43\x65\x72\x74\x69\x66\x69\143\141\x74\x65") {
        goto Ru;
    }
    $BS = new SAML2_Response($Xv, get_site_option("\x6d\x6f\x5f\163\141\x6d\154\137\143\165\162\162\x65\156\x74\137\x63\145\x72\x74\x5f\160\162\151\x76\x61\164\145\137\x6b\145\x79"));
    goto aO;
    Ru:
    $FW = file_get_contents(plugin_dir_path(__FILE__) . "\x72\145\163\157\165\162\x63\145\x73" . DIRECTORY_SEPARATOR . mo_options_enum_default_sp_certificate::SP_Private_Key);
    $BS = new SAML2_Response($Xv, $FW);
    aO:
    $o6 = $BS->getSignatureData();
    $i9 = current($BS->getAssertions())->getSignatureData();
    if (!(empty($i9) && empty($o6))) {
        goto NW;
    }
    if ($C5 == "\x74\145\x73\x74\126\141\x6c\x69\144\x61\164\145" or $C5 == "\x74\145\x73\164\x4e\145\167\x43\145\x72\x74\151\146\x69\x63\141\x74\x65") {
        goto YU;
    }
    wp_die("\x57\145\40\143\157\165\x6c\144\x20\156\157\164\40\163\x69\147\x6e\40\171\157\165\x20\151\156\56\x20\x50\x6c\145\141\x73\x65\40\143\x6f\x6e\164\141\x63\x74\x20\141\144\x6d\151\x6e\x69\163\164\x72\x61\164\x6f\x72", "\105\162\162\x6f\162\72\x20\x49\x6e\166\x61\x6c\x69\144\x20\123\101\115\114\x20\122\145\163\x70\157\x6e\163\x65");
    goto KV;
    YU:
    $SF = mo_options_error_constants::Error_no_certificate;
    $Dl = mo_options_error_constants::Cause_no_certificate;
    echo "\x3c\144\151\x76\40\163\x74\x79\x6c\x65\75\x22\146\x6f\x6e\x74\55\146\141\155\x69\x6c\x79\72\x43\x61\x6c\151\x62\162\151\73\160\141\144\144\151\156\147\x3a\60\40\x33\45\x3b\42\x3e\15\xa\x9\11\x9\x9\11\x9\x3c\144\151\x76\40\163\x74\x79\x6c\145\75\x22\143\157\x6c\x6f\x72\x3a\40\43\141\x39\x34\x34\x34\x32\x3b\x62\141\143\153\x67\162\157\x75\156\x64\x2d\143\157\154\x6f\x72\x3a\40\x23\x66\62\x64\145\144\145\73\160\141\144\144\x69\156\147\x3a\x20\61\x35\x70\x78\x3b\155\x61\162\x67\151\156\55\142\157\x74\x74\x6f\x6d\x3a\40\x32\x30\160\x78\x3b\164\145\x78\x74\x2d\141\x6c\x69\x67\156\72\x63\x65\x6e\164\145\162\x3b\142\x6f\x72\144\145\x72\72\x31\160\170\x20\163\x6f\154\x69\x64\x20\43\105\66\102\x33\102\x32\x3b\x66\x6f\156\x74\55\163\151\x7a\x65\72\61\x38\160\164\73\x22\76\40\x45\122\x52\x4f\122\74\x2f\x64\151\x76\76\15\12\11\x9\x9\x9\11\x9\74\144\151\166\40\163\164\x79\x6c\x65\75\42\143\x6f\154\x6f\162\x3a\40\x23\141\71\x34\x34\64\x32\x3b\x66\157\156\x74\x2d\x73\x69\172\x65\72\x31\x34\160\x74\73\x20\155\x61\162\x67\x69\156\55\x62\x6f\x74\x74\x6f\155\x3a\62\60\160\170\x3b\x22\x3e\x3c\x70\x3e\74\163\x74\x72\x6f\156\x67\76\105\x72\162\x6f\162\40\x20\72" . esc_html($SF) . "\x20\74\57\x73\x74\162\x6f\156\x67\x3e\x3c\57\x70\x3e\xd\xa\x9\11\11\11\11\11\15\xa\11\11\x9\11\x9\11\74\160\76\74\163\x74\162\x6f\156\147\x3e\120\x6f\x73\x73\151\x62\x6c\x65\40\103\x61\165\163\x65\x3a\x20" . esc_html($Dl) . "\74\x2f\163\164\162\157\156\x67\76\74\x2f\160\x3e\15\12\11\11\11\x9\11\11\xd\xa\11\x9\x9\11\11\x9\x3c\57\144\x69\166\76\74\x2f\x64\x69\166\x3e";
    mo_saml_download_logs($SF, $Dl);
    exit;
    KV:
    NW:
    $N4 = '';
    if (is_array($JK)) {
        goto ow;
    }
    $Tj = XMLSecurityKey::getRawThumbprint($JK);
    $Tj = mo_saml_convert_to_windows_iconv($Tj);
    $Tj = preg_replace("\x2f\134\x73\x2b\57", '', $Tj);
    if (empty($o6)) {
        goto ln;
    }
    $N4 = Utilities::processResponse($vW, $Tj, $o6, $BS, 0, $C5);
    ln:
    if (empty($i9)) {
        goto pK;
    }
    $N4 = Utilities::processResponse($vW, $Tj, $i9, $BS, 0, $C5);
    pK:
    goto Yv;
    ow:
    foreach ($JK as $xk => $Fh) {
        $Tj = XMLSecurityKey::getRawThumbprint($Fh);
        $Tj = mo_saml_convert_to_windows_iconv($Tj);
        $Tj = preg_replace("\x2f\x5c\x73\53\57", '', $Tj);
        if (empty($o6)) {
            goto Ep;
        }
        $N4 = Utilities::processResponse($vW, $Tj, $o6, $BS, $xk, $C5);
        Ep:
        if (empty($i9)) {
            goto Cs;
        }
        $N4 = Utilities::processResponse($vW, $Tj, $i9, $BS, $xk, $C5);
        Cs:
        if (!$N4) {
            goto u7;
        }
        goto c2;
        u7:
        EX:
    }
    c2:
    Yv:
    if (empty($o6)) {
        goto cf;
    }
    $w2 = $o6["\103\145\162\x74\x69\x66\x69\x63\141\164\x65\163"][0];
    goto iT;
    cf:
    $w2 = $i9["\103\145\162\164\x69\146\x69\x63\x61\x74\x65\x73"][0];
    iT:
    if ($N4) {
        goto f_;
    }
    if ($C5 == "\164\145\x73\x74\126\x61\x6c\x69\144\x61\x74\145" or $C5 == "\164\x65\x73\x74\x4e\x65\167\103\x65\x72\x74\151\x66\x69\x63\141\164\x65") {
        goto h9;
    }
    wp_die("\127\x65\40\x63\157\165\154\144\40\156\x6f\164\x20\163\x69\147\156\x20\171\157\165\x20\x69\x6e\x2e\40\x50\154\x65\x61\163\x65\x20\143\x6f\156\x74\141\x63\164\40\x79\157\165\162\40\101\144\155\x69\x6e\x69\x73\164\162\x61\164\157\162", "\x45\162\x72\x6f\162\40\72\103\145\162\x74\151\x66\151\143\x61\x74\145\40\x6e\157\x74\40\146\x6f\x75\156\x64");
    goto uS;
    h9:
    $SF = mo_options_error_constants::Error_wrong_certificate;
    $Dl = mo_options_error_constants::Cause_wrong_certificate;
    $ys = "\55\x2d\55\55\55\x42\105\107\111\x4e\40\103\105\122\124\111\106\x49\x43\x41\x54\105\x2d\x2d\55\55\x2d\x3c\x62\x72\76" . chunk_split($w2, 64) . "\x3c\142\162\76\x2d\55\x2d\x2d\x2d\105\116\104\40\x43\105\x52\x54\x49\x46\x49\103\101\124\x45\x2d\x2d\55\x2d\55";
    echo "\74\x64\x69\166\x20\x73\x74\x79\x6c\x65\75\42\146\157\156\164\x2d\x66\x61\155\151\154\x79\72\103\x61\x6c\x69\x62\x72\x69\x3b\160\141\144\x64\x69\156\x67\72\x30\40\x33\x25\x3b\x22\76";
    echo "\74\x64\x69\166\x20\163\164\x79\x6c\145\x3d\42\143\x6f\x6c\157\162\72\x20\x23\141\x39\x34\x34\x34\62\73\x62\141\x63\153\x67\162\x6f\x75\x6e\x64\x2d\143\157\x6c\x6f\x72\72\x20\x23\146\62\144\x65\144\x65\73\x70\141\144\x64\151\156\x67\x3a\40\61\x35\x70\x78\x3b\x6d\x61\162\x67\x69\x6e\55\142\x6f\x74\164\157\155\72\x20\x32\60\x70\x78\73\164\x65\170\x74\55\141\154\151\x67\156\72\x63\x65\156\x74\145\162\x3b\142\x6f\x72\144\145\162\72\61\x70\170\x20\163\x6f\154\x69\144\40\x23\105\x36\x42\x33\102\x32\x3b\x66\157\x6e\164\55\163\151\172\x65\x3a\x31\70\x70\164\x3b\42\x3e\x20\x45\122\122\x4f\122\74\x2f\144\x69\166\x3e\15\xa\x20\40\40\x20\x20\40\40\x20\x20\x20\x20\40\x20\40\x20\40\x20\40\x20\x20\x20\x20\40\x20\x3c\144\x69\x76\x20\x73\x74\171\154\145\75\42\x63\x6f\154\157\162\x3a\40\x23\141\71\x34\x34\x34\62\73\x66\x6f\156\x74\55\x73\151\x7a\145\72\x31\x34\x70\164\x3b\40\x6d\141\x72\x67\151\x6e\x2d\x62\x6f\164\x74\x6f\155\x3a\62\60\x70\x78\x3b\42\x3e\74\x70\76\74\163\x74\x72\x6f\156\147\76\x45\162\162\x6f\x72\72\x20\x3c\57\163\x74\x72\157\x6e\x67\x3e\x55\x6e\141\142\154\x65\x20\164\157\40\x66\151\156\144\40\141\40\143\145\x72\164\151\146\151\143\x61\164\145\x20\155\141\164\x63\x68\x69\156\147\x20\164\150\x65\x20\x63\157\156\146\151\x67\165\162\145\x64\40\146\151\156\147\145\x72\x70\x72\x69\x6e\164\56\74\57\160\76\15\12\x20\x20\x20\40\x20\40\40\x20\40\40\40\x20\x20\40\40\40\x20\x20\40\40\x20\x20\x20\x20\40\40\40\40\x3c\x70\76\x50\154\x65\141\x73\145\x20\143\157\x6e\x74\x61\143\x74\40\171\x6f\165\x72\40\x61\x64\x6d\x69\x6e\151\x73\x74\162\141\x74\x6f\162\x20\141\x6e\144\x20\x72\145\x70\157\162\x74\40\164\x68\145\40\x66\x6f\154\x6c\x6f\167\151\156\x67\x20\145\x72\x72\x6f\x72\72\74\x2f\160\x3e\xd\xa\40\40\x20\x20\40\40\40\40\40\x20\x20\x20\x20\40\x20\40\40\x20\40\x20\x20\x20\40\x20\x20\x20\40\40\74\x70\x3e\74\163\x74\x72\157\x6e\x67\76\120\x6f\163\163\x69\142\x6c\145\x20\103\x61\165\163\145\72\x20\x3c\x2f\x73\x74\x72\157\156\x67\x3e\x27\x58\56\65\60\71\x20\x43\x65\162\x74\151\146\151\x63\x61\x74\x65\x27\x20\x66\x69\x65\154\x64\x20\151\156\x20\x70\154\x75\147\151\156\40\x64\x6f\x65\163\40\x6e\x6f\164\40\x6d\x61\164\143\x68\x20\x74\x68\x65\40\x63\145\x72\x74\x69\146\151\143\141\164\145\x20\146\157\165\156\144\40\x69\156\40\x53\101\x4d\114\40\x52\x65\163\x70\x6f\x6e\x73\145\56\74\57\160\x3e\xd\xa\40\x20\x20\40\40\40\40\40\40\40\x20\40\x20\40\40\40\40\x20\x20\40\x20\40\40\x20\x20\40\x20\40\x3c\x70\76\74\163\x74\162\157\156\x67\x3e\x43\145\x72\164\x69\146\x69\143\x61\164\x65\x20\x66\157\x75\156\144\40\151\x6e\40\123\101\x4d\x4c\x20\x52\145\163\160\157\x6e\163\145\x3a\40\x3c\x2f\x73\x74\x72\157\x6e\147\x3e\74\x66\157\x6e\164\x20\146\141\x63\145\75\x22\103\157\x75\x72\151\145\x72\40\x4e\145\x77\x22\76\x3c\142\x72\x3e\74\x62\x72\x3e" . $ys . "\74\57\160\x3e\x3c\x2f\146\x6f\x6e\164\x3e\xd\xa\40\40\40\x20\40\40\x20\40\x20\x20\x20\40\x20\40\40\x20\x20\x20\40\x20\40\x20\x20\40\40\x20\40\x20\74\160\x3e\x3c\x73\x74\x72\x6f\156\x67\x3e\123\x6f\154\165\164\151\157\x6e\x3a\x20\74\x2f\x73\x74\x72\157\156\x67\x3e\x3c\x2f\160\x3e\xd\12\40\40\40\40\40\x20\x20\x20\40\40\x20\x20\x20\x20\40\40\x20\40\40\x20\x20\40\40\x20\x20\x20\x20\x20\74\x6f\x6c\76\xd\xa\x20\40\40\x20\x20\x20\40\40\x20\x20\x20\40\x20\x20\40\40\40\x20\x20\x20\40\40\x20\x20\x20\x20\x20\x20\x20\40\x20\74\x6c\151\x3e\103\157\x70\171\40\160\141\163\164\145\40\x74\x68\145\x20\x63\x65\162\x74\151\x66\151\143\141\164\145\x20\160\x72\157\x76\x69\144\145\144\40\x61\142\x6f\x76\x65\40\x69\156\40\x58\65\60\71\x20\x43\x65\162\x74\x69\x66\x69\x63\141\x74\x65\40\165\x6e\x64\145\x72\x20\123\145\162\166\151\143\x65\x20\x50\162\157\166\x69\x64\145\x72\40\123\x65\164\165\160\x20\164\x61\x62\x2e\x3c\57\x6c\x69\76\15\xa\x20\x20\40\x20\x20\40\x20\x20\x20\40\x20\40\40\x20\40\40\x20\40\x20\x20\40\x20\40\x20\x20\40\x20\40\x20\40\x20\74\x6c\x69\76\x49\x66\40\151\163\163\165\x65\40\x70\145\162\163\151\x73\164\163\40\144\x69\163\x61\142\x6c\x65\x20\74\142\x3e\103\x68\141\162\141\143\x74\145\x72\x20\145\x6e\x63\157\x64\x69\x6e\x67\x3c\57\x62\x3e\40\x75\x6e\x64\145\162\40\123\x65\162\166\151\x63\x65\x20\x50\162\157\166\x64\x65\x72\x20\x53\x65\164\165\160\40\x74\x61\142\56\74\57\x6c\x69\x3e\15\12\40\x20\x20\x20\x20\40\40\x20\x20\x20\x20\x20\x20\x20\40\x20\40\x20\x20\x20\x20\x20\x20\40\40\x20\x20\x20\x3c\57\157\154\x3e\xd\12\x20\x20\x20\40\40\x20\40\40\40\40\x20\40\x20\40\40\x20\x20\x20\x20\x20\x20\40\x20\40\40\40\40\40\x3c\57\x64\151\x76\76\15\12\40\x20\40\x20\40\x20\x20\40\40\40\x20\40\40\40\40\x20\40\40\40\40\x20\x20\40\x20\74\x64\151\166\x20\163\x74\171\154\x65\x3d\42\x6d\x61\x72\x67\x69\156\x3a\x33\x25\73\x64\x69\x73\160\x6c\x61\171\72\x62\154\x6f\x63\153\73\x74\145\170\164\55\141\154\x69\x67\156\x3a\x63\x65\x6e\x74\x65\x72\73\x22\x3e\xd\xa\x20\40\40\x20\40\40\x20\40\40\40\x20\40\40\40\x20\40\40\x20\40\x20\40\x20\x20\x20\40\x20\x20\40\40\x20\x20\x20\x3c\144\151\166\40\163\164\x79\154\145\75\x22\x6d\141\162\147\x69\156\72\x33\45\73\144\151\x73\x70\154\141\171\72\x62\x6c\x6f\143\x6b\x3b\164\x65\170\164\55\x61\x6c\x69\x67\156\72\143\x65\x6e\x74\145\162\73\42\x3e\x3c\x69\x6e\160\x75\x74\40\163\164\x79\154\145\75\x22\160\141\x64\x64\x69\x6e\x67\x3a\x31\45\x3b\x77\x69\x64\x74\x68\72\61\x30\60\160\x78\73\142\x61\143\153\x67\162\x6f\165\156\x64\72\40\43\x30\x30\x39\61\103\x44\x20\156\x6f\x6e\145\40\x72\145\160\x65\141\164\40\163\x63\162\157\154\154\x20\x30\45\x20\60\x25\x3b\143\165\x72\x73\x6f\162\72\40\x70\157\x69\156\x74\x65\162\x3b\146\157\x6e\x74\x2d\163\151\172\x65\72\61\65\160\x78\x3b\x62\157\x72\x64\145\162\55\x77\151\144\x74\x68\72\x20\x31\x70\170\x3b\142\157\x72\144\x65\162\55\x73\x74\x79\154\x65\x3a\40\x73\x6f\154\151\x64\73\142\x6f\x72\x64\145\x72\x2d\162\141\x64\151\165\x73\72\40\x33\160\x78\x3b\167\150\x69\164\145\x2d\x73\160\x61\x63\x65\72\40\156\157\167\162\x61\x70\73\142\x6f\170\x2d\163\151\172\x69\x6e\147\72\x20\142\x6f\x72\144\x65\162\x2d\142\157\170\73\142\157\162\x64\145\x72\x2d\x63\157\x6c\157\x72\72\40\43\x30\60\67\x33\101\101\73\x62\157\170\55\x73\150\x61\144\157\x77\72\x20\60\x70\170\40\61\x70\170\x20\x30\x70\x78\x20\x72\147\x62\x61\50\x31\x32\60\x2c\40\x32\60\x30\x2c\40\x32\x33\x30\x2c\40\60\56\x36\51\40\x69\156\163\x65\164\73\x63\157\154\x6f\162\x3a\x20\x23\106\106\106\x3b\x22\164\171\x70\145\x3d\42\x62\165\164\164\x6f\x6e\42\40\x76\141\x6c\x75\145\x3d\x22\x44\157\x6e\x65\42\40\157\x6e\103\154\x69\x63\153\x3d\42\x73\x65\x6c\146\56\x63\154\x6f\163\x65\50\51\x3b\x22\76\x3c\57\x64\151\x76\76";
    mo_saml_download_logs($SF, $Dl);
    exit;
    uS:
    f_:
    $IQ = get_site_option("\163\141\x6d\154\x5f\x69\163\163\x75\x65\x72");
    $BG = get_site_option("\155\157\x5f\163\141\155\x6c\x5f\163\160\x5f\145\x6e\164\x69\164\x79\x5f\x69\144");
    if (!empty($BG)) {
        goto Bg;
    }
    $BG = $C3 . "\x2f\167\160\55\143\157\156\164\145\156\x74\57\160\154\x75\x67\x69\156\x73\x2f\x6d\x69\x6e\151\x6f\162\141\x6e\x67\145\x2d\x73\141\x6d\154\55\x32\60\x2d\163\x69\x6e\x67\154\x65\55\163\x69\147\x6e\x2d\x6f\156\57";
    Bg:
    Utilities::validateIssuerAndAudience($BS, $BG, $IQ, $C5);
    $BX = current(current($BS->getAssertions())->getNameId());
    $pJ = current($BS->getAssertions())->getAttributes();
    $pJ["\116\141\155\145\111\104"] = array("\x30" => $BX);
    $EV = current($BS->getAssertions())->getSessionIndex();
    mo_saml_checkMapping($pJ, $C5, $EV);
    goto kl;
    Xl:
    if (!isset($_REQUEST["\x52\x65\x6c\141\171\123\x74\141\x74\x65"])) {
        goto Pm;
    }
    $Gh = $_REQUEST["\122\145\154\x61\x79\x53\x74\141\164\x65"];
    Pm:
    if (!is_user_logged_in()) {
        goto uv;
    }
    wp_logout();
    uv:
    if (empty($Gh)) {
        goto Qm;
    }
    $Gh = mo_saml_parse_url($Gh);
    goto jc;
    Qm:
    $Gh = $C3;
    jc:
    header("\x4c\157\x63\x61\x74\151\157\156\72" . $Gh);
    exit;
    kl:
    k_:
    if (!(array_key_exists("\x53\x41\x4d\114\x52\x65\161\165\x65\x73\x74", $_REQUEST) && !empty($_REQUEST["\x53\101\x4d\114\x52\x65\x71\165\x65\163\164"]))) {
        goto aC;
    }
    $pz = $_REQUEST["\x53\101\115\x4c\x52\145\x71\165\145\163\x74"];
    $C5 = "\57";
    if (!array_key_exists("\x52\145\x6c\141\171\123\x74\141\164\x65", $_REQUEST)) {
        goto kN;
    }
    $C5 = $_REQUEST["\122\145\154\141\171\123\x74\141\x74\x65"];
    kN:
    $pz = base64_decode($pz);
    if (!(array_key_exists("\x53\101\115\x4c\x52\145\161\165\145\163\164", $_GET) && !empty($_GET["\x53\101\x4d\114\122\x65\161\x75\x65\x73\164"]))) {
        goto aV;
    }
    $pz = gzinflate($pz);
    aV:
    $QJ = new DOMDocument();
    $QJ->loadXML($pz);
    $uJ = $QJ->firstChild;
    if (!($uJ->localName == "\x4c\157\x67\157\x75\164\x52\145\x71\165\x65\x73\164")) {
        goto XP;
    }
    $TY = new SAML2_LogoutRequest($uJ);
    if (!(!session_id() || session_id() == '' || !isset($_SESSION))) {
        goto bB;
    }
    session_start();
    bB:
    $_SESSION["\x6d\157\137\x73\141\155\x6c\137\154\x6f\x67\157\165\x74\137\162\145\x71\165\145\x73\x74"] = $pz;
    $_SESSION["\155\157\x5f\163\x61\155\154\137\154\157\x67\x6f\x75\164\x5f\x72\145\x6c\141\171\137\163\x74\141\164\x65"] = $C5;
    wp_redirect(htmlspecialchars_decode(wp_logout_url()));
    exit;
    XP:
    aC:
    if (!(isset($_REQUEST["\157\160\x74\x69\x6f\156"]) and !is_array($_REQUEST["\157\x70\164\151\x6f\x6e"]) and strpos($_REQUEST["\x6f\160\164\151\157\x6e"], "\x72\145\141\x64\x73\x61\x6d\154\154\157\x67\151\156") !== false)) {
        goto fQ;
    }
    require_once dirname(__FILE__) . "\57\151\x6e\x63\x6c\x75\x64\145\x73\x2f\x6c\151\x62\57\x65\x6e\x63\x72\171\x70\x74\x69\x6f\156\56\x70\150\160";
    if (isset($_POST["\123\x54\x41\124\x55\123"]) && $_POST["\x53\124\101\124\x55\123"] == "\x45\x52\x52\117\x52") {
        goto BX;
    }
    if (!(isset($_POST["\x53\124\101\124\x55\123"]) && $_POST["\x53\124\101\x54\125\123"] == "\x53\125\103\103\105\x53\x53")) {
        goto d6;
    }
    $zg = '';
    if (!(isset($_REQUEST["\162\145\x64\151\162\x65\143\x74\137\164\x6f"]) && !empty($_REQUEST["\162\145\144\x69\162\x65\x63\164\x5f\164\x6f"]) && $_REQUEST["\x72\145\144\x69\162\x65\143\x74\x5f\164\157"] != "\57")) {
        goto mL;
    }
    $zg = $_REQUEST["\162\x65\x64\x69\x72\x65\143\164\137\164\157"];
    mL:
    delete_site_option("\x6d\157\137\163\x61\155\x6c\137\162\x65\x64\x69\x72\145\x63\164\x5f\x65\x72\162\157\162\137\x63\157\144\145");
    delete_site_option("\x6d\157\137\163\x61\155\154\137\162\145\x64\x69\x72\145\x63\x74\x5f\145\x72\x72\x6f\x72\137\162\x65\x61\163\x6f\x6e");
    try {
        $aB = get_site_option("\163\x61\x6d\x6c\137\141\155\x5f\145\x6d\x61\151\x6c");
        $tg = get_site_option("\x73\x61\x6d\x6c\137\141\x6d\137\x75\x73\145\162\x6e\x61\155\x65");
        $hT = get_site_option("\163\x61\x6d\x6c\137\x61\x6d\137\146\151\162\x73\x74\x5f\156\141\x6d\x65");
        $YG = get_site_option("\163\x61\x6d\154\x5f\x61\155\x5f\154\x61\163\164\x5f\x6e\x61\x6d\x65");
        $RR = get_site_option("\x73\141\x6d\x6c\137\x61\x6d\137\147\x72\x6f\x75\160\x5f\x6e\141\155\145");
        $zB = get_site_option("\x73\141\155\154\137\141\x6d\x5f\144\x65\146\x61\165\x6c\x74\x5f\x75\x73\x65\x72\x5f\x72\x6f\154\145");
        $NB = get_site_option("\x73\141\x6d\x6c\x5f\141\155\x5f\x64\x6f\x6e\x74\137\x61\154\154\x6f\167\137\165\156\154\151\x73\164\x65\x64\137\165\x73\x65\x72\x5f\x72\x6f\154\x65");
        $ND = get_site_option("\x73\x61\x6d\x6c\137\x61\155\x5f\141\x63\x63\157\x75\156\164\137\x6d\x61\164\x63\x68\145\x72");
        $kw = '';
        $oP = '';
        $hT = str_replace("\x2e", "\137", $hT);
        $hT = str_replace("\x20", "\137", $hT);
        if (!(!empty($hT) && array_key_exists($hT, $_POST))) {
            goto EU;
        }
        $hT = $_POST[$hT];
        EU:
        $YG = str_replace("\x2e", "\137", $YG);
        $YG = str_replace("\40", "\x5f", $YG);
        if (!(!empty($YG) && array_key_exists($YG, $_POST))) {
            goto sW;
        }
        $YG = $_POST[$YG];
        sW:
        $tg = str_replace("\x2e", "\x5f", $tg);
        $tg = str_replace("\x20", "\137", $tg);
        if (!empty($tg) && array_key_exists($tg, $_POST)) {
            goto Dw;
        }
        $oP = $_POST["\x4e\141\x6d\145\x49\104"];
        goto q6;
        Dw:
        $oP = $_POST[$tg];
        q6:
        $kw = str_replace("\x2e", "\x5f", $aB);
        $kw = str_replace("\40", "\137", $aB);
        if (!empty($aB) && array_key_exists($aB, $_POST)) {
            goto vn;
        }
        $kw = $_POST["\116\x61\155\145\x49\104"];
        goto qX;
        vn:
        $kw = $_POST[$aB];
        qX:
        $RR = str_replace("\x2e", "\x5f", $RR);
        $RR = str_replace("\40", "\137", $RR);
        if (!(!empty($RR) && array_key_exists($RR, $_POST))) {
            goto Pu;
        }
        $RR = $_POST[$RR];
        Pu:
        if (!empty($ND)) {
            goto rE;
        }
        $ND = "\x65\x6d\141\151\154";
        rE:
        $xk = get_site_option("\x6d\x6f\137\x73\141\x6d\154\x5f\143\x75\x73\x74\x6f\155\x65\162\x5f\164\157\153\x65\156");
        if (!(isset($xk) || trim($xk) != '')) {
            goto hz;
        }
        $c9 = AESEncryption::decrypt_data($kw, $xk);
        $kw = $c9;
        hz:
        if (!(!empty($hT) && !empty($xk))) {
            goto RH;
        }
        $IA = AESEncryption::decrypt_data($hT, $xk);
        $hT = $IA;
        RH:
        if (!(!empty($YG) && !empty($xk))) {
            goto VJ;
        }
        $jX = AESEncryption::decrypt_data($YG, $xk);
        $YG = $jX;
        VJ:
        if (!(!empty($oP) && !empty($xk))) {
            goto dh;
        }
        $GH = AESEncryption::decrypt_data($oP, $xk);
        $oP = $GH;
        dh:
        if (!(!empty($RR) && !empty($xk))) {
            goto ah;
        }
        $IW = AESEncryption::decrypt_data($RR, $xk);
        $RR = $IW;
        ah:
    } catch (Exception $i0) {
        echo sprintf("\x41\x6e\x20\x65\162\x72\x6f\x72\40\157\143\143\165\162\x72\x65\144\40\x77\150\x69\154\145\x20\160\x72\157\143\145\x73\163\x69\x6e\147\x20\164\150\145\40\123\x41\x4d\114\x20\x52\x65\x73\160\x6f\156\x73\145\x2e");
        exit;
    }
    $no = array($RR);
    mo_saml_login_user($kw, $hT, $YG, $oP, $no, $NB, $zB, $zg, $ND);
    d6:
    goto c6;
    BX:
    update_site_option("\155\157\137\x73\141\x6d\154\x5f\x72\x65\x64\151\x72\x65\x63\164\137\x65\x72\162\157\x72\x5f\143\x6f\144\145", $_POST["\105\122\x52\x4f\122\x5f\x52\105\101\123\117\116"]);
    update_site_option("\x6d\x6f\137\163\141\155\154\137\162\145\144\151\162\145\143\x74\137\145\162\162\157\162\x5f\x72\x65\x61\163\x6f\156", $_POST["\x45\122\122\x4f\x52\137\115\x45\x53\x53\101\107\x45"]);
    c6:
    fQ:
    jm:
}
function mo_saml_relaystate_url($C5)
{
    $Dz = parse_url($C5, PHP_URL_SCHEME);
    $C5 = str_replace($Dz . "\x3a\57\57", '', $C5);
    return $C5;
}
function mo_saml_hash_relaystate($C5)
{
    $Dz = parse_url($C5, PHP_URL_SCHEME);
    $C5 = str_replace($Dz . "\72\x2f\57", '', $C5);
    $C5 = base64_encode($C5);
    $WM = cdjsurkhh($C5);
    $C5 = $C5 . "\56" . $WM;
    return $C5;
}
function mo_saml_get_relaystate($C5)
{
    if (!filter_var($C5, FILTER_VALIDATE_URL)) {
        goto Kn;
    }
    return $C5;
    Kn:
    $Bd = strpos($C5, "\x2e");
    if ($Bd) {
        goto NX;
    }
    wp_die("\101\156\40\x65\162\162\157\162\x20\x6f\x63\143\x75\x72\145\144\x2e\40\x50\154\145\141\163\x65\x20\x63\157\x6e\x74\x61\x63\x74\x20\171\157\165\x72\x20\141\144\x6d\x69\x6e\x69\163\164\162\x61\164\x6f\x72\56", "\105\162\x72\157\162\40\x3a\x20\116\x6f\x74\40\141\40\164\162\x75\x73\164\x65\x64\x20\x73\x6f\165\x72\x63\145\x20\x6f\146\40\164\x68\145\x20\x53\x41\x4d\x4c\x20\162\x65\163\160\157\156\x73\x65");
    exit;
    NX:
    $Gh = substr($C5, 0, $Bd);
    $fJ = substr($C5, $Bd + 1);
    $wK = cdjsurkhh($Gh);
    if (!($fJ !== $wK)) {
        goto Ik;
    }
    wp_die("\101\156\40\x65\162\x72\157\x72\40\x6f\143\x63\165\162\x65\x64\x2e\40\x50\154\145\x61\x73\145\40\143\157\x6e\x74\x61\143\x74\x20\x79\x6f\x75\162\40\141\144\155\151\156\x69\163\x74\162\141\x74\x6f\x72\x2e", "\105\x72\162\157\x72\x20\x3a\40\116\157\164\x20\141\40\x74\x72\x75\x73\x74\145\x64\x20\x73\157\165\x72\x63\145\x20\157\x66\x20\164\x68\x65\x20\x53\101\115\x4c\40\x72\145\163\x70\x6f\156\163\145");
    exit;
    Ik:
    $Gh = base64_decode($Gh);
    return $Gh;
}
function cdjsurkhh($fz)
{
    $WM = hash("\163\150\x61\x35\x31\x32", $fz);
    $zp = substr($WM, 7, 14);
    return $zp;
}
function mo_saml_parse_url($C5)
{
    if (!($C5 != "\x74\x65\x73\x74\126\141\x6c\x69\x64\141\x74\145" && $C5 != "\164\145\x73\164\x4e\145\x77\103\145\162\164\x69\146\151\143\x61\x74\145")) {
        goto zE;
    }
    $C3 = get_site_option("\x6d\157\x5f\163\141\x6d\154\137\x73\160\137\142\x61\163\145\x5f\x75\x72\x6c");
    if (!empty($C3)) {
        goto bm;
    }
    $C3 = get_network_site_url();
    bm:
    $Dz = parse_url($C3, PHP_URL_SCHEME);
    if (filter_var($C5, FILTER_VALIDATE_URL)) {
        goto OK;
    }
    $C5 = $Dz . "\72\x2f\x2f" . $C5;
    OK:
    zE:
    return $C5;
}
function mo_saml_is_subsite($C5)
{
    $bI = parse_url($C5, PHP_URL_HOST);
    $Ca = parse_url($C5, PHP_URL_PATH);
    if (is_subdomain_install()) {
        goto LF;
    }
    $PX = strpos($Ca, "\x2f", 1) != false ? strpos($Ca, "\x2f", 1) : strlen($Ca) - 1;
    $Ca = substr($Ca, 0, $PX + 1);
    $blog_id = get_blog_id_from_url($bI, $Ca);
    goto RJ;
    LF:
    $blog_id = get_blog_id_from_url($bI);
    RJ:
    if ($blog_id !== 0) {
        goto cW;
    }
    return false;
    goto J5;
    cW:
    return true;
    J5:
}
function mo_saml_show_SAML_log($uJ, $ew)
{
    header("\103\x6f\x6e\164\145\x6e\x74\55\124\171\x70\145\x3a\x20\164\145\170\x74\57\x68\x74\155\x6c");
    $Bl = new DOMDocument();
    $Bl->preserveWhiteSpace = false;
    $Bl->formatOutput = true;
    $Bl->loadXML($uJ);
    if ($ew == "\x64\x69\163\160\154\141\x79\x53\x41\x4d\114\122\x65\161\x75\145\163\x74") {
        goto Yl;
    }
    $YO = "\123\x41\115\114\x20\122\x65\163\160\x6f\x6e\x73\x65";
    goto g7;
    Yl:
    $YO = "\123\x41\115\114\40\122\145\x71\x75\x65\x73\x74";
    g7:
    $TX = $Bl->saveXML();
    $R5 = htmlentities($TX);
    $R5 = rtrim($R5);
    $fO = simplexml_load_string($TX);
    $Cv = json_encode($fO);
    $Co = json_decode($Cv);
    $hn = plugins_url("\151\156\143\x6c\165\144\145\x73\57\143\163\x73\x2f\163\164\171\154\x65\x5f\163\145\x74\x74\151\x6e\147\163\56\x63\x73\163\x3f\166\x65\162\x3d\64\56\70\56\64\60", __FILE__);
    echo "\x3c\154\x69\x6e\153\40\162\x65\x6c\75\x27\x73\x74\x79\154\145\163\x68\x65\145\164\47\x20\151\144\75\x27\x6d\x6f\x5f\x73\x61\155\x6c\x5f\x61\x64\155\151\156\137\163\x65\x74\x74\151\156\147\163\137\163\x74\x79\154\145\x2d\x63\163\x73\x27\40\x20\150\162\x65\146\75\x27" . $hn . "\x27\40\x74\x79\x70\145\75\x27\164\145\x78\x74\57\143\x73\x73\x27\40\x6d\x65\x64\x69\141\x3d\x27\141\x6c\x6c\47\x20\x2f\x3e\15\12\xd\12\x3c\x64\151\x76\x20\143\x6c\x61\x73\x73\75\x22\x6d\x6f\x2d\x64\x69\x73\x70\154\141\171\55\x6c\x6f\x67\x73\x22\x20\76\x3c\x70\40\164\171\160\145\x3d\42\164\145\170\x74\x22\x20\40\x20\x69\x64\75\42\x53\x41\x4d\x4c\137\x74\x79\160\x65\42\76" . $YO . "\74\x2f\160\x3e\x3c\57\144\151\166\x3e\15\12\xd\12\74\x64\151\x76\x20\164\171\x70\x65\x3d\42\164\x65\170\164\42\40\x69\144\x3d\42\123\x41\115\x4c\137\x64\151\x73\x70\x6c\x61\x79\x22\x20\x63\154\141\x73\x73\x3d\x22\155\x6f\x2d\x64\x69\163\x70\154\x61\171\55\x62\154\157\x63\x6b\x22\76\x3c\160\162\x65\40\143\x6c\x61\x73\x73\75\47\x62\162\165\163\x68\x3a\x20\170\155\154\73\x27\x3e" . $R5 . "\74\57\160\x72\145\76\74\57\144\x69\x76\x3e\15\xa\x3c\x62\162\x3e\15\12\74\144\x69\x76\x9\x20\x73\164\x79\154\x65\x3d\x22\155\x61\x72\147\x69\156\72\63\x25\73\x64\x69\x73\x70\154\141\x79\72\x62\154\x6f\143\153\73\164\x65\x78\x74\55\141\x6c\x69\x67\x6e\72\x63\x65\x6e\x74\145\x72\x3b\x22\x3e\15\xa\xd\xa\x3c\144\151\166\40\x73\x74\171\154\145\x3d\42\x6d\x61\162\x67\151\x6e\72\x33\45\x3b\144\151\163\x70\x6c\141\171\72\142\154\x6f\143\153\73\x74\145\170\x74\55\141\154\x69\x67\x6e\72\x63\145\x6e\164\145\x72\73\x22\40\76\xd\12\15\xa\x3c\57\144\x69\x76\x3e\xd\12\74\142\x75\x74\164\x6f\x6e\40\151\144\x3d\42\143\157\160\171\x22\40\157\x6e\143\154\151\x63\x6b\75\42\x63\157\x70\171\x44\151\x76\124\x6f\x43\x6c\151\x70\x62\157\x61\x72\144\50\51\x22\x20\40\x73\x74\x79\154\x65\x3d\x22\160\x61\144\x64\x69\156\147\x3a\x31\x25\73\x77\x69\x64\x74\150\72\61\60\60\x70\170\73\142\141\143\x6b\x67\162\157\x75\156\144\72\40\x23\x30\60\71\61\x43\104\40\156\157\156\145\40\162\x65\160\x65\141\164\40\163\x63\x72\157\154\x6c\40\60\45\40\60\45\73\143\165\x72\163\x6f\162\72\x20\160\157\x69\156\x74\x65\162\73\146\157\x6e\x74\55\163\x69\172\x65\x3a\61\65\160\170\x3b\142\x6f\162\144\145\x72\55\167\x69\144\x74\x68\x3a\x20\x31\x70\170\x3b\142\x6f\162\x64\x65\162\x2d\163\x74\x79\x6c\x65\72\40\x73\157\154\x69\x64\x3b\142\157\x72\144\145\x72\x2d\x72\141\144\x69\165\x73\x3a\x20\63\160\170\x3b\167\150\x69\x74\x65\55\163\x70\x61\x63\145\72\40\x6e\x6f\167\162\x61\160\73\x62\157\x78\x2d\163\151\x7a\151\x6e\x67\72\x20\142\157\162\144\x65\162\x2d\x62\157\x78\x3b\x62\157\x72\144\x65\x72\x2d\x63\157\x6c\157\162\x3a\40\x23\x30\60\67\x33\101\x41\x3b\142\x6f\170\55\163\150\x61\144\157\167\72\x20\60\160\170\x20\x31\160\x78\x20\x30\160\x78\40\162\x67\142\x61\50\61\x32\60\54\40\x32\60\60\54\40\62\63\60\54\40\x30\56\x36\x29\x20\151\x6e\x73\145\x74\x3b\143\x6f\154\x6f\x72\x3a\40\43\x46\106\106\x3b\x22\x20\x3e\x43\157\x70\171\74\57\142\165\x74\x74\x6f\156\x3e\xd\xa\x26\156\x62\163\x70\x3b\15\xa\74\x69\x6e\160\x75\x74\x20\151\x64\75\42\144\167\156\55\142\164\x6e\x22\40\163\x74\171\154\x65\x3d\42\160\141\x64\144\151\x6e\x67\x3a\x31\45\x3b\167\151\144\164\x68\72\61\x30\x30\160\x78\x3b\142\x61\143\153\147\162\x6f\165\156\x64\72\x20\43\60\x30\x39\61\103\x44\x20\x6e\x6f\156\x65\40\x72\x65\160\145\141\164\40\x73\x63\x72\x6f\x6c\x6c\40\60\45\40\x30\x25\x3b\143\165\162\163\157\162\x3a\x20\x70\x6f\151\x6e\x74\x65\162\x3b\146\x6f\156\x74\x2d\x73\x69\x7a\x65\x3a\61\x35\x70\170\73\142\x6f\x72\144\145\x72\x2d\167\x69\144\164\x68\72\x20\61\160\170\73\142\157\x72\144\x65\x72\55\163\164\x79\154\145\x3a\40\x73\x6f\x6c\x69\144\73\142\x6f\x72\x64\x65\162\55\162\141\144\x69\165\x73\72\40\x33\160\x78\73\167\x68\x69\x74\x65\55\163\x70\141\143\145\72\40\x6e\x6f\x77\162\141\160\x3b\x62\157\x78\x2d\x73\x69\172\x69\156\147\x3a\40\x62\157\x72\x64\145\162\55\x62\157\170\x3b\142\x6f\x72\x64\x65\162\55\x63\157\154\x6f\x72\72\40\43\x30\60\x37\x33\x41\x41\x3b\142\157\x78\55\163\150\x61\144\157\167\72\x20\x30\x70\x78\40\61\x70\170\40\x30\x70\170\40\162\x67\x62\141\50\61\x32\60\x2c\x20\62\x30\60\x2c\40\62\x33\x30\54\40\x30\x2e\66\51\x20\151\156\x73\145\x74\73\x63\x6f\154\x6f\162\72\x20\x23\106\x46\x46\73\42\x74\x79\160\x65\75\42\142\x75\x74\164\x6f\156\42\x20\166\x61\x6c\x75\x65\75\42\x44\x6f\167\156\x6c\157\141\144\x22\40\15\12\42\x3e\xd\12\74\57\144\151\x76\76\xd\xa\x3c\57\144\x69\166\76\xd\12\15\12\15\xa";
    ob_end_flush();
    echo "\15\12\74\163\x63\x72\151\x70\x74\x3e\xd\12\xd\12\x66\x75\156\x63\x74\151\x6f\x6e\40\143\157\160\171\x44\x69\166\124\x6f\103\x6c\151\x70\x62\157\141\x72\144\x28\x29\x20\x7b\xd\xa\x76\141\x72\40\x61\x75\x78\40\x3d\40\144\157\x63\x75\155\145\x6e\164\56\143\x72\x65\141\164\145\105\154\x65\155\x65\156\164\x28\x22\x69\x6e\x70\165\164\x22\51\73\xd\12\141\x75\x78\x2e\x73\x65\164\x41\164\164\162\x69\142\x75\164\x65\x28\42\166\x61\154\x75\x65\x22\x2c\x20\144\x6f\143\165\155\x65\156\x74\56\x67\145\x74\105\154\x65\x6d\x65\156\164\x42\171\111\x64\50\42\x53\x41\115\114\x5f\x64\x69\x73\160\154\x61\171\x22\51\x2e\x74\145\x78\x74\x43\157\156\164\145\x6e\164\x29\73\15\12\x64\157\143\165\x6d\x65\156\164\x2e\142\157\x64\171\x2e\x61\160\x70\x65\x6e\144\103\150\151\x6c\144\50\x61\165\170\x29\x3b\xd\xa\x61\x75\x78\x2e\163\x65\x6c\x65\143\x74\x28\51\x3b\xd\12\x64\x6f\x63\165\155\x65\156\164\x2e\x65\x78\145\x63\103\157\x6d\155\x61\x6e\x64\50\42\143\157\160\171\42\x29\x3b\xd\xa\144\x6f\143\x75\155\145\x6e\164\x2e\142\157\144\x79\x2e\162\145\155\x6f\166\145\103\x68\x69\x6c\x64\x28\141\x75\x78\51\x3b\xd\xa\144\157\x63\x75\155\145\x6e\164\56\x67\145\x74\105\154\x65\155\145\x6e\164\x42\x79\x49\x64\x28\47\143\x6f\160\x79\47\x29\x2e\x74\x65\170\164\103\157\156\164\x65\x6e\x74\x20\75\40\42\x43\157\x70\151\145\x64\x22\x3b\15\xa\x64\157\x63\x75\155\x65\156\164\x2e\147\145\164\x45\x6c\x65\155\145\x6e\x74\102\171\111\x64\50\x27\x63\157\x70\x79\47\51\x2e\x73\164\x79\x6c\x65\56\142\x61\x63\153\147\x72\x6f\x75\x6e\x64\x20\x3d\x20\x22\147\162\x65\x79\42\73\xd\xa\x77\151\x6e\144\x6f\x77\x2e\x67\x65\164\123\x65\154\x65\x63\x74\x69\157\156\50\51\x2e\163\145\x6c\145\143\x74\x41\154\154\x43\x68\x69\x6c\144\x72\x65\x6e\x28\40\144\x6f\143\165\x6d\145\156\164\56\x67\x65\164\x45\154\145\155\x65\156\x74\102\171\x49\x64\50\x20\42\123\101\x4d\114\137\x64\151\x73\160\x6c\141\171\x22\x20\51\x20\51\x3b\xd\xa\xd\12\175\xd\12\xd\xa\x66\165\x6e\143\164\x69\x6f\x6e\x20\144\x6f\x77\x6e\x6c\157\x61\x64\x28\x66\151\154\145\x6e\x61\155\x65\x2c\40\164\145\170\x74\51\40\x7b\15\12\x76\x61\x72\40\145\x6c\x65\x6d\x65\156\164\40\75\40\144\157\143\165\155\145\x6e\164\56\143\x72\145\x61\164\x65\105\154\145\x6d\145\156\x74\x28\x27\141\x27\51\x3b\xd\xa\145\x6c\145\x6d\x65\x6e\164\x2e\x73\x65\x74\x41\x74\164\162\151\x62\165\164\145\x28\47\x68\162\x65\x66\x27\54\x20\x27\144\141\x74\x61\72\x41\x70\160\x6c\151\143\141\x74\x69\x6f\x6e\x2f\x6f\143\164\145\x74\55\x73\164\x72\x65\x61\155\x3b\x63\x68\x61\162\x73\x65\164\75\165\x74\x66\55\70\54\x27\x20\x2b\x20\x65\156\x63\x6f\x64\x65\125\x52\111\103\x6f\155\160\157\156\x65\x6e\164\50\x74\x65\170\164\51\x29\73\15\xa\x65\154\145\x6d\x65\156\164\56\x73\x65\x74\101\164\x74\x72\151\142\x75\x74\145\x28\47\144\x6f\167\x6e\x6c\x6f\141\144\x27\54\40\x66\x69\x6c\145\156\141\155\x65\51\x3b\xd\xa\15\12\x65\x6c\145\x6d\x65\x6e\x74\56\163\x74\x79\154\x65\x2e\x64\x69\x73\160\154\x61\171\x20\75\x20\x27\156\157\x6e\145\x27\x3b\15\12\x64\x6f\143\165\155\x65\x6e\164\56\x62\157\x64\171\x2e\141\160\160\x65\156\x64\103\x68\151\154\144\50\145\154\145\x6d\145\x6e\x74\51\73\xd\xa\15\12\x65\154\145\155\x65\156\164\x2e\143\154\x69\143\x6b\x28\x29\73\xd\12\15\12\x64\157\143\165\155\x65\x6e\x74\56\142\157\144\171\56\162\145\x6d\x6f\166\x65\103\150\x69\x6c\x64\50\145\154\145\155\145\156\164\x29\73\15\xa\175\xd\12\xd\12\144\157\143\165\155\145\x6e\x74\x2e\147\x65\x74\x45\x6c\145\x6d\145\x6e\x74\x42\x79\x49\144\x28\42\x64\x77\156\55\x62\164\x6e\42\x29\x2e\x61\144\144\x45\x76\145\156\164\114\x69\163\x74\145\x6e\x65\x72\x28\x22\143\154\151\x63\153\42\x2c\40\x66\x75\x6e\x63\x74\151\157\x6e\x20\x28\51\40\173\15\12\15\xa\166\x61\162\x20\x66\151\x6c\145\156\141\155\x65\40\75\40\144\157\x63\165\155\145\x6e\164\56\147\145\x74\105\154\145\x6d\x65\156\164\x42\x79\x49\x64\x28\x22\x53\101\x4d\x4c\137\x74\171\x70\145\x22\x29\x2e\164\x65\170\x74\103\157\x6e\164\145\x6e\164\53\42\x2e\170\155\154\42\x3b\15\12\166\141\x72\40\x6e\x6f\x64\145\x20\75\40\144\157\143\x75\155\x65\156\164\x2e\147\x65\x74\x45\154\145\155\x65\x6e\164\x42\x79\x49\144\x28\x22\123\x41\x4d\x4c\x5f\x64\151\x73\160\154\141\171\42\x29\x3b\15\xa\x68\x74\x6d\154\103\157\156\x74\145\156\164\x20\75\40\156\157\x64\x65\56\151\x6e\x6e\145\162\110\x54\x4d\114\73\xd\xa\164\145\170\164\40\75\40\x6e\157\x64\x65\56\164\145\x78\x74\x43\x6f\x6e\x74\145\156\164\73\15\12\144\x6f\167\x6e\x6c\157\141\144\50\x66\x69\154\x65\156\141\155\145\54\x20\x74\x65\x78\164\51\73\xd\xa\175\54\40\x66\141\x6c\x73\145\51\73\15\xa\15\xa\15\xa\xd\xa\xd\xa\15\xa\74\57\x73\143\162\x69\160\x74\76\15\xa";
    exit;
}
function mo_saml_checkMapping($pJ, $C5, $EV)
{
    try {
        $aB = get_site_option("\x73\141\x6d\x6c\x5f\x61\155\x5f\145\x6d\x61\x69\x6c");
        $tg = get_site_option("\x73\x61\x6d\x6c\137\141\155\137\165\163\145\x72\x6e\141\x6d\145");
        $hT = get_site_option("\x73\141\155\154\137\x61\155\x5f\x66\151\162\x73\164\x5f\156\x61\155\145");
        $YG = get_site_option("\x73\x61\155\x6c\x5f\141\155\x5f\154\141\x73\x74\x5f\x6e\x61\155\145");
        $RR = get_site_option("\163\141\x6d\154\x5f\141\x6d\137\x67\x72\157\165\160\x5f\156\x61\x6d\x65");
        $P_ = array();
        $P_ = maybe_unserialize(get_site_option("\163\x61\155\154\137\141\155\137\162\157\x6c\145\137\x6d\x61\x70\160\x69\156\x67"));
        $ND = get_site_option("\x73\141\x6d\154\x5f\141\155\137\141\x63\x63\x6f\x75\x6e\x74\137\155\141\x74\x63\x68\x65\162");
        $kw = '';
        $oP = '';
        if (empty($pJ)) {
            goto tG;
        }
        if (!empty($hT) && array_key_exists($hT, $pJ)) {
            goto Lb;
        }
        $hT = '';
        goto pE;
        Lb:
        $hT = $pJ[$hT][0];
        pE:
        if (!empty($YG) && array_key_exists($YG, $pJ)) {
            goto UX;
        }
        $YG = '';
        goto RV;
        UX:
        $YG = $pJ[$YG][0];
        RV:
        if (!empty($tg) && array_key_exists($tg, $pJ)) {
            goto Ga;
        }
        $oP = $pJ["\x4e\x61\155\145\111\104"][0];
        goto TS;
        Ga:
        $oP = $pJ[$tg][0];
        TS:
        if (!empty($aB) && array_key_exists($aB, $pJ)) {
            goto rg;
        }
        $kw = $pJ["\x4e\x61\155\145\x49\104"][0];
        goto by;
        rg:
        $kw = $pJ[$aB][0];
        by:
        if (!empty($RR) && array_key_exists($RR, $pJ)) {
            goto Ed;
        }
        $RR = array();
        goto rX;
        Ed:
        $RR = $pJ[$RR];
        rX:
        if (!empty($ND)) {
            goto vh;
        }
        $ND = "\x65\x6d\x61\151\x6c";
        vh:
        tG:
        if ($C5 == "\164\145\x73\164\x56\x61\154\x69\x64\141\x74\145") {
            goto sJ;
        }
        if ($C5 == "\x74\x65\163\x74\116\145\x77\103\145\x72\164\x69\x66\151\x63\141\x74\145") {
            goto r6p;
        }
        mo_saml_login_user($kw, $hT, $YG, $oP, $RR, $P_, $C5, $ND, $EV, $pJ["\x4e\141\x6d\145\111\104"][0], $pJ);
        goto W_;
        sJ:
        update_site_option("\155\157\137\x73\141\x6d\154\x5f\164\x65\x73\164", "\x54\x65\x73\x74\x20\x53\165\x63\143\x65\x73\x73\146\x75\x6c");
        mo_saml_show_test_result($hT, $YG, $kw, $RR, $pJ, $C5);
        goto W_;
        r6p:
        update_site_option("\x6d\x6f\x5f\x73\x61\x6d\154\x5f\x74\x65\163\x74\137\x6e\x65\x77\137\143\x65\162\164", "\x54\145\163\x74\x20\x73\x75\x63\143\145\163\x73\146\165\x6c");
        mo_saml_show_test_result($hT, $YG, $kw, $RR, $pJ, $C5);
        W_:
    } catch (Exception $i0) {
        echo sprintf("\101\156\x20\145\162\x72\x6f\x72\x20\x6f\143\x63\165\x72\162\x65\144\40\x77\150\151\x6c\x65\x20\x70\x72\157\x63\x65\x73\163\x69\x6e\147\40\164\150\145\40\123\101\x4d\x4c\40\x52\145\x73\160\x6f\156\163\x65\56");
        exit;
    }
}
function mo_saml_show_test_result($hT, $YG, $kw, $RR, $pJ, $C5)
{
    echo "\74\x64\151\x76\40\163\x74\171\x6c\x65\x3d\42\x66\157\156\164\x2d\146\141\155\151\154\171\x3a\103\x61\154\151\x62\162\151\x3b\160\x61\x64\144\151\156\147\x3a\x30\40\x33\x25\73\x22\x3e";
    if (!empty($kw)) {
        goto LlS;
    }
    echo "\x3c\x64\151\166\x20\163\x74\x79\x6c\145\75\42\143\157\154\x6f\162\x3a\x20\x23\141\x39\64\x34\64\x32\73\x62\x61\x63\153\147\162\157\165\156\x64\55\x63\157\154\x6f\x72\x3a\40\x23\x66\x32\144\x65\x64\x65\73\160\141\x64\x64\x69\x6e\147\72\x20\61\x35\x70\x78\x3b\x6d\141\x72\147\151\x6e\55\x62\x6f\164\x74\x6f\155\72\x20\62\60\x70\170\x3b\x74\145\170\x74\55\141\154\x69\x67\x6e\72\143\x65\156\x74\145\162\73\x62\157\162\x64\145\162\72\x31\160\x78\40\x73\157\154\151\x64\40\x23\x45\x36\x42\63\x42\62\x3b\146\x6f\156\164\x2d\163\x69\172\x65\72\61\70\x70\x74\x3b\x22\76\x54\105\x53\x54\40\106\x41\x49\x4c\x45\104\74\x2f\x64\151\x76\76\15\12\40\x20\x20\40\x20\x20\40\x20\74\144\x69\166\x20\163\164\x79\x6c\145\x3d\42\x63\157\x6c\x6f\x72\72\40\x23\x61\x39\64\64\64\62\73\146\x6f\x6e\164\x2d\x73\151\172\145\72\61\x34\160\164\73\40\x6d\x61\x72\147\x69\156\x2d\x62\x6f\164\x74\x6f\155\x3a\x32\60\x70\170\x3b\42\76\x57\x41\x52\116\111\x4e\107\x3a\x20\x53\157\155\145\40\101\x74\x74\x72\x69\x62\x75\164\145\163\40\x44\x69\144\40\116\x6f\x74\40\x4d\x61\x74\x63\x68\x2e\x3c\57\144\151\166\x3e\15\xa\40\x20\x20\40\40\x20\40\40\74\144\151\166\40\x73\164\171\x6c\145\75\x22\x64\x69\163\160\154\x61\171\72\142\x6c\x6f\143\153\x3b\164\x65\x78\164\x2d\x61\154\x69\x67\x6e\72\x63\x65\x6e\x74\145\x72\73\155\141\162\147\151\x6e\x2d\x62\x6f\x74\164\157\155\72\64\x25\73\x22\x3e\x3c\151\155\x67\x20\x73\164\171\154\145\75\x22\x77\151\x64\x74\x68\x3a\x31\65\x25\x3b\x22\163\162\143\75\x22" . plugin_dir_url(__FILE__) . "\151\x6d\x61\x67\145\x73\57\167\x72\x6f\156\147\56\160\x6e\x67\x22\x3e\x3c\57\144\x69\166\76";
    goto zQt;
    LlS:
    update_site_option("\155\157\x5f\163\141\155\154\x5f\164\x65\163\164\137\143\x6f\x6e\x66\x69\147\x5f\141\x74\164\x72\x73", $pJ);
    echo "\x3c\x64\x69\x76\40\163\x74\x79\x6c\145\x3d\x22\143\x6f\154\157\162\72\40\x23\x33\x63\x37\x36\63\144\73\15\xa\x20\x20\x20\40\x20\40\40\40\x62\141\x63\x6b\147\162\157\165\156\144\x2d\143\x6f\x6c\x6f\162\x3a\x20\43\144\x66\x66\60\144\70\73\x20\160\x61\x64\x64\x69\156\x67\x3a\62\45\73\x6d\x61\162\x67\x69\x6e\x2d\142\157\164\x74\157\x6d\72\62\x30\160\x78\73\x74\x65\170\x74\55\x61\x6c\151\x67\x6e\72\x63\x65\156\x74\145\162\x3b\40\x62\x6f\162\144\x65\x72\x3a\61\160\170\40\x73\x6f\x6c\x69\144\x20\43\101\x45\104\x42\71\101\73\x20\146\157\156\x74\x2d\x73\151\x7a\145\72\x31\70\160\164\x3b\42\76\124\x45\123\x54\40\x53\x55\x43\x43\x45\x53\123\106\125\114\x3c\57\144\x69\166\76\xd\12\x20\x20\40\x20\40\x20\x20\40\74\144\151\x76\40\x73\x74\171\154\x65\x3d\42\x64\x69\x73\160\x6c\x61\x79\72\142\x6c\157\143\153\73\x74\145\x78\x74\55\141\154\x69\x67\156\x3a\x63\145\x6e\x74\x65\x72\73\x6d\141\x72\147\151\156\55\x62\x6f\164\164\x6f\155\x3a\x34\45\x3b\x22\76\74\151\155\x67\40\163\x74\x79\154\x65\x3d\x22\167\x69\144\164\150\x3a\x31\65\45\x3b\42\163\162\x63\x3d\42" . plugin_dir_url(__FILE__) . "\151\155\x61\x67\145\x73\x2f\x67\x72\x65\x65\156\x5f\x63\x68\145\x63\153\56\x70\156\x67\42\x3e\x3c\x2f\144\151\166\x3e";
    zQt:
    $Gr = $C5 == "\x74\x65\x73\x74\116\145\x77\x43\145\162\x74\151\146\151\x63\x61\164\x65" ? "\x64\x69\163\x70\x6c\141\x79\x3a\156\157\x6e\x65" : '';
    $Hf = get_site_option("\163\141\x6d\154\137\x61\155\x5f\x61\143\143\x6f\x75\x6e\164\137\x6d\x61\x74\x63\150\145\162") ? get_site_option("\x73\x61\x6d\154\137\x61\x6d\137\141\x63\143\x6f\165\x6e\164\137\155\x61\164\x63\x68\145\162") : "\145\x6d\141\151\x6c";
    if (!($Hf == "\145\155\x61\x69\154" && !filter_var($pJ["\x4e\x61\x6d\145\x49\x44"][0], FILTER_VALIDATE_EMAIL))) {
        goto PNf;
    }
    echo "\x3c\x70\x3e\x3c\146\157\156\x74\x20\x63\x6f\x6c\157\x72\75\42\43\106\x46\60\x30\x30\60\42\x20\x73\164\x79\x6c\145\75\x22\x66\157\156\164\55\x73\x69\x7a\x65\72\x31\64\x70\x74\x22\76\x28\x57\x61\x72\156\x69\x6e\x67\x3a\40\124\150\145\40\x4e\x61\155\145\x49\104\x20\166\x61\x6c\x75\x65\40\x69\x73\x20\x6e\157\164\40\141\40\166\141\x6c\x69\x64\x20\105\155\x61\151\x6c\40\x49\104\x29\74\x2f\x66\x6f\156\x74\x3e\74\x2f\x70\76";
    PNf:
    echo "\74\x73\160\x61\x6e\x20\163\164\171\x6c\x65\x3d\x22\146\x6f\156\164\x2d\x73\x69\172\145\72\61\x34\160\164\73\42\76\x3c\142\x3e\110\x65\x6c\154\157\74\x2f\x62\76\x2c\40" . $kw . "\74\x2f\163\x70\141\x6e\76\74\142\162\57\x3e\x3c\160\40\163\164\171\154\x65\75\x22\146\x6f\156\x74\x2d\x77\145\151\147\150\x74\x3a\x62\x6f\154\x64\73\x66\157\x6e\x74\x2d\163\151\x7a\x65\72\x31\64\160\x74\73\155\x61\x72\147\x69\156\55\x6c\x65\146\164\72\x31\x25\73\x22\76\101\124\x54\122\x49\x42\x55\124\x45\x53\40\x52\105\x43\x45\x49\x56\x45\104\72\x3c\x2f\160\76\xd\12\x20\x20\x20\40\x3c\164\141\x62\x6c\145\x20\163\164\171\x6c\x65\x3d\42\x62\157\162\x64\145\x72\x2d\143\157\x6c\154\141\160\x73\x65\72\143\157\154\154\141\x70\x73\x65\73\142\x6f\x72\144\x65\x72\55\x73\x70\141\x63\151\x6e\147\x3a\x30\x3b\x20\x64\151\163\160\154\141\171\72\x74\x61\x62\154\145\73\167\x69\144\164\150\x3a\x31\60\60\45\x3b\40\146\x6f\156\x74\x2d\x73\151\x7a\x65\72\61\64\x70\164\73\x62\141\x63\x6b\147\162\157\x75\156\144\55\x63\x6f\x6c\x6f\162\x3a\x23\x45\x44\105\x44\105\x44\73\x22\76\15\xa\x20\40\x20\x20\40\x20\40\x20\74\x74\x72\x20\x73\x74\171\x6c\145\x3d\x22\164\145\x78\164\55\141\x6c\151\147\156\x3a\143\145\x6e\164\x65\x72\x3b\x22\x3e\74\164\x64\40\163\x74\x79\154\145\x3d\42\146\157\156\x74\55\x77\x65\151\147\x68\164\72\x62\x6f\x6c\x64\x3b\142\157\162\144\x65\162\72\62\160\x78\x20\x73\x6f\154\x69\x64\40\43\x39\64\x39\x30\x39\60\73\160\141\x64\144\x69\156\147\72\62\x25\x3b\42\76\x41\x54\124\122\x49\102\x55\124\105\40\x4e\101\x4d\105\x3c\57\x74\x64\76\x3c\x74\x64\x20\163\x74\171\154\x65\75\x22\x66\x6f\156\164\x2d\x77\145\x69\x67\x68\164\72\x62\157\154\x64\73\x70\x61\x64\144\151\156\147\72\62\x25\x3b\x62\x6f\162\144\145\x72\72\62\x70\x78\x20\163\x6f\x6c\x69\144\x20\43\x39\64\x39\x30\x39\x30\73\x20\x77\157\x72\x64\x2d\x77\162\x61\160\x3a\x62\162\145\141\x6b\55\x77\x6f\162\144\73\42\x3e\x41\124\124\122\x49\x42\125\x54\105\x20\126\101\114\125\x45\74\57\164\144\76\x3c\57\164\x72\76";
    if (!empty($pJ)) {
        goto vDf;
    }
    echo "\x4e\157\40\x41\x74\164\162\x69\142\x75\x74\x65\163\x20\x52\145\x63\x65\x69\166\x65\x64\56";
    goto Gtq;
    vDf:
    foreach ($pJ as $xk => $Fh) {
        echo "\x3c\164\162\76\x3c\164\144\x20\x73\x74\x79\154\x65\x3d\47\x66\157\x6e\x74\x2d\x77\145\151\x67\x68\x74\72\x62\x6f\154\x64\73\142\157\162\x64\145\x72\72\62\160\x78\x20\163\x6f\x6c\x69\144\x20\x23\x39\64\x39\60\71\x30\x3b\160\x61\x64\x64\x69\x6e\147\72\x32\45\73\x27\76" . $xk . "\74\x2f\x74\144\76\x3c\x74\144\x20\163\164\x79\154\145\75\47\160\x61\x64\x64\151\156\147\72\62\45\73\x62\157\162\144\145\x72\x3a\x32\x70\x78\40\x73\x6f\x6c\x69\x64\40\x23\x39\64\71\60\71\60\73\40\167\x6f\162\144\x2d\167\162\141\x70\x3a\x62\x72\x65\x61\153\x2d\x77\157\162\144\x3b\47\x3e" . implode("\x3c\x68\162\57\x3e", $Fh) . "\x3c\57\x74\144\76\74\57\x74\x72\76";
        ejS:
    }
    Bre:
    Gtq:
    echo "\x3c\x2f\164\x61\142\154\145\76\x3c\57\144\151\x76\76";
    echo "\74\144\x69\x76\40\163\164\x79\154\x65\75\42\155\x61\162\x67\x69\x6e\x3a\x33\x25\73\144\x69\x73\x70\x6c\141\x79\72\142\154\x6f\143\x6b\73\x74\x65\170\164\55\141\x6c\x69\x67\x6e\x3a\x63\145\x6e\x74\145\162\73\42\76\xd\12\x20\40\x20\x20\40\x20\x20\x20\40\x20\x20\x20\74\151\156\x70\x75\x74\x20\x73\x74\171\154\x65\75\42\x70\x61\x64\x64\x69\x6e\147\x3a\x31\45\73\x77\x69\144\x74\150\x3a\x32\65\x30\160\x78\73\x62\141\143\x6b\x67\162\x6f\165\156\x64\72\40\x23\x30\60\x39\61\x43\x44\x20\156\x6f\x6e\x65\x20\162\145\160\x65\x61\164\40\x73\143\162\x6f\x6c\154\40\x30\45\x20\x30\45\73\15\xa\x20\40\40\x20\40\40\x20\x20\x20\x20\x20\x20\x63\x75\162\163\x6f\162\72\40\x70\x6f\151\156\164\x65\x72\73\146\157\156\x74\55\x73\151\x7a\145\72\x31\65\160\x78\73\x62\x6f\x72\144\x65\x72\55\x77\x69\x64\164\x68\x3a\x20\x31\160\170\73\142\157\x72\144\x65\x72\55\163\164\x79\x6c\145\x3a\40\163\157\x6c\151\144\73\x62\x6f\162\144\x65\162\x2d\162\x61\144\151\x75\x73\72\x20\63\x70\x78\73\167\x68\151\x74\145\55\x73\160\x61\143\x65\x3a\15\12\x20\x20\40\40\x20\40\40\x20\x20\40\x20\40\156\157\167\x72\x61\x70\73\x62\x6f\170\x2d\x73\151\x7a\151\156\147\x3a\40\142\x6f\x72\x64\x65\x72\55\x62\157\x78\73\x62\x6f\162\x64\x65\162\x2d\143\157\x6c\x6f\162\x3a\40\43\60\60\67\63\101\101\73\x62\x6f\x78\55\x73\x68\141\144\x6f\x77\x3a\x20\60\160\x78\40\x31\x70\x78\x20\x30\x70\x78\40\x72\x67\x62\x61\50\x31\62\60\x2c\x20\x32\x30\60\54\x20\62\63\60\54\40\x30\x2e\66\51\40\151\156\163\x65\x74\x3b\143\x6f\154\x6f\162\x3a\40\43\x46\x46\x46\x3b" . $Gr . "\x22\xd\12\40\x20\40\40\x20\40\40\40\x20\x20\x20\40\x20\40\x20\40\164\171\x70\145\x3d\42\142\165\x74\x74\157\x6e\x22\x20\166\141\x6c\165\x65\x3d\42\x43\157\156\x66\151\x67\165\x72\145\40\x41\x74\x74\x72\x69\142\165\164\145\x2f\x52\x6f\x6c\145\x20\x4d\x61\160\160\x69\156\x67\x22\x20\157\156\103\x6c\151\143\x6b\75\x22\x63\x6c\157\x73\145\137\141\156\x64\x5f\162\145\x64\x69\x72\x65\143\164\x28\x29\x3b\x22\x3e\40\x26\156\x62\x73\x70\73\40\xd\xa\x20\x20\40\40\x20\40\x20\x20\x20\40\40\x20\x20\x20\x20\40\xd\12\40\x20\40\x20\40\x20\x20\40\x20\40\x20\40\x3c\x69\x6e\160\x75\x74\40\x73\164\171\x6c\145\x3d\x22\160\x61\x64\x64\151\156\x67\x3a\x31\x25\x3b\167\x69\144\x74\150\72\x31\60\60\x70\170\73\142\x61\143\x6b\147\x72\x6f\x75\156\144\72\40\x23\x30\x30\x39\x31\x43\x44\x20\156\157\x6e\145\x20\x72\145\x70\145\141\x74\40\x73\x63\162\157\154\154\x20\60\45\x20\x30\45\x3b\x63\165\162\x73\x6f\x72\72\x20\x70\157\x69\x6e\164\145\x72\73\x66\157\156\x74\55\x73\151\x7a\x65\x3a\61\65\160\x78\73\142\x6f\162\x64\145\162\55\167\x69\x64\164\150\x3a\x20\x31\160\x78\x3b\142\x6f\x72\144\145\x72\x2d\x73\x74\x79\154\x65\x3a\x20\x73\157\x6c\x69\144\73\x62\x6f\162\x64\145\162\x2d\x72\x61\x64\x69\x75\x73\x3a\40\63\x70\170\73\167\150\x69\x74\145\55\x73\160\141\x63\x65\x3a\40\156\x6f\x77\162\x61\x70\x3b\x62\x6f\x78\55\x73\151\172\151\x6e\147\x3a\40\142\x6f\x72\144\x65\162\55\x62\157\x78\x3b\142\x6f\162\x64\x65\x72\x2d\143\157\x6c\157\x72\72\40\43\60\60\x37\63\101\x41\x3b\142\x6f\170\x2d\163\150\x61\x64\157\x77\x3a\40\x30\x70\170\40\x31\160\x78\x20\60\160\170\x20\x72\x67\x62\x61\50\x31\62\x30\54\x20\x32\x30\x30\54\x20\62\63\60\54\x20\60\56\66\51\40\151\x6e\x73\x65\x74\x3b\x63\157\x6c\x6f\x72\72\x20\x23\106\106\106\73\x22\x74\171\x70\145\75\42\x62\x75\164\x74\x6f\156\42\x20\x76\x61\x6c\165\x65\75\42\104\157\156\x65\x22\x20\x6f\156\103\x6c\x69\x63\153\x3d\x22\163\145\154\146\56\143\154\x6f\x73\x65\x28\x29\x3b\x22\x3e\74\57\x64\x69\166\x3e\15\12\40\40\40\40\40\x20\40\x20\40\40\x20\40\40\x20\40\40\40\40\40\x20\x20\x20\40\40\x20\40\x20\40\x20\40\x20\40\x3c\x73\143\162\x69\x70\x74\76\xd\xa\15\xa\x20\x20\x20\40\40\x20\40\40\40\x20\x20\x20\146\x75\156\143\x74\151\x6f\x6e\40\x63\154\157\x73\145\137\141\156\144\137\x72\x65\x64\151\162\x65\x63\164\50\x29\173\15\xa\40\x20\40\40\x20\40\x20\x20\x20\x20\40\40\x20\40\x20\x20\167\x69\156\x64\157\x77\56\x6f\x70\x65\x6e\x65\x72\x2e\162\145\x64\x69\162\x65\143\164\137\164\157\137\x61\164\164\162\x69\x62\165\164\x65\x5f\155\x61\160\160\151\156\147\x28\x29\73\xd\12\40\40\40\x20\40\x20\x20\x20\x20\40\40\40\x20\x20\x20\x20\163\x65\154\146\x2e\x63\154\x6f\163\145\50\x29\73\15\xa\40\x20\x20\40\x20\x20\40\x20\x20\40\40\x20\175\xd\12\x20\40\x20\x20\40\40\x20\40\x20\40\x20\40\xd\12\40\40\x20\40\x20\x20\40\40\40\40\x20\40\x66\x75\x6e\x63\x74\151\157\x6e\40\162\145\146\x72\x65\163\150\120\x61\x72\145\x6e\x74\50\51\40\173\xd\xa\x20\40\40\40\x20\x20\x20\x20\x20\x20\40\40\40\x20\40\40\167\x69\x6e\x64\x6f\167\x2e\157\160\145\x6e\145\x72\x2e\x6c\x6f\x63\141\164\151\x6f\156\x2e\x72\145\154\x6f\x61\x64\x28\x29\73\15\12\40\40\x20\x20\40\40\40\40\x20\x20\x20\x20\x7d\xd\xa\x20\x20\40\40\40\x20\x20\40\x20\40\40\40\x3c\57\x73\143\162\151\160\164\x3e";
    exit;
}
function mo_saml_convert_to_windows_iconv($Tj)
{
    $ne = get_site_option("\155\x6f\137\x73\x61\x6d\154\x5f\x65\156\x63\157\x64\151\x6e\147\137\145\156\141\x62\154\x65\x64");
    if (!($ne !== "\x63\150\x65\143\x6b\145\144")) {
        goto Rn7;
    }
    return $Tj;
    Rn7:
    return iconv("\125\x54\x46\x2d\70", "\103\120\61\62\x35\62\x2f\57\x49\107\x4e\117\122\x45", $Tj);
}
function mo_saml_login_user($kw, $hT, $YG, $oP, $RR, $P_, $C5, $ND, $EV = '', $SY = '', $pJ = null)
{
    do_action("\155\157\x5f\141\x62\162\x5f\146\151\154\164\145\162\x5f\x6c\x6f\x67\x69\x6e", $pJ);
    $oP = mo_saml_sanitize_username($oP);
    if (get_site_option("\x6d\x6f\x5f\x73\141\x6d\154\x5f\x64\x69\x73\141\x62\154\x65\x5f\162\157\154\145\x5f\155\141\160\160\x69\x6e\147")) {
        goto gRm;
    }
    check_if_user_allowed_to_login_due_to_role_restriction($RR);
    gRm:
    $C3 = get_site_option("\x6d\157\137\x73\x61\155\154\x5f\x73\x70\x5f\142\141\x73\145\137\x75\162\154");
    mo_saml_restrict_users_based_on_domain($kw);
    if (!empty($P_)) {
        goto aPV;
    }
    $P_["\x44\x45\x46\x41\125\x4c\x54"]["\144\x65\146\x61\165\154\x74\x5f\x72\157\154\145"] = "\x73\x75\x62\163\x63\162\x69\x62\x65\162";
    $P_["\x44\x45\x46\101\125\x4c\124"]["\144\x6f\x6e\x74\137\x61\x6c\154\x6f\x77\137\x75\156\154\151\163\x74\x65\144\x5f\x75\163\145\162"] = '';
    $P_["\x44\105\x46\101\x55\x4c\x54"]["\144\157\x6e\x74\x5f\143\162\145\141\x74\x65\x5f\165\x73\x65\x72"] = '';
    $P_["\104\105\x46\101\125\x4c\124"]["\153\x65\145\160\137\145\x78\151\163\164\x69\156\x67\x5f\165\163\x65\x72\163\x5f\162\157\x6c\145"] = '';
    $P_["\x44\x45\106\x41\125\114\x54"]["\x6d\157\137\163\141\x6d\x6c\x5f\x64\x6f\x6e\164\137\x61\x6c\x6c\157\x77\137\165\x73\145\162\x5f\164\x6f\x6c\157\x67\151\156\x5f\x63\x72\145\141\164\145\x5f\167\151\164\150\137\x67\151\x76\x65\156\137\147\x72\x6f\165\x70\163"] = '';
    $P_["\x44\x45\106\x41\x55\x4c\x54"]["\x6d\x6f\x5f\x73\x61\x6d\154\x5f\x72\145\163\x74\x72\151\x63\164\x5f\x75\163\145\x72\163\137\167\x69\164\150\137\147\x72\x6f\165\x70\163"] = '';
    aPV:
    global $wpdb;
    $KS = get_current_blog_id();
    $wU = "\165\x6e\x63\150\x65\143\x6b\145\x64";
    if (!empty($C3)) {
        goto Pbp;
    }
    $C3 = get_network_site_url();
    Pbp:
    if (email_exists($kw) || username_exists($oP)) {
        goto CEX;
    }
    $gw = Utilities::get_active_sites();
    $cR = get_site_option("\x6d\157\137\x61\x70\x70\x6c\171\137\162\x6f\x6c\x65\x5f\155\141\x70\160\x69\156\x67\137\x66\157\x72\137\163\151\164\145\x73");
    if (!get_site_option("\x6d\x6f\x5f\x73\141\155\x6c\137\x64\x69\x73\x61\142\x6c\x65\137\x72\157\x6c\x65\137\x6d\141\160\x70\151\156\x67")) {
        goto pgW;
    }
    $V7 = wp_generate_password(12, false);
    $v0 = wpmu_create_user($oP, $V7, $kw);
    goto tmn;
    pgW:
    $v0 = mo_saml_assign_roles_to_new_user($gw, $cR, $P_, $RR, $oP, $kw);
    tmn:
    switch_to_blog($KS);
    if (!empty($v0)) {
        goto Khq;
    }
    if (!get_site_option("\155\157\x5f\163\x61\155\x6c\x5f\x64\151\163\x61\142\x6c\x65\x5f\x72\x6f\154\x65\x5f\x6d\141\160\x70\151\156\147")) {
        goto PgR;
    }
    wp_die("\127\x65\40\143\x6f\x75\x6c\x64\x20\156\x6f\164\x20\163\151\147\156\x20\171\x6f\165\x20\151\x6e\56\x20\120\x6c\x65\141\x73\145\x20\x63\157\156\x74\141\x63\x74\40\141\144\155\151\x6e\x69\163\x74\162\x61\x74\x6f\x72", "\114\157\147\x69\x6e\40\106\x61\x69\154\x65\x64\x21");
    goto D7I;
    PgR:
    $qk = get_site_option("\x6d\x6f\137\x73\141\155\x6c\137\141\143\x63\157\165\156\164\x5f\143\162\145\141\x74\x69\x6f\156\137\144\151\163\x61\x62\154\x65\144\x5f\x6d\163\x67");
    if (!empty($qk)) {
        goto z_R;
    }
    $qk = "\127\145\40\x63\x6f\x75\154\x64\40\156\x6f\164\x20\x73\151\x67\156\x20\x79\157\165\40\151\156\x2e\40\x50\x6c\x65\x61\163\x65\x20\x63\157\156\164\x61\143\164\x20\x79\157\x75\162\40\x41\x64\x6d\151\x6e\151\163\164\x72\141\164\157\162\x2e";
    z_R:
    wp_die($qk, "\x45\162\x72\157\162\x3a\40\116\x6f\164\40\141\40\x57\x6f\x72\144\x50\162\x65\x73\x73\x20\x4d\145\155\142\x65\x72");
    D7I:
    Khq:
    $user = get_user_by("\x69\x64", $v0);
    mo_saml_map_basic_attributes($user, $hT, $YG, $pJ);
    mo_saml_map_custom_attributes($v0, $pJ);
    $wG = mo_saml_get_redirect_url($C3, $C5);
    do_action("\x6d\x69\x6e\x69\x6f\x72\x61\x6e\147\145\x5f\160\x6f\x73\164\137\141\165\x74\x68\145\156\x74\x69\x63\x61\x74\145\x5f\x75\x73\145\162\x5f\154\x6f\x67\151\x6e", $user, null, $wG, true);
    mo_saml_set_auth_cookie($user, $EV, $SY, true);
    do_action("\x6d\x6f\137\163\x61\x6d\x6c\x5f\141\164\164\162\x69\x62\x75\164\x65\163", $oP, $kw, $hT, $YG, $RR, null, true);
    goto AnL;
    CEX:
    if (email_exists($kw)) {
        goto Pu6;
    }
    $user = get_user_by("\x6c\x6f\x67\x69\156", $oP);
    goto sIl;
    Pu6:
    $user = get_user_by("\145\x6d\141\x69\154", $kw);
    sIl:
    $v0 = $user->ID;
    if (!(!empty($kw) and strcasecmp($kw, $user->user_email) != 0)) {
        goto FKg;
    }
    $v0 = wp_update_user(array("\111\x44" => $v0, "\x75\163\x65\x72\137\145\x6d\141\151\x6c" => $kw));
    FKg:
    mo_saml_map_basic_attributes($user, $hT, $YG, $pJ);
    mo_saml_map_custom_attributes($v0, $pJ);
    $gw = Utilities::get_active_sites();
    $cR = get_site_option("\x6d\157\137\x61\x70\160\154\x79\x5f\x72\157\x6c\145\x5f\155\141\160\x70\151\156\147\137\146\157\x72\137\163\151\164\145\x73");
    if (get_site_option("\x6d\x6f\x5f\163\141\155\154\x5f\x64\x69\163\141\x62\x6c\145\x5f\162\157\x6c\x65\x5f\155\141\160\160\x69\156\147")) {
        goto CEv;
    }
    foreach ($gw as $blog_id) {
        switch_to_blog($blog_id);
        $user = get_user_by("\x69\144", $v0);
        $N2 = '';
        if ($cR) {
            goto M2p;
        }
        $N2 = $blog_id;
        goto wIe;
        M2p:
        $N2 = 0;
        wIe:
        if (empty($P_)) {
            goto pil;
        }
        if (!empty($P_[$N2])) {
            goto XaF;
        }
        if (!empty($P_["\x44\x45\x46\101\x55\114\124"])) {
            goto eMv;
        }
        $zB = "\x73\165\x62\163\x63\162\151\142\x65\162";
        $NB = '';
        $wU = '';
        $CE = '';
        goto Qeo;
        eMv:
        $zB = isset($P_["\104\105\106\101\125\x4c\x54"]["\x64\x65\146\x61\165\x6c\x74\137\162\x6f\x6c\x65"]) ? $P_["\104\x45\x46\x41\125\x4c\124"]["\x64\x65\146\x61\165\154\164\x5f\x72\157\154\x65"] : "\x73\165\142\163\143\162\x69\x62\145\162";
        $NB = isset($P_["\x44\x45\106\101\x55\114\x54"]["\144\x6f\x6e\164\x5f\141\154\154\x6f\167\137\x75\x6e\154\151\x73\x74\145\144\137\165\163\145\162"]) ? $P_["\x44\x45\x46\101\125\114\x54"]["\144\157\156\x74\137\141\x6c\154\157\x77\137\x75\156\154\151\x73\164\x65\x64\137\165\163\145\x72"] : '';
        $wU = isset($P_["\104\105\106\101\125\x4c\x54"]["\x64\x6f\156\x74\x5f\143\162\145\x61\164\x65\137\165\x73\x65\x72"]) ? $P_["\104\x45\106\101\125\x4c\x54"]["\x64\x6f\x6e\x74\x5f\x63\162\145\141\x74\145\x5f\x75\163\x65\162"] : '';
        $CE = isset($P_["\104\105\x46\101\125\x4c\124"]["\153\x65\145\160\137\x65\x78\x69\163\164\151\x6e\x67\137\165\x73\x65\162\163\137\x72\x6f\x6c\145"]) ? $P_["\x44\x45\106\101\125\114\x54"]["\153\x65\145\160\137\x65\x78\x69\x73\x74\x69\x6e\147\137\165\x73\145\162\x73\x5f\162\157\154\145"] : '';
        Qeo:
        goto W6j;
        XaF:
        $zB = isset($P_[$N2]["\x64\145\x66\141\x75\x6c\x74\x5f\162\157\x6c\145"]) ? $P_[$N2]["\x64\x65\146\141\x75\154\x74\x5f\162\157\154\x65"] : '';
        $NB = isset($P_[$N2]["\144\157\156\x74\x5f\x61\x6c\x6c\157\x77\x5f\x75\156\x6c\x69\163\164\145\144\x5f\x75\x73\145\162"]) ? $P_[$N2]["\x64\157\156\x74\137\141\x6c\x6c\157\x77\137\x75\x6e\x6c\151\x73\164\145\x64\x5f\165\x73\145\162"] : '';
        $wU = isset($P_[$N2]["\144\157\156\164\137\143\162\x65\141\x74\x65\137\x75\163\x65\x72"]) ? $P_[$N2]["\x64\x6f\156\x74\x5f\x63\x72\x65\141\x74\145\x5f\165\163\x65\x72"] : '';
        $CE = isset($P_[$N2]["\x6b\x65\x65\x70\137\x65\x78\151\x73\x74\x69\156\147\137\165\163\145\x72\x73\x5f\x72\x6f\154\145"]) ? $P_[$N2]["\x6b\x65\145\160\x5f\x65\x78\151\x73\x74\151\156\x67\137\x75\x73\145\162\163\137\x72\x6f\x6c\x65"] : '';
        W6j:
        pil:
        if (!is_user_member_of_blog($v0, $blog_id)) {
            goto u4M;
        }
        if (isset($CE) && $CE == "\143\150\145\x63\153\x65\144") {
            goto app;
        }
        $D7 = assign_roles_to_user($user, $P_, $blog_id, $RR, $N2);
        goto FAd;
        app:
        $D7 = false;
        FAd:
        if (is_administrator_user($user)) {
            goto Dp9;
        }
        if (isset($CE) && $CE == "\143\150\x65\x63\153\x65\x64") {
            goto Rv8;
        }
        if ($D7 !== true && !empty($NB) && $NB == "\143\x68\x65\x63\x6b\x65\x64") {
            goto lUE;
        }
        if ($D7 !== true && !empty($zB) && $zB !== "\x66\141\154\x73\x65") {
            goto GHx;
        }
        if ($D7 !== true && is_user_member_of_blog($v0, $blog_id)) {
            goto Hjn;
        }
        goto HmE;
        Rv8:
        goto HmE;
        lUE:
        $v0 = wp_update_user(array("\111\104" => $v0, "\x72\x6f\x6c\145" => false));
        goto HmE;
        GHx:
        $v0 = wp_update_user(array("\111\x44" => $v0, "\162\157\154\145" => $zB));
        goto HmE;
        Hjn:
        $fg = get_site_option("\x64\x65\146\141\165\x6c\164\137\x72\x6f\x6c\x65");
        $v0 = wp_update_user(array("\x49\x44" => $v0, "\x72\157\154\145" => $fg));
        HmE:
        Dp9:
        goto M5N;
        u4M:
        $tl = TRUE;
        $h6 = get_site_option("\x73\141\x6d\154\x5f\x73\163\x6f\137\x73\x65\x74\x74\151\156\147\x73");
        if (!empty($h6[$blog_id])) {
            goto S5o;
        }
        $h6[$blog_id] = $h6["\x44\105\106\101\x55\114\124"];
        S5o:
        if (empty($P_)) {
            goto sJQ;
        }
        if (array_key_exists($N2, $P_)) {
            goto d3V;
        }
        if (!array_key_exists("\x44\105\106\x41\x55\x4c\x54", $P_)) {
            goto FLJ;
        }
        $rt = get_saml_roles_to_assign($P_, $N2, $RR);
        if (!(empty($rt) && strcmp($P_["\x44\x45\x46\x41\x55\114\124"]["\144\x6f\x6e\x74\x5f\143\x72\145\x61\x74\x65\x5f\x75\x73\x65\162"], "\143\150\145\143\x6b\145\x64") == 0)) {
            goto CKo;
        }
        $tl = FALSE;
        CKo:
        FLJ:
        goto qOJ;
        d3V:
        $rt = get_saml_roles_to_assign($P_, $N2, $RR);
        if (!(empty($rt) && strcmp($P_[$N2]["\144\x6f\x6e\164\137\143\x72\x65\141\164\145\137\165\163\145\x72"], "\143\x68\145\x63\x6b\x65\144") == 0)) {
            goto a9X;
        }
        $tl = FALSE;
        a9X:
        qOJ:
        sJQ:
        if (!$tl) {
            goto Wlh;
        }
        add_user_to_blog($blog_id, $v0, false);
        $D7 = assign_roles_to_user($user, $P_, $blog_id, $RR, $N2);
        if ($D7 !== true && !empty($NB) && $NB == "\143\150\x65\x63\153\x65\x64") {
            goto DAq;
        }
        if ($D7 !== true && !empty($zB) && $zB !== "\x66\141\x6c\x73\145") {
            goto dDl;
        }
        if ($D7 !== true) {
            goto olV;
        }
        goto GM0;
        DAq:
        $v0 = wp_update_user(array("\x49\104" => $v0, "\162\x6f\x6c\145" => false));
        goto GM0;
        dDl:
        $v0 = wp_update_user(array("\x49\x44" => $v0, "\162\x6f\x6c\145" => $zB));
        goto GM0;
        olV:
        $fg = get_site_option("\144\x65\146\x61\x75\154\x74\137\162\x6f\x6c\x65");
        $v0 = wp_update_user(array("\111\104" => $v0, "\162\x6f\x6c\145" => $fg));
        GM0:
        Wlh:
        M5N:
        G6V:
    }
    yaO:
    CEv:
    switch_to_blog($KS);
    if ($v0) {
        goto vku;
    }
    wp_die("\x49\156\166\x61\154\151\144\40\x75\163\145\162\56\x20\120\154\x65\x61\163\145\40\164\x72\171\40\x61\x67\x61\151\156\x2e");
    vku:
    $user = get_user_by("\x69\144", $v0);
    mo_saml_set_auth_cookie($user, $EV, $SY, true);
    do_action("\x6d\157\x5f\x73\x61\x6d\154\x5f\141\x74\164\x72\x69\142\x75\x74\145\163", $oP, $kw, $hT, $YG, $RR);
    AnL:
    mo_saml_post_login_redirection($C3, $C5);
}
function mo_saml_add_user_to_blog($kw, $oP, $blog_id = 0)
{
    if (email_exists($kw)) {
        goto OyH;
    }
    if (!empty($oP)) {
        goto n8J;
    }
    $v0 = mo_saml_create_user($kw, $kw, $blog_id);
    goto pno;
    n8J:
    $v0 = mo_saml_create_user($oP, $kw, $blog_id);
    pno:
    goto J72;
    OyH:
    $user = get_user_by("\x65\155\141\x69\154", $kw);
    $v0 = $user->ID;
    if (empty($blog_id)) {
        goto mYJ;
    }
    add_user_to_blog($blog_id, $v0, false);
    mYJ:
    J72:
    return $v0;
}
function mo_saml_create_user($oP, $kw, $blog_id)
{
    $je = wp_generate_password(10, false);
    if (username_exists($oP)) {
        goto AL7;
    }
    $v0 = wp_create_user($oP, $je, $kw);
    goto bnV;
    AL7:
    $user = get_user_by("\154\157\x67\x69\x6e", $oP);
    $v0 = $user->ID;
    if (!$blog_id) {
        goto JqQ;
    }
    add_user_to_blog($blog_id, $v0, false);
    JqQ:
    bnV:
    if (!is_wp_error($v0)) {
        goto Hd7;
    }
    echo "\74\163\x74\x72\157\x6e\147\x3e\105\122\122\x4f\122\x3c\x2f\163\x74\x72\x6f\x6e\147\76\x3a\40\105\155\160\x74\171\40\125\163\145\162\x20\x4e\x61\155\x65\x20\141\x6e\144\x20\x45\155\x61\x69\154\x2e\40\x50\x6c\145\141\x73\145\x20\x63\157\156\164\141\x63\x74\x20\x79\157\x75\162\x20\141\144\155\x69\156\x69\163\164\162\x61\x74\x6f\162\x2e";
    exit;
    Hd7:
    return $v0;
}
function mo_saml_assign_roles_to_new_user($gw, $cR, $P_, $RR, $oP, $kw)
{
    global $wpdb;
    $user = NULL;
    $Xy = false;
    foreach ($gw as $blog_id) {
        $mV = TRUE;
        $N2 = '';
        if ($cR) {
            goto fq7;
        }
        $N2 = $blog_id;
        goto SxI;
        fq7:
        $N2 = 0;
        SxI:
        $h6 = get_site_option("\163\x61\x6d\x6c\137\163\163\157\x5f\163\x65\x74\x74\x69\x6e\147\163");
        if (!empty($h6[$blog_id])) {
            goto HIh;
        }
        $h6[$blog_id] = $h6["\x44\105\x46\x41\125\114\124"];
        HIh:
        if (empty($P_)) {
            goto eP_;
        }
        if (!empty($P_[$N2])) {
            goto ntk;
        }
        if (!empty($P_["\104\x45\106\x41\x55\114\x54"])) {
            goto IHx;
        }
        $zB = "\x73\165\142\163\x63\162\151\142\x65\162";
        $NB = '';
        $CE = '';
        $rt = '';
        goto efP;
        IHx:
        $zB = isset($P_["\x44\105\106\101\x55\114\x54"]["\144\145\x66\x61\x75\x6c\164\x5f\162\x6f\154\x65"]) ? $P_["\104\x45\106\x41\x55\114\x54"]["\x64\x65\x66\141\x75\154\164\137\162\157\x6c\x65"] : '';
        $NB = isset($P_["\x44\105\106\101\125\x4c\124"]["\144\x6f\156\x74\x5f\141\x6c\154\x6f\x77\x5f\x75\x6e\x6c\151\163\164\x65\144\137\165\x73\145\x72"]) ? $P_["\104\105\x46\x41\x55\114\x54"]["\144\x6f\x6e\164\x5f\x61\154\154\x6f\167\137\x75\x6e\154\x69\x73\164\145\x64\x5f\x75\x73\145\x72"] : '';
        $CE = array_key_exists("\x6b\145\x65\x70\x5f\145\170\151\x73\164\x69\x6e\x67\137\165\x73\145\x72\163\137\x72\x6f\x6c\145", $P_["\104\x45\106\x41\x55\114\x54"]) ? $P_["\104\105\x46\101\125\x4c\124"]["\x6b\145\145\x70\x5f\x65\x78\151\163\x74\x69\x6e\147\x5f\165\x73\145\162\x73\137\162\157\x6c\x65"] : '';
        $rt = get_saml_roles_to_assign($P_, $N2, $RR);
        if (!(empty($rt) && strcmp($P_["\104\x45\x46\101\125\114\x54"]["\x64\157\156\x74\137\143\x72\x65\x61\164\x65\x5f\x75\x73\145\162"], "\x63\150\145\x63\x6b\145\144") == 0)) {
            goto ESq;
        }
        $mV = FALSE;
        ESq:
        efP:
        goto Yqh;
        ntk:
        $zB = isset($P_[$N2]["\x64\x65\x66\x61\x75\x6c\164\x5f\162\x6f\x6c\145"]) ? $P_[$N2]["\144\145\146\141\x75\x6c\x74\137\162\x6f\154\145"] : '';
        $NB = isset($P_[$N2]["\144\x6f\x6e\164\x5f\x61\x6c\154\x6f\x77\137\165\156\154\x69\x73\164\145\x64\137\165\x73\145\x72"]) ? $P_[$N2]["\144\157\x6e\x74\x5f\x61\154\x6c\157\x77\137\165\156\x6c\x69\163\x74\145\144\x5f\165\163\x65\x72"] : '';
        $CE = array_key_exists("\x6b\145\145\160\x5f\145\x78\151\x73\164\x69\x6e\x67\137\165\163\145\x72\x73\137\x72\x6f\154\145", $P_[$N2]) ? $P_[$N2]["\x6b\x65\x65\x70\137\x65\x78\x69\163\x74\151\x6e\147\137\x75\163\145\x72\x73\x5f\162\x6f\x6c\x65"] : '';
        $rt = get_saml_roles_to_assign($P_, $N2, $RR);
        if (!(empty($rt) && strcmp($P_[$N2]["\x64\x6f\156\164\137\x63\x72\145\141\164\145\137\165\163\145\x72"], "\x63\150\145\143\x6b\x65\x64") == 0)) {
            goto l2G;
        }
        $mV = FALSE;
        l2G:
        Yqh:
        eP_:
        if (!$mV) {
            goto S_1;
        }
        $v0 = NULL;
        switch_to_blog($blog_id);
        $v0 = mo_saml_add_user_to_blog($kw, $oP, $blog_id);
        $user = get_user_by("\x69\x64", $v0);
        $D7 = assign_roles_to_user($user, $P_, $blog_id, $RR, $N2);
        if ($D7 !== true && !empty($NB) && $NB == "\143\x68\x65\x63\x6b\x65\x64") {
            goto Bdt;
        }
        if ($D7 !== true && !empty($zB) && $zB !== "\146\141\x6c\163\x65") {
            goto Dbs;
        }
        if ($D7 !== true) {
            goto dIc;
        }
        goto pe0;
        Bdt:
        $v0 = wp_update_user(array("\111\x44" => $v0, "\162\x6f\x6c\145" => false));
        goto pe0;
        Dbs:
        $v0 = wp_update_user(array("\x49\x44" => $v0, "\162\157\x6c\x65" => $zB));
        goto pe0;
        dIc:
        $fg = get_site_option("\144\145\146\x61\165\154\164\x5f\162\x6f\154\x65");
        $v0 = wp_update_user(array("\x49\x44" => $v0, "\162\x6f\x6c\145" => $fg));
        pe0:
        $ME = $user->{$wpdb->prefix . "\143\141\x70\x61\x62\151\x6c\x69\x74\151\x65\x73"};
        if (isset($wp_roles)) {
            goto PYF;
        }
        $wp_roles = new WP_Roles($N2);
        PYF:
        S_1:
        pij:
    }
    csK:
    if (!empty($user)) {
        goto gfb;
    }
    return;
    goto ISr;
    gfb:
    return $user->ID;
    ISr:
}
function mo_saml_sanitize_username($oP)
{
    $QE = sanitize_user($oP, true);
    $a3 = apply_filters("\160\162\x65\x5f\165\163\x65\x72\x5f\x6c\157\147\x69\x6e", $QE);
    $oP = trim($a3);
    return $oP;
}
function mo_saml_map_basic_attributes($user, $hT, $YG, $pJ)
{
    $v0 = $user->ID;
    if (empty($hT)) {
        goto tjJ;
    }
    $v0 = wp_update_user(array("\x49\104" => $v0, "\146\x69\x72\x73\164\x5f\156\x61\155\x65" => $hT));
    tjJ:
    if (empty($YG)) {
        goto FlD;
    }
    $v0 = wp_update_user(array("\111\x44" => $v0, "\154\141\x73\164\137\x6e\x61\x6d\x65" => $YG));
    FlD:
    if (is_null($pJ)) {
        goto ndh;
    }
    update_user_meta($v0, "\155\157\137\x73\141\x6d\x6c\137\165\x73\x65\x72\137\141\x74\x74\162\151\x62\x75\164\x65\163", $pJ);
    $Mm = get_site_option("\x73\141\x6d\x6c\137\x61\155\137\x64\x69\x73\160\154\141\171\x5f\156\141\155\x65");
    if (empty($Mm)) {
        goto ixE;
    }
    if (strcmp($Mm, "\x55\x53\x45\x52\x4e\101\115\105") == 0) {
        goto CLq;
    }
    if (strcmp($Mm, "\x46\x4e\x41\x4d\x45") == 0 && !empty($hT)) {
        goto K2z;
    }
    if (strcmp($Mm, "\114\116\101\x4d\105") == 0 && !empty($YG)) {
        goto xjC;
    }
    if (strcmp($Mm, "\x46\x4e\x41\115\x45\x5f\114\116\101\115\105") == 0 && !empty($YG) && !empty($hT)) {
        goto MHn;
    }
    if (!(strcmp($Mm, "\x4c\116\x41\115\x45\x5f\106\116\x41\x4d\105") == 0 && !empty($YG) && !empty($hT))) {
        goto wi2;
    }
    $v0 = wp_update_user(array("\x49\x44" => $v0, "\144\x69\x73\160\154\141\x79\137\156\x61\155\x65" => $YG . "\40" . $hT));
    wi2:
    goto eND;
    MHn:
    $v0 = wp_update_user(array("\x49\104" => $v0, "\x64\151\163\x70\154\141\171\137\x6e\x61\155\x65" => $hT . "\40" . $YG));
    eND:
    goto BoH;
    xjC:
    $v0 = wp_update_user(array("\111\x44" => $v0, "\x64\x69\x73\x70\154\x61\x79\x5f\156\141\155\145" => $YG));
    BoH:
    goto tbA;
    K2z:
    $v0 = wp_update_user(array("\x49\x44" => $v0, "\x64\151\163\160\x6c\x61\x79\x5f\156\x61\x6d\145" => $hT));
    tbA:
    goto st4;
    CLq:
    $v0 = wp_update_user(array("\111\x44" => $v0, "\x64\151\163\160\154\x61\171\x5f\156\141\155\145" => $user->user_login));
    st4:
    ixE:
    ndh:
}
function mo_saml_map_custom_attributes($v0, $pJ)
{
    if (!get_site_option("\155\x6f\x5f\163\x61\x6d\x6c\137\x63\165\163\x74\x6f\x6d\137\141\x74\x74\162\x73\137\155\x61\x70\160\x69\x6e\147")) {
        goto Oyx;
    }
    $fj = maybe_unserialize(get_site_option("\x6d\157\x5f\163\141\x6d\x6c\137\x63\x75\163\x74\x6f\155\137\x61\164\164\162\163\137\155\x61\160\160\151\x6e\x67"));
    foreach ($fj as $xk => $Fh) {
        if (!array_key_exists($Fh, $pJ)) {
            goto ENU;
        }
        $ho = false;
        if (!(count($pJ[$Fh]) == 1)) {
            goto X0l;
        }
        $ho = true;
        X0l:
        if (!$ho) {
            goto nMd;
        }
        update_user_meta($v0, $xk, $pJ[$Fh][0]);
        goto a0j;
        nMd:
        $wS = array();
        foreach ($pJ[$Fh] as $Ri) {
            array_push($wS, $Ri);
            F_a:
        }
        NTn:
        update_user_meta($v0, $xk, $wS);
        a0j:
        ENU:
        wnK:
    }
    hxz:
    Oyx:
}
function mo_saml_restrict_users_based_on_domain($kw)
{
    $Oz = get_site_option("\155\x6f\x5f\163\x61\x6d\154\137\145\156\x61\142\154\145\137\x64\x6f\155\x61\x69\x6e\x5f\162\x65\163\164\x72\x69\143\x74\151\157\x6e\x5f\x6c\157\147\x69\156");
    if (!$Oz) {
        goto wmW;
    }
    $Zd = get_site_option("\163\141\x6d\154\x5f\141\155\x5f\x65\155\141\151\154\137\x64\x6f\x6d\141\151\x6e\163");
    $eq = explode("\73", $Zd);
    $if = explode("\100", $kw);
    $as = array_key_exists("\x31", $if) ? $if[1] : '';
    $nY = get_site_option("\155\x6f\x5f\x73\141\155\x6c\x5f\141\x6c\154\157\167\137\144\x65\x6e\x79\137\x75\x73\145\162\137\x77\x69\x74\150\137\144\157\x6d\141\151\x6e");
    $qk = get_site_option("\155\157\x5f\x73\141\155\154\137\162\x65\163\x74\162\151\x63\x74\145\144\x5f\x64\157\x6d\141\x69\x6e\137\145\162\162\157\162\137\x6d\163\x67");
    if (!empty($qk)) {
        goto PSG;
    }
    $qk = "\131\x6f\x75\40\141\x72\x65\x20\156\x6f\164\x20\x61\x6c\x6c\x6f\x77\x65\x64\40\x74\x6f\x20\154\x6f\x67\151\156\56\x20\120\x6c\145\x61\x73\x65\x20\x63\157\156\x74\141\143\164\x20\x79\157\x75\x72\40\101\x64\155\x69\x6e\x69\163\x74\162\141\164\157\162\56";
    PSG:
    if (!empty($nY) && $nY == "\144\145\156\x79") {
        goto UQn;
    }
    if (in_array($as, $eq)) {
        goto THW;
    }
    wp_die($qk, "\120\145\162\155\x69\163\x73\x69\157\x6e\40\104\145\156\151\x65\144\x20\x45\162\162\157\x72\40\x2d\40\62");
    THW:
    goto oyr;
    UQn:
    if (!in_array($as, $eq)) {
        goto Ho0;
    }
    wp_die($qk, "\x50\145\x72\155\x69\x73\x73\x69\157\x6e\40\x44\145\x6e\151\145\x64\40\x45\x72\x72\157\162\x20\x2d\40\61");
    Ho0:
    oyr:
    wmW:
}
function mo_saml_set_auth_cookie($user, $EV, $SY, $x1)
{
    $v0 = $user->ID;
    do_action("\167\x70\x5f\x6c\x6f\x67\x69\156", $user->user_login, $user);
    if (empty($EV)) {
        goto AGw;
    }
    update_user_meta($v0, "\155\157\137\x73\x61\x6d\x6c\137\x73\x65\163\x73\151\x6f\156\137\x69\x6e\144\x65\170", $EV);
    AGw:
    if (empty($SY)) {
        goto ueI;
    }
    update_user_meta($v0, "\155\157\x5f\x73\x61\x6d\x6c\137\x6e\x61\x6d\x65\137\x69\x64", $SY);
    ueI:
    if (!(!session_id() || session_id() == '' || !isset($_SESSION))) {
        goto x0y;
    }
    session_start();
    x0y:
    $_SESSION["\x6d\157\137\x73\x61\155\x6c"]["\x6c\x6f\147\147\145\x64\137\x69\156\x5f\167\151\x74\150\137\x69\144\160"] = TRUE;
    update_user_meta($v0, "\x6d\x6f\x5f\163\x61\155\x6c\137\x69\x64\x70\137\x6c\x6f\x67\x69\156", "\164\162\165\x65");
    wp_set_current_user($v0);
    $Ry = false;
    $Ry = apply_filters("\x6d\157\x5f\162\x65\x6d\145\155\x62\145\162\x5f\x6d\x65", $Ry);
    wp_set_auth_cookie($v0, $Ry);
    if (!$x1) {
        goto uV0;
    }
    do_action("\165\x73\145\x72\137\162\x65\147\151\x73\x74\145\x72", $v0);
    uV0:
}
function mo_saml_post_login_redirection($C3, $C5)
{
    $HE = mo_saml_get_redirect_url($C3, $C5);
    wp_redirect($HE);
    exit;
}
function mo_saml_get_redirect_url($C3, $C5)
{
    $wG = '';
    $h6 = get_site_option("\x73\141\x6d\154\137\x73\x73\157\137\163\145\164\x74\151\x6e\147\163");
    $nV = get_current_blog_id();
    if (!(empty($h6[$nV]) && !empty($h6["\x44\105\x46\101\x55\114\x54"]))) {
        goto Kx_;
    }
    $h6[$nV] = $h6["\104\105\x46\x41\125\x4c\x54"];
    Kx_:
    $w1 = isset($h6[$nV]["\x6d\x6f\137\x73\x61\155\x6c\x5f\x72\x65\154\141\171\137\x73\x74\141\164\x65"]) ? $h6[$nV]["\x6d\157\137\163\x61\x6d\x6c\137\x72\x65\154\141\171\x5f\x73\x74\141\x74\145"] : '';
    if (!empty($w1)) {
        goto b9t;
    }
    if (!empty($C5)) {
        goto ayI;
    }
    $wG = $C3;
    goto W52;
    ayI:
    $wG = $C5;
    W52:
    goto HT6;
    b9t:
    $wG = $w1;
    HT6:
    return $wG;
}
function check_if_user_allowed_to_login($user, $C3)
{
    $v0 = $user->ID;
    global $wpdb;
    if (get_user_meta($v0, "\155\x6f\137\163\141\155\x6c\137\x75\x73\145\162\x5f\164\171\x70\145", true)) {
        goto ROz;
    }
    if (get_site_option("\155\x6f\x5f\163\141\x6d\x6c\137\165\163\162\x5f\154\x6d\x74")) {
        goto t_X;
    }
    update_user_meta($v0, "\155\157\137\x73\141\x6d\x6c\x5f\165\163\x65\x72\x5f\164\171\x70\145", "\x73\x73\157\x5f\165\163\145\x72");
    goto tvQ;
    t_X:
    $xk = get_site_option("\x6d\x6f\137\163\x61\x6d\154\x5f\143\x75\x73\164\157\155\x65\162\137\x74\157\x6b\145\x6e");
    $lC = AESEncryption::decrypt_data(get_site_option("\155\157\x5f\163\141\155\x6c\137\165\163\162\x5f\154\x6d\164"), $xk);
    $wF = "\123\x45\x4c\x45\103\x54\40\103\x4f\125\116\x54\x28\x2a\x29\x20\x46\x52\x4f\x4d\x20" . $wpdb->prefix . "\165\163\145\x72\x6d\x65\x74\141\40\127\110\105\122\105\x20\155\145\164\141\x5f\x6b\145\171\75\x27\x6d\157\137\163\141\x6d\x6c\x5f\x75\163\145\162\137\164\171\160\x65\x27";
    $hz = $wpdb->get_var($wF);
    if ($hz >= $lC) {
        goto eZd;
    }
    update_user_meta($v0, "\155\157\x5f\163\141\155\x6c\x5f\165\163\x65\162\x5f\164\x79\x70\x65", "\163\163\x6f\x5f\x75\x73\x65\162");
    goto zDQ;
    eZd:
    if (get_site_option("\165\163\145\x72\x5f\x61\x6c\x65\x72\x74\x5f\x65\155\141\x69\154\137\x73\x65\x6e\164")) {
        goto SM_;
    }
    $IC = new Customersaml();
    $IC->mo_saml_send_user_exceeded_alert_email($lC, $this);
    SM_:
    if (is_administrator_user($user)) {
        goto yzF;
    }
    wp_redirect($C3);
    exit;
    goto Nul;
    yzF:
    update_user_meta($v0, "\x6d\157\137\x73\x61\155\x6c\x5f\165\163\x65\162\x5f\x74\x79\160\145", "\163\x73\157\137\165\163\145\x72");
    Nul:
    zDQ:
    tvQ:
    ROz:
}
function check_if_user_allowed_to_login_due_to_role_restriction($RR)
{
    $P_ = maybe_unserialize(get_site_option("\x73\141\x6d\x6c\137\141\x6d\137\x72\157\154\145\137\x6d\141\x70\160\x69\156\147"));
    $gw = Utilities::get_active_sites();
    $cR = get_site_option("\x6d\x6f\137\x61\160\160\x6c\x79\137\x72\x6f\154\145\137\x6d\141\x70\x70\x69\156\147\137\x66\x6f\162\x5f\x73\x69\164\145\x73");
    if ($P_) {
        goto BM4;
    }
    $P_ = array();
    BM4:
    if (array_key_exists("\x44\x45\106\101\125\x4c\124", $P_)) {
        goto q2E;
    }
    $P_["\x44\105\x46\101\125\x4c\x54"] = array();
    q2E:
    foreach ($gw as $blog_id) {
        if ($cR) {
            goto Eez;
        }
        $N2 = $blog_id;
        goto WVY;
        Eez:
        $N2 = 0;
        WVY:
        if (isset($P_[$N2])) {
            goto CnU;
        }
        $Ts = $P_["\104\x45\x46\x41\125\x4c\124"];
        goto EAw;
        CnU:
        $Ts = $P_[$N2];
        EAw:
        if (empty($Ts)) {
            goto oj_;
        }
        $zj = isset($Ts["\155\x6f\x5f\x73\141\x6d\154\x5f\144\x6f\x6e\x74\137\141\x6c\x6c\157\x77\x5f\165\163\x65\162\137\164\157\154\157\147\151\156\x5f\x63\x72\145\141\x74\x65\x5f\x77\151\x74\x68\x5f\147\x69\x76\145\156\137\x67\x72\157\x75\160\x73"]) ? $Ts["\x6d\157\137\x73\141\155\x6c\137\144\157\156\164\x5f\x61\x6c\x6c\x6f\167\137\x75\x73\x65\x72\137\x74\157\154\x6f\x67\151\156\x5f\x63\162\145\141\164\x65\x5f\x77\151\164\150\x5f\147\x69\166\145\156\x5f\x67\162\x6f\165\160\x73"] : '';
        if (!($zj == "\143\150\x65\x63\x6b\x65\x64")) {
            goto OJy;
        }
        if (empty($RR)) {
            goto eZa;
        }
        $M8 = $Ts["\155\x6f\x5f\x73\141\x6d\x6c\x5f\162\x65\x73\x74\x72\151\143\164\137\165\163\145\x72\163\137\x77\x69\164\x68\137\x67\162\x6f\165\160\x73"];
        $qv = explode("\x3b", $M8);
        foreach ($qv as $ln) {
            foreach ($RR as $SG) {
                $SG = trim($SG);
                if (!(!empty($SG) && $SG == $ln)) {
                    goto zgq;
                }
                wp_die("\131\x6f\165\x20\x61\x72\145\x20\156\x6f\x74\x20\141\x75\x74\x68\x6f\x72\151\x7a\x65\144\40\164\x6f\40\154\x6f\x67\x69\x6e\56\x20\120\x6c\x65\x61\163\x65\x20\143\x6f\156\x74\141\143\164\40\x79\x6f\x75\x72\x20\141\144\155\x69\x6e\x69\163\164\x72\x61\164\157\162\56", "\105\162\x72\x6f\162");
                zgq:
                xBg:
            }
            N8h:
            UHw:
        }
        snr:
        eZa:
        OJy:
        oj_:
        KXu:
    }
    xLd:
}
function assign_roles_to_user($user, $P_, $blog_id, $RR, $N2)
{
    $D7 = false;
    if (!(!empty($RR) && !empty($P_) && !is_administrator_user($user) && is_user_member_of_blog($user->ID, $blog_id))) {
        goto vi_;
    }
    if (!empty($P_[$N2])) {
        goto C5p;
    }
    if (empty($P_["\x44\105\106\x41\x55\114\124"])) {
        goto WYk;
    }
    $Ts = $P_["\104\105\x46\x41\125\114\x54"];
    WYk:
    goto GSt;
    C5p:
    $Ts = $P_[$N2];
    GSt:
    if (empty($Ts)) {
        goto FbE;
    }
    $user->set_role(false);
    $ox = '';
    $ug = false;
    unset($Ts["\144\x65\146\x61\x75\154\x74\x5f\162\x6f\154\x65"]);
    unset($Ts["\x64\157\x6e\164\137\143\162\x65\x61\x74\145\x5f\x75\163\145\x72"]);
    unset($Ts["\x64\x6f\x6e\x74\137\x61\154\154\x6f\167\x5f\x75\156\x6c\x69\x73\164\145\x64\137\x75\163\145\162"]);
    unset($Ts["\153\145\x65\160\137\145\170\x69\163\164\151\x6e\x67\137\x75\x73\x65\162\x73\x5f\x72\157\154\145"]);
    unset($Ts["\155\157\137\163\x61\155\x6c\137\144\x6f\x6e\164\137\141\x6c\154\x6f\167\x5f\x75\163\x65\x72\137\x74\157\x6c\157\x67\151\156\x5f\x63\x72\x65\x61\x74\x65\x5f\167\151\164\150\x5f\147\x69\166\x65\x6e\137\147\x72\x6f\x75\x70\163"]);
    unset($Ts["\x6d\157\x5f\163\141\x6d\x6c\137\162\145\163\164\x72\x69\143\164\137\165\x73\145\162\163\x5f\x77\x69\164\150\137\147\162\157\x75\x70\163"]);
    foreach ($Ts as $yM => $Tp) {
        $qv = explode("\x3b", $Tp);
        foreach ($qv as $ln) {
            if (!(!empty($ln) && in_array($ln, $RR))) {
                goto HH5;
            }
            $D7 = true;
            $user->add_role($yM);
            HH5:
            P7a:
        }
        pcZ:
        rA9:
    }
    bcu:
    FbE:
    vi_:
    $Hl = get_site_option("\x6d\x6f\137\163\141\155\154\137\x73\165\160\145\x72\x5f\x61\x64\x6d\x69\x6e\137\162\x6f\x6c\145\x5f\155\x61\x70\160\x69\x6e\147");
    $MV = array();
    if (empty($Hl)) {
        goto xfB;
    }
    $MV = explode("\x3b", $Hl);
    xfB:
    if (!(!empty($RR) && !empty($MV))) {
        goto U5E;
    }
    foreach ($MV as $ln) {
        if (!in_array($ln, $RR)) {
            goto kXh;
        }
        grant_super_admin($user->ID);
        kXh:
        oOt:
    }
    goh:
    U5E:
    return $D7;
}
function get_saml_roles_to_assign($P_, $blog_id, $RR)
{
    $rt = array();
    if (!(!empty($RR) && !empty($P_))) {
        goto eRt;
    }
    if (!empty($P_[$blog_id])) {
        goto Vzp;
    }
    if (empty($P_["\x44\x45\106\x41\x55\x4c\x54"])) {
        goto yag;
    }
    $Ts = $P_["\104\105\x46\x41\125\114\124"];
    yag:
    goto bRW;
    Vzp:
    $Ts = $P_[$blog_id];
    bRW:
    if (empty($Ts)) {
        goto Uxc;
    }
    unset($Ts["\x64\x65\x66\141\x75\x6c\x74\x5f\x72\x6f\x6c\x65"]);
    unset($Ts["\144\x6f\156\164\x5f\x63\162\145\x61\164\x65\x5f\x75\163\x65\x72"]);
    unset($Ts["\x64\x6f\x6e\x74\137\141\154\x6c\x6f\167\137\x75\156\154\151\x73\x74\145\x64\137\x75\163\x65\x72"]);
    unset($Ts["\153\x65\x65\x70\x5f\x65\x78\x69\x73\164\151\156\147\x5f\165\x73\145\x72\163\137\x72\x6f\x6c\x65"]);
    unset($Ts["\x6d\x6f\x5f\x73\141\155\x6c\137\144\x6f\156\164\137\141\154\154\x6f\x77\x5f\x75\x73\145\162\137\x74\x6f\x6c\x6f\x67\x69\x6e\137\143\162\x65\x61\x74\x65\x5f\x77\151\164\150\x5f\147\151\x76\145\x6e\137\x67\x72\x6f\x75\x70\163"]);
    unset($Ts["\155\x6f\x5f\163\x61\x6d\154\137\162\145\x73\164\162\151\x63\x74\137\165\x73\x65\162\163\137\x77\151\x74\150\x5f\147\162\157\165\160\163"]);
    foreach ($Ts as $yM => $Tp) {
        $qv = explode("\73", $Tp);
        foreach ($qv as $ln) {
            if (!(!empty($ln) and in_array($ln, $RR))) {
                goto IP2;
            }
            array_push($rt, $yM);
            IP2:
            fia:
        }
        yXk:
        iGu:
    }
    d97:
    Uxc:
    eRt:
    return $rt;
}
function is_administrator_user($user)
{
    $Yf = $user->roles;
    if (!is_null($Yf) && in_array("\141\x64\x6d\x69\156\x69\163\164\162\x61\x74\x6f\162", $Yf)) {
        goto WRL;
    }
    return false;
    goto eNS;
    WRL:
    return true;
    eNS:
}
function mo_saml_is_customer_registered()
{
    return 1;
    $Fq = get_site_option("\x6d\157\137\163\x61\x6d\x6c\x5f\141\x64\155\x69\156\137\145\155\x61\151\x6c");
    $bJ = get_site_option("\155\157\x5f\163\x61\155\154\x5f\141\x64\155\151\156\x5f\x63\x75\x73\164\157\155\x65\x72\137\x6b\145\x79");
    if (!$Fq || !$bJ || !is_numeric(trim($bJ))) {
        goto Z1j;
    }
    return 1;
    goto OAI;
    Z1j:
    return 0;
    OAI:
}
function mo_saml_is_customer_license_verified()
{
    $fN = mo_saml_get_plugin_details();
    if ($fN !== true) {
        goto i6l;
    }
    return 1;
    goto Fsk;
    i6l:
    return 0;
    Fsk:
    $xk = get_site_option("\155\157\x5f\163\x61\155\154\x5f\143\165\x73\x74\157\x6d\x65\x72\137\x74\157\153\145\x6e");
    $qZ = AESEncryption::decrypt_data(get_site_option("\164\137\x73\151\164\x65\x5f\163\x74\x61\164\x75\x73"), $xk);
    $ue = get_site_option("\163\x6d\x6c\137\154\153");
    $Fq = get_site_option("\155\157\137\x73\141\155\x6c\x5f\141\144\x6d\151\156\x5f\x65\155\141\x69\x6c");
    $bJ = get_site_option("\x6d\x6f\137\163\x61\155\154\x5f\141\144\x6d\x69\156\x5f\x63\x75\163\x74\157\x6d\145\x72\x5f\153\145\171");
    $xJ = AESEncryption::decrypt_data(get_site_option("\156\157\x5f\163\142\x73"), $xk);
    $OO = false;
    if (!get_site_option("\x6e\x6f\137\163\x62\163")) {
        goto DpK;
    }
    $bz = Utilities::get_sites();
    $OO = $xJ < count($bz);
    DpK:
    if ($qZ != "\x74\162\165\x65" && !$ue || !$Fq || !$bJ || !is_numeric(trim($bJ)) || $OO) {
        goto LMq;
    }
    return 1;
    goto KDO;
    LMq:
    return 0;
    KDO:
}
function show_status_error($dl, $C5)
{
    if ($C5 == "\164\x65\x73\x74\126\x61\x6c\151\x64\x61\x74\145" or $C5 == "\x74\145\163\x74\x4e\145\x77\x43\x65\x72\x74\151\x66\151\x63\x61\x74\x65") {
        goto DSU;
    }
    wp_die("\127\x65\40\x63\157\x75\154\144\x20\156\157\164\40\x73\151\147\x6e\x20\171\x6f\x75\40\151\156\x2e\x20\120\x6c\145\141\163\145\40\143\x6f\x6e\x74\141\143\x74\40\x79\x6f\165\x72\x20\101\x64\x6d\x69\x6e\x69\163\x74\162\141\x74\x6f\162\56", "\105\x72\162\157\162\72\40\111\156\x76\141\x6c\x69\144\40\123\101\115\x4c\x20\122\145\163\x70\157\x6e\163\145\40\123\x74\x61\164\x75\x73");
    goto Nx3;
    DSU:
    echo "\74\144\x69\166\40\x73\164\171\x6c\145\75\x22\x66\x6f\x6e\x74\x2d\146\141\x6d\151\154\x79\72\103\x61\x6c\x69\142\x72\151\73\x70\141\144\144\x69\x6e\x67\72\60\x20\x33\x25\73\42\76";
    echo "\x3c\144\x69\x76\x20\x73\x74\x79\x6c\x65\75\42\x63\x6f\154\157\162\72\x20\43\x61\71\64\64\x34\62\x3b\x62\141\x63\x6b\x67\162\157\165\156\144\x2d\143\157\x6c\x6f\162\72\x20\x23\146\62\144\145\144\145\x3b\160\x61\x64\x64\x69\x6e\x67\x3a\40\61\x35\160\170\73\155\x61\x72\x67\x69\x6e\55\x62\x6f\164\x74\x6f\x6d\x3a\40\x32\x30\160\x78\73\164\145\170\x74\55\141\x6c\x69\x67\156\x3a\x63\145\156\x74\x65\x72\x3b\x62\x6f\162\144\x65\162\72\61\x70\170\x20\x73\x6f\x6c\151\x64\40\x23\105\66\x42\x33\102\x32\x3b\146\x6f\x6e\164\x2d\x73\151\x7a\145\x3a\61\70\160\164\x3b\x22\76\40\x45\x52\x52\x4f\x52\x3c\x2f\144\151\x76\x3e\15\xa\40\x20\x20\x20\x20\x20\x20\x20\x3c\144\151\x76\x20\163\x74\171\154\x65\75\42\x63\x6f\x6c\x6f\x72\72\x20\x23\141\71\64\64\64\62\x3b\146\157\x6e\164\x2d\163\x69\x7a\145\72\x31\x34\x70\x74\x3b\40\155\x61\x72\x67\151\156\55\x62\157\164\x74\157\155\x3a\x32\x30\x70\170\x3b\x22\76\74\x70\76\x3c\x73\164\162\x6f\156\x67\76\105\162\162\x6f\162\x3a\40\x3c\57\163\164\x72\157\156\x67\76\x20\x49\156\x76\141\x6c\x69\x64\40\123\101\x4d\114\x20\x52\x65\x73\160\x6f\x6e\x73\145\40\x53\164\141\x74\165\x73\56\74\57\x70\x3e\15\xa\40\x20\x20\x20\40\x20\40\40\x20\40\x20\40\x3c\x70\76\x3c\x73\x74\162\x6f\156\147\76\x43\141\x75\x73\x65\163\x3c\x2f\163\164\162\x6f\156\x67\76\x3a\x20\111\x64\145\156\164\151\164\x79\40\120\162\x6f\166\x69\x64\x65\x72\x20\150\141\x73\x20\x73\145\x6e\x74\40\x27" . esc_html($dl) . "\47\40\163\164\x61\164\x75\x73\40\143\157\144\x65\40\151\156\40\123\x41\115\114\40\122\145\x73\x70\157\156\x73\x65\56\x20\x3c\57\x70\76\xd\12\x20\40\x20\x20\x20\40\40\x20\x20\x20\40\x20\74\160\x3e\x3c\163\x74\x72\157\x6e\x67\76\122\x65\x61\163\x6f\x6e\74\x2f\x73\x74\162\157\156\147\76\x3a\40" . get_status_message(esc_html($dl)) . "\x3c\x2f\x70\x3e\x3c\142\x72\x3e";
    if (empty($FY)) {
        goto Nrb;
    }
    echo "\74\160\76\x3c\x73\x74\162\x6f\x6e\147\76\x53\x74\141\164\165\x73\40\x4d\145\x73\x73\141\147\145\x20\x69\156\40\164\x68\145\40\x53\x41\115\x4c\40\122\x65\x73\160\x6f\x6e\x73\x65\72\74\x2f\x73\164\x72\x6f\156\147\x3e\40\74\142\x72\x2f\x3e" . esc_html($FY) . "\x3c\57\x70\76\74\x62\x72\x3e";
    Nrb:
    echo "\15\xa\x20\40\40\x20\40\40\40\40\x3c\x2f\144\x69\x76\x3e\15\xa\xd\12\x20\40\40\x20\x20\x20\40\40\x3c\x64\151\166\x20\x73\164\171\154\145\x3d\42\x6d\141\162\147\151\156\72\63\45\73\144\x69\163\160\x6c\141\171\x3a\142\154\157\143\153\x3b\164\145\x78\x74\x2d\141\x6c\x69\x67\x6e\72\143\145\156\x74\x65\162\x3b\42\76\xd\12\x20\x20\x20\40\x20\40\x20\40\40\40\40\x20\x3c\x64\151\x76\x20\x73\x74\171\154\x65\75\x22\155\141\x72\147\x69\156\x3a\63\x25\73\x64\151\163\x70\x6c\141\x79\x3a\x62\x6c\157\x63\153\x3b\x74\145\170\x74\55\x61\154\x69\147\x6e\72\x63\145\156\x74\x65\x72\x3b\42\76\x3c\151\x6e\160\165\164\40\x73\x74\x79\x6c\145\75\42\160\141\144\144\x69\x6e\x67\x3a\61\x25\73\167\151\x64\164\x68\72\x31\x30\60\160\x78\73\142\x61\x63\153\147\162\x6f\165\x6e\144\x3a\40\43\60\60\x39\x31\103\104\40\x6e\x6f\x6e\145\40\x72\145\160\145\141\164\40\163\x63\162\x6f\154\154\x20\60\45\x20\x30\45\x3b\143\x75\162\163\157\x72\72\x20\x70\x6f\x69\x6e\x74\145\162\x3b\x66\157\x6e\x74\55\x73\151\172\145\72\61\65\160\170\x3b\142\157\x72\144\x65\x72\x2d\x77\151\144\x74\x68\72\40\x31\x70\170\73\142\157\162\144\145\x72\55\163\x74\171\154\x65\72\40\163\157\x6c\x69\144\73\142\x6f\162\144\x65\x72\x2d\x72\x61\144\x69\x75\x73\x3a\x20\63\160\170\73\x77\150\x69\164\x65\55\163\160\141\x63\145\x3a\x20\156\x6f\167\x72\x61\160\x3b\142\x6f\170\55\163\151\x7a\x69\156\147\72\40\142\157\x72\x64\145\162\x2d\142\x6f\170\x3b\142\157\x72\x64\x65\x72\x2d\143\x6f\154\x6f\162\72\x20\43\x30\x30\67\x33\101\101\x3b\x62\x6f\x78\x2d\x73\x68\x61\x64\x6f\x77\x3a\x20\60\x70\170\x20\x31\x70\170\x20\60\160\x78\40\162\147\142\x61\50\61\62\60\54\40\62\60\x30\54\40\62\x33\60\x2c\40\60\x2e\x36\51\x20\x69\x6e\x73\145\164\73\143\157\x6c\157\162\72\40\43\x46\106\x46\x3b\42\x74\x79\160\145\x3d\42\x62\x75\x74\x74\157\156\42\40\x76\x61\154\165\x65\75\x22\x44\x6f\x6e\145\x22\x20\x6f\x6e\103\154\x69\143\153\75\42\163\145\x6c\146\x2e\x63\154\157\163\x65\50\x29\x3b\42\x3e\74\x2f\x64\x69\166\x3e";
    exit;
    Nx3:
}
function addLink($LQ, $eJ)
{
    $sr = "\x3c\x61\x20\150\x72\x65\x66\x3d\42" . $eJ . "\42\x3e" . $LQ . "\74\57\x61\76";
    return $sr;
}
function get_status_message($dl)
{
    switch ($dl) {
        case "\x52\145\x71\165\x65\163\x74\x65\162":
            return "\x54\150\x65\40\162\x65\x71\165\x65\x73\164\40\x63\x6f\165\154\144\40\156\x6f\x74\x20\142\145\x20\160\145\x72\146\157\x72\x6d\145\x64\40\144\x75\145\40\164\x6f\x20\141\x6e\40\145\162\x72\x6f\162\40\x6f\x6e\40\164\150\145\x20\160\x61\162\164\40\x6f\146\x20\x74\x68\145\40\162\145\x71\x75\145\x73\x74\x65\162\x2e";
            goto Usg;
        case "\122\x65\x73\160\x6f\156\x64\145\x72":
            return "\x54\150\x65\40\x72\145\x71\x75\x65\163\164\x20\x63\157\x75\x6c\x64\x20\156\x6f\x74\x20\x62\145\40\x70\145\162\146\157\x72\x6d\145\x64\40\x64\x75\145\40\164\157\x20\x61\156\40\x65\162\162\x6f\162\x20\157\x6e\40\x74\150\x65\40\160\x61\x72\164\40\x6f\x66\40\x74\150\x65\x20\123\x41\115\114\40\x72\145\163\160\x6f\x6e\144\145\162\x20\x6f\162\40\x53\101\115\x4c\40\141\x75\164\x68\x6f\x72\x69\x74\x79\56";
            goto Usg;
        case "\x56\145\x72\163\151\157\x6e\x4d\x69\163\155\141\x74\x63\150":
            return "\x54\x68\145\x20\x53\101\115\114\40\x72\145\163\x70\157\x6e\x64\x65\x72\x20\x63\x6f\165\154\144\x20\156\x6f\164\40\x70\162\157\143\145\163\x73\x20\x74\150\145\40\x72\x65\161\165\x65\x73\164\40\142\x65\x63\141\165\x73\145\40\164\150\x65\40\x76\x65\x72\x73\x69\157\156\x20\x6f\146\40\164\150\x65\x20\162\145\x71\x75\x65\163\x74\40\x6d\x65\x73\163\x61\147\145\40\x77\141\x73\x20\151\156\143\157\162\x72\x65\143\164\x2e";
            goto Usg;
        default:
            return "\x55\x6e\x6b\x6e\x6f\167\x6e";
    }
    OLr:
    Usg:
}
function saml_get_current_page_url()
{
    $ul = $_SERVER["\110\124\x54\120\x5f\110\x4f\123\124"];
    if (!(substr($ul, -1) == "\x2f")) {
        goto eDy;
    }
    $ul = substr($ul, 0, -1);
    eDy:
    $sK = $_SERVER["\x52\105\x51\x55\105\x53\124\x5f\125\122\111"];
    if (!(substr($sK, 0, 1) == "\x2f")) {
        goto Ce6;
    }
    $sK = substr($sK, 1);
    Ce6:
    $pc = isset($_SERVER["\110\x54\124\x50\123"]) && strcasecmp($_SERVER["\110\x54\x54\x50\x53"], "\x6f\156") == 0;
    $Gh = "\150\x74\164\x70" . ($pc ? "\163" : '') . "\x3a\x2f\x2f" . $ul . "\57" . $sK;
    return $Gh;
}
function get_network_site_url()
{
    $hn = network_site_url();
    if (!(substr($hn, -1) == "\x2f")) {
        goto eJe;
    }
    $hn = substr($hn, 0, -1);
    eJe:
    return $hn;
}
function get_current_base_url()
{
    return sprintf("\x25\x73\x3a\57\x2f\45\163\57", isset($_SERVER["\110\x54\124\x50\123"]) && $_SERVER["\x48\124\124\120\123"] != "\157\x66\146" ? "\150\164\x74\160\163" : "\150\x74\164\160", $_SERVER["\110\124\124\x50\x5f\x48\x4f\x53\x54"]);
}
add_action("\167\x69\x64\x67\145\x74\x73\x5f\x69\x6e\151\164", function () {
    register_widget("\x6d\157\137\x6c\157\147\151\156\137\x77\x69\x64");
});
add_action("\151\156\x69\164", "\155\x6f\x5f\x6c\157\147\x69\x6e\x5f\x76\x61\154\x69\144\141\164\x65");
