<?php


abstract class BasicEnum
{
    private static $constCacheArray = NULL;
    public static function getConstants()
    {
        if (!(self::$constCacheArray == NULL)) {
            goto SK;
        }
        self::$constCacheArray = array();
        SK:
        $Te = get_called_class();
        if (array_key_exists($Te, self::$constCacheArray)) {
            goto PY;
        }
        $ZD = new ReflectionClass($Te);
        self::$constCacheArray[$Te] = $ZD->getConstants();
        PY:
        return self::$constCacheArray[$Te];
    }
    public static function isValidName($zY, $I4 = false)
    {
        $cq = self::getConstants();
        if (!$I4) {
            goto jw;
        }
        return array_key_exists($zY, $cq);
        jw:
        $JR = array_map("\163\x74\162\x74\x6f\x6c\157\x77\x65\x72", array_keys($cq));
        return in_array(strtolower($zY), $JR);
    }
    public static function isValidValue($Fh, $I4 = true)
    {
        $iH = array_values(self::getConstants());
        return in_array($Fh, $iH, $I4);
    }
}
