<?php


class AESEncryption
{
    public static function encrypt_data($jd, $xk)
    {
        $xk = openssl_digest($xk, "\163\x68\141\62\x35\x36");
        $mq = "\x61\145\x73\55\x31\x32\70\55\145\143\x62";
        $J_ = openssl_encrypt($jd, $mq, $xk, OPENSSL_RAW_DATA || OPENSSL_ZERO_PADDING);
        return base64_encode($J_);
    }
    public static function decrypt_data($jd, $xk)
    {
        $ql = base64_decode($jd);
        $xk = openssl_digest($xk, "\163\150\x61\62\x35\66");
        $mq = "\101\105\123\x2d\61\62\70\55\x45\103\x42";
        $oL = openssl_cipher_iv_length($mq);
        $Fo = substr($ql, 0, $oL);
        $jd = substr($ql, $oL);
        $ey = openssl_decrypt($jd, $mq, $xk, OPENSSL_RAW_DATA || OPENSSL_ZERO_PADDING, $Fo);
        return $ey;
    }
}
