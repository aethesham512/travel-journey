<?php


if (defined("\127\120\111\116\x43")) {
    goto U2;
}
die;
U2:
