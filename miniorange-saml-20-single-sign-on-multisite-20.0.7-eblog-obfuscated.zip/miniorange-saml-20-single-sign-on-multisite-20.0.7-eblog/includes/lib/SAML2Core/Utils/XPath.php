<?php


namespace RobRichards\XMLSecLibs\Utils;

class XPath
{
    const ALPHANUMERIC = "\x5c\167\x5c\x64";
    const NUMERIC = "\x5c\144";
    const LETTERS = "\x5c\x77";
    const EXTENDED_ALPHANUMERIC = "\134\x77\134\144\x5c\x73\x5c\x2d\x5f\x3a\x5c\x2e";
    const SINGLE_QUOTE = "\47";
    const DOUBLE_QUOTE = "\x22";
    const ALL_QUOTES = "\133\47\x22\x5d";
    public static function filterAttrValue($Fh, $dc = self::ALL_QUOTES)
    {
        return preg_replace("\x23" . $dc . "\x23", '', $Fh);
    }
    public static function filterAttrName($zY, $aD = self::EXTENDED_ALPHANUMERIC)
    {
        return preg_replace("\x23\x5b\136" . $aD . "\x5d\x23", '', $zY);
    }
}
