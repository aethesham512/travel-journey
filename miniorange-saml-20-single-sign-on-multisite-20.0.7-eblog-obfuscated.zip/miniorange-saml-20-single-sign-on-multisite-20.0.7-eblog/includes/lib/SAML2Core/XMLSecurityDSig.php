<?php


namespace RobRichards\XMLSecLibs;

use DOMDocument;
use DOMElement;
use DOMNode;
use DOMXPath;
use Exception;
use RobRichards\XMLSecLibs\Utils\XPath as XPath;
class XMLSecurityDSig
{
    const XMLDSIGNS = "\x68\164\164\x70\x3a\x2f\57\167\x77\167\56\x77\63\56\x6f\x72\x67\57\x32\60\60\x30\57\60\71\57\170\x6d\154\x64\163\x69\x67\43";
    const SHA1 = "\150\x74\x74\x70\x3a\x2f\57\167\x77\167\x2e\x77\63\x2e\157\x72\x67\x2f\62\x30\x30\60\57\60\x39\57\x78\155\154\144\163\151\x67\x23\163\150\141\x31";
    const SHA256 = "\150\164\164\x70\72\x2f\x2f\167\167\x77\56\167\63\x2e\157\x72\x67\x2f\x32\x30\60\x31\57\x30\x34\57\170\155\x6c\145\156\x63\43\163\x68\x61\x32\65\66";
    const SHA384 = "\x68\164\x74\160\72\57\57\167\x77\167\56\x77\63\56\157\x72\x67\57\62\60\x30\61\x2f\60\x34\57\170\x6d\x6c\x64\163\x69\x67\x2d\x6d\157\x72\x65\x23\163\150\141\63\x38\x34";
    const SHA512 = "\150\x74\164\160\x3a\x2f\x2f\167\x77\167\56\x77\x33\56\157\x72\x67\57\62\60\60\61\57\60\x34\x2f\170\x6d\x6c\x65\156\x63\x23\163\150\141\65\x31\62";
    const RIPEMD160 = "\150\164\164\x70\72\57\x2f\167\167\167\56\x77\63\x2e\157\x72\x67\x2f\x32\x30\60\61\x2f\60\64\x2f\x78\155\154\x65\156\143\43\x72\151\160\x65\x6d\144\x31\x36\60";
    const C14N = "\x68\x74\164\160\x3a\x2f\x2f\167\x77\x77\x2e\x77\x33\56\157\x72\147\x2f\x54\122\x2f\x32\60\60\61\x2f\x52\x45\x43\55\x78\x6d\154\55\x63\x31\64\156\x2d\x32\x30\x30\x31\60\x33\x31\x35";
    const C14N_COMMENTS = "\x68\164\164\x70\x3a\x2f\57\x77\167\x77\56\167\x33\x2e\157\x72\147\57\x54\x52\57\x32\60\x30\x31\57\122\x45\103\x2d\170\x6d\x6c\x2d\143\x31\x34\156\55\x32\60\60\x31\x30\63\61\x35\43\x57\151\164\x68\103\x6f\x6d\155\145\x6e\164\x73";
    const EXC_C14N = "\x68\164\x74\x70\x3a\x2f\x2f\x77\167\x77\x2e\167\x33\56\x6f\x72\147\x2f\x32\60\x30\x31\57\61\60\57\170\155\x6c\55\145\x78\x63\x2d\x63\61\x34\x6e\x23";
    const EXC_C14N_COMMENTS = "\150\x74\164\160\72\57\57\167\x77\167\x2e\x77\63\56\x6f\x72\147\57\62\60\x30\x31\57\x31\60\x2f\170\x6d\154\55\145\170\143\55\143\61\64\156\x23\127\151\164\x68\x43\157\x6d\x6d\145\156\164\x73";
    const template = "\x3c\144\163\72\123\151\147\156\141\164\x75\162\145\x20\170\155\x6c\x6e\x73\x3a\144\x73\x3d\x22\x68\x74\x74\x70\x3a\57\57\167\x77\x77\56\167\x33\56\157\162\147\x2f\x32\60\x30\60\57\x30\x39\57\x78\155\154\x64\163\x69\x67\43\x22\76\xd\xa\40\x20\x3c\144\163\x3a\x53\151\147\x6e\x65\x64\111\156\146\157\x3e\15\12\x20\x20\x20\x20\x3c\144\x73\x3a\123\151\147\x6e\x61\164\x75\162\145\x4d\x65\164\x68\157\144\40\57\76\xd\12\40\x20\x3c\57\144\163\72\x53\x69\x67\156\145\x64\111\156\146\x6f\x3e\15\xa\74\x2f\x64\163\x3a\x53\x69\x67\x6e\141\x74\x75\162\145\76";
    const BASE_TEMPLATE = "\74\123\x69\147\x6e\x61\x74\x75\x72\x65\40\170\155\x6c\x6e\x73\x3d\x22\150\x74\x74\160\x3a\x2f\x2f\x77\x77\167\x2e\x77\x33\56\x6f\162\x67\x2f\x32\60\60\60\57\x30\x39\57\170\x6d\x6c\144\163\x69\x67\x23\42\76\15\12\x20\40\x3c\123\151\x67\156\x65\144\111\x6e\x66\157\x3e\xd\12\40\40\x20\x20\74\123\151\x67\156\141\164\x75\162\x65\x4d\145\x74\150\157\144\40\x2f\x3e\xd\12\x20\x20\74\x2f\123\151\x67\x6e\145\x64\x49\x6e\146\x6f\x3e\15\12\x3c\x2f\123\x69\147\156\141\164\x75\162\x65\76";
    public $sigNode = null;
    public $idKeys = array();
    public $idNS = array();
    private $signedInfo = null;
    private $xPathCtx = null;
    private $canonicalMethod = null;
    private $prefix = '';
    private $searchpfx = "\x73\x65\x63\144\x73\151\x67";
    private $validatedNodes = null;
    public function __construct($cg = "\x64\x73")
    {
        $nw = self::BASE_TEMPLATE;
        if (empty($cg)) {
            goto JJ;
        }
        $this->prefix = $cg . "\x3a";
        $nP = array("\x3c\123", "\74\57\123", "\170\x6d\x6c\156\x73\75");
        $lh = array("\x3c{$cg}\72\123", "\x3c\57{$cg}\x3a\123", "\170\155\x6c\156\x73\x3a{$cg}\x3d");
        $nw = str_replace($nP, $lh, $nw);
        JJ:
        $rJ = new DOMDocument();
        $rJ->loadXML($nw);
        $this->sigNode = $rJ->documentElement;
    }
    private function resetXPathObj()
    {
        $this->xPathCtx = null;
    }
    private function getXPathObj()
    {
        if (!(empty($this->xPathCtx) && !empty($this->sigNode))) {
            goto yd;
        }
        $OE = new DOMXPath($this->sigNode->ownerDocument);
        $OE->registerNamespace("\163\x65\143\x64\x73\x69\147", self::XMLDSIGNS);
        $this->xPathCtx = $OE;
        yd:
        return $this->xPathCtx;
    }
    public static function generateGUID($cg = "\x70\x66\170")
    {
        $C2 = md5(uniqid(mt_rand(), true));
        $WC = $cg . substr($C2, 0, 8) . "\x2d" . substr($C2, 8, 4) . "\55" . substr($C2, 12, 4) . "\55" . substr($C2, 16, 4) . "\55" . substr($C2, 20, 12);
        return $WC;
    }
    public static function generate_GUID($cg = "\160\146\170")
    {
        return self::generateGUID($cg);
    }
    public function locateSignature($AT, $ez = 0)
    {
        if ($AT instanceof DOMDocument) {
            goto Tm;
        }
        $Bl = $AT->ownerDocument;
        goto xX;
        Tm:
        $Bl = $AT;
        xX:
        if (!$Bl) {
            goto F2;
        }
        $OE = new DOMXPath($Bl);
        $OE->registerNamespace("\163\x65\143\144\x73\x69\147", self::XMLDSIGNS);
        $wF = "\56\57\x2f\x73\145\143\144\x73\151\x67\72\123\x69\x67\x6e\x61\x74\165\x72\x65";
        $Gf = $OE->query($wF, $AT);
        $this->sigNode = $Gf->item($ez);
        return $this->sigNode;
        F2:
        return null;
    }
    public function createNewSignNode($zY, $Fh = null)
    {
        $Bl = $this->sigNode->ownerDocument;
        if (!is_null($Fh)) {
            goto MY;
        }
        $Qh = $Bl->createElementNS(self::XMLDSIGNS, $this->prefix . $zY);
        goto K1;
        MY:
        $Qh = $Bl->createElementNS(self::XMLDSIGNS, $this->prefix . $zY, $Fh);
        K1:
        return $Qh;
    }
    public function setCanonicalMethod($mq)
    {
        switch ($mq) {
            case "\150\164\164\x70\x3a\x2f\x2f\x77\x77\x77\56\x77\63\56\157\162\x67\x2f\x54\122\x2f\x32\60\60\61\57\x52\105\103\x2d\170\155\x6c\55\143\61\64\x6e\x2d\62\60\60\x31\x30\63\61\65":
            case "\x68\x74\x74\160\72\57\57\167\x77\167\x2e\x77\x33\x2e\x6f\162\x67\x2f\124\122\57\x32\60\60\x31\57\122\105\103\x2d\170\155\x6c\x2d\143\61\64\x6e\55\62\60\x30\61\x30\x33\61\x35\x23\127\151\x74\x68\103\x6f\x6d\x6d\145\x6e\x74\163":
            case "\150\x74\x74\x70\x3a\x2f\57\x77\167\167\x2e\167\63\56\157\162\x67\x2f\x32\60\x30\x31\x2f\61\60\57\x78\x6d\x6c\x2d\145\170\x63\55\x63\61\x34\x6e\43":
            case "\150\x74\164\160\72\x2f\x2f\167\x77\167\x2e\x77\x33\56\157\162\147\57\x32\x30\x30\x31\57\61\x30\x2f\x78\155\x6c\55\x65\x78\x63\55\143\61\64\156\43\127\151\164\150\x43\157\x6d\x6d\145\156\164\163":
                $this->canonicalMethod = $mq;
                goto Wx;
            default:
                throw new Exception("\x49\156\166\141\x6c\151\144\40\x43\141\x6e\x6f\x6e\x69\x63\141\x6c\40\115\145\164\x68\157\x64");
        }
        ii:
        Wx:
        if (!($OE = $this->getXPathObj())) {
            goto PN;
        }
        $wF = "\56\x2f" . $this->searchpfx . "\72\x53\x69\x67\156\145\x64\x49\156\x66\157";
        $Gf = $OE->query($wF, $this->sigNode);
        if (!($gg = $Gf->item(0))) {
            goto ep;
        }
        $wF = "\56\x2f" . $this->searchpfx . "\x43\x61\x6e\157\156\151\143\x61\154\151\x7a\141\164\x69\157\156\x4d\x65\164\150\x6f\144";
        $Gf = $OE->query($wF, $gg);
        if ($qF = $Gf->item(0)) {
            goto Mm;
        }
        $qF = $this->createNewSignNode("\103\141\156\x6f\x6e\x69\x63\x61\x6c\x69\172\x61\x74\151\x6f\156\115\145\x74\150\157\x64");
        $gg->insertBefore($qF, $gg->firstChild);
        Mm:
        $qF->setAttribute("\101\x6c\x67\x6f\x72\151\164\150\x6d", $this->canonicalMethod);
        ep:
        PN:
    }
    private function canonicalizeData($Qh, $dP, $uj = null, $Lq = null)
    {
        $Hc = false;
        $wy = false;
        switch ($dP) {
            case "\x68\164\164\160\72\x2f\x2f\x77\x77\x77\x2e\167\63\56\157\x72\x67\57\x54\122\57\62\x30\60\61\x2f\122\x45\x43\x2d\170\x6d\154\55\143\x31\x34\156\55\62\x30\x30\x31\60\63\61\x35":
                $Hc = false;
                $wy = false;
                goto mK;
            case "\x68\164\164\x70\x3a\x2f\x2f\x77\x77\167\x2e\x77\x33\x2e\x6f\x72\x67\57\124\x52\x2f\62\60\60\61\x2f\122\105\103\x2d\x78\x6d\154\x2d\x63\61\64\156\x2d\x32\x30\x30\61\60\x33\x31\65\x23\127\151\x74\x68\103\157\155\x6d\145\x6e\164\163":
                $wy = true;
                goto mK;
            case "\150\x74\x74\160\72\x2f\x2f\x77\x77\167\x2e\167\x33\x2e\x6f\x72\x67\x2f\62\x30\x30\61\x2f\x31\60\x2f\x78\155\154\x2d\145\170\x63\55\143\x31\x34\156\43":
                $Hc = true;
                goto mK;
            case "\150\164\164\160\72\57\x2f\x77\x77\167\x2e\x77\x33\x2e\x6f\162\x67\57\62\x30\60\61\57\x31\x30\x2f\170\x6d\154\55\x65\x78\x63\x2d\143\61\x34\x6e\43\x57\x69\164\x68\x43\x6f\x6d\x6d\x65\156\x74\163":
                $Hc = true;
                $wy = true;
                goto mK;
        }
        IE:
        mK:
        if (!(is_null($uj) && $Qh instanceof DOMNode && $Qh->ownerDocument !== null && $Qh->isSameNode($Qh->ownerDocument->documentElement))) {
            goto hj;
        }
        $B7 = $Qh;
        CY:
        if (!($ax = $B7->previousSibling)) {
            goto lH;
        }
        if (!($ax->nodeType == XML_PI_NODE || $ax->nodeType == XML_COMMENT_NODE && $wy)) {
            goto Cu;
        }
        goto lH;
        Cu:
        $B7 = $ax;
        goto CY;
        lH:
        if (!($ax == null)) {
            goto gU;
        }
        $Qh = $Qh->ownerDocument;
        gU:
        hj:
        return $Qh->C14N($Hc, $wy, $uj, $Lq);
    }
    public function canonicalizeSignedInfo()
    {
        $Bl = $this->sigNode->ownerDocument;
        $dP = null;
        if (!$Bl) {
            goto NY;
        }
        $OE = $this->getXPathObj();
        $wF = "\x2e\x2f\x73\x65\143\x64\163\151\x67\x3a\x53\x69\147\156\x65\x64\111\156\146\x6f";
        $Gf = $OE->query($wF, $this->sigNode);
        if (!($w_ = $Gf->item(0))) {
            goto Ip;
        }
        $wF = "\56\x2f\163\145\x63\x64\163\x69\x67\x3a\x43\x61\156\x6f\x6e\151\143\141\154\151\x7a\x61\x74\x69\157\156\x4d\x65\x74\150\157\x64";
        $Gf = $OE->query($wF, $w_);
        if (!($qF = $Gf->item(0))) {
            goto jo;
        }
        $dP = $qF->getAttribute("\101\x6c\147\x6f\162\x69\x74\150\155");
        jo:
        $this->signedInfo = $this->canonicalizeData($w_, $dP);
        return $this->signedInfo;
        Ip:
        NY:
        return null;
    }
    public function calculateDigest($Ew, $jd, $U6 = true)
    {
        switch ($Ew) {
            case self::SHA1:
                $oc = "\x73\150\x61\x31";
                goto W7;
            case self::SHA256:
                $oc = "\163\150\141\62\x35\66";
                goto W7;
            case self::SHA384:
                $oc = "\x73\x68\x61\x33\x38\x34";
                goto W7;
            case self::SHA512:
                $oc = "\163\x68\x61\x35\61\62";
                goto W7;
            case self::RIPEMD160:
                $oc = "\x72\x69\x70\145\155\144\61\x36\x30";
                goto W7;
            default:
                throw new Exception("\103\141\156\156\x6f\x74\x20\166\141\x6c\151\x64\x61\164\145\x20\x64\x69\x67\x65\163\164\72\40\x55\x6e\x73\x75\x70\x70\x6f\162\164\145\x64\x20\x41\x6c\147\157\x72\x69\x74\x68\155\x20\74{$Ew}\x3e");
        }
        t0:
        W7:
        $zQ = hash($oc, $jd, true);
        if (!$U6) {
            goto Fd;
        }
        $zQ = base64_encode($zQ);
        Fd:
        return $zQ;
    }
    public function validateDigest($we, $jd)
    {
        $OE = new DOMXPath($we->ownerDocument);
        $OE->registerNamespace("\163\x65\143\144\163\x69\x67", self::XMLDSIGNS);
        $wF = "\163\164\x72\151\x6e\x67\x28\56\x2f\x73\x65\x63\x64\163\151\x67\72\104\151\x67\x65\163\x74\115\145\164\x68\x6f\144\x2f\100\101\x6c\147\x6f\162\x69\x74\x68\155\51";
        $Ew = $OE->evaluate($wF, $we);
        $vp = $this->calculateDigest($Ew, $jd, false);
        $wF = "\x73\x74\162\x69\156\147\x28\56\57\163\145\143\x64\163\x69\147\72\x44\151\x67\145\x73\x74\126\x61\154\165\145\51";
        $sp = $OE->evaluate($wF, $we);
        return $vp === base64_decode($sp);
    }
    public function processTransforms($we, $ZS, $yz = true)
    {
        $jd = $ZS;
        $OE = new DOMXPath($we->ownerDocument);
        $OE->registerNamespace("\163\x65\143\x64\x73\x69\147", self::XMLDSIGNS);
        $wF = "\x2e\57\x73\x65\x63\144\163\x69\x67\x3a\x54\x72\141\x6e\163\146\x6f\x72\155\163\57\x73\x65\x63\x64\163\x69\x67\x3a\124\162\141\x6e\163\146\157\x72\x6d";
        $oJ = $OE->query($wF, $we);
        $kf = "\150\164\x74\x70\72\57\x2f\167\167\167\56\x77\63\x2e\157\x72\x67\57\x54\x52\x2f\x32\x30\60\61\x2f\122\105\103\x2d\x78\x6d\x6c\x2d\143\x31\x34\x6e\x2d\62\60\60\x31\x30\x33\x31\x35";
        $uj = null;
        $Lq = null;
        foreach ($oJ as $hC) {
            $FM = $hC->getAttribute("\101\154\x67\x6f\162\151\164\x68\x6d");
            switch ($FM) {
                case "\x68\x74\164\160\x3a\57\57\x77\167\167\x2e\x77\x33\56\x6f\x72\147\x2f\62\x30\60\61\x2f\61\60\57\x78\155\154\55\145\170\x63\55\143\61\x34\156\43":
                case "\150\164\x74\x70\x3a\x2f\x2f\167\x77\167\x2e\167\x33\56\x6f\162\x67\57\62\x30\x30\61\x2f\x31\x30\57\170\155\154\55\145\170\x63\55\143\61\64\156\43\127\x69\164\x68\x43\157\x6d\x6d\145\156\164\163":
                    if (!$yz) {
                        goto Yi;
                    }
                    $kf = $FM;
                    goto qi;
                    Yi:
                    $kf = "\150\x74\164\160\72\x2f\57\x77\x77\167\x2e\167\x33\56\x6f\x72\x67\x2f\x32\60\x30\61\57\61\60\x2f\x78\x6d\x6c\55\145\170\143\55\143\61\64\156\43";
                    qi:
                    $Qh = $hC->firstChild;
                    Ak:
                    if (!$Qh) {
                        goto pz;
                    }
                    if (!($Qh->localName == "\111\156\x63\x6c\x75\x73\151\166\x65\116\x61\x6d\x65\x73\160\x61\143\x65\163")) {
                        goto RI;
                    }
                    if (!($gU = $Qh->getAttribute("\120\x72\x65\146\x69\x78\x4c\151\163\164"))) {
                        goto vT;
                    }
                    $ES = array();
                    $QU = explode("\40", $gU);
                    foreach ($QU as $gU) {
                        $pa = trim($gU);
                        if (empty($pa)) {
                            goto qF;
                        }
                        $ES[] = $pa;
                        qF:
                        Yd:
                    }
                    X_:
                    if (!(count($ES) > 0)) {
                        goto n4;
                    }
                    $Lq = $ES;
                    n4:
                    vT:
                    goto pz;
                    RI:
                    $Qh = $Qh->nextSibling;
                    goto Ak;
                    pz:
                    goto Pc;
                case "\150\164\x74\160\x3a\x2f\x2f\167\167\167\56\167\63\x2e\157\x72\x67\x2f\x54\122\57\62\60\60\x31\x2f\122\105\103\x2d\170\x6d\154\55\x63\x31\64\x6e\x2d\x32\x30\x30\x31\60\x33\61\x35":
                case "\x68\x74\164\160\x3a\57\x2f\167\167\x77\56\167\x33\x2e\x6f\162\147\x2f\x54\x52\57\62\x30\x30\x31\x2f\x52\x45\x43\x2d\x78\x6d\154\55\143\61\x34\156\55\x32\60\x30\x31\60\63\x31\65\43\127\x69\x74\150\103\157\155\155\x65\156\164\163":
                    if (!$yz) {
                        goto Cq;
                    }
                    $kf = $FM;
                    goto MO;
                    Cq:
                    $kf = "\150\x74\164\x70\x3a\x2f\57\167\x77\x77\56\167\63\x2e\157\162\147\x2f\124\122\57\62\60\60\x31\x2f\x52\105\103\x2d\170\x6d\154\55\143\61\64\156\x2d\x32\60\x30\x31\x30\x33\61\x35";
                    MO:
                    goto Pc;
                case "\x68\164\164\x70\72\57\x2f\x77\167\x77\56\x77\63\x2e\157\162\x67\57\124\122\57\61\x39\x39\71\57\x52\x45\103\55\170\160\141\x74\150\55\x31\x39\71\x39\x31\x31\61\66":
                    $Qh = $hC->firstChild;
                    ZO:
                    if (!$Qh) {
                        goto uD;
                    }
                    if (!($Qh->localName == "\x58\120\141\164\150")) {
                        goto i1;
                    }
                    $uj = array();
                    $uj["\161\x75\x65\x72\x79"] = "\50\x2e\x2f\x2f\56\40\x7c\40\56\x2f\57\x40\x2a\x20\x7c\40\x2e\x2f\x2f\x6e\x61\155\x65\x73\160\141\x63\x65\x3a\72\x2a\51\133" . $Qh->nodeValue . "\135";
                    $zK["\156\141\155\x65\163\160\141\x63\x65\x73"] = array();
                    $u1 = $OE->query("\56\x2f\x6e\141\x6d\145\163\160\141\143\145\x3a\72\x2a", $Qh);
                    foreach ($u1 as $UO) {
                        if (!($UO->localName != "\x78\x6d\x6c")) {
                            goto HD;
                        }
                        $uj["\x6e\141\155\x65\163\x70\x61\x63\145\163"][$UO->localName] = $UO->nodeValue;
                        HD:
                        A_:
                    }
                    dB:
                    goto uD;
                    i1:
                    $Qh = $Qh->nextSibling;
                    goto ZO;
                    uD:
                    goto Pc;
            }
            Au:
            Pc:
            ma:
        }
        qy:
        if (!$jd instanceof DOMNode) {
            goto KC;
        }
        $jd = $this->canonicalizeData($ZS, $kf, $uj, $Lq);
        KC:
        return $jd;
    }
    public function processRefNode($we)
    {
        $LM = null;
        $yz = true;
        if ($k3 = $we->getAttribute("\x55\x52\x49")) {
            goto ju;
        }
        $yz = false;
        $LM = $we->ownerDocument;
        goto I9;
        ju:
        $E_ = parse_url($k3);
        if (!empty($E_["\160\x61\x74\150"])) {
            goto Da;
        }
        if ($hl = $E_["\x66\x72\141\147\155\x65\156\164"]) {
            goto t9;
        }
        $LM = $we->ownerDocument;
        goto Fe;
        t9:
        $yz = false;
        $p7 = new DOMXPath($we->ownerDocument);
        if (!($this->idNS && is_array($this->idNS))) {
            goto T0;
        }
        foreach ($this->idNS as $us => $Ud) {
            $p7->registerNamespace($us, $Ud);
            ku:
        }
        pA:
        T0:
        $RN = "\x40\x49\144\x3d\42" . XPath::filterAttrValue($hl, XPath::DOUBLE_QUOTE) . "\x22";
        if (!is_array($this->idKeys)) {
            goto Br;
        }
        foreach ($this->idKeys as $Cf) {
            $RN .= "\x20\157\162\x20\100" . XPath::filterAttrName($Cf) . "\x3d\x22" . XPath::filterAttrValue($hl, XPath::DOUBLE_QUOTE) . "\x22";
            db:
        }
        Aj:
        Br:
        $wF = "\x2f\57\52\133" . $RN . "\135";
        $LM = $p7->query($wF)->item(0);
        Fe:
        Da:
        I9:
        $jd = $this->processTransforms($we, $LM, $yz);
        if ($this->validateDigest($we, $jd)) {
            goto Jk;
        }
        return false;
        Jk:
        if (!$LM instanceof DOMNode) {
            goto b6;
        }
        if (!empty($hl)) {
            goto ZX;
        }
        $this->validatedNodes[] = $LM;
        goto uG;
        ZX:
        $this->validatedNodes[$hl] = $LM;
        uG:
        b6:
        return true;
    }
    public function getRefNodeID($we)
    {
        if (!($k3 = $we->getAttribute("\125\x52\111"))) {
            goto Lc;
        }
        $E_ = parse_url($k3);
        if (!empty($E_["\x70\141\164\150"])) {
            goto vs;
        }
        if (!($hl = $E_["\x66\162\141\147\x6d\x65\x6e\164"])) {
            goto kz;
        }
        return $hl;
        kz:
        vs:
        Lc:
        return null;
    }
    public function getRefIDs()
    {
        $tm = array();
        $OE = $this->getXPathObj();
        $wF = "\x2e\57\163\145\x63\x64\x73\151\147\72\123\151\147\x6e\x65\144\111\x6e\146\x6f\57\x73\145\143\144\163\151\x67\72\122\145\146\145\162\145\156\x63\x65";
        $Gf = $OE->query($wF, $this->sigNode);
        if (!($Gf->length == 0)) {
            goto Nv;
        }
        throw new Exception("\x52\145\x66\x65\162\145\156\x63\x65\x20\x6e\157\x64\x65\163\40\156\157\x74\40\146\157\x75\156\144");
        Nv:
        foreach ($Gf as $we) {
            $tm[] = $this->getRefNodeID($we);
            Pj:
        }
        Aq:
        return $tm;
    }
    public function validateReference()
    {
        $pi = $this->sigNode->ownerDocument->documentElement;
        if ($pi->isSameNode($this->sigNode)) {
            goto N7;
        }
        if (!($this->sigNode->parentNode != null)) {
            goto Nu;
        }
        $this->sigNode->parentNode->removeChild($this->sigNode);
        Nu:
        N7:
        $OE = $this->getXPathObj();
        $wF = "\x2e\x2f\163\x65\143\x64\163\x69\147\72\x53\x69\x67\x6e\x65\x64\111\x6e\146\x6f\57\x73\x65\143\144\x73\x69\x67\x3a\122\145\x66\145\x72\x65\x6e\x63\145";
        $Gf = $OE->query($wF, $this->sigNode);
        if (!($Gf->length == 0)) {
            goto Xx;
        }
        throw new Exception("\x52\145\146\145\162\x65\x6e\143\x65\x20\156\157\144\145\x73\x20\156\157\164\x20\146\157\x75\x6e\144");
        Xx:
        $this->validatedNodes = array();
        foreach ($Gf as $we) {
            if ($this->processRefNode($we)) {
                goto B0;
            }
            $this->validatedNodes = null;
            throw new Exception("\122\x65\146\145\x72\145\x6e\143\145\x20\x76\141\154\x69\144\x61\x74\151\157\156\x20\146\x61\x69\154\x65\144");
            B0:
            gv:
        }
        b4:
        return true;
    }
    private function addRefInternal($rV, $Qh, $FM, $MG = null, $Z1 = null)
    {
        $cg = null;
        $GR = null;
        $IH = "\x49\144";
        $L4 = true;
        $tf = false;
        if (!is_array($Z1)) {
            goto T7;
        }
        $cg = empty($Z1["\160\162\145\x66\x69\170"]) ? null : $Z1["\x70\162\x65\x66\151\170"];
        $GR = empty($Z1["\x70\162\145\146\151\170\137\156\163"]) ? null : $Z1["\x70\162\x65\x66\151\x78\x5f\156\163"];
        $IH = empty($Z1["\x69\x64\x5f\x6e\141\x6d\x65"]) ? "\x49\144" : $Z1["\151\x64\137\156\141\x6d\145"];
        $L4 = !isset($Z1["\157\166\145\162\x77\x72\151\164\145"]) ? true : (bool) $Z1["\x6f\166\145\x72\x77\162\151\x74\145"];
        $tf = !isset($Z1["\146\x6f\x72\x63\x65\137\165\162\151"]) ? false : (bool) $Z1["\146\x6f\x72\x63\145\137\165\162\x69"];
        T7:
        $WZ = $IH;
        if (empty($cg)) {
            goto KX;
        }
        $WZ = $cg . "\72" . $WZ;
        KX:
        $we = $this->createNewSignNode("\122\145\146\145\x72\x65\156\x63\145");
        $rV->appendChild($we);
        if (!$Qh instanceof DOMDocument) {
            goto xD;
        }
        if ($tf) {
            goto h8;
        }
        goto WZ;
        xD:
        $k3 = null;
        if ($L4) {
            goto KB;
        }
        $k3 = $GR ? $Qh->getAttributeNS($GR, $IH) : $Qh->getAttribute($IH);
        KB:
        if (!empty($k3)) {
            goto M1;
        }
        $k3 = self::generateGUID();
        $Qh->setAttributeNS($GR, $WZ, $k3);
        M1:
        $we->setAttribute("\125\122\111", "\43" . $k3);
        goto WZ;
        h8:
        $we->setAttribute("\125\x52\x49", '');
        WZ:
        $qy = $this->createNewSignNode("\x54\x72\x61\156\x73\x66\157\x72\x6d\x73");
        $we->appendChild($qy);
        if (is_array($MG)) {
            goto dy;
        }
        if (!empty($this->canonicalMethod)) {
            goto Eh;
        }
        goto dl;
        dy:
        foreach ($MG as $hC) {
            $J5 = $this->createNewSignNode("\124\x72\x61\156\x73\x66\157\162\155");
            $qy->appendChild($J5);
            if (is_array($hC) && !empty($hC["\150\x74\x74\160\x3a\x2f\57\x77\167\167\56\167\x33\x2e\157\162\147\57\x54\122\x2f\61\x39\x39\x39\x2f\x52\105\x43\55\x78\x70\141\164\150\55\61\71\71\x39\x31\x31\61\66"]) && !empty($hC["\150\164\x74\160\x3a\x2f\57\x77\167\x77\x2e\x77\x33\56\157\162\x67\x2f\124\x52\57\61\71\x39\x39\x2f\x52\105\103\55\x78\160\x61\164\150\x2d\61\x39\71\x39\x31\61\61\x36"]["\161\165\145\162\171"])) {
                goto Af;
            }
            $J5->setAttribute("\x41\x6c\147\157\x72\151\164\150\x6d", $hC);
            goto oq;
            Af:
            $J5->setAttribute("\101\154\147\157\162\x69\x74\x68\x6d", "\x68\x74\x74\160\72\57\x2f\x77\167\167\56\x77\x33\56\157\162\147\x2f\124\122\x2f\61\71\71\x39\57\x52\x45\x43\x2d\x78\x70\141\x74\x68\55\x31\71\x39\x39\x31\61\x31\x36");
            $IU = $this->createNewSignNode("\130\120\x61\x74\x68", $hC["\x68\164\164\x70\x3a\57\57\x77\x77\x77\x2e\167\63\x2e\157\x72\147\57\x54\x52\x2f\x31\x39\71\71\x2f\x52\105\x43\x2d\x78\160\141\x74\150\x2d\61\x39\x39\x39\x31\61\61\x36"]["\161\x75\145\x72\x79"]);
            $J5->appendChild($IU);
            if (empty($hC["\150\x74\164\160\72\x2f\x2f\x77\x77\167\x2e\167\63\56\157\162\147\57\x54\x52\x2f\x31\x39\71\x39\57\x52\105\x43\x2d\170\160\141\164\x68\55\x31\x39\x39\x39\61\61\61\66"]["\x6e\x61\x6d\x65\x73\160\141\143\x65\163"])) {
                goto tg;
            }
            foreach ($hC["\150\x74\164\160\72\57\x2f\167\x77\167\x2e\x77\x33\x2e\x6f\x72\x67\x2f\124\122\57\x31\71\x39\71\57\x52\105\103\x2d\x78\x70\x61\164\x68\x2d\61\71\71\x39\61\61\61\66"]["\156\141\x6d\145\163\x70\x61\x63\145\163"] as $cg => $pK) {
                $IU->setAttributeNS("\150\x74\x74\160\72\57\57\167\167\x77\56\x77\x33\56\157\162\147\57\62\x30\x30\60\57\170\x6d\x6c\156\x73\x2f", "\x78\x6d\154\156\x73\72{$cg}", $pK);
                hw:
            }
            PI:
            tg:
            oq:
            iC:
        }
        So:
        goto dl;
        Eh:
        $J5 = $this->createNewSignNode("\x54\162\141\156\163\x66\x6f\162\155");
        $qy->appendChild($J5);
        $J5->setAttribute("\x41\154\147\x6f\162\x69\164\x68\x6d", $this->canonicalMethod);
        dl:
        $m_ = $this->processTransforms($we, $Qh);
        $vp = $this->calculateDigest($FM, $m_);
        $G7 = $this->createNewSignNode("\104\x69\147\145\x73\164\x4d\145\x74\x68\157\144");
        $we->appendChild($G7);
        $G7->setAttribute("\x41\154\x67\x6f\162\x69\x74\150\x6d", $FM);
        $sp = $this->createNewSignNode("\104\x69\147\145\163\164\x56\141\x6c\x75\x65", $vp);
        $we->appendChild($sp);
    }
    public function addReference($Qh, $FM, $MG = null, $Z1 = null)
    {
        if (!($OE = $this->getXPathObj())) {
            goto no;
        }
        $wF = "\x2e\57\163\145\143\x64\163\151\147\72\123\x69\147\156\145\x64\x49\156\x66\x6f";
        $Gf = $OE->query($wF, $this->sigNode);
        if (!($PC = $Gf->item(0))) {
            goto Pw;
        }
        $this->addRefInternal($PC, $Qh, $FM, $MG, $Z1);
        Pw:
        no:
    }
    public function addReferenceList($j_, $FM, $MG = null, $Z1 = null)
    {
        if (!($OE = $this->getXPathObj())) {
            goto F1;
        }
        $wF = "\x2e\x2f\163\145\143\x64\163\151\147\72\x53\151\147\x6e\x65\x64\111\x6e\146\157";
        $Gf = $OE->query($wF, $this->sigNode);
        if (!($PC = $Gf->item(0))) {
            goto hu;
        }
        foreach ($j_ as $Qh) {
            $this->addRefInternal($PC, $Qh, $FM, $MG, $Z1);
            bQ:
        }
        Fw:
        hu:
        F1:
    }
    public function addObject($jd, $Ip = null, $Wt = null)
    {
        $XQ = $this->createNewSignNode("\117\142\x6a\145\143\164");
        $this->sigNode->appendChild($XQ);
        if (empty($Ip)) {
            goto Hl;
        }
        $XQ->setAttribute("\115\x69\x6d\145\x54\171\160\145", $Ip);
        Hl:
        if (empty($Wt)) {
            goto zo;
        }
        $XQ->setAttribute("\105\x6e\143\x6f\x64\x69\x6e\x67", $Wt);
        zo:
        if ($jd instanceof DOMElement) {
            goto pv;
        }
        $TO = $this->sigNode->ownerDocument->createTextNode($jd);
        goto X5;
        pv:
        $TO = $this->sigNode->ownerDocument->importNode($jd, true);
        X5:
        $XQ->appendChild($TO);
        return $XQ;
    }
    public function locateKey($Qh = null)
    {
        if (!empty($Qh)) {
            goto zw;
        }
        $Qh = $this->sigNode;
        zw:
        if ($Qh instanceof DOMNode) {
            goto VN;
        }
        return null;
        VN:
        if (!($Bl = $Qh->ownerDocument)) {
            goto v3;
        }
        $OE = new DOMXPath($Bl);
        $OE->registerNamespace("\x73\145\143\144\163\151\147", self::XMLDSIGNS);
        $wF = "\x73\x74\x72\151\x6e\147\50\56\x2f\163\145\143\144\163\151\147\x3a\123\151\x67\156\x65\x64\111\x6e\x66\157\x2f\163\x65\143\x64\163\151\x67\72\123\x69\x67\x6e\141\164\x75\162\145\x4d\x65\164\x68\157\x64\x2f\x40\x41\154\147\157\162\151\164\150\155\x29";
        $FM = $OE->evaluate($wF, $Qh);
        if (!$FM) {
            goto Qc;
        }
        try {
            $xe = new XMLSecurityKey($FM, array("\x74\171\160\145" => "\160\x75\142\x6c\151\x63"));
        } catch (Exception $i0) {
            return null;
        }
        return $xe;
        Qc:
        v3:
        return null;
    }
    public function verify($xe)
    {
        $Bl = $this->sigNode->ownerDocument;
        $OE = new DOMXPath($Bl);
        $OE->registerNamespace("\x73\145\143\x64\163\151\147", self::XMLDSIGNS);
        $wF = "\163\x74\162\151\x6e\x67\x28\x2e\57\x73\145\143\144\x73\x69\x67\72\x53\151\x67\x6e\x61\164\165\162\x65\x56\x61\x6c\165\145\x29";
        $QR = $OE->evaluate($wF, $this->sigNode);
        if (!empty($QR)) {
            goto pq;
        }
        throw new Exception("\125\156\x61\x62\x6c\145\40\x74\157\x20\x6c\x6f\x63\141\164\145\40\123\151\x67\156\x61\x74\x75\x72\x65\126\x61\154\x75\145");
        pq:
        return $xe->verifySignature($this->signedInfo, base64_decode($QR));
    }
    public function signData($xe, $jd)
    {
        return $xe->signData($jd);
    }
    public function sign($xe, $gP = null)
    {
        if (!($gP != null)) {
            goto DU;
        }
        $this->resetXPathObj();
        $this->appendSignature($gP);
        $this->sigNode = $gP->lastChild;
        DU:
        if (!($OE = $this->getXPathObj())) {
            goto PP;
        }
        $wF = "\x2e\x2f\163\x65\143\144\x73\151\x67\72\123\151\x67\156\x65\x64\x49\156\146\157";
        $Gf = $OE->query($wF, $this->sigNode);
        if (!($PC = $Gf->item(0))) {
            goto Ee;
        }
        $wF = "\56\57\163\145\x63\144\x73\x69\147\72\x53\151\147\x6e\141\164\165\x72\145\115\x65\164\x68\157\144";
        $Gf = $OE->query($wF, $PC);
        $u5 = $Gf->item(0);
        $u5->setAttribute("\x41\x6c\147\157\162\151\164\150\x6d", $xe->type);
        $jd = $this->canonicalizeData($PC, $this->canonicalMethod);
        $QR = base64_encode($this->signData($xe, $jd));
        $F4 = $this->createNewSignNode("\123\151\147\156\141\164\165\162\145\126\141\154\165\x65", $QR);
        if ($L5 = $PC->nextSibling) {
            goto Yx;
        }
        $this->sigNode->appendChild($F4);
        goto tN;
        Yx:
        $L5->parentNode->insertBefore($F4, $L5);
        tN:
        Ee:
        PP:
    }
    public function appendCert()
    {
    }
    public function appendKey($xe, $mC = null)
    {
        $xe->serializeKey($mC);
    }
    public function insertSignature($Qh, $Cj = null)
    {
        $QJ = $Qh->ownerDocument;
        $Io = $QJ->importNode($this->sigNode, true);
        if ($Cj == null) {
            goto Io;
        }
        return $Qh->insertBefore($Io, $Cj);
        goto Ay;
        Io:
        return $Qh->insertBefore($Io);
        Ay:
    }
    public function appendSignature($U9, $sE = false)
    {
        $Cj = $sE ? $U9->firstChild : null;
        return $this->insertSignature($U9, $Cj);
    }
    public static function get509XCert($Wz, $Tu = true)
    {
        $HW = self::staticGet509XCerts($Wz, $Tu);
        if (empty($HW)) {
            goto Tr;
        }
        return $HW[0];
        Tr:
        return '';
    }
    public static function staticGet509XCerts($HW, $Tu = true)
    {
        if ($Tu) {
            goto Od;
        }
        return array($HW);
        goto M2;
        Od:
        $jd = '';
        $Uo = array();
        $Sb = explode("\12", $HW);
        $rg = false;
        foreach ($Sb as $Wn) {
            if (!$rg) {
                goto Qv;
            }
            if (!(strncmp($Wn, "\x2d\x2d\55\55\x2d\x45\x4e\x44\x20\x43\x45\122\x54\111\106\x49\x43\101\x54\105", 20) == 0)) {
                goto gu;
            }
            $rg = false;
            $Uo[] = $jd;
            $jd = '';
            goto uL;
            gu:
            $jd .= trim($Wn);
            goto fa;
            Qv:
            if (!(strncmp($Wn, "\55\55\x2d\x2d\55\102\x45\107\111\116\40\103\105\122\x54\111\x46\111\103\101\x54\105", 22) == 0)) {
                goto EK;
            }
            $rg = true;
            EK:
            fa:
            uL:
        }
        ja:
        return $Uo;
        M2:
    }
    public static function staticAdd509Cert($u7, $Wz, $Tu = true, $MW = false, $OE = null, $Z1 = null)
    {
        if (!$MW) {
            goto q7;
        }
        $Wz = file_get_contents($Wz);
        q7:
        if ($u7 instanceof DOMElement) {
            goto a5;
        }
        throw new Exception("\x49\156\166\141\x6c\x69\144\40\x70\141\162\145\x6e\164\40\x4e\x6f\144\145\x20\160\x61\162\x61\155\145\x74\x65\x72");
        a5:
        $kz = $u7->ownerDocument;
        if (!empty($OE)) {
            goto oI;
        }
        $OE = new DOMXPath($u7->ownerDocument);
        $OE->registerNamespace("\x73\x65\143\x64\163\x69\147", self::XMLDSIGNS);
        oI:
        $wF = "\x2e\57\163\x65\143\144\163\151\x67\x3a\x4b\x65\x79\111\156\x66\157";
        $Gf = $OE->query($wF, $u7);
        $jV = $Gf->item(0);
        $Al = '';
        if (!$jV) {
            goto in;
        }
        $gU = $jV->lookupPrefix(self::XMLDSIGNS);
        if (empty($gU)) {
            goto mP;
        }
        $Al = $gU . "\x3a";
        mP:
        goto Fu;
        in:
        $gU = $u7->lookupPrefix(self::XMLDSIGNS);
        if (empty($gU)) {
            goto ka;
        }
        $Al = $gU . "\72";
        ka:
        $hx = false;
        $jV = $kz->createElementNS(self::XMLDSIGNS, $Al . "\113\x65\171\111\156\x66\157");
        $wF = "\56\57\x73\145\143\144\x73\151\147\72\117\142\152\x65\x63\164";
        $Gf = $OE->query($wF, $u7);
        if (!($E7 = $Gf->item(0))) {
            goto J2;
        }
        $E7->parentNode->insertBefore($jV, $E7);
        $hx = true;
        J2:
        if ($hx) {
            goto NP;
        }
        $u7->appendChild($jV);
        NP:
        Fu:
        $HW = self::staticGet509XCerts($Wz, $Tu);
        $QV = $kz->createElementNS(self::XMLDSIGNS, $Al . "\x58\x35\x30\x39\104\x61\164\141");
        $jV->appendChild($QV);
        $k_ = false;
        $ha = false;
        if (!is_array($Z1)) {
            goto MZ;
        }
        if (empty($Z1["\x69\x73\x73\x75\145\162\x53\x65\162\x69\141\x6c"])) {
            goto Fa;
        }
        $k_ = true;
        Fa:
        if (empty($Z1["\x73\165\142\x6a\145\x63\x74\x4e\x61\x6d\x65"])) {
            goto rI;
        }
        $ha = true;
        rI:
        MZ:
        foreach ($HW as $F5) {
            if (!($k_ || $ha)) {
                goto R5;
            }
            if (!($NR = openssl_x509_parse("\55\55\55\x2d\55\x42\x45\107\x49\x4e\40\x43\105\122\x54\x49\106\x49\103\101\124\x45\x2d\55\55\x2d\x2d\xa" . chunk_split($F5, 64, "\xa") . "\x2d\55\x2d\x2d\x2d\x45\x4e\104\x20\x43\105\x52\124\x49\x46\x49\x43\101\x54\105\x2d\55\x2d\x2d\x2d\xa"))) {
                goto pM;
            }
            if (!($ha && !empty($NR["\x73\165\x62\152\x65\143\164"]))) {
                goto cB;
            }
            if (is_array($NR["\163\x75\x62\152\145\x63\x74"])) {
                goto X2;
            }
            $uv = $NR["\151\x73\x73\x75\x65\x72"];
            goto XE;
            X2:
            $wq = array();
            foreach ($NR["\163\165\x62\x6a\145\143\164"] as $xk => $Fh) {
                if (is_array($Fh)) {
                    goto Hc;
                }
                array_unshift($wq, "{$xk}\75{$Fh}");
                goto cA;
                Hc:
                foreach ($Fh as $Gl) {
                    array_unshift($wq, "{$xk}\x3d{$Gl}");
                    i4:
                }
                my:
                cA:
                kW:
            }
            pi:
            $uv = implode("\54", $wq);
            XE:
            $eU = $kz->createElementNS(self::XMLDSIGNS, $Al . "\130\x35\x30\x39\x53\x75\142\x6a\145\x63\164\x4e\141\x6d\145", $uv);
            $QV->appendChild($eU);
            cB:
            if (!($k_ && !empty($NR["\151\163\163\x75\x65\x72"]) && !empty($NR["\163\145\162\151\x61\154\x4e\x75\155\x62\x65\x72"]))) {
                goto qh;
            }
            if (is_array($NR["\x69\x73\163\165\145\x72"])) {
                goto jq;
            }
            $nA = $NR["\151\x73\163\165\x65\x72"];
            goto W1;
            jq:
            $wq = array();
            foreach ($NR["\x69\x73\163\x75\x65\x72"] as $xk => $Fh) {
                array_unshift($wq, "{$xk}\x3d{$Fh}");
                Hk:
            }
            b5:
            $nA = implode("\54", $wq);
            W1:
            $A1 = $kz->createElementNS(self::XMLDSIGNS, $Al . "\130\65\x30\x39\x49\x73\x73\165\x65\162\123\x65\162\x69\x61\x6c");
            $QV->appendChild($A1);
            $fF = $kz->createElementNS(self::XMLDSIGNS, $Al . "\130\65\x30\x39\111\163\163\165\x65\162\116\141\x6d\x65", $nA);
            $A1->appendChild($fF);
            $fF = $kz->createElementNS(self::XMLDSIGNS, $Al . "\x58\x35\x30\71\x53\x65\162\151\x61\x6c\116\x75\x6d\142\145\162", $NR["\x73\x65\x72\x69\141\154\116\x75\155\142\x65\162"]);
            $A1->appendChild($fF);
            qh:
            pM:
            R5:
            $dM = $kz->createElementNS(self::XMLDSIGNS, $Al . "\x58\65\x30\x39\x43\x65\162\164\x69\146\x69\x63\141\164\145", $F5);
            $QV->appendChild($dM);
            MI:
        }
        MU:
    }
    public function add509Cert($Wz, $Tu = true, $MW = false, $Z1 = null)
    {
        if (!($OE = $this->getXPathObj())) {
            goto aD;
        }
        self::staticAdd509Cert($this->sigNode, $Wz, $Tu, $MW, $OE, $Z1);
        aD:
    }
    public function appendToKeyInfo($Qh)
    {
        $u7 = $this->sigNode;
        $kz = $u7->ownerDocument;
        $OE = $this->getXPathObj();
        if (!empty($OE)) {
            goto eT;
        }
        $OE = new DOMXPath($u7->ownerDocument);
        $OE->registerNamespace("\163\145\143\x64\x73\151\x67", self::XMLDSIGNS);
        eT:
        $wF = "\56\x2f\163\145\x63\x64\x73\151\147\x3a\x4b\145\171\111\156\x66\x6f";
        $Gf = $OE->query($wF, $u7);
        $jV = $Gf->item(0);
        if ($jV) {
            goto DG;
        }
        $Al = '';
        $gU = $u7->lookupPrefix(self::XMLDSIGNS);
        if (empty($gU)) {
            goto At;
        }
        $Al = $gU . "\x3a";
        At:
        $hx = false;
        $jV = $kz->createElementNS(self::XMLDSIGNS, $Al . "\113\145\x79\x49\x6e\146\x6f");
        $wF = "\x2e\57\x73\145\x63\x64\x73\x69\x67\x3a\117\x62\152\145\143\164";
        $Gf = $OE->query($wF, $u7);
        if (!($E7 = $Gf->item(0))) {
            goto ea;
        }
        $E7->parentNode->insertBefore($jV, $E7);
        $hx = true;
        ea:
        if ($hx) {
            goto nw;
        }
        $u7->appendChild($jV);
        nw:
        DG:
        $jV->appendChild($Qh);
        return $jV;
    }
    public function getValidatedNodes()
    {
        return $this->validatedNodes;
    }
}
