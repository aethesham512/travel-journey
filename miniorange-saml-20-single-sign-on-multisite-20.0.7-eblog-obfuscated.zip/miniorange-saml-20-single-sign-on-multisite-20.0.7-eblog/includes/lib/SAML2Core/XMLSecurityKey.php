<?php


namespace RobRichards\XMLSecLibs;

use DOMElement;
use Exception;
class XMLSecurityKey
{
    const TRIPLEDES_CBC = "\150\164\x74\x70\x3a\x2f\57\167\x77\x77\x2e\x77\x33\x2e\x6f\x72\147\x2f\x32\60\x30\x31\57\x30\x34\57\x78\155\x6c\145\156\143\x23\164\162\151\160\154\x65\144\x65\x73\x2d\143\x62\x63";
    const AES128_CBC = "\150\164\x74\x70\72\x2f\x2f\x77\x77\x77\56\167\x33\x2e\x6f\162\x67\x2f\x32\x30\x30\61\x2f\x30\x34\x2f\170\155\154\145\x6e\143\x23\x61\145\163\61\x32\70\x2d\x63\x62\143";
    const AES192_CBC = "\150\164\164\160\x3a\57\57\167\x77\167\56\167\63\x2e\157\162\x67\x2f\x32\60\x30\x31\57\x30\64\57\170\x6d\154\x65\x6e\143\x23\x61\x65\163\x31\71\62\x2d\143\142\x63";
    const AES256_CBC = "\150\164\x74\160\x3a\x2f\x2f\167\x77\167\x2e\x77\63\x2e\x6f\162\147\57\x32\x30\x30\61\57\x30\x34\x2f\x78\x6d\x6c\145\156\143\43\141\145\163\x32\65\66\x2d\143\142\143";
    const RSA_1_5 = "\150\x74\164\160\x3a\x2f\57\167\167\167\x2e\x77\63\x2e\x6f\x72\147\x2f\x32\60\x30\61\57\x30\x34\57\x78\x6d\154\x65\156\143\x23\162\x73\141\55\61\137\x35";
    const RSA_OAEP_MGF1P = "\150\x74\x74\x70\x3a\57\57\x77\167\167\56\167\x33\x2e\157\162\147\x2f\x32\60\x30\x31\57\x30\64\57\170\x6d\x6c\x65\x6e\143\x23\162\x73\x61\55\x6f\x61\x65\x70\x2d\155\147\x66\61\x70";
    const DSA_SHA1 = "\150\x74\x74\x70\x3a\x2f\x2f\x77\x77\x77\56\x77\x33\x2e\x6f\162\147\57\62\x30\60\60\x2f\60\x39\x2f\x78\x6d\154\144\x73\x69\x67\x23\x64\163\141\x2d\163\150\141\61";
    const RSA_SHA1 = "\x68\164\x74\160\x3a\x2f\57\167\167\167\x2e\167\63\x2e\157\x72\147\x2f\62\x30\x30\60\57\x30\71\57\x78\x6d\154\144\x73\151\147\43\x72\x73\141\55\163\x68\141\61";
    const RSA_SHA256 = "\x68\164\x74\160\x3a\57\x2f\167\x77\x77\x2e\167\63\56\x6f\x72\147\57\x32\60\60\x31\x2f\x30\x34\57\x78\155\x6c\x64\x73\x69\147\x2d\155\x6f\162\x65\43\162\x73\141\55\x73\150\141\62\65\x36";
    const RSA_SHA384 = "\x68\x74\x74\160\x3a\57\57\x77\x77\167\56\167\63\56\157\162\x67\x2f\x32\x30\60\x31\x2f\x30\64\x2f\x78\x6d\x6c\144\163\151\147\55\155\x6f\x72\145\x23\162\x73\141\55\163\x68\141\63\x38\x34";
    const RSA_SHA512 = "\x68\164\164\160\72\57\x2f\167\x77\x77\x2e\x77\63\56\x6f\162\147\57\x32\60\60\61\x2f\x30\64\x2f\170\155\154\144\x73\151\x67\x2d\x6d\x6f\162\x65\x23\162\x73\141\x2d\x73\150\x61\65\x31\x32";
    const HMAC_SHA1 = "\150\x74\x74\160\72\57\57\167\167\x77\x2e\x77\63\x2e\157\x72\x67\x2f\62\x30\x30\60\x2f\60\71\57\x78\155\x6c\x64\x73\151\147\x23\x68\155\x61\x63\55\x73\150\141\61";
    private $cryptParams = array();
    public $type = 0;
    public $key = null;
    public $passphrase = '';
    public $iv = null;
    public $name = null;
    public $keyChain = null;
    public $isEncrypted = false;
    public $encryptedCtx = null;
    public $guid = null;
    private $x509Certificate = null;
    private $X509Thumbprint = null;
    public function __construct($ew, $BM = null)
    {
        switch ($ew) {
            case self::TRIPLEDES_CBC:
                $this->cryptParams["\154\x69\142\x72\141\162\x79"] = "\x6f\x70\x65\156\x73\163\154";
                $this->cryptParams["\143\151\x70\150\x65\162"] = "\x64\x65\163\x2d\145\x64\x65\x33\x2d\x63\x62\143";
                $this->cryptParams["\164\x79\160\145"] = "\163\171\155\155\145\164\x72\151\x63";
                $this->cryptParams["\x6d\x65\164\x68\x6f\x64"] = "\x68\x74\x74\160\72\x2f\57\x77\x77\x77\x2e\167\63\x2e\x6f\162\147\57\x32\x30\60\x31\x2f\60\64\x2f\x78\x6d\x6c\145\x6e\x63\x23\x74\x72\151\160\x6c\x65\144\x65\x73\55\x63\142\143";
                $this->cryptParams["\153\145\x79\163\x69\172\145"] = 24;
                $this->cryptParams["\142\154\x6f\143\153\x73\151\172\x65"] = 8;
                goto Gc;
            case self::AES128_CBC:
                $this->cryptParams["\x6c\x69\x62\162\x61\162\171"] = "\x6f\x70\x65\x6e\x73\163\154";
                $this->cryptParams["\143\151\x70\x68\145\x72"] = "\141\145\x73\x2d\61\x32\70\x2d\x63\142\143";
                $this->cryptParams["\x74\x79\160\x65"] = "\163\x79\155\x6d\x65\x74\x72\x69\x63";
                $this->cryptParams["\x6d\x65\x74\150\157\144"] = "\x68\x74\164\160\x3a\x2f\57\167\167\x77\x2e\167\x33\x2e\157\162\147\x2f\62\x30\x30\x31\x2f\60\64\57\x78\x6d\x6c\145\156\143\43\141\145\163\x31\x32\70\55\x63\142\x63";
                $this->cryptParams["\153\x65\x79\163\151\172\145"] = 16;
                $this->cryptParams["\142\154\x6f\143\x6b\x73\151\172\145"] = 16;
                goto Gc;
            case self::AES192_CBC:
                $this->cryptParams["\154\x69\142\x72\x61\x72\x79"] = "\x6f\160\x65\x6e\x73\163\154";
                $this->cryptParams["\143\x69\x70\150\x65\x72"] = "\141\145\163\x2d\x31\x39\x32\x2d\x63\142\143";
                $this->cryptParams["\x74\171\160\145"] = "\163\171\x6d\155\x65\164\162\151\143";
                $this->cryptParams["\155\145\x74\150\157\144"] = "\150\164\x74\x70\72\57\x2f\x77\167\x77\56\x77\63\x2e\157\162\147\x2f\x32\60\x30\x31\x2f\x30\64\57\x78\155\154\x65\x6e\143\x23\141\145\x73\x31\x39\62\x2d\x63\x62\143";
                $this->cryptParams["\x6b\x65\x79\x73\151\x7a\145"] = 24;
                $this->cryptParams["\x62\x6c\x6f\x63\x6b\163\x69\x7a\145"] = 16;
                goto Gc;
            case self::AES256_CBC:
                $this->cryptParams["\x6c\x69\142\162\x61\162\x79"] = "\157\x70\x65\x6e\163\163\x6c";
                $this->cryptParams["\x63\151\160\150\145\162"] = "\141\145\163\x2d\62\65\x36\55\x63\x62\143";
                $this->cryptParams["\164\x79\x70\145"] = "\x73\x79\155\155\x65\164\x72\x69\143";
                $this->cryptParams["\x6d\x65\x74\150\157\x64"] = "\x68\x74\164\x70\x3a\57\57\167\x77\x77\56\167\63\x2e\x6f\162\x67\x2f\62\x30\x30\x31\x2f\60\x34\57\x78\155\x6c\145\x6e\x63\x23\x61\x65\163\x32\65\x36\x2d\143\142\143";
                $this->cryptParams["\x6b\x65\x79\x73\151\x7a\145"] = 32;
                $this->cryptParams["\142\x6c\157\143\153\x73\151\x7a\145"] = 16;
                goto Gc;
            case self::RSA_1_5:
                $this->cryptParams["\x6c\151\142\x72\x61\x72\x79"] = "\157\x70\x65\156\163\163\x6c";
                $this->cryptParams["\160\141\144\144\x69\156\147"] = OPENSSL_PKCS1_PADDING;
                $this->cryptParams["\x6d\x65\x74\x68\157\x64"] = "\150\164\x74\160\72\x2f\57\x77\167\x77\56\x77\63\56\x6f\162\x67\x2f\62\x30\60\x31\x2f\60\64\57\170\x6d\154\145\x6e\143\43\162\163\141\x2d\61\137\65";
                if (!(is_array($BM) && !empty($BM["\164\171\160\x65"]))) {
                    goto Ko;
                }
                if (!($BM["\164\x79\160\x65"] == "\x70\165\x62\154\x69\143" || $BM["\x74\171\160\x65"] == "\x70\162\151\166\141\164\x65")) {
                    goto fy;
                }
                $this->cryptParams["\x74\x79\x70\145"] = $BM["\164\x79\160\x65"];
                goto Gc;
                fy:
                Ko:
                throw new Exception("\103\x65\x72\x74\151\146\x69\x63\x61\x74\x65\x20\42\x74\171\x70\145\42\40\50\x70\x72\x69\x76\x61\164\x65\x2f\160\165\142\154\151\x63\51\40\x6d\x75\163\164\40\142\x65\40\160\x61\163\x73\x65\x64\40\x76\151\141\x20\160\141\162\141\x6d\x65\x74\x65\x72\x73");
            case self::RSA_OAEP_MGF1P:
                $this->cryptParams["\x6c\151\x62\162\141\x72\x79"] = "\x6f\160\x65\156\163\x73\154";
                $this->cryptParams["\x70\x61\144\144\x69\x6e\147"] = OPENSSL_PKCS1_OAEP_PADDING;
                $this->cryptParams["\155\145\x74\x68\157\144"] = "\x68\164\x74\x70\72\x2f\57\167\167\167\56\167\63\56\157\162\x67\x2f\62\60\60\x31\x2f\x30\x34\57\170\155\154\145\156\143\x23\162\x73\141\55\157\141\145\160\55\x6d\x67\x66\61\160";
                $this->cryptParams["\150\x61\163\x68"] = null;
                if (!(is_array($BM) && !empty($BM["\164\171\160\145"]))) {
                    goto AL;
                }
                if (!($BM["\x74\171\160\145"] == "\160\x75\142\154\151\143" || $BM["\x74\171\x70\145"] == "\x70\x72\151\166\x61\x74\145")) {
                    goto rT;
                }
                $this->cryptParams["\164\x79\160\145"] = $BM["\164\171\x70\145"];
                goto Gc;
                rT:
                AL:
                throw new Exception("\103\145\162\x74\151\x66\x69\x63\x61\164\x65\x20\x22\164\x79\160\x65\x22\40\50\x70\x72\151\x76\141\x74\145\57\160\x75\x62\x6c\151\x63\x29\40\155\165\163\164\x20\x62\145\40\160\141\x73\x73\x65\144\40\166\151\141\40\160\141\x72\x61\155\145\164\145\x72\x73");
            case self::RSA_SHA1:
                $this->cryptParams["\154\151\142\162\x61\162\x79"] = "\x6f\160\x65\x6e\163\163\x6c";
                $this->cryptParams["\x6d\145\164\150\x6f\144"] = "\x68\x74\164\160\x3a\57\57\167\x77\x77\56\167\63\x2e\x6f\162\x67\x2f\x32\x30\x30\60\57\x30\x39\x2f\x78\x6d\x6c\x64\x73\x69\x67\43\x72\163\141\x2d\163\150\141\61";
                $this->cryptParams["\x70\x61\x64\144\x69\x6e\147"] = OPENSSL_PKCS1_PADDING;
                if (!(is_array($BM) && !empty($BM["\164\171\x70\145"]))) {
                    goto wX;
                }
                if (!($BM["\164\x79\x70\145"] == "\x70\165\142\x6c\x69\143" || $BM["\164\171\160\145"] == "\160\162\x69\166\x61\164\145")) {
                    goto sS;
                }
                $this->cryptParams["\164\171\160\x65"] = $BM["\x74\171\160\145"];
                goto Gc;
                sS:
                wX:
                throw new Exception("\103\145\x72\164\x69\x66\151\x63\141\x74\145\40\42\164\171\160\145\42\x20\50\160\x72\x69\x76\141\164\x65\x2f\x70\165\142\154\x69\x63\51\40\155\165\x73\164\40\142\x65\x20\x70\141\x73\163\x65\x64\x20\166\151\x61\40\x70\141\162\x61\x6d\145\164\x65\162\x73");
            case self::RSA_SHA256:
                $this->cryptParams["\154\x69\142\x72\x61\162\171"] = "\157\x70\145\x6e\x73\x73\x6c";
                $this->cryptParams["\x6d\x65\x74\150\157\x64"] = "\x68\x74\164\x70\72\57\x2f\167\167\167\56\167\63\56\x6f\x72\147\x2f\62\x30\x30\61\x2f\60\64\57\170\155\154\x64\x73\x69\147\55\155\157\x72\x65\43\x72\x73\141\x2d\x73\x68\x61\x32\x35\x36";
                $this->cryptParams["\160\141\x64\144\151\x6e\147"] = OPENSSL_PKCS1_PADDING;
                $this->cryptParams["\x64\151\147\x65\163\164"] = "\123\x48\101\x32\65\66";
                if (!(is_array($BM) && !empty($BM["\164\171\160\x65"]))) {
                    goto Yc;
                }
                if (!($BM["\164\171\160\x65"] == "\x70\x75\x62\x6c\x69\x63" || $BM["\x74\171\x70\x65"] == "\160\x72\x69\x76\141\164\x65")) {
                    goto Xq;
                }
                $this->cryptParams["\x74\x79\160\145"] = $BM["\164\171\160\x65"];
                goto Gc;
                Xq:
                Yc:
                throw new Exception("\103\145\162\x74\x69\x66\x69\x63\x61\x74\145\x20\x22\x74\x79\x70\x65\42\40\50\x70\162\x69\x76\141\x74\x65\x2f\x70\165\142\154\151\x63\x29\40\155\165\163\x74\x20\x62\145\40\160\141\163\x73\145\x64\40\x76\x69\141\x20\x70\x61\162\x61\155\x65\164\x65\x72\163");
            case self::RSA_SHA384:
                $this->cryptParams["\x6c\151\142\162\x61\x72\x79"] = "\x6f\x70\x65\156\x73\163\x6c";
                $this->cryptParams["\155\145\164\x68\157\x64"] = "\150\164\164\160\72\x2f\57\x77\x77\x77\56\167\x33\56\x6f\x72\x67\x2f\x32\60\x30\61\x2f\x30\x34\57\170\x6d\x6c\x64\x73\x69\147\55\155\x6f\x72\x65\43\162\x73\141\x2d\x73\x68\x61\x33\70\64";
                $this->cryptParams["\x70\x61\x64\144\151\x6e\x67"] = OPENSSL_PKCS1_PADDING;
                $this->cryptParams["\144\151\147\145\x73\164"] = "\123\110\x41\63\x38\64";
                if (!(is_array($BM) && !empty($BM["\164\x79\x70\145"]))) {
                    goto OC;
                }
                if (!($BM["\164\x79\x70\145"] == "\160\165\142\x6c\151\x63" || $BM["\x74\x79\160\x65"] == "\x70\x72\151\x76\x61\x74\145")) {
                    goto f4;
                }
                $this->cryptParams["\x74\x79\160\x65"] = $BM["\164\x79\160\x65"];
                goto Gc;
                f4:
                OC:
                throw new Exception("\x43\x65\x72\x74\151\146\x69\x63\x61\164\x65\x20\x22\164\171\x70\x65\42\x20\50\x70\x72\x69\166\141\x74\x65\x2f\x70\x75\142\154\x69\x63\51\40\155\165\x73\x74\x20\x62\145\x20\x70\x61\163\x73\x65\144\40\x76\x69\141\40\x70\141\x72\141\155\x65\x74\145\x72\163");
            case self::RSA_SHA512:
                $this->cryptParams["\154\x69\x62\x72\x61\162\x79"] = "\x6f\160\145\x6e\x73\163\x6c";
                $this->cryptParams["\155\145\x74\x68\157\144"] = "\150\164\x74\160\72\x2f\57\167\x77\167\56\167\x33\x2e\157\162\x67\x2f\x32\x30\60\61\57\x30\x34\x2f\x78\x6d\154\144\163\x69\x67\55\x6d\x6f\162\145\43\x72\x73\141\55\163\x68\x61\x35\61\x32";
                $this->cryptParams["\x70\x61\x64\x64\x69\156\x67"] = OPENSSL_PKCS1_PADDING;
                $this->cryptParams["\144\151\x67\x65\x73\x74"] = "\x53\x48\101\x35\61\62";
                if (!(is_array($BM) && !empty($BM["\x74\x79\160\x65"]))) {
                    goto Co;
                }
                if (!($BM["\164\171\160\145"] == "\160\165\142\154\151\143" || $BM["\164\x79\x70\145"] == "\x70\x72\151\166\x61\x74\x65")) {
                    goto XY;
                }
                $this->cryptParams["\x74\x79\160\x65"] = $BM["\x74\x79\x70\145"];
                goto Gc;
                XY:
                Co:
                throw new Exception("\x43\145\162\164\151\146\151\x63\x61\x74\x65\40\x22\164\x79\x70\145\42\40\x28\160\162\151\x76\141\164\x65\57\160\x75\142\154\151\x63\x29\x20\x6d\x75\x73\x74\40\142\x65\x20\160\x61\163\x73\145\x64\40\x76\151\x61\x20\160\141\162\141\x6d\x65\164\145\162\x73");
            case self::HMAC_SHA1:
                $this->cryptParams["\154\151\142\162\141\162\171"] = $ew;
                $this->cryptParams["\x6d\145\x74\150\x6f\144"] = "\150\164\x74\x70\x3a\x2f\57\x77\167\x77\x2e\167\63\x2e\x6f\x72\147\x2f\62\x30\x30\x30\x2f\60\x39\57\x78\x6d\x6c\x64\x73\x69\147\43\150\155\141\143\x2d\163\150\141\x31";
                goto Gc;
            default:
                throw new Exception("\111\x6e\x76\x61\154\x69\x64\40\113\x65\171\40\x54\171\160\145");
        }
        u0:
        Gc:
        $this->type = $ew;
    }
    public function getSymmetricKeySize()
    {
        if (isset($this->cryptParams["\x6b\x65\x79\x73\151\x7a\x65"])) {
            goto R6;
        }
        return null;
        R6:
        return $this->cryptParams["\x6b\x65\171\163\x69\172\x65"];
    }
    public function generateSessionKey()
    {
        if (isset($this->cryptParams["\x6b\x65\x79\163\x69\172\145"])) {
            goto NB;
        }
        throw new Exception("\125\x6e\153\156\x6f\167\156\40\x6b\145\171\x20\163\x69\172\145\x20\146\157\162\40\164\171\160\x65\40\x22" . $this->type . "\x22\x2e");
        NB:
        $bO = $this->cryptParams["\153\x65\x79\x73\x69\172\145"];
        $xk = openssl_random_pseudo_bytes($bO);
        if (!($this->type === self::TRIPLEDES_CBC)) {
            goto N5;
        }
        $OA = 0;
        v0:
        if (!($OA < strlen($xk))) {
            goto Xw;
        }
        $zq = ord($xk[$OA]) & 0xfe;
        $Yy = 1;
        $gB = 1;
        ER:
        if (!($gB < 8)) {
            goto wD;
        }
        $Yy ^= $zq >> $gB & 1;
        ob:
        $gB++;
        goto ER;
        wD:
        $zq |= $Yy;
        $xk[$OA] = chr($zq);
        y0:
        $OA++;
        goto v0;
        Xw:
        N5:
        $this->key = $xk;
        return $xk;
    }
    public static function getRawThumbprint($Wz)
    {
        $Sb = explode("\12", $Wz);
        $jd = '';
        $rg = false;
        foreach ($Sb as $Wn) {
            if (!$rg) {
                goto qk;
            }
            if (!(strncmp($Wn, "\55\55\55\x2d\x2d\105\x4e\x44\40\x43\x45\x52\x54\x49\x46\x49\103\x41\x54\x45", 20) == 0)) {
                goto kC;
            }
            goto CE;
            kC:
            $jd .= trim($Wn);
            goto lY;
            qk:
            if (!(strncmp($Wn, "\x2d\55\55\55\55\x42\105\x47\111\x4e\40\x43\x45\122\124\x49\x46\111\103\101\x54\105", 22) == 0)) {
                goto wx;
            }
            $rg = true;
            wx:
            lY:
            Jf:
        }
        CE:
        if (empty($jd)) {
            goto vl;
        }
        return strtolower(sha1(base64_decode($jd)));
        vl:
        return null;
    }
    public function loadKey($xk, $Yu = false, $Ik = false)
    {
        if ($Yu) {
            goto WA;
        }
        $this->key = $xk;
        goto jN;
        WA:
        $this->key = file_get_contents($xk);
        jN:
        if ($Ik) {
            goto xO;
        }
        $this->x509Certificate = null;
        goto i3;
        xO:
        $this->key = openssl_x509_read($this->key);
        openssl_x509_export($this->key, $tU);
        $this->x509Certificate = $tU;
        $this->key = $tU;
        i3:
        if (!($this->cryptParams["\x6c\151\x62\x72\x61\x72\x79"] == "\x6f\x70\x65\156\163\163\x6c")) {
            goto GB;
        }
        switch ($this->cryptParams["\x74\171\160\145"]) {
            case "\160\165\x62\x6c\151\x63":
                if (!$Ik) {
                    goto iA;
                }
                $this->X509Thumbprint = self::getRawThumbprint($this->key);
                iA:
                $this->key = openssl_get_publickey($this->key);
                if ($this->key) {
                    goto KL;
                }
                throw new Exception("\125\156\x61\142\x6c\x65\x20\x74\157\x20\x65\170\x74\162\x61\x63\164\40\x70\165\x62\154\x69\143\x20\153\145\171");
                KL:
                goto JX;
            case "\x70\x72\x69\166\x61\x74\x65":
                $this->key = openssl_get_privatekey($this->key, $this->passphrase);
                goto JX;
            case "\x73\171\x6d\x6d\x65\164\162\x69\143":
                if (!(strlen($this->key) < $this->cryptParams["\153\x65\171\x73\151\172\145"])) {
                    goto VY;
                }
                throw new Exception("\113\x65\171\x20\x6d\165\x73\x74\40\143\x6f\x6e\164\x61\151\x6e\40\x61\164\x20\154\x65\141\x73\x74\40\62\65\x20\x63\x68\x61\x72\141\143\x74\145\162\x73\x20\x66\157\x72\40\x74\x68\x69\x73\40\143\151\160\150\x65\162");
                VY:
                goto JX;
            default:
                throw new Exception("\125\156\x6b\x6e\157\167\156\x20\164\171\160\x65");
        }
        PG:
        JX:
        GB:
    }
    private function padISO10126($jd, $Lp)
    {
        if (!($Lp > 256)) {
            goto Ui;
        }
        throw new Exception("\x42\154\x6f\x63\153\x20\x73\151\x7a\145\40\x68\x69\x67\150\145\x72\x20\x74\150\141\x6e\40\62\65\66\40\x6e\157\164\40\x61\x6c\154\x6f\167\145\x64");
        Ui:
        $Ec = $Lp - strlen($jd) % $Lp;
        $fC = chr($Ec);
        return $jd . str_repeat($fC, $Ec);
    }
    private function unpadISO10126($jd)
    {
        $Ec = substr($jd, -1);
        $eP = ord($Ec);
        return substr($jd, 0, -$eP);
    }
    private function encryptSymmetric($jd)
    {
        $this->iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length($this->cryptParams["\143\x69\x70\150\145\162"]));
        $jd = $this->padISO10126($jd, $this->cryptParams["\x62\x6c\x6f\143\153\163\x69\x7a\145"]);
        $mM = openssl_encrypt($jd, $this->cryptParams["\143\x69\160\x68\145\162"], $this->key, OPENSSL_RAW_DATA | OPENSSL_ZERO_PADDING, $this->iv);
        if (!(false === $mM)) {
            goto FQ;
        }
        throw new Exception("\x46\x61\x69\154\165\162\145\40\145\156\x63\162\171\x70\x74\x69\156\x67\x20\104\141\164\141\40\x28\157\160\x65\156\x73\163\154\40\163\x79\x6d\x6d\x65\164\x72\x69\143\x29\x20\x2d\x20" . openssl_error_string());
        FQ:
        return $this->iv . $mM;
    }
    private function decryptSymmetric($jd)
    {
        $yd = openssl_cipher_iv_length($this->cryptParams["\143\x69\160\150\145\x72"]);
        $this->iv = substr($jd, 0, $yd);
        $jd = substr($jd, $yd);
        $I1 = openssl_decrypt($jd, $this->cryptParams["\x63\151\x70\150\145\x72"], $this->key, OPENSSL_RAW_DATA | OPENSSL_ZERO_PADDING, $this->iv);
        if (!(false === $I1)) {
            goto tP;
        }
        throw new Exception("\106\141\151\154\165\162\145\40\x64\x65\143\x72\x79\160\x74\x69\x6e\x67\x20\x44\x61\x74\x61\x20\x28\x6f\160\145\156\x73\163\154\x20\163\x79\155\155\145\x74\162\151\143\x29\x20\55\x20" . openssl_error_string());
        tP:
        return $this->unpadISO10126($I1);
    }
    private function encryptPublic($jd)
    {
        if (openssl_public_encrypt($jd, $mM, $this->key, $this->cryptParams["\160\141\x64\x64\x69\156\147"])) {
            goto l3;
        }
        throw new Exception("\x46\x61\x69\x6c\165\162\x65\40\x65\156\x63\162\x79\160\x74\151\x6e\147\x20\x44\141\164\141\x20\x28\x6f\x70\145\156\163\x73\x6c\x20\160\x75\142\154\x69\143\51\40\x2d\x20" . openssl_error_string());
        l3:
        return $mM;
    }
    private function decryptPublic($jd)
    {
        if (openssl_public_decrypt($jd, $I1, $this->key, $this->cryptParams["\160\x61\x64\144\151\x6e\147"])) {
            goto Gu;
        }
        throw new Exception("\x46\x61\151\x6c\165\162\x65\40\x64\x65\x63\x72\x79\160\x74\x69\156\147\40\x44\x61\x74\141\x20\50\x6f\160\x65\x6e\163\163\154\x20\x70\165\x62\154\x69\143\x29\40\x2d\x20" . openssl_error_string());
        Gu:
        return $I1;
    }
    private function encryptPrivate($jd)
    {
        if (openssl_private_encrypt($jd, $mM, $this->key, $this->cryptParams["\160\x61\144\x64\151\156\x67"])) {
            goto jG;
        }
        throw new Exception("\x46\141\151\x6c\165\162\145\40\145\x6e\x63\162\x79\160\164\x69\156\147\40\x44\141\164\141\40\50\x6f\x70\145\156\163\163\154\40\160\x72\151\166\x61\164\145\51\x20\x2d\40" . openssl_error_string());
        jG:
        return $mM;
    }
    private function decryptPrivate($jd)
    {
        if (openssl_private_decrypt($jd, $I1, $this->key, $this->cryptParams["\160\x61\144\144\151\x6e\147"])) {
            goto D_;
        }
        throw new Exception("\106\141\151\x6c\x75\162\145\40\144\145\143\x72\171\x70\x74\x69\x6e\x67\x20\x44\141\164\141\x20\x28\x6f\x70\145\156\x73\163\x6c\x20\160\x72\151\x76\141\164\x65\x29\40\55\x20" . openssl_error_string());
        D_:
        return $I1;
    }
    private function signOpenSSL($jd)
    {
        $EP = OPENSSL_ALGO_SHA1;
        if (empty($this->cryptParams["\144\x69\x67\x65\163\164"])) {
            goto RK;
        }
        $EP = $this->cryptParams["\144\151\x67\x65\x73\x74"];
        RK:
        if (openssl_sign($jd, $GX, $this->key, $EP)) {
            goto Pp;
        }
        throw new Exception("\106\141\x69\x6c\x75\162\x65\x20\123\x69\x67\x6e\151\156\147\40\x44\x61\x74\x61\72\40" . openssl_error_string() . "\x20\x2d\x20" . $EP);
        Pp:
        return $GX;
    }
    private function verifyOpenSSL($jd, $GX)
    {
        $EP = OPENSSL_ALGO_SHA1;
        if (empty($this->cryptParams["\x64\x69\x67\145\x73\164"])) {
            goto RT;
        }
        $EP = $this->cryptParams["\x64\151\147\x65\x73\164"];
        RT:
        return openssl_verify($jd, $GX, $this->key, $EP);
    }
    public function encryptData($jd)
    {
        if (!($this->cryptParams["\154\151\142\162\141\x72\x79"] === "\x6f\x70\145\156\x73\163\x6c")) {
            goto v1;
        }
        switch ($this->cryptParams["\164\x79\160\145"]) {
            case "\x73\x79\x6d\155\145\x74\162\x69\143":
                return $this->encryptSymmetric($jd);
            case "\x70\x75\142\x6c\x69\x63":
                return $this->encryptPublic($jd);
            case "\x70\x72\x69\166\141\x74\145":
                return $this->encryptPrivate($jd);
        }
        DW:
        VU:
        v1:
    }
    public function decryptData($jd)
    {
        if (!($this->cryptParams["\154\151\x62\x72\x61\x72\171"] === "\x6f\160\x65\x6e\163\163\x6c")) {
            goto SV;
        }
        switch ($this->cryptParams["\x74\171\160\x65"]) {
            case "\163\x79\x6d\x6d\145\164\x72\x69\x63":
                return $this->decryptSymmetric($jd);
            case "\x70\x75\142\x6c\151\143":
                return $this->decryptPublic($jd);
            case "\x70\162\151\166\141\x74\x65":
                return $this->decryptPrivate($jd);
        }
        OJ:
        B2:
        SV:
    }
    public function signData($jd)
    {
        switch ($this->cryptParams["\x6c\151\142\162\141\162\171"]) {
            case "\157\160\x65\156\163\163\x6c":
                return $this->signOpenSSL($jd);
            case self::HMAC_SHA1:
                return hash_hmac("\x73\x68\x61\61", $jd, $this->key, true);
        }
        h3:
        bX:
    }
    public function verifySignature($jd, $GX)
    {
        switch ($this->cryptParams["\x6c\151\x62\x72\141\x72\x79"]) {
            case "\x6f\160\x65\x6e\163\163\x6c":
                return $this->verifyOpenSSL($jd, $GX);
            case self::HMAC_SHA1:
                $rs = hash_hmac("\x73\x68\141\x31", $jd, $this->key, true);
                return strcmp($GX, $rs) == 0;
        }
        Oo:
        IS:
    }
    public function getAlgorith()
    {
        return $this->getAlgorithm();
    }
    public function getAlgorithm()
    {
        return $this->cryptParams["\155\145\x74\x68\x6f\x64"];
    }
    public static function makeAsnSegment($ew, $fz)
    {
        switch ($ew) {
            case 0x2:
                if (!(ord($fz) > 0x7f)) {
                    goto O8;
                }
                $fz = chr(0) . $fz;
                O8:
                goto um;
            case 0x3:
                $fz = chr(0) . $fz;
                goto um;
        }
        RP:
        um:
        $Bx = strlen($fz);
        if ($Bx < 128) {
            goto Ze;
        }
        if ($Bx < 0x100) {
            goto Ka;
        }
        if ($Bx < 0x10000) {
            goto qG;
        }
        $Wj = null;
        goto wM;
        qG:
        $Wj = sprintf("\45\x63\x25\143\45\143\45\143\x25\163", $ew, 0x82, $Bx / 0x100, $Bx % 0x100, $fz);
        wM:
        goto AV;
        Ka:
        $Wj = sprintf("\x25\x63\x25\143\x25\x63\45\163", $ew, 0x81, $Bx, $fz);
        AV:
        goto hm;
        Ze:
        $Wj = sprintf("\x25\143\x25\x63\x25\x73", $ew, $Bx, $fz);
        hm:
        return $Wj;
    }
    public static function convertRSA($em, $rp)
    {
        $hS = self::makeAsnSegment(0x2, $rp);
        $bY = self::makeAsnSegment(0x2, $em);
        $zr = self::makeAsnSegment(0x30, $bY . $hS);
        $KC = self::makeAsnSegment(0x3, $zr);
        $U2 = pack("\110\x2a", "\x33\60\60\104\60\x36\x30\x39\62\101\x38\x36\x34\x38\70\x36\x46\x37\60\x44\60\x31\x30\61\60\x31\60\x35\x30\60");
        $Mx = self::makeAsnSegment(0x30, $U2 . $KC);
        $Ov = base64_encode($Mx);
        $Wt = "\x2d\55\55\55\x2d\102\x45\107\111\x4e\x20\x50\x55\102\114\111\x43\x20\x4b\105\131\55\x2d\x2d\x2d\x2d\xa";
        $HB = 0;
        cH:
        if (!($LB = substr($Ov, $HB, 64))) {
            goto ej;
        }
        $Wt = $Wt . $LB . "\xa";
        $HB += 64;
        goto cH;
        ej:
        return $Wt . "\x2d\55\55\x2d\55\105\116\104\40\120\x55\102\x4c\111\x43\40\x4b\x45\x59\55\x2d\55\x2d\55\xa";
    }
    public function serializeKey($mC)
    {
    }
    public function getX509Certificate()
    {
        return $this->x509Certificate;
    }
    public function getX509Thumbprint()
    {
        return $this->X509Thumbprint;
    }
    public static function fromEncryptedKeyElement(DOMElement $B7)
    {
        $jD = new XMLSecEnc();
        $jD->setNode($B7);
        if ($xe = $jD->locateKey()) {
            goto fL;
        }
        throw new Exception("\125\x6e\x61\142\x6c\x65\40\164\x6f\40\x6c\x6f\143\141\x74\145\40\141\x6c\x67\157\x72\151\164\150\x6d\40\x66\x6f\x72\x20\164\x68\x69\x73\x20\x45\156\143\162\171\x70\x74\x65\x64\40\113\x65\x79");
        fL:
        $xe->isEncrypted = true;
        $xe->encryptedCtx = $jD;
        XMLSecEnc::staticLocateKeyInfo($xe, $B7);
        return $xe;
    }
}
