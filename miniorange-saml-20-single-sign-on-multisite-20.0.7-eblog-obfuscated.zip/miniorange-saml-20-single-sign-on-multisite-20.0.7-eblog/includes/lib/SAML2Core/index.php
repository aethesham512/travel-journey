<?php


if (defined("\127\x50\111\116\103")) {
    goto Px;
}
die;
Px:
