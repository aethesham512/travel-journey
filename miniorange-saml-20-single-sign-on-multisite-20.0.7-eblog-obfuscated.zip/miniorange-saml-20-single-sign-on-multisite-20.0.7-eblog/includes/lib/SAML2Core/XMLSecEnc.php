<?php


namespace RobRichards\XMLSecLibs;

use DOMDocument;
use DOMNode;
use DOMXPath;
use Exception;
use RobRichards\XMLSecLibs\Utils\XPath as XPath;
class XMLSecEnc
{
    const template = "\x3c\170\145\156\x63\x3a\105\x6e\143\x72\171\160\164\x65\x64\x44\141\164\141\x20\x78\x6d\x6c\x6e\163\x3a\x78\145\x6e\x63\75\47\x68\x74\164\x70\72\x2f\57\x77\x77\x77\56\x77\x33\56\x6f\162\147\57\x32\60\x30\61\x2f\60\x34\x2f\170\155\x6c\145\156\143\x23\x27\x3e\15\xa\x20\x20\40\x3c\170\x65\156\x63\x3a\x43\151\160\x68\x65\162\x44\141\x74\x61\76\15\12\x20\x20\x20\40\x20\x20\74\170\x65\156\143\x3a\103\151\160\150\x65\x72\126\x61\x6c\165\145\x3e\74\57\x78\145\156\x63\x3a\103\151\160\150\x65\162\x56\x61\154\165\x65\76\15\xa\40\40\40\x3c\x2f\170\x65\156\x63\x3a\103\x69\160\x68\x65\x72\x44\141\164\x61\76\xd\xa\x3c\57\x78\145\156\143\x3a\x45\156\x63\162\171\160\164\x65\x64\x44\141\x74\141\76";
    const Element = "\x68\164\x74\160\x3a\x2f\57\167\167\167\56\167\63\x2e\157\162\147\57\x32\x30\x30\x31\57\x30\x34\x2f\170\155\x6c\x65\156\143\x23\x45\x6c\x65\x6d\x65\156\164";
    const Content = "\150\x74\x74\x70\72\x2f\x2f\167\x77\x77\56\167\63\56\157\x72\147\57\x32\60\x30\61\x2f\x30\x34\57\x78\x6d\x6c\145\x6e\x63\x23\x43\x6f\x6e\x74\145\x6e\164";
    const URI = 3;
    const XMLENCNS = "\150\164\164\x70\x3a\57\x2f\167\167\x77\56\167\x33\x2e\157\162\147\x2f\62\x30\60\x31\57\60\x34\x2f\170\x6d\x6c\x65\156\x63\x23";
    private $encdoc = null;
    private $rawNode = null;
    public $type = null;
    public $encKey = null;
    private $references = array();
    public function __construct()
    {
        $this->_resetTemplate();
    }
    private function _resetTemplate()
    {
        $this->encdoc = new DOMDocument();
        $this->encdoc->loadXML(self::template);
    }
    public function addReference($zY, $Qh, $ew)
    {
        if ($Qh instanceof DOMNode) {
            goto PK;
        }
        throw new Exception("\x24\x6e\157\x64\x65\x20\151\163\40\156\157\x74\x20\157\x66\40\164\x79\x70\145\40\104\x4f\115\x4e\157\x64\145");
        PK:
        $Nl = $this->encdoc;
        $this->_resetTemplate();
        $nN = $this->encdoc;
        $this->encdoc = $Nl;
        $Zl = XMLSecurityDSig::generateGUID();
        $B7 = $nN->documentElement;
        $B7->setAttribute("\x49\x64", $Zl);
        $this->references[$zY] = array("\156\x6f\144\x65" => $Qh, "\x74\171\160\x65" => $ew, "\145\156\x63\156\157\x64\x65" => $nN, "\162\x65\146\x75\x72\x69" => $Zl);
    }
    public function setNode($Qh)
    {
        $this->rawNode = $Qh;
    }
    public function encryptNode($xe, $lh = true)
    {
        $jd = '';
        if (!empty($this->rawNode)) {
            goto r_;
        }
        throw new Exception("\116\x6f\144\145\40\x74\x6f\40\x65\x6e\143\162\171\x70\x74\40\x68\x61\x73\40\x6e\x6f\x74\40\142\145\x65\x6e\x20\163\145\x74");
        r_:
        if ($xe instanceof XMLSecurityKey) {
            goto E6;
        }
        throw new Exception("\111\156\166\141\x6c\x69\x64\x20\x4b\x65\x79");
        E6:
        $Bl = $this->rawNode->ownerDocument;
        $p7 = new DOMXPath($this->encdoc);
        $YY = $p7->query("\57\170\x65\x6e\x63\72\x45\x6e\x63\162\171\160\x74\x65\144\104\x61\164\141\x2f\x78\145\156\143\72\103\151\x70\150\x65\x72\104\141\164\141\x2f\170\145\156\x63\x3a\103\x69\x70\150\145\x72\x56\141\x6c\x75\145");
        $ed = $YY->item(0);
        if (!($ed == null)) {
            goto UD;
        }
        throw new Exception("\105\x72\162\157\x72\x20\x6c\157\x63\x61\x74\x69\156\147\x20\103\x69\x70\x68\145\x72\126\141\154\165\x65\x20\x65\154\x65\155\145\x6e\x74\x20\167\x69\164\x68\x69\x6e\x20\x74\x65\155\x70\x6c\141\x74\x65");
        UD:
        switch ($this->type) {
            case self::Element:
                $jd = $Bl->saveXML($this->rawNode);
                $this->encdoc->documentElement->setAttribute("\x54\171\160\x65", self::Element);
                goto Rm;
            case self::Content:
                $EW = $this->rawNode->childNodes;
                foreach ($EW as $w8) {
                    $jd .= $Bl->saveXML($w8);
                    o4:
                }
                Bk:
                $this->encdoc->documentElement->setAttribute("\124\x79\160\145", self::Content);
                goto Rm;
            default:
                throw new Exception("\x54\x79\160\x65\x20\151\x73\40\143\165\x72\x72\145\156\x74\x6c\x79\x20\x6e\157\164\40\x73\165\160\160\157\x72\x74\145\x64");
        }
        VW:
        Rm:
        $hG = $this->encdoc->documentElement->appendChild($this->encdoc->createElementNS(self::XMLENCNS, "\x78\x65\156\x63\72\x45\156\143\162\171\x70\x74\151\157\x6e\115\x65\164\150\157\x64"));
        $hG->setAttribute("\101\154\x67\x6f\162\x69\164\x68\155", $xe->getAlgorithm());
        $ed->parentNode->parentNode->insertBefore($hG, $ed->parentNode->parentNode->firstChild);
        $lE = base64_encode($xe->encryptData($jd));
        $Fh = $this->encdoc->createTextNode($lE);
        $ed->appendChild($Fh);
        if ($lh) {
            goto TJ;
        }
        return $this->encdoc->documentElement;
        goto yn;
        TJ:
        switch ($this->type) {
            case self::Element:
                if (!($this->rawNode->nodeType == XML_DOCUMENT_NODE)) {
                    goto Dg;
                }
                return $this->encdoc;
                Dg:
                $gT = $this->rawNode->ownerDocument->importNode($this->encdoc->documentElement, true);
                $this->rawNode->parentNode->replaceChild($gT, $this->rawNode);
                return $gT;
            case self::Content:
                $gT = $this->rawNode->ownerDocument->importNode($this->encdoc->documentElement, true);
                bi:
                if (!$this->rawNode->firstChild) {
                    goto E5;
                }
                $this->rawNode->removeChild($this->rawNode->firstChild);
                goto bi;
                E5:
                $this->rawNode->appendChild($gT);
                return $gT;
        }
        Ar:
        ML:
        yn:
    }
    public function encryptReferences($xe)
    {
        $Bb = $this->rawNode;
        $zG = $this->type;
        foreach ($this->references as $zY => $Xh) {
            $this->encdoc = $Xh["\145\x6e\x63\x6e\157\144\145"];
            $this->rawNode = $Xh["\156\x6f\x64\x65"];
            $this->type = $Xh["\164\171\160\145"];
            try {
                $Q2 = $this->encryptNode($xe);
                $this->references[$zY]["\x65\156\143\x6e\157\144\x65"] = $Q2;
            } catch (Exception $i0) {
                $this->rawNode = $Bb;
                $this->type = $zG;
                throw $i0;
            }
            YT:
        }
        B4:
        $this->rawNode = $Bb;
        $this->type = $zG;
    }
    public function getCipherValue()
    {
        if (!empty($this->rawNode)) {
            goto Tj;
        }
        throw new Exception("\116\x6f\x64\145\40\164\157\x20\144\x65\143\162\x79\160\x74\x20\x68\x61\163\x20\156\x6f\164\40\142\145\x65\x6e\40\163\x65\x74");
        Tj:
        $Bl = $this->rawNode->ownerDocument;
        $p7 = new DOMXPath($Bl);
        $p7->registerNamespace("\x78\155\154\x65\x6e\x63\162", self::XMLENCNS);
        $wF = "\x2e\x2f\170\x6d\154\x65\156\143\162\72\103\151\160\x68\x65\x72\x44\x61\x74\x61\x2f\170\155\x6c\145\x6e\143\x72\x3a\103\151\x70\150\145\x72\x56\x61\154\165\145";
        $Gf = $p7->query($wF, $this->rawNode);
        $Qh = $Gf->item(0);
        if ($Qh) {
            goto Qu;
        }
        return null;
        Qu:
        return base64_decode($Qh->nodeValue);
    }
    public function decryptNode($xe, $lh = true)
    {
        if ($xe instanceof XMLSecurityKey) {
            goto Hq;
        }
        throw new Exception("\x49\156\x76\141\154\151\x64\40\113\145\x79");
        Hq:
        $BI = $this->getCipherValue();
        if ($BI) {
            goto g8;
        }
        throw new Exception("\103\x61\156\156\x6f\x74\40\x6c\x6f\143\x61\164\145\x20\145\x6e\x63\162\x79\160\x74\145\x64\40\x64\x61\x74\141");
        goto hT;
        g8:
        $I1 = $xe->decryptData($BI);
        if ($lh) {
            goto wH;
        }
        return $I1;
        goto s4;
        wH:
        switch ($this->type) {
            case self::Element:
                $sf = new DOMDocument();
                $sf->loadXML($I1);
                if (!($this->rawNode->nodeType == XML_DOCUMENT_NODE)) {
                    goto CS;
                }
                return $sf;
                CS:
                $gT = $this->rawNode->ownerDocument->importNode($sf->documentElement, true);
                $this->rawNode->parentNode->replaceChild($gT, $this->rawNode);
                return $gT;
            case self::Content:
                if ($this->rawNode->nodeType == XML_DOCUMENT_NODE) {
                    goto q4;
                }
                $Bl = $this->rawNode->ownerDocument;
                goto UI;
                q4:
                $Bl = $this->rawNode;
                UI:
                $xK = $Bl->createDocumentFragment();
                $xK->appendXML($I1);
                $mC = $this->rawNode->parentNode;
                $mC->replaceChild($xK, $this->rawNode);
                return $mC;
            default:
                return $I1;
        }
        y2:
        kH:
        s4:
        hT:
    }
    public function encryptKey($TV, $pM, $Se = true)
    {
        if (!(!$TV instanceof XMLSecurityKey || !$pM instanceof XMLSecurityKey)) {
            goto m_;
        }
        throw new Exception("\x49\x6e\x76\141\154\151\144\x20\x4b\x65\171");
        m_:
        $Xp = base64_encode($TV->encryptData($pM->key));
        $r8 = $this->encdoc->documentElement;
        $MZ = $this->encdoc->createElementNS(self::XMLENCNS, "\170\145\156\x63\72\x45\156\x63\x72\171\160\164\x65\144\113\x65\x79");
        if ($Se) {
            goto m9;
        }
        $this->encKey = $MZ;
        goto iZ;
        m9:
        $jV = $r8->insertBefore($this->encdoc->createElementNS("\150\x74\x74\160\x3a\x2f\x2f\167\x77\x77\56\x77\x33\56\x6f\162\x67\x2f\x32\x30\60\60\57\60\71\57\x78\x6d\x6c\x64\x73\151\147\43", "\x64\163\x69\x67\x3a\x4b\x65\x79\111\156\x66\x6f"), $r8->firstChild);
        $jV->appendChild($MZ);
        iZ:
        $hG = $MZ->appendChild($this->encdoc->createElementNS(self::XMLENCNS, "\x78\145\156\143\x3a\x45\x6e\x63\162\x79\160\164\x69\157\156\115\145\x74\150\x6f\x64"));
        $hG->setAttribute("\101\x6c\x67\x6f\162\151\164\150\x6d", $TV->getAlgorith());
        if (empty($TV->name)) {
            goto ZM;
        }
        $jV = $MZ->appendChild($this->encdoc->createElementNS("\x68\164\164\160\72\x2f\57\x77\167\x77\56\x77\63\56\x6f\x72\147\x2f\62\60\60\60\x2f\x30\x39\57\170\155\154\144\163\x69\x67\x23", "\x64\x73\x69\147\72\113\x65\x79\111\156\x66\x6f"));
        $jV->appendChild($this->encdoc->createElementNS("\x68\164\x74\160\72\x2f\x2f\x77\167\167\56\167\63\x2e\x6f\162\x67\x2f\x32\x30\60\60\57\x30\71\x2f\x78\155\x6c\144\x73\x69\x67\x23", "\x64\x73\x69\147\x3a\x4b\145\x79\x4e\x61\x6d\x65", $TV->name));
        ZM:
        $O7 = $MZ->appendChild($this->encdoc->createElementNS(self::XMLENCNS, "\x78\x65\x6e\x63\x3a\103\x69\x70\150\145\x72\x44\x61\x74\x61"));
        $O7->appendChild($this->encdoc->createElementNS(self::XMLENCNS, "\170\x65\156\143\x3a\103\x69\160\x68\145\162\x56\x61\x6c\x75\145", $Xp));
        if (!(is_array($this->references) && count($this->references) > 0)) {
            goto Ot;
        }
        $fs = $MZ->appendChild($this->encdoc->createElementNS(self::XMLENCNS, "\170\145\156\x63\72\x52\145\x66\x65\x72\145\156\143\x65\x4c\x69\163\x74"));
        foreach ($this->references as $zY => $Xh) {
            $Zl = $Xh["\162\145\146\165\162\151"];
            $K3 = $fs->appendChild($this->encdoc->createElementNS(self::XMLENCNS, "\170\x65\156\143\x3a\104\x61\164\141\122\145\x66\x65\162\x65\x6e\x63\x65"));
            $K3->setAttribute("\125\x52\111", "\43" . $Zl);
            w2:
        }
        BJ:
        Ot:
        return;
    }
    public function decryptKey($MZ)
    {
        if ($MZ->isEncrypted) {
            goto A9;
        }
        throw new Exception("\x4b\x65\171\40\x69\x73\x20\156\x6f\x74\x20\105\x6e\143\x72\171\x70\164\145\144");
        A9:
        if (!empty($MZ->key)) {
            goto tX;
        }
        throw new Exception("\x4b\x65\171\x20\x69\x73\40\155\x69\163\163\151\x6e\x67\x20\144\x61\164\x61\x20\164\x6f\x20\x70\145\162\146\157\x72\155\40\164\x68\x65\x20\144\x65\x63\162\x79\160\164\x69\x6f\156");
        tX:
        return $this->decryptNode($MZ, false);
    }
    public function locateEncryptedData($B7)
    {
        if ($B7 instanceof DOMDocument) {
            goto dv;
        }
        $Bl = $B7->ownerDocument;
        goto tp;
        dv:
        $Bl = $B7;
        tp:
        if (!$Bl) {
            goto t6;
        }
        $OE = new DOMXPath($Bl);
        $wF = "\x2f\x2f\x2a\133\x6c\x6f\143\141\154\55\156\x61\x6d\x65\x28\51\75\47\x45\156\143\x72\171\x70\x74\145\144\104\x61\164\141\47\x20\141\x6e\x64\40\x6e\x61\155\x65\x73\160\x61\143\x65\x2d\165\x72\151\50\51\75\x27" . self::XMLENCNS . "\x27\x5d";
        $Gf = $OE->query($wF);
        return $Gf->item(0);
        t6:
        return null;
    }
    public function locateKey($Qh = null)
    {
        if (!empty($Qh)) {
            goto Ej;
        }
        $Qh = $this->rawNode;
        Ej:
        if ($Qh instanceof DOMNode) {
            goto r0;
        }
        return null;
        r0:
        if (!($Bl = $Qh->ownerDocument)) {
            goto wC;
        }
        $OE = new DOMXPath($Bl);
        $OE->registerNamespace("\x78\155\x6c\x73\145\143\145\156\143", self::XMLENCNS);
        $wF = "\56\x2f\x2f\x78\155\154\x73\x65\143\x65\x6e\x63\x3a\105\156\x63\x72\171\160\164\x69\x6f\156\115\145\x74\x68\x6f\144";
        $Gf = $OE->query($wF, $Qh);
        if (!($O1 = $Gf->item(0))) {
            goto yE;
        }
        $GK = $O1->getAttribute("\101\x6c\x67\x6f\x72\151\x74\x68\x6d");
        try {
            $xe = new XMLSecurityKey($GK, array("\164\171\160\145" => "\x70\x72\151\x76\x61\x74\x65"));
        } catch (Exception $i0) {
            return null;
        }
        return $xe;
        yE:
        wC:
        return null;
    }
    public static function staticLocateKeyInfo($Bw = null, $Qh = null)
    {
        if (!(empty($Qh) || !$Qh instanceof DOMNode)) {
            goto qe;
        }
        return null;
        qe:
        $Bl = $Qh->ownerDocument;
        if ($Bl) {
            goto uH;
        }
        return null;
        uH:
        $OE = new DOMXPath($Bl);
        $OE->registerNamespace("\170\155\x6c\x73\145\143\x65\x6e\x63", self::XMLENCNS);
        $OE->registerNamespace("\x78\x6d\x6c\163\x65\143\x64\x73\x69\147", XMLSecurityDSig::XMLDSIGNS);
        $wF = "\56\57\170\155\x6c\163\145\143\144\163\151\x67\x3a\x4b\145\171\x49\156\x66\x6f";
        $Gf = $OE->query($wF, $Qh);
        $O1 = $Gf->item(0);
        if ($O1) {
            goto jI;
        }
        return $Bw;
        jI:
        foreach ($O1->childNodes as $w8) {
            switch ($w8->localName) {
                case "\x4b\145\171\116\x61\155\x65":
                    if (empty($Bw)) {
                        goto dD;
                    }
                    $Bw->name = $w8->nodeValue;
                    dD:
                    goto nF;
                case "\x4b\145\171\126\x61\154\165\145":
                    foreach ($w8->childNodes as $u_) {
                        switch ($u_->localName) {
                            case "\104\x53\x41\113\145\x79\x56\141\154\165\145":
                                throw new Exception("\104\x53\x41\x4b\x65\x79\126\x61\154\165\x65\40\143\165\162\x72\145\x6e\164\x6c\171\x20\156\x6f\164\x20\x73\x75\x70\160\157\162\164\x65\x64");
                            case "\122\123\x41\x4b\x65\171\x56\141\154\165\145":
                                $em = null;
                                $rp = null;
                                if (!($CZ = $u_->getElementsByTagName("\x4d\x6f\x64\x75\154\165\x73")->item(0))) {
                                    goto zv;
                                }
                                $em = base64_decode($CZ->nodeValue);
                                zv:
                                if (!($JA = $u_->getElementsByTagName("\x45\x78\x70\157\x6e\145\x6e\164")->item(0))) {
                                    goto ww;
                                }
                                $rp = base64_decode($JA->nodeValue);
                                ww:
                                if (!(empty($em) || empty($rp))) {
                                    goto uP;
                                }
                                throw new Exception("\x4d\151\x73\x73\x69\156\x67\40\x4d\157\144\x75\154\165\163\x20\x6f\162\x20\105\170\160\157\x6e\145\x6e\164");
                                uP:
                                $Jm = XMLSecurityKey::convertRSA($em, $rp);
                                $Bw->loadKey($Jm);
                                goto bs;
                        }
                        Hh:
                        bs:
                        LL:
                    }
                    h2:
                    goto nF;
                case "\x52\x65\164\x72\x69\145\x76\x61\x6c\115\x65\x74\150\157\x64":
                    $ew = $w8->getAttribute("\124\171\160\x65");
                    if (!($ew !== "\150\x74\x74\x70\x3a\57\57\167\167\167\56\x77\x33\x2e\157\x72\x67\57\x32\x30\x30\61\x2f\x30\64\x2f\x78\x6d\154\145\x6e\x63\43\105\156\x63\162\171\x70\x74\145\x64\113\x65\171")) {
                        goto v9;
                    }
                    goto nF;
                    v9:
                    $k3 = $w8->getAttribute("\125\x52\111");
                    if (!($k3[0] !== "\43")) {
                        goto i5;
                    }
                    goto nF;
                    i5:
                    $mS = substr($k3, 1);
                    $wF = "\x2f\57\170\155\x6c\163\x65\143\145\156\x63\x3a\105\156\143\162\171\160\x74\145\x64\x4b\x65\171\x5b\100\111\x64\75\42" . XPath::filterAttrValue($mS, XPath::DOUBLE_QUOTE) . "\42\x5d";
                    $AM = $OE->query($wF)->item(0);
                    if ($AM) {
                        goto nJ;
                    }
                    throw new Exception("\x55\156\141\x62\154\x65\x20\x74\157\x20\154\x6f\143\141\164\145\x20\x45\x6e\x63\x72\x79\160\164\145\144\x4b\x65\171\x20\167\x69\164\150\x20\x40\111\x64\75\x27{$mS}\47\x2e");
                    nJ:
                    return XMLSecurityKey::fromEncryptedKeyElement($AM);
                case "\x45\x6e\x63\162\x79\x70\x74\x65\144\x4b\x65\171":
                    return XMLSecurityKey::fromEncryptedKeyElement($w8);
                case "\x58\65\60\x39\x44\x61\x74\x61":
                    if (!($zF = $w8->getElementsByTagName("\x58\65\60\x39\x43\145\x72\164\151\x66\x69\x63\141\x74\x65"))) {
                        goto Cy;
                    }
                    if (!($zF->length > 0)) {
                        goto t2;
                    }
                    $qf = $zF->item(0)->textContent;
                    $qf = str_replace(array("\xd", "\xa", "\x20"), '', $qf);
                    $qf = "\x2d\x2d\x2d\x2d\55\x42\105\107\111\116\40\103\105\122\124\111\106\x49\x43\101\x54\105\x2d\55\55\x2d\55\12" . chunk_split($qf, 64, "\xa") . "\x2d\55\55\x2d\x2d\105\x4e\104\40\x43\105\x52\x54\x49\x46\111\103\x41\124\105\x2d\55\x2d\55\55\12";
                    $Bw->loadKey($qf, false, true);
                    t2:
                    Cy:
                    goto nF;
            }
            SJ:
            nF:
            Cg:
        }
        vN:
        return $Bw;
    }
    public function locateKeyInfo($Bw = null, $Qh = null)
    {
        if (!empty($Qh)) {
            goto Li;
        }
        $Qh = $this->rawNode;
        Li:
        return self::staticLocateKeyInfo($Bw, $Qh);
    }
}
