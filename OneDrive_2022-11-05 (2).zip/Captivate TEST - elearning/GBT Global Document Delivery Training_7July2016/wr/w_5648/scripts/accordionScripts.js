var btnClicked = "-1";

function resizeInteraction(thewidth,theheight) {
	var scale = 0;
	thewidth = String(thewidth).replace("px","");
	theheight = String(theheight).replace("px","");
	if(thewidth<theheight){
	 scale = thewidth / (680+70);
	}else{
	 scale = theheight/ (500);
	}
	
	var margins = Math.round(25 * scale);
	margins+="px"
	scale = "scale(" + scale + ")";
	$('#reveal').css('-webkit-transform', scale);
	$('#reveal').css('-moz-transform', scale);
	$('#reveal').css('-o-transform', scale);
	$('#reveal').css('-ms-transform', scale);
	
	$('#reveal').css('-moz-transform-origin', '0 0');
	$('#reveal').css('-webkit-transform-origin', '0 0');
	$('#reveal').css('-moz-transform-origin', '0 0');
	$('#reveal').css('-o-transform-origin', '0 0');
	$('#reveal').css('-ms-transform-origin', '0 0');
	

	$('#reveal').css('margin-top', margins);
	$('#reveal').css('margin-left', margins);
	
}


function addClickHandlers() {
	
	$("#reveal").fadeIn();		
	$('#content_bg .header a').mouseleave(function() {
  		var main = $(this).parent().hasClass('activeBtn')
		if (!main) {
			outState(this);
		}
	});
	
		$('#content_bg .header a').mouseenter(function() {
			 var main = $(this).parent().hasClass('activeBtn')
			if (!main) {
				overState(this);
			}
	});
										  
	$('#content_bg .header a').click(function(e){	
		if (btnClicked != e.target.id) //make sure that nothing happens if the same button is clicked
		{
			
			var dad = $(this).parent(); //grab parent
			if (btnClicked != "-1") { //make sure it's not the first click 
				var grabMe = btnClicked*2 + 1;
				$('#content_bg div').eq(grabMe).slideUp('slow'); //slide the content div
				$('#content_bg div').eq(grabMe-1).removeClass('overBtn'); //remove class from header div
				$('#content_bg div').eq(grabMe-1).removeClass('activeBtn'); //remove class from header div
				$('#content_bg div').eq(grabMe-1).addClass('unactive'); //add the unactive state to the btn						
			}
			//now move up the other 
			btnClicked = e.target.id;
			$(dad).removeClass('unactive'); //remove class from header div
			$(dad).removeClass('overBtn'); //remove class from header div
			$(dad).addClass('activeBtn');
			$(this).addClass('active').parent('div').next('.content').slideDown('slow', function() {
				//after animation is complete, run setup and play audio
				pauseSound();
				if (soundArray[btnClicked] != "-1") {
					setTimeout("play_sound(soundArray[btnClicked])",50);
				}
			  });
		}
		
		
		$('.unactive a').css('color', buttonStyles.color);
		$('.unactive').css('background-color', generalStyles.btnColorUp);
		$('.activeBtn').css('background-color', generalStyles.btnColorDown);
		$('.activeBtn a').css('color', buttonStyles.textDown);
	});
}
function overState(obj) {
	var dad = $(obj).parent();
	$(dad).addClass('overBtn');
	$('.overBtn').css('background-color', generalStyles.btnColorOver);
	$('.overBtn a').css('color', buttonStyles.textOver);
	
}

function outState(obj2) {
	//alert("out");
	var dad = $(obj2).parent();
	$(dad).removeClass('overBtn');
	$(dad).addClass('unactive');
	$('.unactive').css('background-color', generalStyles.btnColorUp);
	$('.unactive a').css('color', buttonStyles.color);
	
}


function html5_audio(){
	var a = document.createElement('audio');
	return !!(a.canPlayType && a.canPlayType('audio/mpeg;').replace(/no/, ''));
}
 
var theSnd = null;

function pauseSound() {
	if(theSnd != null) // && theSnd.src != wavePath)
	{ theSnd.pause();}
}

function play_sound(url){
	theSnd = new Audio(url);
	theSnd.load();
	theSnd.play();	
}

 




function setupCustomStyles() {
	generalStyles.headerColor = formatColor(generalStyles.headerColor); //generalStyles.headerColor.substring(2);
	generalStyles.contentBodyColor = formatColor(generalStyles.contentBodyColor); //"#" + generalStyles.contentBodyColor.substring(2);
	generalStyles.bodyColor = formatColor(generalStyles.bodyColor); //"#" + generalStyles.bodyColor.substring(2);
	//generalStyles.arrowColor = formatColor(generalStyles.arrowColor);
	generalStyles.btnColorUp = formatColor(generalStyles.btnColorUp);
	generalStyles.btnColorOver = formatColor(generalStyles.btnColorOver);
	generalStyles.btnColorDown = formatColor(generalStyles.btnColorDown);
	//generalStyles.lineColor = formatColor(generalStyles.lineColor);	
	buttonStyles.color  = formatColor(buttonStyles.color);
	buttonStyles.textOver = formatColor(buttonStyles.textOver);
	buttonStyles.textDown = formatColor(buttonStyles.textDown);
		
	//alert(generalStyles.lineColor);
		if (currentTheme != 3 && currentTheme != 11 && currentTheme != 16) {
			$('#headerColor').css('background-color', generalStyles.headerColor)//generalStyles.headerColor);
		} else {
			$('#headerColor').css('background-color', generalStyles.bodyColor)//generalStyles.headerColor);
			
		}
		//alert(buttonStyles.color);
	//$('#headerColor').css('background-image', 'none');
	$('div.content').css('background-color', generalStyles.contentBodyColor);
	$('#content_bg').css('background-color', generalStyles.bodyColor);
	$('.header').css('background-color', generalStyles.btnColorUp);
	
	$('.header a').css('color', buttonStyles.color);
	
	
}

	

	
	
	