=== wordpress publish post email notification ===
Contributors:nik00726
Tags:wordpress publish post,send email when post is publish,send email publish post wordpress,wordpress publish post email,notify author when post published
Donate link: http://www.i13websolution.com/donate_for_publish_post_notification_email_sender.php
Requires at least:3.0
Tested up to:6.0
Version:1.0.2.1
Stable tag:1.0.2.1
License:GPLv2 or later
License URI:http://www.gnu.org/licenses/gpl-2.0.html


== Description ==



Publish post notification is plugin which will send an automatic email to its author when the post is published and approved by WordPress admin.
admin has to go to setting and set email template that's it all other things are managed by this plugin.

**Find wordpress publish post email notification Pro Plugin at [Publish Post Email Notification Pro](https://www.i13websolution.com/product/wordpress-publish-post-email-notification-pro-plugin/)**

=Features=

1. set email template.

2. Notify author via email when post is published.



=Pro Version Features=


1.Support for send email to author when custom post type published

2.No Advertisements.


[Get Support](http://www.i13websolution.com/contacts) 


== Installation ==


This plugin is easy to install like other plug-ins of Wordpress as you need to just follow the below mentioned steps:

1. upload publish-post-notification folder to wp-Content/plugins folder.

2. Activate the plugin from Dashboard / Plugins window.

4. Now Plugin is Activated, Go to the Usage section to see how to use Vertical News Scroller.

### Usage ###

1.Use of publish post notification is easy after activating plugin go to Settings menu.

2.Select Publish post email template sub menu.

3.Fill out email template you can use place holders in email content.

4.Thats it your email is set now whenever a post is publish the author is notified via email.


== Screenshots ==

1. Email template settings
2. Pro version with full html editor

== License ==

This plugin is free for everyone! Since it's released under the GPL, you can use it free of charge on your personal or commercial blog. But you can make some donations if you realy find it useful.

== Changelog ==

= 1.0.2.1 =

* Fixed undefined variable problem.
* Tested with WordPress 5.9


= 1.0.2 =

* Fixed character set problem for non- english lang.
* Tested with WordPress 5.5


= 1.0.1 =

* added  WordPress capebilities feature.
* Added WordPress editor for email content
* Tested with WordPress 5.1


= 1.0 =

* Stable 1.0 first release


== Upgrade Notice ==

= 1.0 =

* Stable 1.0 first release

 
== Frequently Asked Questions ==

1.How to use ?

For More info use readme installation and usage notes.
