<?php


if (defined("\x57\120\111\116\x43")) {
    goto aJ;
}
die;
aJ:
