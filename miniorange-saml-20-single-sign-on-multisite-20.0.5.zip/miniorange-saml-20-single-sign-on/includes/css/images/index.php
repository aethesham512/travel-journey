<?php


if (defined("\127\x50\111\x4e\x43")) {
    goto pq;
}
die;
pq:
