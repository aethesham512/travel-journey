<?php


if (defined("\x57\x50\x49\x4e\x43")) {
    goto oZ;
}
die;
oZ:
