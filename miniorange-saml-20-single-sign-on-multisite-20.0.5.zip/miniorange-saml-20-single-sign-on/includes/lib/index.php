<?php


if (defined("\x57\x50\111\x4e\103")) {
    goto ip;
}
die;
ip:
