<?php


include "\x42\x61\163\x69\x63\105\x6e\x75\x6d\56\160\150\160";
class mo_options_enum_sso_login extends BasicEnum
{
    const SSO_Settings = "\x73\141\155\154\137\x73\x73\x6f\137\163\x65\164\x74\151\x6e\x67\163";
    const Enable_SSO_For_sites = "\155\157\x5f\x65\156\141\142\x6c\x65\x5f\163\x73\x6f\x5f\163\151\x74\145\x73";
    const Relay_state = "\x6d\157\x5f\x73\x61\155\x6c\137\x72\x65\x6c\141\x79\x5f\163\x74\141\x74\x65";
    const Redirect_Idp = "\x6d\x6f\x5f\163\x61\155\154\x5f\162\x65\x67\x69\x73\x74\x65\162\145\144\x5f\157\x6e\x6c\171\x5f\x61\x63\143\145\x73\163";
    const Force_authentication = "\x6d\157\x5f\x73\x61\x6d\154\137\x66\x6f\162\x63\x65\137\x61\165\164\x68\x65\156\164\x69\x63\x61\164\151\157\x6e";
    const Enable_access_RSS = "\155\x6f\x5f\163\141\x6d\x6c\137\145\x6e\x61\x62\154\x65\x5f\162\163\x73\x5f\x61\143\143\145\163\163";
    const Auto_redirect = "\x6d\x6f\x5f\x73\x61\155\x6c\x5f\x65\x6e\x61\142\x6c\145\x5f\x6c\x6f\x67\151\156\x5f\x72\x65\144\x69\162\x65\143\x74";
    const Allow_wp_signin = "\155\x6f\x5f\x73\141\155\154\x5f\x61\x6c\154\157\167\x5f\167\160\137\x73\x69\x67\156\x69\x6e";
    const Custom_login_button = "\x6d\x6f\x5f\x73\141\155\154\137\x63\165\163\164\x6f\155\x5f\x6c\157\x67\x69\156\x5f\164\145\170\164";
    const Custom_greeting_text = "\155\157\137\x73\141\x6d\154\x5f\143\165\163\x74\157\155\137\147\x72\x65\x65\164\151\x6e\x67\137\164\x65\x78\x74";
    const Custom_greeting_name = "\x6d\157\x5f\163\x61\x6d\x6c\x5f\x67\x72\x65\145\x74\151\156\x67\x5f\156\x61\155\x65";
    const Custom_logout_button = "\155\x6f\137\163\141\155\x6c\x5f\143\165\163\164\x6f\155\137\154\157\x67\157\165\x74\137\x74\145\170\164";
    const Keep_Configuration_Intact = "\x6d\157\x5f\163\x61\155\x6c\137\x6b\x65\145\x70\x5f\x73\x65\x74\164\151\x6e\147\x73\137\157\x6e\137\144\145\154\145\164\151\x6f\x6e";
}
class mo_options_enum_identity_provider extends BasicEnum
{
    const Broker_service = "\x6d\157\x5f\x73\141\x6d\x6c\x5f\x65\156\x61\142\154\x65\137\143\154\157\x75\x64\137\142\x72\x6f\153\x65\162";
    const SP_Base_Url = "\x6d\157\x5f\x73\141\155\x6c\137\163\160\x5f\142\x61\x73\x65\x5f\165\162\x6c";
    const SP_Entity_ID = "\x6d\x6f\137\x73\141\x6d\154\137\x73\160\x5f\145\x6e\x74\x69\x74\x79\137\x69\x64";
}
class mo_options_enum_custom_messages extends BasicEnum
{
    const Custom_Account_Creation_Disabled_message = "\155\x6f\x5f\x73\x61\x6d\x6c\137\141\143\143\x6f\x75\156\x74\x5f\x63\x72\145\x61\164\x69\x6f\156\137\x64\x69\x73\141\142\154\145\x64\137\x6d\x73\x67";
    const Custom_Restricted_Domain_message = "\x6d\157\x5f\163\141\x6d\x6c\137\x72\145\163\164\162\x69\143\164\x65\x64\137\x64\x6f\x6d\x61\x69\x6e\137\145\162\x72\157\162\137\155\163\x67";
}
class mo_options_enum_domain_restriction extends BasicEnum
{
    const Email_Domains = "\163\141\x6d\154\137\x61\155\x5f\145\155\x61\x69\154\137\x64\157\155\141\x69\156\163";
    const Enable_Domain_Restriction_Login = "\155\x6f\137\163\x61\x6d\154\137\145\156\x61\142\x6c\145\137\144\157\155\x61\151\x6e\x5f\162\145\x73\164\162\x69\143\164\151\157\x6e\x5f\154\157\147\x69\x6e";
    const Allow_deny_user_with_Domain = "\x6d\x6f\x5f\163\x61\x6d\x6c\137\141\154\154\x6f\x77\137\x64\145\156\171\137\x75\163\145\162\x5f\x77\151\164\x68\x5f\x64\157\155\x61\151\156";
}
class mo_options_enum_service_provider extends BasicEnum
{
    const Identity_name = "\163\141\x6d\x6c\x5f\151\x64\x65\156\x74\x69\x74\171\137\156\141\155\x65";
    const Send_Signed_request = "\163\141\155\x6c\x5f\162\145\x71\x75\x65\x73\x74\x5f\x73\x69\x67\156\x65\x64";
    const Login_binding_type = "\163\x61\x6d\154\x5f\154\157\147\151\x6e\137\x62\151\x6e\144\x69\x6e\147\x5f\164\x79\160\x65";
    const Login_URL = "\x73\141\155\x6c\x5f\x6c\157\147\151\156\x5f\x75\x72\x6c";
    const Logout_binding_type = "\163\141\155\x6c\x5f\x6c\157\147\x6f\165\164\137\142\151\x6e\144\151\x6e\x67\x5f\164\171\160\x65";
    const Logout_URL = "\x73\141\x6d\x6c\137\x6c\x6f\147\x6f\x75\x74\x5f\x75\x72\x6c";
    const Issuer = "\x73\x61\x6d\154\x5f\151\x73\163\165\145\x72";
    const X509_certificate = "\x73\x61\155\154\137\170\65\60\71\137\x63\x65\x72\164\151\x66\151\143\x61\x74\145";
    const Request_signed = "\x73\141\x6d\x6c\137\162\145\x71\x75\145\x73\164\137\x73\x69\147\x6e\x65\144";
    const Name_ID_format = "\x73\141\155\x6c\137\x6e\x61\155\x65\x69\x64\x5f\146\x6f\162\x6d\141\x74";
    const Guide_name = "\x73\141\x6d\154\137\x69\x64\145\156\164\x69\x74\x79\137\x70\162\157\166\x69\144\x65\x72\137\x67\165\151\x64\145\137\156\141\155\x65";
    const Character_encoding = "\x6d\157\137\x73\141\155\x6c\x5f\145\156\x63\157\144\151\x6e\x67\137\x65\x6e\x61\142\154\x65\x64";
    const Sync_URL = "\163\x61\x6d\154\x5f\x6d\145\x74\x61\x64\x61\x74\141\x5f\165\162\154\x5f\146\x6f\162\137\x73\x79\156\143";
    const Sync_interval = "\x73\141\155\154\137\155\145\164\141\144\x61\x74\141\x5f\x73\171\156\143\137\151\156\164\145\162\x76\x61\x6c";
}
class mo_options_enum_attribute_mapping extends BasicEnum
{
    const Attribute_Username = "\x73\x61\155\154\137\141\155\137\165\x73\x65\162\156\141\155\145";
    const Attribute_Email = "\x73\x61\155\154\x5f\x61\x6d\137\x65\x6d\x61\x69\x6c";
    const Attribute_First_name = "\163\141\x6d\x6c\x5f\141\x6d\137\146\x69\x72\x73\164\137\156\x61\155\145";
    const Attribute_Last_name = "\163\141\x6d\154\x5f\x61\x6d\x5f\154\x61\163\x74\x5f\156\x61\155\145";
    const Attribute_Group_name = "\x73\x61\x6d\154\137\141\x6d\137\x67\x72\157\x75\160\137\156\x61\155\145";
    const Attribute_Display_name = "\x73\x61\155\x6c\137\x61\x6d\137\x64\x69\x73\160\154\x61\171\137\156\141\x6d\145";
    const Attribute_Custom_mapping = "\x6d\157\x5f\163\x61\x6d\x6c\137\143\x75\x73\164\x6f\x6d\x5f\x61\164\x74\162\163\x5f\155\141\160\160\151\x6e\147";
    const Attribute_Account_matcher = "\x73\141\x6d\x6c\x5f\x61\155\137\141\143\143\x6f\x75\156\164\137\155\141\x74\143\x68\x65\x72";
}
class mo_options_enum_role_mapping extends BasicEnum
{
    const Role_mapping_site = "\x73\141\x6d\154\x5f\141\155\x5f\162\x6f\x6c\145\x5f\155\141\x70\160\x69\x6e\147";
    const Super_Admin_role_mapping = "\x6d\157\137\163\141\155\154\137\x73\165\x70\145\162\x5f\x61\144\155\x69\156\x5f\x72\x6f\x6c\x65\x5f\x6d\141\160\x70\151\x6e\x67";
}
class mo_options_enum_test_configuration extends BasicEnum
{
    const SAML_REQUEST = "\x6d\x6f\x5f\163\141\x6d\x6c\137\162\x65\x71\x75\145\163\164";
    const SAML_RESPONSE = "\155\x6f\137\x73\141\155\154\137\x72\x65\163\160\x6f\156\163\x65";
    const TEST_CONFIG_ERROR_LOG = "\x6d\x6f\x5f\163\141\155\x6c\x5f\164\x65\x73\164";
    const TEST_CONFIG_ATTRS = "\155\157\x5f\x73\x61\x6d\x6c\x5f\x74\x65\x73\x74\137\143\x6f\156\x66\x69\147\137\x61\x74\164\x72\x73";
}
class mo_options_enum_custom_certificate extends BasicEnum
{
    const Custom_Public_Certificate = "\x6d\157\137\x73\x61\x6d\154\137\x63\x75\x73\x74\157\x6d\x5f\x63\145\162\164";
    const Custom_Private_Certificate = "\155\x6f\x5f\x73\x61\x6d\x6c\x5f\x63\x75\x73\x74\157\x6d\137\x63\145\162\164\137\160\162\x69\x76\141\x74\145\x5f\x6b\145\171";
}
class mo_options_enum_default_sp_certificate extends BasicEnum
{
    const SP_Public_Certificate = "\x6d\151\x6e\151\x6f\162\x61\x6e\147\145\137\x73\x70\x2e\x63\162\164";
    const SP_Private_Key = "\155\151\156\x69\157\162\x61\156\x67\x65\x5f\163\x70\x5f\160\162\151\166\56\153\145\171";
    const SP_Rollback_Public_Cert = "\x6d\x69\x6e\151\157\162\x61\156\147\x65\x5f\x73\160\137\x32\60\62\60\56\x63\162\164";
    const SP_Rollback_Public_Key = "\x6d\x69\x6e\x69\157\162\141\x6e\x67\145\x5f\163\x70\x5f\x32\60\62\60\137\160\162\x69\166\x2e\x6b\145\171";
}
class mo_options_error_constants extends BasicEnum
{
    const Error_no_certificate = "\x55\156\x61\x62\154\145\x20\164\x6f\x20\x66\x69\156\144\40\141\x20\143\x65\162\164\151\146\151\x63\x61\164\x65\40\x2e";
    const Cause_no_certificate = "\116\157\x20\163\151\x67\x6e\141\164\x75\162\x65\40\x66\157\x75\x6e\x64\x20\151\156\x20\123\x41\x4d\114\x20\x52\x65\x73\160\157\x6e\x73\145\40\157\x72\x20\x41\x73\x73\x65\x72\x74\151\157\156\x2e\40\x50\154\x65\x61\163\145\40\x73\151\147\x6e\x20\141\164\40\x6c\145\x61\163\164\x20\157\x6e\145\40\157\146\40\164\x68\145\155\56";
    const Error_wrong_certificate = "\x55\x6e\141\142\x6c\x65\x20\164\x6f\x20\x66\x69\x6e\144\40\141\x20\143\145\162\164\x69\146\151\x63\141\x74\x65\40\155\x61\x74\143\x68\151\156\147\x20\x74\x68\145\40\x63\157\x6e\x66\151\x67\165\162\x65\144\40\x66\x69\156\147\x65\x72\160\162\151\156\164\56";
    const Cause_wrong_certificate = "\x58\x2e\65\60\71\x20\103\145\162\x74\151\146\x69\143\x61\164\x65\40\146\x69\x65\154\x64\40\x69\156\40\x70\154\x75\x67\x69\156\x20\x64\157\145\x73\40\x6e\157\164\40\155\141\x74\x63\x68\x20\x74\x68\145\x20\x63\x65\x72\164\151\x66\151\x63\x61\164\145\x20\x66\x6f\x75\x6e\144\x20\x69\156\x20\x53\101\x4d\114\40\x52\x65\x73\160\157\156\163\145\x2e";
    const Error_invalid_audience = "\111\156\x76\141\x6c\x69\144\40\101\165\144\151\x65\156\x63\145\40\x55\122\111\56";
    const Cause_invalid_audience = "\x54\x68\x65\40\x76\141\154\165\145\40\157\146\x20\47\x41\165\x64\151\x65\x6e\x63\145\x20\x55\122\111\x27\x20\x66\x69\x65\x6c\x64\x20\x6f\x6e\x20\111\144\145\156\x74\151\x74\x79\40\x50\x72\157\x76\x69\x64\x65\162\47\x73\40\163\151\x64\x65\x20\x69\x73\40\x69\156\143\157\x72\162\145\x63\x74";
    const Error_issuer_not_verfied = "\111\163\x73\x75\x65\162\x20\x63\x61\x6e\x6e\x6f\164\40\x62\145\40\166\x65\x72\151\146\x69\145\x64\56";
    const Cause_issuer_not_verfied = "\x49\144\x50\40\x45\x6e\x74\151\x74\x79\40\x49\x44\40\143\157\x6e\x66\x69\147\x75\162\x65\144\40\141\x6e\x64\x20\164\x68\x65\x20\x6f\156\145\40\x66\x6f\165\x6e\144\x20\151\x6e\40\123\101\x4d\114\x20\122\x65\x73\x70\x6f\156\x73\145\40\x64\157\40\x6e\x6f\x74\40\155\x61\164\x63\150";
}
class mo_options_enum_nameid_formats extends BasicEnum
{
    const EMAIL = "\x75\162\x6e\72\x6f\x61\x73\151\x73\x3a\x6e\x61\155\x65\x73\72\x74\x63\72\x53\101\x4d\x4c\x3a\61\x2e\61\x3a\x6e\x61\x6d\x65\x69\144\x2d\146\x6f\x72\x6d\141\164\72\x65\155\x61\151\x6c\x41\144\144\162\145\163\x73";
    const UNSPECIFIED = "\165\162\x6e\x3a\157\x61\x73\x69\163\72\x6e\x61\x6d\x65\x73\x3a\164\x63\x3a\x53\x41\x4d\114\72\61\56\61\72\x6e\x61\155\x65\x69\x64\x2d\146\x6f\x72\x6d\x61\164\x3a\x75\156\x73\x70\145\143\151\x66\x69\x65\144";
    const TRANSIENT = "\x75\x72\x6e\72\157\x61\x73\x69\x73\72\156\141\155\145\x73\x3a\164\x63\x3a\x53\x41\x4d\x4c\x3a\62\56\60\72\156\141\x6d\x65\151\144\x2d\146\157\x72\x6d\x61\x74\x3a\x74\x72\141\156\163\x69\145\x6e\x74";
    const PERSISTENT = "\x75\x72\x6e\72\157\x61\163\151\163\72\156\x61\x6d\145\163\72\164\143\72\123\101\x4d\x4c\72\x32\x2e\x30\72\156\141\x6d\145\151\144\x2d\146\x6f\x72\155\141\164\72\160\145\162\x73\151\x73\164\145\x6e\164";
}
class mo_options_plugin_constants extends BasicEnum
{
    const CMS_Name = "\127\120";
    const Application_Name = "\x57\x50\x20\x6d\x69\x6e\x69\x4f\162\141\x6e\x67\145\40\123\101\115\114\x20\x32\56\x30\40\x53\x53\x4f\x20\x50\154\165\147\x69\156";
    const Application_type = "\123\101\x4d\x4c";
    const Version = "\62\60\x2e\60\x2e\x35";
    const HOSTNAME = "\150\x74\x74\160\163\72\57\57\154\x6f\x67\x69\156\x2e\170\x65\x63\165\x72\x69\146\x79\56\143\157\155";
    const LICENSE_TYPE = "\x57\x50\x5f\123\101\x4d\x4c\x5f\x53\x50\x5f\x4d\125\114\124\x49\x53\x49\x54\105\137\120\114\x55\x47\111\116";
    const LICENSE_PLAN_NAME = "\167\160\x5f\x73\x61\155\x6c\137\163\x73\157\137\x6d\x75\154\164\x69\163\151\164\x65\137\x62\141\x73\x69\143\137\160\154\141\x6e";
}
class mo_options_plugin_idp extends BasicEnum
{
    public static $IDP_GUIDES = array("\101\104\106\x53" => "\141\x64\146\x73", "\x4f\153\164\x61" => "\x6f\153\x74\141", "\101\172\165\x72\145\102\62\x43" => "\141\x7a\165\162\145\55\x62\x32\143", "\101\172\165\x72\145\x20\x41\104" => "\x61\172\x75\x72\145\x2d\141\x64", "\113\x65\x79\x63\x6c\157\x61\153" => "\152\x62\x6f\163\x73\55\153\145\x79\x63\154\x6f\x61\x6b", "\123\x61\154\x65\x73\x46\157\162\x63\145" => "\163\141\x6c\145\x73\x66\x6f\x72\x63\145", "\107\x6f\157\x67\154\x65\40\x41\160\x70\x73" => "\x67\x6f\x6f\x67\x6c\x65\x2d\141\x70\160\x73", "\115\x69\156\151\x4f\162\141\x6e\x67\x65" => "\155\x69\x6e\151\x6f\162\141\156\x67\145", "\117\146\x66\x69\x63\145\63\x36\x35" => "\141\x7a\165\162\145\55\141\x64", "\x4f\156\x65\114\x6f\x67\x69\x6e" => "\x6f\156\145\x6c\x6f\x67\151\x6e", "\x41\x62\x73\x6f\x72\x62\114\115\x53" => "\141\x62\x73\157\x72\142\x2d\x6c\x6d\163", "\x47\154\165\165\40\123\x65\162\x76\x65\x72" => "\x67\x6c\165\165\55\x73\x65\x72\x76\x65\x72", "\104\145\147\x72\145\145\x64" => "\x64\x65\x67\x72\x65\x65\144", "\x4a\x75\155\160\103\154\157\165\144" => "\x6a\165\x6d\x70\x63\154\157\x75\144", "\120\151\156\147\x46\x65\x64\145\162\141\x74\145" => "\160\151\156\x67\x66\145\x64\x65\x72\x61\x74\145", "\x50\x69\x6e\x67\x4f\156\145" => "\160\151\x6e\x67\x6f\x6e\145", "\x43\145\156\x74\162\151\x66\x79" => "\143\145\x6e\164\162\151\146\171", "\x4f\162\x61\x63\154\145" => "\x6f\162\x61\143\x6c\145\x2d\x65\156\x74\x65\162\x70\x72\x69\x73\145\x2d\x6d\x61\156\x61\147\145\x72", "\x42\151\x74\151\x75\155" => "\142\151\x74\151\165\155", "\123\150\151\142\x62\x6f\x6c\145\164\150\x20\62" => "\163\x68\x69\x62\142\157\154\x65\164\150\62", "\123\150\151\x62\x62\x6f\154\145\164\x68\x20\63" => "\x73\x68\151\142\142\x6f\x6c\145\x74\150\63", "\x53\151\x6d\160\x6c\145\x53\x41\x4d\114\160\150\160" => "\163\x69\155\x70\154\145\163\141\155\x6c", "\x4f\160\145\156\101\115" => "\x6f\160\145\156\x61\x6d", "\x41\x75\164\x68\x61\156\166\151\x6c" => "\141\165\164\x68\141\156\166\x69\154", "\101\x75\x74\x68\x30" => "\141\165\x74\150\60", "\x43\101\x20\111\144\x65\156\164\x69\164\171" => "\x63\141\55\151\x64\145\156\x74\151\x74\x79", "\127\x53\117\62" => "\x77\x73\157\x32", "\x52\x53\x41\x20\123\x65\143\x75\x72\x65\x49\x44" => "\162\163\x61\x2d\x73\x65\x63\x75\x72\145\x69\144", "\x4f\164\x68\x65\162" => "\117\x74\x68\145\162");
}
