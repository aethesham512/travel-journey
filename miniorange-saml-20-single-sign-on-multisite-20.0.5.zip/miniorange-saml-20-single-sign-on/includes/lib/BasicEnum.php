<?php


abstract class BasicEnum
{
    private static $constCacheArray = NULL;
    public static function getConstants()
    {
        if (!(self::$constCacheArray == NULL)) {
            goto Wo;
        }
        self::$constCacheArray = array();
        Wo:
        $H8 = get_called_class();
        if (array_key_exists($H8, self::$constCacheArray)) {
            goto mR;
        }
        $g5 = new ReflectionClass($H8);
        self::$constCacheArray[$H8] = $g5->getConstants();
        mR:
        return self::$constCacheArray[$H8];
    }
    public static function isValidName($GN, $oV = false)
    {
        $LU = self::getConstants();
        if (!$oV) {
            goto lU;
        }
        return array_key_exists($GN, $LU);
        lU:
        $Rm = array_map("\163\x74\162\164\x6f\x6c\157\167\x65\x72", array_keys($LU));
        return in_array(strtolower($GN), $Rm);
    }
    public static function isValidValue($yS, $oV = true)
    {
        $lG = array_values(self::getConstants());
        return in_array($yS, $lG, $oV);
    }
}
