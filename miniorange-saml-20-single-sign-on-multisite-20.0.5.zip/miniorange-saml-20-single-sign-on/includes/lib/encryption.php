<?php


class AESEncryption
{
    public static function encrypt_data($FA, $YX)
    {
        $YX = openssl_digest($YX, "\x73\150\141\62\x35\x36");
        $Eu = "\141\x65\x73\x2d\x31\62\70\x2d\145\143\x62";
        $eb = openssl_encrypt($FA, $Eu, $YX, OPENSSL_RAW_DATA || OPENSSL_ZERO_PADDING);
        return base64_encode($eb);
    }
    public static function decrypt_data($FA, $YX)
    {
        $p4 = base64_decode($FA);
        $YX = openssl_digest($YX, "\163\x68\x61\62\x35\x36");
        $Eu = "\101\x45\123\x2d\61\62\x38\x2d\x45\x43\102";
        $eP = openssl_cipher_iv_length($Eu);
        $b9 = substr($p4, 0, $eP);
        $FA = substr($p4, $eP);
        $iO = openssl_decrypt($FA, $Eu, $YX, OPENSSL_RAW_DATA || OPENSSL_ZERO_PADDING, $b9);
        return $iO;
    }
}
