<?php


if (defined("\x57\120\x49\116\x43")) {
    goto E9;
}
die;
E9:
