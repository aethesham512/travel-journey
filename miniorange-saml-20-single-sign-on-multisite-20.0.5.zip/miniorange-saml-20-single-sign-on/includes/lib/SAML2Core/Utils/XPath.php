<?php


namespace RobRichards\XMLSecLibs\Utils;

class XPath
{
    const ALPHANUMERIC = "\134\167\x5c\x64";
    const NUMERIC = "\134\x64";
    const LETTERS = "\x5c\167";
    const EXTENDED_ALPHANUMERIC = "\134\x77\x5c\x64\134\x73\x5c\55\x5f\72\134\x2e";
    const SINGLE_QUOTE = "\47";
    const DOUBLE_QUOTE = "\42";
    const ALL_QUOTES = "\x5b\x27\x22\135";
    public static function filterAttrValue($yS, $Q3 = self::ALL_QUOTES)
    {
        return preg_replace("\43" . $Q3 . "\43", '', $yS);
    }
    public static function filterAttrName($GN, $st = self::EXTENDED_ALPHANUMERIC)
    {
        return preg_replace("\43\133\136" . $st . "\135\43", '', $GN);
    }
}
