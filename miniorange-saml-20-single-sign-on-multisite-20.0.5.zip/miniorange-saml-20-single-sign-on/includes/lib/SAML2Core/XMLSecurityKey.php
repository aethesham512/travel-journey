<?php


namespace RobRichards\XMLSecLibs;

use DOMElement;
use Exception;
class XMLSecurityKey
{
    const TRIPLEDES_CBC = "\x68\164\x74\x70\x3a\57\x2f\x77\x77\167\56\167\x33\x2e\x6f\162\147\57\62\x30\60\x31\57\60\64\57\170\x6d\154\x65\156\x63\43\164\x72\x69\x70\x6c\x65\x64\x65\163\55\x63\x62\143";
    const AES128_CBC = "\150\164\164\x70\x3a\x2f\57\167\167\x77\x2e\x77\x33\56\157\x72\x67\57\62\60\x30\x31\x2f\60\x34\57\x78\155\x6c\145\x6e\x63\x23\x61\145\163\61\x32\x38\x2d\x63\142\x63";
    const AES192_CBC = "\x68\164\164\x70\x3a\57\x2f\167\x77\167\x2e\x77\x33\56\157\x72\x67\x2f\x32\x30\60\x31\x2f\60\x34\x2f\x78\155\x6c\x65\156\143\x23\x61\x65\163\61\71\62\x2d\x63\142\x63";
    const AES256_CBC = "\x68\x74\x74\160\x3a\57\57\x77\167\167\56\167\63\56\157\x72\147\x2f\x32\60\x30\61\x2f\x30\64\57\x78\155\154\x65\x6e\143\43\x61\145\163\62\x35\x36\55\x63\142\x63";
    const RSA_1_5 = "\150\164\164\160\72\57\x2f\x77\167\x77\56\167\x33\56\157\162\x67\x2f\62\60\60\61\57\60\64\57\x78\155\154\x65\156\x63\43\162\x73\x61\x2d\x31\x5f\x35";
    const RSA_OAEP_MGF1P = "\150\164\x74\x70\72\x2f\57\x77\x77\x77\56\x77\63\56\x6f\x72\x67\57\x32\x30\60\x31\57\x30\64\57\x78\x6d\154\x65\x6e\143\43\x72\163\141\55\x6f\141\x65\160\x2d\155\x67\146\61\x70";
    const DSA_SHA1 = "\150\164\x74\160\72\57\x2f\167\x77\x77\56\x77\63\x2e\x6f\x72\x67\57\62\x30\60\x30\x2f\60\71\57\170\x6d\x6c\x64\163\151\147\x23\144\163\x61\x2d\163\x68\141\x31";
    const RSA_SHA1 = "\x68\x74\x74\x70\72\57\x2f\x77\167\167\56\x77\x33\x2e\157\162\147\x2f\62\x30\60\x30\x2f\60\x39\x2f\x78\155\154\144\x73\x69\147\43\x72\x73\x61\55\163\x68\141\61";
    const RSA_SHA256 = "\150\164\164\160\72\57\x2f\x77\x77\x77\56\x77\x33\x2e\x6f\162\x67\x2f\x32\x30\x30\x31\x2f\x30\64\57\x78\x6d\154\144\163\x69\147\x2d\x6d\157\x72\x65\x23\162\163\141\x2d\163\150\141\x32\x35\66";
    const RSA_SHA384 = "\150\164\x74\x70\72\x2f\57\x77\x77\x77\56\167\x33\56\157\162\147\x2f\x32\x30\x30\x31\x2f\x30\64\57\170\x6d\154\x64\163\x69\x67\x2d\x6d\x6f\x72\145\43\x72\x73\141\55\163\x68\141\63\x38\x34";
    const RSA_SHA512 = "\x68\x74\x74\160\x3a\x2f\x2f\x77\167\167\56\x77\63\x2e\157\162\147\x2f\x32\60\x30\x31\57\x30\x34\x2f\170\155\x6c\144\x73\x69\x67\55\155\157\162\x65\43\x72\163\x61\x2d\x73\x68\x61\x35\61\62";
    const HMAC_SHA1 = "\150\x74\x74\x70\x3a\57\57\167\x77\167\56\167\63\x2e\157\x72\147\57\x32\x30\60\60\57\60\x39\57\170\x6d\154\144\x73\151\x67\43\x68\x6d\141\143\55\163\150\141\61";
    private $cryptParams = array();
    public $type = 0;
    public $key = null;
    public $passphrase = '';
    public $iv = null;
    public $name = null;
    public $keyChain = null;
    public $isEncrypted = false;
    public $encryptedCtx = null;
    public $guid = null;
    private $x509Certificate = null;
    private $X509Thumbprint = null;
    public function __construct($Oj, $FJ = null)
    {
        switch ($Oj) {
            case self::TRIPLEDES_CBC:
                $this->cryptParams["\x6c\x69\142\162\x61\x72\171"] = "\157\x70\145\156\163\163\x6c";
                $this->cryptParams["\x63\151\160\x68\145\162"] = "\144\x65\x73\55\145\x64\145\x33\55\x63\142\143";
                $this->cryptParams["\164\x79\160\x65"] = "\163\171\x6d\x6d\x65\x74\x72\151\x63";
                $this->cryptParams["\155\x65\164\150\157\144"] = "\x68\x74\x74\x70\x3a\57\57\167\x77\167\x2e\x77\63\x2e\x6f\x72\147\57\62\x30\60\61\57\60\64\57\x78\155\154\145\x6e\143\43\164\162\151\x70\x6c\145\x64\x65\163\x2d\x63\x62\x63";
                $this->cryptParams["\x6b\145\x79\x73\151\x7a\x65"] = 24;
                $this->cryptParams["\142\154\x6f\143\x6b\163\151\x7a\x65"] = 8;
                goto Kc;
            case self::AES128_CBC:
                $this->cryptParams["\x6c\151\142\162\141\x72\x79"] = "\157\160\145\x6e\x73\x73\x6c";
                $this->cryptParams["\x63\x69\x70\150\x65\x72"] = "\x61\145\163\55\x31\62\70\55\x63\142\x63";
                $this->cryptParams["\x74\x79\160\145"] = "\x73\x79\155\155\x65\164\162\151\143";
                $this->cryptParams["\x6d\145\164\x68\157\x64"] = "\x68\164\164\x70\x3a\57\57\x77\x77\167\56\x77\63\56\x6f\162\147\x2f\62\x30\60\x31\x2f\60\x34\57\x78\x6d\154\x65\156\143\43\141\x65\163\61\62\70\x2d\x63\x62\x63";
                $this->cryptParams["\153\x65\171\163\x69\172\145"] = 16;
                $this->cryptParams["\142\x6c\157\x63\x6b\x73\151\x7a\x65"] = 16;
                goto Kc;
            case self::AES192_CBC:
                $this->cryptParams["\x6c\x69\x62\x72\x61\162\x79"] = "\x6f\x70\x65\156\163\163\154";
                $this->cryptParams["\x63\151\160\150\145\162"] = "\x61\x65\x73\55\x31\71\62\55\x63\x62\x63";
                $this->cryptParams["\x74\171\x70\145"] = "\163\171\155\155\145\x74\162\x69\143";
                $this->cryptParams["\155\x65\x74\x68\x6f\144"] = "\150\164\x74\x70\x3a\x2f\x2f\167\167\x77\56\167\63\x2e\157\162\x67\x2f\62\x30\x30\x31\x2f\60\64\57\x78\155\154\x65\156\143\x23\x61\145\163\61\x39\x32\x2d\143\142\143";
                $this->cryptParams["\x6b\145\171\163\151\172\145"] = 24;
                $this->cryptParams["\142\x6c\x6f\x63\153\x73\x69\x7a\145"] = 16;
                goto Kc;
            case self::AES256_CBC:
                $this->cryptParams["\154\151\142\162\x61\x72\x79"] = "\157\x70\145\156\163\163\154";
                $this->cryptParams["\x63\151\160\x68\x65\x72"] = "\141\145\x73\x2d\x32\65\x36\x2d\143\x62\143";
                $this->cryptParams["\164\x79\160\145"] = "\163\171\155\x6d\x65\164\x72\x69\x63";
                $this->cryptParams["\155\x65\x74\150\157\x64"] = "\x68\164\x74\x70\x3a\x2f\57\167\x77\x77\x2e\167\63\56\157\x72\x67\57\62\60\x30\x31\x2f\x30\x34\x2f\x78\155\154\x65\x6e\143\x23\x61\145\x73\x32\65\x36\55\x63\x62\143";
                $this->cryptParams["\x6b\145\171\x73\151\172\x65"] = 32;
                $this->cryptParams["\142\x6c\157\143\153\x73\x69\x7a\x65"] = 16;
                goto Kc;
            case self::RSA_1_5:
                $this->cryptParams["\x6c\151\x62\x72\141\x72\x79"] = "\157\160\x65\156\163\163\x6c";
                $this->cryptParams["\x70\x61\144\x64\x69\x6e\147"] = OPENSSL_PKCS1_PADDING;
                $this->cryptParams["\x6d\x65\x74\x68\x6f\144"] = "\x68\x74\164\x70\72\57\x2f\x77\x77\x77\x2e\167\63\56\x6f\162\147\57\62\60\x30\x31\57\60\64\57\170\155\154\x65\156\x63\43\162\163\x61\55\61\137\65";
                if (!(is_array($FJ) && !empty($FJ["\x74\x79\160\x65"]))) {
                    goto DY;
                }
                if (!($FJ["\x74\x79\x70\x65"] == "\160\x75\142\x6c\x69\143" || $FJ["\x74\x79\160\x65"] == "\160\162\x69\x76\141\164\x65")) {
                    goto Sb;
                }
                $this->cryptParams["\164\x79\160\x65"] = $FJ["\x74\171\160\145"];
                goto Kc;
                Sb:
                DY:
                throw new Exception("\103\145\162\x74\151\146\151\x63\141\164\x65\40\x22\x74\171\x70\145\42\x20\x28\160\162\x69\x76\141\x74\x65\57\x70\165\142\154\151\x63\x29\x20\x6d\165\x73\x74\x20\x62\x65\x20\x70\x61\x73\x73\x65\144\x20\x76\151\x61\40\x70\141\162\141\155\x65\x74\145\x72\x73");
            case self::RSA_OAEP_MGF1P:
                $this->cryptParams["\154\151\142\162\141\162\x79"] = "\x6f\160\145\156\x73\x73\x6c";
                $this->cryptParams["\x70\x61\144\x64\151\156\x67"] = OPENSSL_PKCS1_OAEP_PADDING;
                $this->cryptParams["\155\145\164\150\x6f\144"] = "\150\x74\164\160\72\x2f\x2f\x77\x77\167\56\167\x33\x2e\x6f\162\147\x2f\62\x30\60\61\x2f\x30\64\x2f\x78\155\x6c\145\156\143\43\x72\163\x61\x2d\157\x61\x65\x70\x2d\155\147\146\61\160";
                $this->cryptParams["\x68\141\163\x68"] = null;
                if (!(is_array($FJ) && !empty($FJ["\x74\171\x70\145"]))) {
                    goto p_;
                }
                if (!($FJ["\164\x79\160\x65"] == "\x70\165\x62\154\x69\143" || $FJ["\x74\171\x70\145"] == "\160\162\151\166\x61\164\x65")) {
                    goto uK;
                }
                $this->cryptParams["\164\171\x70\x65"] = $FJ["\164\171\x70\x65"];
                goto Kc;
                uK:
                p_:
                throw new Exception("\103\145\162\x74\x69\x66\151\143\141\x74\x65\x20\42\x74\x79\x70\x65\x22\40\x28\x70\162\151\166\141\164\145\x2f\x70\165\x62\x6c\x69\143\51\x20\155\165\163\164\40\x62\145\x20\x70\141\x73\163\145\144\x20\166\x69\x61\40\x70\141\x72\141\155\x65\164\145\x72\163");
            case self::RSA_SHA1:
                $this->cryptParams["\154\x69\x62\x72\x61\162\171"] = "\157\160\145\156\163\163\154";
                $this->cryptParams["\x6d\x65\x74\x68\x6f\x64"] = "\x68\164\164\x70\72\x2f\57\167\x77\167\x2e\x77\x33\x2e\157\162\x67\x2f\x32\60\60\x30\x2f\60\x39\x2f\x78\155\154\x64\163\x69\x67\x23\x72\163\x61\55\x73\x68\141\x31";
                $this->cryptParams["\x70\141\144\144\x69\156\x67"] = OPENSSL_PKCS1_PADDING;
                if (!(is_array($FJ) && !empty($FJ["\164\171\160\145"]))) {
                    goto Av;
                }
                if (!($FJ["\164\x79\x70\145"] == "\x70\165\x62\x6c\x69\143" || $FJ["\164\x79\x70\x65"] == "\x70\162\x69\166\x61\164\x65")) {
                    goto oP;
                }
                $this->cryptParams["\164\x79\x70\x65"] = $FJ["\x74\171\160\145"];
                goto Kc;
                oP:
                Av:
                throw new Exception("\103\145\x72\164\x69\x66\151\143\141\x74\x65\x20\x22\x74\x79\160\x65\42\40\50\160\162\x69\x76\141\164\145\57\x70\x75\x62\x6c\x69\143\51\x20\155\x75\163\164\40\142\145\x20\160\141\x73\163\145\x64\x20\x76\151\x61\40\160\x61\162\141\x6d\145\164\x65\x72\163");
            case self::RSA_SHA256:
                $this->cryptParams["\x6c\x69\x62\162\x61\x72\171"] = "\157\160\145\156\163\163\154";
                $this->cryptParams["\x6d\145\x74\x68\157\x64"] = "\150\164\x74\x70\72\x2f\x2f\x77\x77\x77\56\x77\x33\56\x6f\x72\147\x2f\62\60\60\61\x2f\x30\x34\57\170\155\154\144\163\x69\147\55\x6d\x6f\x72\145\x23\x72\163\x61\x2d\163\150\x61\x32\x35\x36";
                $this->cryptParams["\x70\x61\144\x64\151\156\147"] = OPENSSL_PKCS1_PADDING;
                $this->cryptParams["\x64\x69\147\x65\x73\164"] = "\x53\x48\101\62\x35\x36";
                if (!(is_array($FJ) && !empty($FJ["\x74\171\x70\x65"]))) {
                    goto DE;
                }
                if (!($FJ["\164\x79\160\x65"] == "\x70\x75\x62\154\x69\x63" || $FJ["\164\171\x70\145"] == "\160\x72\x69\x76\141\164\145")) {
                    goto w2;
                }
                $this->cryptParams["\x74\171\160\x65"] = $FJ["\x74\x79\160\145"];
                goto Kc;
                w2:
                DE:
                throw new Exception("\x43\x65\162\164\x69\146\151\x63\x61\164\x65\40\42\x74\x79\160\x65\x22\x20\x28\x70\162\151\x76\141\164\x65\57\160\x75\142\154\x69\x63\x29\40\x6d\x75\x73\x74\40\142\x65\x20\160\x61\163\163\x65\144\x20\166\151\141\40\160\141\x72\141\x6d\x65\164\145\x72\x73");
            case self::RSA_SHA384:
                $this->cryptParams["\x6c\151\142\162\x61\162\x79"] = "\157\160\145\156\x73\163\x6c";
                $this->cryptParams["\x6d\x65\164\x68\157\x64"] = "\x68\x74\164\160\x3a\57\57\167\167\x77\x2e\167\63\x2e\157\162\147\x2f\x32\x30\60\61\x2f\x30\64\x2f\x78\x6d\154\144\163\x69\x67\55\155\x6f\162\x65\43\162\163\x61\x2d\x73\150\x61\63\x38\64";
                $this->cryptParams["\160\x61\x64\x64\151\x6e\147"] = OPENSSL_PKCS1_PADDING;
                $this->cryptParams["\144\151\147\145\x73\x74"] = "\x53\110\101\x33\70\x34";
                if (!(is_array($FJ) && !empty($FJ["\164\x79\x70\x65"]))) {
                    goto a0;
                }
                if (!($FJ["\164\171\160\145"] == "\160\x75\142\x6c\151\x63" || $FJ["\164\x79\x70\x65"] == "\x70\x72\151\166\x61\x74\x65")) {
                    goto iN;
                }
                $this->cryptParams["\x74\171\160\x65"] = $FJ["\164\x79\x70\x65"];
                goto Kc;
                iN:
                a0:
                throw new Exception("\103\145\x72\x74\151\x66\151\143\141\x74\145\40\x22\164\171\x70\x65\x22\x20\50\x70\x72\151\x76\x61\x74\x65\x2f\160\x75\142\154\151\143\x29\40\155\165\x73\164\x20\x62\x65\40\x70\x61\x73\x73\145\144\40\x76\x69\141\x20\160\x61\162\x61\155\x65\164\145\x72\163");
            case self::RSA_SHA512:
                $this->cryptParams["\x6c\151\x62\x72\x61\x72\171"] = "\x6f\x70\145\156\163\x73\154";
                $this->cryptParams["\x6d\x65\164\x68\x6f\x64"] = "\150\164\164\160\x3a\x2f\57\167\167\167\x2e\x77\x33\56\x6f\162\x67\x2f\x32\60\x30\x31\x2f\60\x34\57\170\x6d\x6c\x64\x73\151\147\x2d\x6d\x6f\162\145\43\x72\163\x61\55\163\150\141\x35\x31\x32";
                $this->cryptParams["\160\141\144\x64\x69\156\x67"] = OPENSSL_PKCS1_PADDING;
                $this->cryptParams["\x64\151\147\145\x73\164"] = "\123\110\101\x35\61\x32";
                if (!(is_array($FJ) && !empty($FJ["\164\171\160\x65"]))) {
                    goto hu;
                }
                if (!($FJ["\x74\x79\x70\x65"] == "\160\x75\x62\x6c\x69\143" || $FJ["\x74\x79\x70\145"] == "\x70\x72\x69\166\141\x74\145")) {
                    goto Tl;
                }
                $this->cryptParams["\164\x79\160\x65"] = $FJ["\164\171\x70\x65"];
                goto Kc;
                Tl:
                hu:
                throw new Exception("\103\x65\x72\164\x69\146\151\143\141\x74\x65\x20\42\164\x79\x70\145\42\x20\x28\160\162\x69\166\141\164\145\57\160\x75\x62\x6c\151\x63\x29\x20\155\165\x73\164\40\142\145\40\160\x61\163\163\145\x64\40\x76\151\141\40\x70\x61\x72\x61\x6d\145\x74\x65\162\163");
            case self::HMAC_SHA1:
                $this->cryptParams["\x6c\x69\142\x72\141\162\171"] = $Oj;
                $this->cryptParams["\x6d\x65\x74\x68\x6f\x64"] = "\x68\x74\x74\x70\x3a\57\57\167\x77\167\56\x77\x33\x2e\x6f\162\147\57\x32\60\x30\x30\x2f\60\x39\57\170\155\154\x64\x73\151\x67\43\x68\x6d\141\143\55\163\x68\141\x31";
                goto Kc;
            default:
                throw new Exception("\111\x6e\166\x61\154\x69\x64\x20\x4b\145\x79\x20\x54\171\160\x65");
        }
        z7:
        Kc:
        $this->type = $Oj;
    }
    public function getSymmetricKeySize()
    {
        if (isset($this->cryptParams["\x6b\x65\171\163\x69\x7a\145"])) {
            goto Dh;
        }
        return null;
        Dh:
        return $this->cryptParams["\153\x65\x79\163\151\x7a\x65"];
    }
    public function generateSessionKey()
    {
        if (isset($this->cryptParams["\153\x65\x79\163\151\x7a\x65"])) {
            goto D3;
        }
        throw new Exception("\125\156\x6b\156\157\x77\156\x20\153\x65\x79\x20\x73\151\172\145\40\146\157\162\x20\x74\171\160\145\x20\42" . $this->type . "\x22\56");
        D3:
        $PF = $this->cryptParams["\x6b\x65\x79\163\x69\x7a\145"];
        $YX = openssl_random_pseudo_bytes($PF);
        if (!($this->type === self::TRIPLEDES_CBC)) {
            goto Ko;
        }
        $Ce = 0;
        Xq:
        if (!($Ce < strlen($YX))) {
            goto ds;
        }
        $w0 = ord($YX[$Ce]) & 0xfe;
        $J9 = 1;
        $jf = 1;
        nL:
        if (!($jf < 8)) {
            goto qd;
        }
        $J9 ^= $w0 >> $jf & 1;
        eq:
        $jf++;
        goto nL;
        qd:
        $w0 |= $J9;
        $YX[$Ce] = chr($w0);
        pa:
        $Ce++;
        goto Xq;
        ds:
        Ko:
        $this->key = $YX;
        return $YX;
    }
    public static function getRawThumbprint($Pd)
    {
        $hU = explode("\xa", $Pd);
        $FA = '';
        $HD = false;
        foreach ($hU as $zX) {
            if (!$HD) {
                goto jR;
            }
            if (!(strncmp($zX, "\55\55\x2d\x2d\x2d\x45\x4e\x44\x20\103\105\x52\124\x49\x46\x49\103\101\124\105", 20) == 0)) {
                goto CL;
            }
            goto Hr;
            CL:
            $FA .= trim($zX);
            goto tQ;
            jR:
            if (!(strncmp($zX, "\55\55\x2d\x2d\x2d\x42\x45\107\x49\116\40\x43\105\122\124\111\x46\x49\x43\101\x54\105", 22) == 0)) {
                goto V4;
            }
            $HD = true;
            V4:
            tQ:
            XA:
        }
        Hr:
        if (empty($FA)) {
            goto os;
        }
        return strtolower(sha1(base64_decode($FA)));
        os:
        return null;
    }
    public function loadKey($YX, $PE = false, $R2 = false)
    {
        if ($PE) {
            goto R2;
        }
        $this->key = $YX;
        goto Kh;
        R2:
        $this->key = file_get_contents($YX);
        Kh:
        if ($R2) {
            goto NI;
        }
        $this->x509Certificate = null;
        goto K_;
        NI:
        $this->key = openssl_x509_read($this->key);
        openssl_x509_export($this->key, $qT);
        $this->x509Certificate = $qT;
        $this->key = $qT;
        K_:
        if (!($this->cryptParams["\154\151\x62\x72\x61\x72\171"] == "\x6f\160\145\156\163\163\x6c")) {
            goto aQ;
        }
        switch ($this->cryptParams["\164\171\x70\x65"]) {
            case "\160\165\x62\154\151\x63":
                if (!$R2) {
                    goto MH;
                }
                $this->X509Thumbprint = self::getRawThumbprint($this->key);
                MH:
                $this->key = openssl_get_publickey($this->key);
                if ($this->key) {
                    goto hZ;
                }
                throw new Exception("\x55\x6e\141\x62\154\x65\x20\164\157\x20\x65\x78\x74\162\141\143\x74\x20\160\165\142\154\151\143\x20\x6b\145\x79");
                hZ:
                goto JI;
            case "\160\162\151\166\141\x74\145":
                $this->key = openssl_get_privatekey($this->key, $this->passphrase);
                goto JI;
            case "\x73\171\155\155\x65\164\162\151\x63":
                if (!(strlen($this->key) < $this->cryptParams["\x6b\145\171\163\x69\x7a\145"])) {
                    goto MC;
                }
                throw new Exception("\113\x65\x79\40\155\x75\x73\164\40\x63\157\x6e\164\141\151\156\40\x61\x74\40\154\145\141\163\x74\x20\x32\x35\x20\x63\x68\x61\162\x61\x63\164\145\x72\163\x20\x66\157\x72\x20\x74\150\151\x73\40\143\151\160\150\x65\x72");
                MC:
                goto JI;
            default:
                throw new Exception("\x55\156\153\156\157\x77\156\40\164\171\x70\x65");
        }
        Ha:
        JI:
        aQ:
    }
    private function padISO10126($FA, $oG)
    {
        if (!($oG > 256)) {
            goto wi;
        }
        throw new Exception("\102\154\x6f\143\153\x20\163\x69\x7a\145\40\150\151\147\150\145\162\40\164\150\x61\x6e\x20\x32\65\x36\40\x6e\157\164\x20\141\154\154\157\167\x65\x64");
        wi:
        $eK = $oG - strlen($FA) % $oG;
        $Hz = chr($eK);
        return $FA . str_repeat($Hz, $eK);
    }
    private function unpadISO10126($FA)
    {
        $eK = substr($FA, -1);
        $ns = ord($eK);
        return substr($FA, 0, -$ns);
    }
    private function encryptSymmetric($FA)
    {
        $this->iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length($this->cryptParams["\x63\x69\160\x68\145\x72"]));
        $FA = $this->padISO10126($FA, $this->cryptParams["\142\154\157\143\x6b\x73\151\x7a\145"]);
        $Fu = openssl_encrypt($FA, $this->cryptParams["\143\x69\x70\x68\x65\x72"], $this->key, OPENSSL_RAW_DATA | OPENSSL_ZERO_PADDING, $this->iv);
        if (!(false === $Fu)) {
            goto DD;
        }
        throw new Exception("\106\141\151\154\165\162\145\x20\x65\156\143\x72\171\x70\164\151\156\x67\x20\104\x61\164\x61\x20\x28\x6f\160\x65\156\x73\163\154\x20\x73\171\155\155\145\164\162\151\143\x29\x20\x2d\40" . openssl_error_string());
        DD:
        return $this->iv . $Fu;
    }
    private function decryptSymmetric($FA)
    {
        $D4 = openssl_cipher_iv_length($this->cryptParams["\143\151\160\x68\145\x72"]);
        $this->iv = substr($FA, 0, $D4);
        $FA = substr($FA, $D4);
        $UO = openssl_decrypt($FA, $this->cryptParams["\x63\x69\160\x68\145\x72"], $this->key, OPENSSL_RAW_DATA | OPENSSL_ZERO_PADDING, $this->iv);
        if (!(false === $UO)) {
            goto gj;
        }
        throw new Exception("\106\x61\x69\x6c\165\x72\145\40\144\x65\x63\162\x79\x70\x74\x69\156\147\x20\104\x61\x74\x61\40\50\x6f\x70\x65\x6e\x73\x73\154\40\163\x79\155\155\x65\x74\162\151\143\51\x20\55\40" . openssl_error_string());
        gj:
        return $this->unpadISO10126($UO);
    }
    private function encryptPublic($FA)
    {
        if (openssl_public_encrypt($FA, $Fu, $this->key, $this->cryptParams["\x70\141\x64\144\151\156\147"])) {
            goto lA;
        }
        throw new Exception("\106\x61\x69\154\165\162\x65\40\x65\x6e\x63\162\x79\160\164\151\x6e\x67\40\104\141\x74\x61\x20\x28\157\x70\x65\x6e\163\x73\x6c\x20\x70\165\142\154\151\x63\51\x20\x2d\x20" . openssl_error_string());
        lA:
        return $Fu;
    }
    private function decryptPublic($FA)
    {
        if (openssl_public_decrypt($FA, $UO, $this->key, $this->cryptParams["\160\x61\x64\144\x69\156\147"])) {
            goto gX;
        }
        throw new Exception("\106\x61\x69\154\x75\x72\x65\x20\144\145\143\x72\x79\x70\164\151\x6e\147\x20\x44\141\164\x61\40\50\157\160\x65\156\163\163\154\40\160\x75\x62\154\x69\143\x29\x20\55\x20" . openssl_error_string());
        gX:
        return $UO;
    }
    private function encryptPrivate($FA)
    {
        if (openssl_private_encrypt($FA, $Fu, $this->key, $this->cryptParams["\160\141\144\144\151\156\147"])) {
            goto oL;
        }
        throw new Exception("\x46\x61\x69\x6c\x75\162\145\x20\145\x6e\x63\162\x79\x70\x74\x69\x6e\x67\x20\104\141\164\x61\x20\x28\157\x70\x65\x6e\163\x73\154\x20\160\x72\151\x76\x61\x74\145\x29\40\x2d\40" . openssl_error_string());
        oL:
        return $Fu;
    }
    private function decryptPrivate($FA)
    {
        if (openssl_private_decrypt($FA, $UO, $this->key, $this->cryptParams["\x70\141\144\x64\151\156\x67"])) {
            goto lL;
        }
        throw new Exception("\106\x61\151\x6c\165\162\145\x20\144\x65\143\x72\171\160\x74\x69\x6e\x67\x20\x44\x61\x74\141\40\50\157\160\145\x6e\163\x73\154\40\160\x72\x69\x76\141\164\x65\51\40\x2d\x20" . openssl_error_string());
        lL:
        return $UO;
    }
    private function signOpenSSL($FA)
    {
        $gr = OPENSSL_ALGO_SHA1;
        if (empty($this->cryptParams["\x64\x69\x67\145\163\164"])) {
            goto ga;
        }
        $gr = $this->cryptParams["\x64\x69\x67\x65\163\164"];
        ga:
        if (openssl_sign($FA, $Od, $this->key, $gr)) {
            goto Jt;
        }
        throw new Exception("\x46\141\x69\154\x75\162\x65\x20\123\x69\147\156\151\x6e\x67\40\104\141\x74\141\72\40" . openssl_error_string() . "\40\55\x20" . $gr);
        Jt:
        return $Od;
    }
    private function verifyOpenSSL($FA, $Od)
    {
        $gr = OPENSSL_ALGO_SHA1;
        if (empty($this->cryptParams["\x64\151\147\x65\x73\164"])) {
            goto b5;
        }
        $gr = $this->cryptParams["\144\x69\x67\145\x73\164"];
        b5:
        return openssl_verify($FA, $Od, $this->key, $gr);
    }
    public function encryptData($FA)
    {
        if (!($this->cryptParams["\x6c\x69\142\x72\141\162\171"] === "\x6f\160\x65\156\163\x73\154")) {
            goto F2;
        }
        switch ($this->cryptParams["\164\x79\x70\145"]) {
            case "\x73\x79\155\x6d\145\164\162\x69\143":
                return $this->encryptSymmetric($FA);
            case "\160\165\142\154\x69\143":
                return $this->encryptPublic($FA);
            case "\x70\x72\x69\166\141\164\x65":
                return $this->encryptPrivate($FA);
        }
        vP:
        t6:
        F2:
    }
    public function decryptData($FA)
    {
        if (!($this->cryptParams["\154\x69\x62\162\141\162\171"] === "\157\x70\145\x6e\x73\x73\154")) {
            goto Mq;
        }
        switch ($this->cryptParams["\x74\171\160\145"]) {
            case "\x73\x79\155\155\145\164\x72\151\x63":
                return $this->decryptSymmetric($FA);
            case "\160\x75\x62\x6c\151\x63":
                return $this->decryptPublic($FA);
            case "\160\162\151\x76\x61\x74\x65":
                return $this->decryptPrivate($FA);
        }
        wG:
        EC:
        Mq:
    }
    public function signData($FA)
    {
        switch ($this->cryptParams["\154\x69\142\x72\141\162\x79"]) {
            case "\x6f\160\145\x6e\x73\x73\x6c":
                return $this->signOpenSSL($FA);
            case self::HMAC_SHA1:
                return hash_hmac("\x73\x68\141\61", $FA, $this->key, true);
        }
        LO:
        kt:
    }
    public function verifySignature($FA, $Od)
    {
        switch ($this->cryptParams["\x6c\151\x62\x72\x61\162\x79"]) {
            case "\157\x70\145\x6e\163\x73\154":
                return $this->verifyOpenSSL($FA, $Od);
            case self::HMAC_SHA1:
                $Ur = hash_hmac("\163\x68\x61\61", $FA, $this->key, true);
                return strcmp($Od, $Ur) == 0;
        }
        yd:
        Dt:
    }
    public function getAlgorith()
    {
        return $this->getAlgorithm();
    }
    public function getAlgorithm()
    {
        return $this->cryptParams["\155\145\164\150\x6f\x64"];
    }
    public static function makeAsnSegment($Oj, $pg)
    {
        switch ($Oj) {
            case 0x2:
                if (!(ord($pg) > 0x7f)) {
                    goto XX;
                }
                $pg = chr(0) . $pg;
                XX:
                goto w9;
            case 0x3:
                $pg = chr(0) . $pg;
                goto w9;
        }
        qv:
        w9:
        $OB = strlen($pg);
        if ($OB < 128) {
            goto Gw;
        }
        if ($OB < 0x100) {
            goto Oi;
        }
        if ($OB < 0x10000) {
            goto lv;
        }
        $GC = null;
        goto ec;
        lv:
        $GC = sprintf("\x25\143\45\143\45\143\x25\x63\x25\163", $Oj, 0x82, $OB / 0x100, $OB % 0x100, $pg);
        ec:
        goto ol;
        Oi:
        $GC = sprintf("\x25\143\x25\143\x25\x63\45\x73", $Oj, 0x81, $OB, $pg);
        ol:
        goto Zh;
        Gw:
        $GC = sprintf("\45\x63\45\143\45\x73", $Oj, $OB, $pg);
        Zh:
        return $GC;
    }
    public static function convertRSA($s6, $Rd)
    {
        $YD = self::makeAsnSegment(0x2, $Rd);
        $ZY = self::makeAsnSegment(0x2, $s6);
        $Zk = self::makeAsnSegment(0x30, $ZY . $YD);
        $fi = self::makeAsnSegment(0x3, $Zk);
        $dw = pack("\x48\52", "\63\60\x30\104\x30\x36\60\71\62\x41\70\x36\64\70\70\x36\106\x37\60\104\60\x31\x30\61\60\61\60\65\60\60");
        $Dm = self::makeAsnSegment(0x30, $dw . $fi);
        $EE = base64_encode($Dm);
        $gK = "\x2d\x2d\x2d\x2d\x2d\102\x45\x47\x49\x4e\40\120\x55\102\x4c\111\x43\x20\113\105\x59\x2d\x2d\x2d\55\55\xa";
        $E3 = 0;
        mN:
        if (!($Iu = substr($EE, $E3, 64))) {
            goto Ul;
        }
        $gK = $gK . $Iu . "\xa";
        $E3 += 64;
        goto mN;
        Ul:
        return $gK . "\x2d\x2d\55\x2d\55\x45\x4e\104\x20\120\x55\102\x4c\111\x43\x20\113\x45\131\x2d\55\x2d\x2d\55\12";
    }
    public function serializeKey($uu)
    {
    }
    public function getX509Certificate()
    {
        return $this->x509Certificate;
    }
    public function getX509Thumbprint()
    {
        return $this->X509Thumbprint;
    }
    public static function fromEncryptedKeyElement(DOMElement $vj)
    {
        $uq = new XMLSecEnc();
        $uq->setNode($vj);
        if ($lP = $uq->locateKey()) {
            goto ih;
        }
        throw new Exception("\125\156\x61\x62\154\145\40\x74\157\x20\x6c\x6f\x63\x61\x74\145\x20\141\154\147\x6f\162\151\164\x68\x6d\40\146\157\162\40\x74\x68\x69\x73\x20\x45\x6e\x63\162\171\160\x74\145\144\x20\113\145\x79");
        ih:
        $lP->isEncrypted = true;
        $lP->encryptedCtx = $uq;
        XMLSecEnc::staticLocateKeyInfo($lP, $vj);
        return $lP;
    }
}
