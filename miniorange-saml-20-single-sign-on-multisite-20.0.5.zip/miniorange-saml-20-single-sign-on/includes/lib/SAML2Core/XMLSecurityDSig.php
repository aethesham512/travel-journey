<?php


namespace RobRichards\XMLSecLibs;

use DOMDocument;
use DOMElement;
use DOMNode;
use DOMXPath;
use Exception;
use RobRichards\XMLSecLibs\Utils\XPath as XPath;
class XMLSecurityDSig
{
    const XMLDSIGNS = "\150\x74\x74\160\72\57\57\x77\x77\x77\56\x77\x33\x2e\x6f\162\147\57\62\x30\60\60\x2f\x30\71\x2f\x78\155\154\x64\163\151\147\43";
    const SHA1 = "\150\x74\164\160\x3a\57\57\x77\167\167\56\x77\x33\56\x6f\x72\147\x2f\62\x30\x30\x30\57\60\x39\57\170\x6d\x6c\144\x73\x69\147\43\163\x68\141\x31";
    const SHA256 = "\x68\x74\164\160\x3a\x2f\57\x77\167\167\x2e\167\63\56\157\x72\x67\x2f\x32\x30\x30\61\x2f\x30\64\57\x78\155\154\x65\156\x63\x23\163\150\x61\62\65\x36";
    const SHA384 = "\150\164\x74\x70\x3a\57\57\x77\x77\x77\x2e\x77\x33\x2e\x6f\x72\x67\57\62\x30\60\61\x2f\x30\x34\x2f\x78\155\154\x64\163\x69\x67\55\155\157\162\x65\x23\163\150\x61\x33\x38\64";
    const SHA512 = "\x68\x74\x74\160\x3a\57\57\x77\x77\167\56\x77\63\56\x6f\x72\147\x2f\62\60\x30\61\57\60\x34\57\x78\155\x6c\x65\x6e\x63\43\163\x68\141\65\x31\x32";
    const RIPEMD160 = "\150\164\164\160\x3a\x2f\57\167\167\167\56\x77\63\x2e\157\x72\x67\57\x32\x30\60\x31\x2f\60\64\x2f\170\x6d\154\145\x6e\143\x23\162\x69\x70\x65\x6d\144\x31\66\x30";
    const C14N = "\x68\x74\x74\x70\x3a\57\57\167\167\167\56\x77\63\56\157\x72\147\x2f\x54\122\x2f\62\x30\x30\x31\x2f\122\x45\x43\x2d\x78\x6d\x6c\55\x63\x31\64\x6e\x2d\x32\x30\x30\61\x30\x33\61\65";
    const C14N_COMMENTS = "\x68\x74\164\x70\72\x2f\x2f\x77\x77\x77\x2e\167\63\x2e\x6f\162\147\57\124\x52\57\62\x30\60\x31\57\122\x45\103\x2d\170\x6d\x6c\55\x63\61\x34\x6e\x2d\62\x30\60\61\60\63\x31\x35\43\127\151\x74\x68\x43\157\x6d\155\x65\x6e\x74\x73";
    const EXC_C14N = "\150\164\164\160\72\57\x2f\167\x77\167\56\x77\x33\x2e\x6f\162\147\x2f\62\x30\60\x31\57\x31\x30\x2f\x78\x6d\x6c\55\145\x78\143\x2d\x63\61\x34\x6e\43";
    const EXC_C14N_COMMENTS = "\x68\x74\164\x70\x3a\57\x2f\167\167\167\56\x77\x33\x2e\x6f\x72\x67\x2f\x32\x30\60\61\x2f\x31\60\57\170\x6d\x6c\x2d\145\x78\143\x2d\x63\61\64\x6e\x23\127\x69\x74\x68\103\157\155\155\145\156\164\x73";
    const template = "\x3c\x64\163\72\123\x69\x67\156\x61\x74\x75\x72\145\x20\170\x6d\154\x6e\163\x3a\144\x73\x3d\x22\150\x74\164\160\x3a\x2f\57\x77\x77\167\x2e\167\x33\x2e\157\162\x67\x2f\x32\60\x30\60\57\x30\x39\57\170\155\154\x64\163\x69\147\43\42\x3e\xd\xa\x20\40\x3c\144\163\72\x53\x69\147\x6e\145\x64\x49\156\146\157\x3e\15\xa\x20\40\x20\40\x3c\x64\x73\72\x53\151\x67\156\141\164\x75\x72\145\115\x65\164\x68\x6f\x64\x20\57\x3e\xd\xa\x20\x20\74\57\144\163\72\x53\x69\147\156\145\144\x49\156\x66\157\76\15\12\x3c\57\144\163\72\x53\151\x67\x6e\x61\x74\165\x72\x65\x3e";
    const BASE_TEMPLATE = "\74\x53\151\x67\x6e\141\x74\x75\x72\145\40\x78\155\154\x6e\163\75\x22\x68\x74\x74\160\72\x2f\x2f\x77\167\x77\56\x77\x33\56\x6f\162\x67\57\62\x30\60\x30\x2f\60\71\57\x78\x6d\154\144\163\151\x67\43\x22\76\15\xa\40\x20\x3c\123\151\x67\x6e\145\144\111\156\146\157\76\xd\12\40\40\x20\40\x3c\x53\x69\147\156\141\x74\165\x72\x65\x4d\x65\x74\150\157\144\40\x2f\x3e\xd\xa\40\x20\x3c\57\123\x69\x67\x6e\145\x64\x49\156\146\x6f\76\15\xa\74\57\123\x69\x67\156\141\164\x75\x72\x65\x3e";
    public $sigNode = null;
    public $idKeys = array();
    public $idNS = array();
    private $signedInfo = null;
    private $xPathCtx = null;
    private $canonicalMethod = null;
    private $prefix = '';
    private $searchpfx = "\x73\145\143\144\x73\x69\x67";
    private $validatedNodes = null;
    public function __construct($LP = "\144\163")
    {
        $JY = self::BASE_TEMPLATE;
        if (empty($LP)) {
            goto C7;
        }
        $this->prefix = $LP . "\72";
        $MB = array("\x3c\123", "\x3c\57\123", "\x78\x6d\154\x6e\163\x3d");
        $ZZ = array("\74{$LP}\72\x53", "\74\57{$LP}\x3a\123", "\x78\155\x6c\156\x73\x3a{$LP}\x3d");
        $JY = str_replace($MB, $ZZ, $JY);
        C7:
        $cO = new DOMDocument();
        $cO->loadXML($JY);
        $this->sigNode = $cO->documentElement;
    }
    private function resetXPathObj()
    {
        $this->xPathCtx = null;
    }
    private function getXPathObj()
    {
        if (!(empty($this->xPathCtx) && !empty($this->sigNode))) {
            goto rA;
        }
        $Ne = new DOMXPath($this->sigNode->ownerDocument);
        $Ne->registerNamespace("\163\145\143\144\163\151\x67", self::XMLDSIGNS);
        $this->xPathCtx = $Ne;
        rA:
        return $this->xPathCtx;
    }
    public static function generateGUID($LP = "\160\x66\x78")
    {
        $JB = md5(uniqid(mt_rand(), true));
        $bA = $LP . substr($JB, 0, 8) . "\x2d" . substr($JB, 8, 4) . "\x2d" . substr($JB, 12, 4) . "\55" . substr($JB, 16, 4) . "\x2d" . substr($JB, 20, 12);
        return $bA;
    }
    public static function generate_GUID($LP = "\160\146\x78")
    {
        return self::generateGUID($LP);
    }
    public function locateSignature($Dw, $x6 = 0)
    {
        if ($Dw instanceof DOMDocument) {
            goto Tm;
        }
        $o7 = $Dw->ownerDocument;
        goto DC;
        Tm:
        $o7 = $Dw;
        DC:
        if (!$o7) {
            goto y8;
        }
        $Ne = new DOMXPath($o7);
        $Ne->registerNamespace("\x73\145\143\x64\163\x69\x67", self::XMLDSIGNS);
        $XK = "\56\57\x2f\163\x65\x63\144\163\x69\147\x3a\x53\x69\147\x6e\141\164\165\x72\145";
        $gD = $Ne->query($XK, $Dw);
        $this->sigNode = $gD->item($x6);
        return $this->sigNode;
        y8:
        return null;
    }
    public function createNewSignNode($GN, $yS = null)
    {
        $o7 = $this->sigNode->ownerDocument;
        if (!is_null($yS)) {
            goto Hz;
        }
        $aB = $o7->createElementNS(self::XMLDSIGNS, $this->prefix . $GN);
        goto Y7;
        Hz:
        $aB = $o7->createElementNS(self::XMLDSIGNS, $this->prefix . $GN, $yS);
        Y7:
        return $aB;
    }
    public function setCanonicalMethod($Eu)
    {
        switch ($Eu) {
            case "\x68\164\164\x70\72\x2f\x2f\x77\x77\x77\x2e\x77\63\56\x6f\162\x67\x2f\x54\122\57\x32\60\60\x31\57\122\x45\x43\55\170\155\x6c\55\x63\x31\x34\156\55\x32\60\x30\x31\60\63\61\x35":
            case "\x68\164\x74\160\x3a\x2f\x2f\x77\x77\167\x2e\x77\63\x2e\x6f\x72\147\x2f\x54\x52\x2f\x32\60\x30\61\x2f\x52\x45\103\x2d\x78\x6d\154\x2d\x63\61\64\x6e\x2d\62\x30\60\x31\x30\x33\61\65\43\127\x69\164\150\103\x6f\x6d\155\x65\156\164\x73":
            case "\150\x74\164\160\x3a\x2f\x2f\x77\x77\x77\x2e\167\x33\x2e\157\x72\x67\57\62\60\x30\61\57\61\60\57\170\x6d\154\55\x65\170\143\x2d\143\61\x34\156\x23":
            case "\150\x74\x74\160\72\x2f\x2f\167\167\x77\56\167\63\56\x6f\x72\x67\x2f\x32\60\x30\x31\x2f\61\60\x2f\170\x6d\x6c\55\x65\170\143\55\x63\61\64\x6e\43\127\x69\x74\x68\103\157\155\x6d\145\x6e\164\x73":
                $this->canonicalMethod = $Eu;
                goto E4;
            default:
                throw new Exception("\x49\x6e\x76\x61\x6c\x69\x64\x20\x43\141\x6e\x6f\x6e\x69\143\x61\x6c\40\x4d\x65\x74\x68\157\144");
        }
        dJ:
        E4:
        if (!($Ne = $this->getXPathObj())) {
            goto P9;
        }
        $XK = "\x2e\x2f" . $this->searchpfx . "\72\123\151\147\x6e\x65\x64\x49\156\x66\x6f";
        $gD = $Ne->query($XK, $this->sigNode);
        if (!($pr = $gD->item(0))) {
            goto is;
        }
        $XK = "\56\57" . $this->searchpfx . "\103\141\156\157\x6e\x69\143\x61\154\151\172\x61\164\x69\157\156\x4d\x65\164\x68\x6f\144";
        $gD = $Ne->query($XK, $pr);
        if ($RJ = $gD->item(0)) {
            goto v_;
        }
        $RJ = $this->createNewSignNode("\103\x61\x6e\157\156\x69\143\141\154\x69\172\x61\x74\151\157\x6e\115\x65\164\150\x6f\x64");
        $pr->insertBefore($RJ, $pr->firstChild);
        v_:
        $RJ->setAttribute("\x41\x6c\147\157\x72\151\x74\150\155", $this->canonicalMethod);
        is:
        P9:
    }
    private function canonicalizeData($aB, $VG, $ik = null, $Fz = null)
    {
        $Gx = false;
        $ew = false;
        switch ($VG) {
            case "\x68\164\164\x70\72\57\57\167\x77\167\x2e\x77\63\56\157\x72\x67\57\x54\122\x2f\62\x30\x30\x31\57\122\105\103\55\x78\155\154\x2d\x63\61\64\156\x2d\x32\60\x30\x31\x30\63\61\65":
                $Gx = false;
                $ew = false;
                goto cZ;
            case "\x68\164\x74\160\x3a\57\x2f\x77\167\167\56\167\63\56\157\x72\x67\x2f\124\122\57\x32\60\x30\x31\x2f\x52\105\x43\x2d\x78\x6d\154\x2d\143\x31\64\x6e\x2d\62\60\60\x31\x30\63\x31\65\43\x57\151\164\150\x43\x6f\155\x6d\x65\156\x74\x73":
                $ew = true;
                goto cZ;
            case "\x68\164\x74\x70\x3a\57\x2f\x77\x77\167\x2e\x77\63\x2e\157\x72\147\x2f\62\x30\60\61\57\x31\x30\x2f\x78\155\154\55\x65\170\143\55\x63\x31\64\x6e\x23":
                $Gx = true;
                goto cZ;
            case "\x68\x74\164\160\x3a\x2f\x2f\x77\167\x77\56\167\63\56\157\x72\147\x2f\x32\x30\60\x31\57\x31\x30\x2f\x78\155\x6c\x2d\x65\x78\143\x2d\x63\61\64\x6e\x23\x57\151\164\x68\x43\x6f\155\x6d\145\x6e\164\x73":
                $Gx = true;
                $ew = true;
                goto cZ;
        }
        ia:
        cZ:
        if (!(is_null($ik) && $aB instanceof DOMNode && $aB->ownerDocument !== null && $aB->isSameNode($aB->ownerDocument->documentElement))) {
            goto XO;
        }
        $vj = $aB;
        vC:
        if (!($SM = $vj->previousSibling)) {
            goto xK;
        }
        if (!($SM->nodeType == XML_PI_NODE || $SM->nodeType == XML_COMMENT_NODE && $ew)) {
            goto bx;
        }
        goto xK;
        bx:
        $vj = $SM;
        goto vC;
        xK:
        if (!($SM == null)) {
            goto hm;
        }
        $aB = $aB->ownerDocument;
        hm:
        XO:
        return $aB->C14N($Gx, $ew, $ik, $Fz);
    }
    public function canonicalizeSignedInfo()
    {
        $o7 = $this->sigNode->ownerDocument;
        $VG = null;
        if (!$o7) {
            goto Vy;
        }
        $Ne = $this->getXPathObj();
        $XK = "\x2e\57\x73\x65\x63\144\163\151\x67\72\x53\151\147\156\x65\144\111\156\x66\x6f";
        $gD = $Ne->query($XK, $this->sigNode);
        if (!($t4 = $gD->item(0))) {
            goto ZF;
        }
        $XK = "\56\x2f\163\x65\x63\144\x73\x69\147\x3a\103\141\x6e\157\x6e\151\143\141\154\x69\x7a\x61\x74\151\157\x6e\115\145\x74\150\157\144";
        $gD = $Ne->query($XK, $t4);
        if (!($RJ = $gD->item(0))) {
            goto H1;
        }
        $VG = $RJ->getAttribute("\101\x6c\147\157\162\x69\x74\150\x6d");
        H1:
        $this->signedInfo = $this->canonicalizeData($t4, $VG);
        return $this->signedInfo;
        ZF:
        Vy:
        return null;
    }
    public function calculateDigest($H3, $FA, $e_ = true)
    {
        switch ($H3) {
            case self::SHA1:
                $Pv = "\x73\150\x61\61";
                goto ja;
            case self::SHA256:
                $Pv = "\163\x68\141\62\65\x36";
                goto ja;
            case self::SHA384:
                $Pv = "\163\150\141\x33\70\64";
                goto ja;
            case self::SHA512:
                $Pv = "\x73\150\141\65\61\x32";
                goto ja;
            case self::RIPEMD160:
                $Pv = "\162\x69\160\x65\x6d\144\x31\66\x30";
                goto ja;
            default:
                throw new Exception("\103\x61\156\x6e\x6f\164\x20\x76\141\154\x69\x64\x61\x74\x65\40\x64\x69\147\145\163\164\x3a\40\125\x6e\163\165\160\160\157\x72\x74\x65\144\x20\101\154\x67\x6f\162\x69\x74\x68\x6d\x20\74{$H3}\x3e");
        }
        cS:
        ja:
        $T3 = hash($Pv, $FA, true);
        if (!$e_) {
            goto NV;
        }
        $T3 = base64_encode($T3);
        NV:
        return $T3;
    }
    public function validateDigest($tg, $FA)
    {
        $Ne = new DOMXPath($tg->ownerDocument);
        $Ne->registerNamespace("\163\145\x63\144\163\151\x67", self::XMLDSIGNS);
        $XK = "\x73\164\x72\151\156\x67\x28\56\57\x73\x65\x63\x64\x73\x69\147\x3a\104\151\x67\x65\163\x74\x4d\145\x74\x68\x6f\x64\x2f\x40\101\154\x67\157\162\x69\164\x68\155\x29";
        $H3 = $Ne->evaluate($XK, $tg);
        $Xw = $this->calculateDigest($H3, $FA, false);
        $XK = "\x73\164\x72\x69\x6e\x67\50\x2e\x2f\x73\145\143\x64\163\x69\x67\x3a\x44\x69\x67\x65\163\164\x56\141\x6c\165\x65\51";
        $ta = $Ne->evaluate($XK, $tg);
        return $Xw === base64_decode($ta);
    }
    public function processTransforms($tg, $Tp, $nW = true)
    {
        $FA = $Tp;
        $Ne = new DOMXPath($tg->ownerDocument);
        $Ne->registerNamespace("\163\x65\143\144\163\x69\147", self::XMLDSIGNS);
        $XK = "\x2e\x2f\x73\145\x63\144\x73\151\x67\72\124\162\x61\x6e\x73\146\x6f\162\155\163\57\163\145\143\x64\163\x69\147\72\x54\x72\141\x6e\163\146\157\162\155";
        $yP = $Ne->query($XK, $tg);
        $fI = "\150\164\164\160\x3a\x2f\57\167\x77\167\56\167\63\56\157\162\x67\57\124\x52\x2f\x32\x30\x30\x31\57\x52\x45\x43\x2d\x78\155\154\x2d\x63\x31\x34\x6e\x2d\x32\60\x30\x31\x30\63\x31\65";
        $ik = null;
        $Fz = null;
        foreach ($yP as $BI) {
            $N9 = $BI->getAttribute("\x41\154\x67\157\x72\x69\164\150\x6d");
            switch ($N9) {
                case "\x68\164\164\x70\72\57\57\167\167\x77\x2e\167\63\56\x6f\x72\x67\57\62\60\60\61\x2f\x31\x30\x2f\170\155\154\55\145\x78\143\55\x63\61\x34\156\x23":
                case "\150\164\164\x70\72\57\x2f\x77\167\x77\56\167\63\x2e\x6f\x72\x67\x2f\62\60\60\61\x2f\x31\60\57\x78\155\x6c\55\145\x78\x63\x2d\x63\61\64\x6e\43\x57\151\164\x68\x43\157\x6d\155\145\156\x74\163":
                    if (!$nW) {
                        goto HI;
                    }
                    $fI = $N9;
                    goto tX;
                    HI:
                    $fI = "\150\x74\x74\160\72\x2f\x2f\x77\167\x77\x2e\x77\x33\x2e\157\x72\147\x2f\x32\x30\x30\x31\x2f\61\x30\x2f\170\x6d\x6c\55\145\x78\143\55\x63\x31\64\156\43";
                    tX:
                    $aB = $BI->firstChild;
                    IH:
                    if (!$aB) {
                        goto nS;
                    }
                    if (!($aB->localName == "\111\156\143\x6c\165\163\x69\166\145\x4e\x61\155\x65\x73\x70\141\x63\x65\x73")) {
                        goto Sv;
                    }
                    if (!($Fd = $aB->getAttribute("\120\162\x65\x66\151\170\114\151\x73\164"))) {
                        goto ER;
                    }
                    $Oq = array();
                    $Mn = explode("\40", $Fd);
                    foreach ($Mn as $Fd) {
                        $yr = trim($Fd);
                        if (empty($yr)) {
                            goto M1;
                        }
                        $Oq[] = $yr;
                        M1:
                        Cq:
                    }
                    Sk:
                    if (!(count($Oq) > 0)) {
                        goto BO;
                    }
                    $Fz = $Oq;
                    BO:
                    ER:
                    goto nS;
                    Sv:
                    $aB = $aB->nextSibling;
                    goto IH;
                    nS:
                    goto Oq;
                case "\150\x74\164\160\72\x2f\57\167\x77\x77\56\167\63\x2e\x6f\x72\x67\57\x54\122\57\x32\60\60\x31\x2f\122\x45\x43\55\x78\155\x6c\55\143\61\64\x6e\55\x32\60\x30\61\60\63\x31\x35":
                case "\x68\164\164\x70\x3a\x2f\x2f\x77\x77\167\x2e\x77\63\x2e\157\x72\147\x2f\x54\x52\57\x32\60\60\x31\57\122\105\x43\x2d\170\155\154\55\x63\61\64\x6e\x2d\x32\60\x30\x31\x30\63\x31\65\x23\127\151\x74\x68\103\157\x6d\x6d\145\x6e\x74\x73":
                    if (!$nW) {
                        goto nV;
                    }
                    $fI = $N9;
                    goto K9;
                    nV:
                    $fI = "\150\x74\x74\160\x3a\x2f\57\167\x77\167\56\167\x33\56\157\x72\147\x2f\124\x52\x2f\x32\x30\60\x31\57\122\105\103\55\170\155\154\55\143\61\64\156\x2d\x32\60\60\61\x30\x33\x31\65";
                    K9:
                    goto Oq;
                case "\x68\164\164\x70\72\57\x2f\x77\167\167\56\x77\63\x2e\157\x72\147\x2f\124\x52\x2f\x31\x39\x39\x39\x2f\x52\105\103\55\x78\x70\x61\164\150\55\x31\71\71\71\61\61\x31\x36":
                    $aB = $BI->firstChild;
                    uz:
                    if (!$aB) {
                        goto Bh;
                    }
                    if (!($aB->localName == "\x58\x50\x61\x74\x68")) {
                        goto A3;
                    }
                    $ik = array();
                    $ik["\x71\x75\145\162\171"] = "\50\x2e\x2f\57\x2e\40\174\x20\x2e\57\x2f\x40\x2a\x20\x7c\40\x2e\57\x2f\156\141\x6d\x65\163\x70\x61\x63\x65\x3a\72\52\x29\133" . $aB->nodeValue . "\x5d";
                    $x9["\x6e\x61\155\145\163\160\x61\x63\x65\x73"] = array();
                    $aj = $Ne->query("\x2e\x2f\x6e\141\155\x65\163\x70\141\x63\145\x3a\72\52", $aB);
                    foreach ($aj as $tR) {
                        if (!($tR->localName != "\170\x6d\x6c")) {
                            goto Na;
                        }
                        $ik["\x6e\141\155\145\x73\x70\141\x63\x65\x73"][$tR->localName] = $tR->nodeValue;
                        Na:
                        zW:
                    }
                    u5:
                    goto Bh;
                    A3:
                    $aB = $aB->nextSibling;
                    goto uz;
                    Bh:
                    goto Oq;
            }
            c1:
            Oq:
            TV:
        }
        XZ:
        if (!$FA instanceof DOMNode) {
            goto M6;
        }
        $FA = $this->canonicalizeData($Tp, $fI, $ik, $Fz);
        M6:
        return $FA;
    }
    public function processRefNode($tg)
    {
        $jj = null;
        $nW = true;
        if ($nJ = $tg->getAttribute("\x55\122\111")) {
            goto sz;
        }
        $nW = false;
        $jj = $tg->ownerDocument;
        goto Mr;
        sz:
        $BJ = parse_url($nJ);
        if (!empty($BJ["\160\x61\x74\150"])) {
            goto tD;
        }
        if ($Yf = $BJ["\146\x72\x61\147\155\x65\x6e\x74"]) {
            goto Bx;
        }
        $jj = $tg->ownerDocument;
        goto s9;
        Bx:
        $nW = false;
        $lR = new DOMXPath($tg->ownerDocument);
        if (!($this->idNS && is_array($this->idNS))) {
            goto Ep;
        }
        foreach ($this->idNS as $NK => $zE) {
            $lR->registerNamespace($NK, $zE);
            gZ:
        }
        sH:
        Ep:
        $Z4 = "\100\x49\144\x3d\42" . XPath::filterAttrValue($Yf, XPath::DOUBLE_QUOTE) . "\x22";
        if (!is_array($this->idKeys)) {
            goto NC;
        }
        foreach ($this->idKeys as $q6) {
            $Z4 .= "\x20\157\162\x20\x40" . XPath::filterAttrName($q6) . "\x3d\x22" . XPath::filterAttrValue($Yf, XPath::DOUBLE_QUOTE) . "\42";
            hz:
        }
        e3:
        NC:
        $XK = "\57\57\x2a\x5b" . $Z4 . "\x5d";
        $jj = $lR->query($XK)->item(0);
        s9:
        tD:
        Mr:
        $FA = $this->processTransforms($tg, $jj, $nW);
        if ($this->validateDigest($tg, $FA)) {
            goto Ez;
        }
        return false;
        Ez:
        if (!$jj instanceof DOMNode) {
            goto z4;
        }
        if (!empty($Yf)) {
            goto z5;
        }
        $this->validatedNodes[] = $jj;
        goto Ut;
        z5:
        $this->validatedNodes[$Yf] = $jj;
        Ut:
        z4:
        return true;
    }
    public function getRefNodeID($tg)
    {
        if (!($nJ = $tg->getAttribute("\x55\122\x49"))) {
            goto AL;
        }
        $BJ = parse_url($nJ);
        if (!empty($BJ["\160\x61\x74\x68"])) {
            goto ps;
        }
        if (!($Yf = $BJ["\x66\162\x61\147\x6d\145\156\x74"])) {
            goto rr;
        }
        return $Yf;
        rr:
        ps:
        AL:
        return null;
    }
    public function getRefIDs()
    {
        $ox = array();
        $Ne = $this->getXPathObj();
        $XK = "\56\57\x73\145\143\x64\163\x69\x67\72\123\x69\147\x6e\145\144\111\156\x66\157\x2f\163\145\143\x64\x73\x69\x67\x3a\x52\x65\146\x65\x72\145\x6e\x63\x65";
        $gD = $Ne->query($XK, $this->sigNode);
        if (!($gD->length == 0)) {
            goto vd;
        }
        throw new Exception("\122\x65\146\145\162\145\156\143\x65\x20\x6e\x6f\144\145\x73\x20\156\x6f\164\x20\x66\157\x75\x6e\144");
        vd:
        foreach ($gD as $tg) {
            $ox[] = $this->getRefNodeID($tg);
            vB:
        }
        JD:
        return $ox;
    }
    public function validateReference()
    {
        $UH = $this->sigNode->ownerDocument->documentElement;
        if ($UH->isSameNode($this->sigNode)) {
            goto ys;
        }
        if (!($this->sigNode->parentNode != null)) {
            goto Zb;
        }
        $this->sigNode->parentNode->removeChild($this->sigNode);
        Zb:
        ys:
        $Ne = $this->getXPathObj();
        $XK = "\x2e\x2f\x73\145\x63\x64\163\x69\x67\x3a\x53\x69\x67\156\x65\x64\111\156\x66\x6f\x2f\163\x65\143\x64\x73\151\147\72\122\145\x66\x65\x72\145\156\x63\x65";
        $gD = $Ne->query($XK, $this->sigNode);
        if (!($gD->length == 0)) {
            goto zn;
        }
        throw new Exception("\x52\145\146\145\162\145\x6e\143\145\x20\156\x6f\x64\x65\163\40\x6e\x6f\x74\x20\x66\157\x75\156\x64");
        zn:
        $this->validatedNodes = array();
        foreach ($gD as $tg) {
            if ($this->processRefNode($tg)) {
                goto er;
            }
            $this->validatedNodes = null;
            throw new Exception("\122\x65\146\x65\x72\145\156\143\145\40\166\141\x6c\151\x64\141\164\x69\157\156\40\146\x61\151\154\145\144");
            er:
            gm:
        }
        jC:
        return true;
    }
    private function addRefInternal($Ag, $aB, $N9, $OE = null, $OX = null)
    {
        $LP = null;
        $Cy = null;
        $jX = "\x49\144";
        $Xr = true;
        $ii = false;
        if (!is_array($OX)) {
            goto X0;
        }
        $LP = empty($OX["\160\x72\x65\146\151\x78"]) ? null : $OX["\160\162\145\x66\x69\170"];
        $Cy = empty($OX["\x70\x72\145\146\x69\170\137\x6e\x73"]) ? null : $OX["\160\162\x65\x66\x69\170\x5f\156\x73"];
        $jX = empty($OX["\151\144\x5f\156\x61\x6d\145"]) ? "\111\x64" : $OX["\151\144\137\x6e\x61\155\x65"];
        $Xr = !isset($OX["\157\166\x65\x72\x77\x72\x69\164\x65"]) ? true : (bool) $OX["\x6f\166\145\162\167\162\151\164\145"];
        $ii = !isset($OX["\146\x6f\162\143\x65\x5f\165\x72\151"]) ? false : (bool) $OX["\146\157\162\143\x65\x5f\165\x72\x69"];
        X0:
        $Ci = $jX;
        if (empty($LP)) {
            goto KQ;
        }
        $Ci = $LP . "\72" . $Ci;
        KQ:
        $tg = $this->createNewSignNode("\122\x65\146\x65\162\145\x6e\x63\x65");
        $Ag->appendChild($tg);
        if (!$aB instanceof DOMDocument) {
            goto IM;
        }
        if ($ii) {
            goto Vs;
        }
        goto ne;
        IM:
        $nJ = null;
        if ($Xr) {
            goto KG;
        }
        $nJ = $Cy ? $aB->getAttributeNS($Cy, $jX) : $aB->getAttribute($jX);
        KG:
        if (!empty($nJ)) {
            goto Hg;
        }
        $nJ = self::generateGUID();
        $aB->setAttributeNS($Cy, $Ci, $nJ);
        Hg:
        $tg->setAttribute("\x55\x52\111", "\43" . $nJ);
        goto ne;
        Vs:
        $tg->setAttribute("\x55\x52\x49", '');
        ne:
        $l4 = $this->createNewSignNode("\124\x72\x61\x6e\163\146\x6f\x72\x6d\x73");
        $tg->appendChild($l4);
        if (is_array($OE)) {
            goto zm;
        }
        if (!empty($this->canonicalMethod)) {
            goto Lv;
        }
        goto tg;
        zm:
        foreach ($OE as $BI) {
            $ks = $this->createNewSignNode("\124\162\141\156\x73\x66\157\x72\155");
            $l4->appendChild($ks);
            if (is_array($BI) && !empty($BI["\x68\164\x74\160\x3a\x2f\57\167\167\167\56\x77\63\x2e\x6f\162\x67\x2f\x54\x52\57\61\x39\x39\x39\57\122\105\x43\55\x78\160\x61\x74\x68\x2d\61\x39\71\71\61\61\x31\66"]) && !empty($BI["\150\x74\x74\160\72\x2f\57\x77\x77\167\56\x77\63\x2e\x6f\x72\x67\x2f\124\x52\x2f\61\x39\x39\71\57\122\105\103\55\170\x70\141\x74\150\55\61\x39\x39\71\x31\x31\x31\66"]["\161\165\x65\162\x79"])) {
                goto W8;
            }
            $ks->setAttribute("\101\154\147\157\162\x69\164\x68\155", $BI);
            goto yy;
            W8:
            $ks->setAttribute("\x41\x6c\x67\x6f\162\151\x74\x68\x6d", "\x68\164\x74\160\x3a\57\x2f\x77\x77\167\56\167\x33\56\157\162\x67\57\124\x52\x2f\61\71\71\71\57\122\x45\x43\55\x78\160\x61\164\x68\x2d\x31\x39\x39\x39\61\61\61\66");
            $tj = $this->createNewSignNode("\130\x50\x61\164\x68", $BI["\150\x74\164\x70\72\57\57\167\x77\167\x2e\167\x33\x2e\157\x72\x67\x2f\x54\122\57\61\71\71\71\57\122\105\x43\55\170\x70\141\164\x68\x2d\61\71\x39\71\61\x31\61\66"]["\x71\x75\x65\162\171"]);
            $ks->appendChild($tj);
            if (empty($BI["\x68\x74\x74\x70\72\x2f\57\x77\x77\x77\56\x77\63\x2e\157\x72\x67\x2f\124\122\x2f\61\x39\x39\71\57\122\x45\x43\55\x78\x70\141\x74\x68\x2d\61\x39\71\x39\x31\61\x31\x36"]["\156\x61\x6d\x65\x73\x70\141\x63\x65\163"])) {
                goto my;
            }
            foreach ($BI["\x68\164\x74\x70\x3a\x2f\57\x77\x77\x77\56\x77\x33\56\x6f\162\x67\57\x54\122\x2f\x31\71\x39\x39\57\122\105\103\55\170\x70\x61\164\150\55\x31\x39\x39\x39\61\x31\x31\x36"]["\156\141\x6d\145\163\160\141\143\145\163"] as $LP => $sO) {
                $tj->setAttributeNS("\150\x74\x74\160\72\57\57\167\167\x77\56\167\63\x2e\x6f\x72\x67\x2f\x32\x30\x30\60\57\x78\155\154\x6e\163\57", "\170\x6d\154\x6e\163\x3a{$LP}", $sO);
                gV:
            }
            Sc:
            my:
            yy:
            MF:
        }
        lV:
        goto tg;
        Lv:
        $ks = $this->createNewSignNode("\x54\162\x61\x6e\x73\146\157\162\155");
        $l4->appendChild($ks);
        $ks->setAttribute("\x41\154\147\x6f\x72\x69\x74\150\155", $this->canonicalMethod);
        tg:
        $Dn = $this->processTransforms($tg, $aB);
        $Xw = $this->calculateDigest($N9, $Dn);
        $b2 = $this->createNewSignNode("\104\151\147\145\x73\164\115\145\164\150\x6f\144");
        $tg->appendChild($b2);
        $b2->setAttribute("\x41\154\147\x6f\162\x69\164\x68\155", $N9);
        $ta = $this->createNewSignNode("\104\151\x67\145\163\164\x56\141\154\165\x65", $Xw);
        $tg->appendChild($ta);
    }
    public function addReference($aB, $N9, $OE = null, $OX = null)
    {
        if (!($Ne = $this->getXPathObj())) {
            goto mP;
        }
        $XK = "\x2e\57\x73\145\143\144\x73\x69\x67\72\x53\151\x67\x6e\x65\x64\111\x6e\146\x6f";
        $gD = $Ne->query($XK, $this->sigNode);
        if (!($sb = $gD->item(0))) {
            goto ev;
        }
        $this->addRefInternal($sb, $aB, $N9, $OE, $OX);
        ev:
        mP:
    }
    public function addReferenceList($CI, $N9, $OE = null, $OX = null)
    {
        if (!($Ne = $this->getXPathObj())) {
            goto zD;
        }
        $XK = "\56\57\x73\x65\x63\x64\163\x69\147\x3a\123\151\147\x6e\x65\x64\111\156\146\x6f";
        $gD = $Ne->query($XK, $this->sigNode);
        if (!($sb = $gD->item(0))) {
            goto Ig;
        }
        foreach ($CI as $aB) {
            $this->addRefInternal($sb, $aB, $N9, $OE, $OX);
            h2:
        }
        j_:
        Ig:
        zD:
    }
    public function addObject($FA, $vz = null, $gK = null)
    {
        $dM = $this->createNewSignNode("\117\x62\x6a\x65\x63\x74");
        $this->sigNode->appendChild($dM);
        if (empty($vz)) {
            goto oK;
        }
        $dM->setAttribute("\115\x69\x6d\145\124\171\160\145", $vz);
        oK:
        if (empty($gK)) {
            goto ty;
        }
        $dM->setAttribute("\105\156\143\x6f\144\x69\156\x67", $gK);
        ty:
        if ($FA instanceof DOMElement) {
            goto J_;
        }
        $TC = $this->sigNode->ownerDocument->createTextNode($FA);
        goto M8;
        J_:
        $TC = $this->sigNode->ownerDocument->importNode($FA, true);
        M8:
        $dM->appendChild($TC);
        return $dM;
    }
    public function locateKey($aB = null)
    {
        if (!empty($aB)) {
            goto tj;
        }
        $aB = $this->sigNode;
        tj:
        if ($aB instanceof DOMNode) {
            goto PU;
        }
        return null;
        PU:
        if (!($o7 = $aB->ownerDocument)) {
            goto jN;
        }
        $Ne = new DOMXPath($o7);
        $Ne->registerNamespace("\163\145\143\x64\x73\x69\147", self::XMLDSIGNS);
        $XK = "\x73\164\162\x69\156\147\50\x2e\x2f\163\145\x63\144\x73\x69\147\x3a\x53\x69\x67\x6e\145\x64\x49\x6e\x66\x6f\57\x73\145\x63\144\x73\x69\147\72\x53\x69\147\x6e\x61\x74\x75\162\x65\x4d\145\164\150\x6f\144\x2f\100\101\154\147\157\162\151\x74\x68\x6d\51";
        $N9 = $Ne->evaluate($XK, $aB);
        if (!$N9) {
            goto cs;
        }
        try {
            $lP = new XMLSecurityKey($N9, array("\164\x79\x70\145" => "\x70\x75\x62\154\151\x63"));
        } catch (Exception $L7) {
            return null;
        }
        return $lP;
        cs:
        jN:
        return null;
    }
    public function verify($lP)
    {
        $o7 = $this->sigNode->ownerDocument;
        $Ne = new DOMXPath($o7);
        $Ne->registerNamespace("\163\x65\143\x64\x73\x69\x67", self::XMLDSIGNS);
        $XK = "\x73\164\162\x69\x6e\147\x28\x2e\x2f\163\x65\143\x64\163\151\x67\x3a\123\x69\147\x6e\x61\164\165\x72\x65\126\x61\x6c\165\145\x29";
        $SL = $Ne->evaluate($XK, $this->sigNode);
        if (!empty($SL)) {
            goto Cy;
        }
        throw new Exception("\x55\x6e\x61\x62\x6c\145\40\164\x6f\40\154\x6f\x63\x61\x74\x65\x20\123\x69\147\x6e\141\x74\165\x72\145\x56\x61\154\165\145");
        Cy:
        return $lP->verifySignature($this->signedInfo, base64_decode($SL));
    }
    public function signData($lP, $FA)
    {
        return $lP->signData($FA);
    }
    public function sign($lP, $x1 = null)
    {
        if (!($x1 != null)) {
            goto FP;
        }
        $this->resetXPathObj();
        $this->appendSignature($x1);
        $this->sigNode = $x1->lastChild;
        FP:
        if (!($Ne = $this->getXPathObj())) {
            goto lh;
        }
        $XK = "\56\x2f\x73\145\143\x64\163\x69\x67\72\123\x69\147\156\145\144\111\x6e\146\157";
        $gD = $Ne->query($XK, $this->sigNode);
        if (!($sb = $gD->item(0))) {
            goto qU;
        }
        $XK = "\x2e\57\163\x65\143\144\163\151\x67\x3a\x53\x69\x67\x6e\x61\164\x75\x72\x65\115\145\164\x68\x6f\144";
        $gD = $Ne->query($XK, $sb);
        $E1 = $gD->item(0);
        $E1->setAttribute("\x41\x6c\x67\157\162\x69\x74\x68\155", $lP->type);
        $FA = $this->canonicalizeData($sb, $this->canonicalMethod);
        $SL = base64_encode($this->signData($lP, $FA));
        $MA = $this->createNewSignNode("\123\151\147\x6e\141\x74\165\x72\145\126\x61\154\165\145", $SL);
        if ($Sr = $sb->nextSibling) {
            goto U1;
        }
        $this->sigNode->appendChild($MA);
        goto H0;
        U1:
        $Sr->parentNode->insertBefore($MA, $Sr);
        H0:
        qU:
        lh:
    }
    public function appendCert()
    {
    }
    public function appendKey($lP, $uu = null)
    {
        $lP->serializeKey($uu);
    }
    public function insertSignature($aB, $xE = null)
    {
        $CP = $aB->ownerDocument;
        $ar = $CP->importNode($this->sigNode, true);
        if ($xE == null) {
            goto yH;
        }
        return $aB->insertBefore($ar, $xE);
        goto rc;
        yH:
        return $aB->insertBefore($ar);
        rc:
    }
    public function appendSignature($HI, $Mq = false)
    {
        $xE = $Mq ? $HI->firstChild : null;
        return $this->insertSignature($HI, $xE);
    }
    public static function get509XCert($Pd, $hx = true)
    {
        $aM = self::staticGet509XCerts($Pd, $hx);
        if (empty($aM)) {
            goto GM;
        }
        return $aM[0];
        GM:
        return '';
    }
    public static function staticGet509XCerts($aM, $hx = true)
    {
        if ($hx) {
            goto Me;
        }
        return array($aM);
        goto Kg;
        Me:
        $FA = '';
        $NO = array();
        $hU = explode("\12", $aM);
        $HD = false;
        foreach ($hU as $zX) {
            if (!$HD) {
                goto jA;
            }
            if (!(strncmp($zX, "\55\55\55\55\55\105\116\x44\x20\x43\105\122\x54\x49\x46\x49\103\101\124\x45", 20) == 0)) {
                goto xO;
            }
            $HD = false;
            $NO[] = $FA;
            $FA = '';
            goto Sg;
            xO:
            $FA .= trim($zX);
            goto aa;
            jA:
            if (!(strncmp($zX, "\x2d\x2d\x2d\55\55\x42\105\107\111\116\40\103\105\x52\x54\x49\x46\x49\103\x41\x54\105", 22) == 0)) {
                goto W5;
            }
            $HD = true;
            W5:
            aa:
            Sg:
        }
        ue:
        return $NO;
        Kg:
    }
    public static function staticAdd509Cert($yD, $Pd, $hx = true, $Hg = false, $Ne = null, $OX = null)
    {
        if (!$Hg) {
            goto YB;
        }
        $Pd = file_get_contents($Pd);
        YB:
        if ($yD instanceof DOMElement) {
            goto Cp;
        }
        throw new Exception("\x49\x6e\x76\x61\154\151\x64\40\x70\141\x72\x65\x6e\164\40\116\157\x64\x65\x20\160\141\x72\141\x6d\x65\164\x65\x72");
        Cp:
        $eA = $yD->ownerDocument;
        if (!empty($Ne)) {
            goto j3;
        }
        $Ne = new DOMXPath($yD->ownerDocument);
        $Ne->registerNamespace("\x73\x65\x63\x64\163\x69\x67", self::XMLDSIGNS);
        j3:
        $XK = "\56\57\x73\x65\x63\x64\x73\151\x67\72\x4b\x65\171\x49\156\x66\157";
        $gD = $Ne->query($XK, $yD);
        $LN = $gD->item(0);
        $Iw = '';
        if (!$LN) {
            goto Qc;
        }
        $Fd = $LN->lookupPrefix(self::XMLDSIGNS);
        if (empty($Fd)) {
            goto BY;
        }
        $Iw = $Fd . "\x3a";
        BY:
        goto Kv;
        Qc:
        $Fd = $yD->lookupPrefix(self::XMLDSIGNS);
        if (empty($Fd)) {
            goto RC;
        }
        $Iw = $Fd . "\x3a";
        RC:
        $eG = false;
        $LN = $eA->createElementNS(self::XMLDSIGNS, $Iw . "\113\x65\x79\111\x6e\146\157");
        $XK = "\x2e\57\163\145\143\144\x73\x69\147\x3a\117\142\152\145\x63\x74";
        $gD = $Ne->query($XK, $yD);
        if (!($HN = $gD->item(0))) {
            goto M5;
        }
        $HN->parentNode->insertBefore($LN, $HN);
        $eG = true;
        M5:
        if ($eG) {
            goto wg;
        }
        $yD->appendChild($LN);
        wg:
        Kv:
        $aM = self::staticGet509XCerts($Pd, $hx);
        $E7 = $eA->createElementNS(self::XMLDSIGNS, $Iw . "\x58\x35\x30\71\104\x61\164\x61");
        $LN->appendChild($E7);
        $dd = false;
        $to = false;
        if (!is_array($OX)) {
            goto Pe;
        }
        if (empty($OX["\151\163\x73\x75\x65\162\123\x65\162\151\x61\x6c"])) {
            goto ay;
        }
        $dd = true;
        ay:
        if (empty($OX["\x73\x75\x62\x6a\x65\143\x74\116\141\x6d\x65"])) {
            goto aE;
        }
        $to = true;
        aE:
        Pe:
        foreach ($aM as $sr) {
            if (!($dd || $to)) {
                goto w_;
            }
            if (!($YH = openssl_x509_parse("\x2d\x2d\x2d\55\x2d\x42\x45\x47\x49\x4e\x20\x43\105\x52\124\111\106\x49\103\101\124\105\55\x2d\55\x2d\x2d\xa" . chunk_split($sr, 64, "\12") . "\x2d\x2d\55\x2d\x2d\x45\116\x44\40\x43\105\x52\124\111\x46\111\103\x41\x54\x45\x2d\x2d\55\x2d\55\12"))) {
                goto S4;
            }
            if (!($to && !empty($YH["\x73\x75\142\152\145\143\164"]))) {
                goto gq;
            }
            if (is_array($YH["\163\165\x62\152\145\143\164"])) {
                goto gC;
            }
            $Ez = $YH["\151\163\x73\165\x65\x72"];
            goto Ap;
            gC:
            $f8 = array();
            foreach ($YH["\163\x75\x62\152\145\x63\x74"] as $YX => $yS) {
                if (is_array($yS)) {
                    goto al;
                }
                array_unshift($f8, "{$YX}\x3d{$yS}");
                goto eG;
                al:
                foreach ($yS as $QJ) {
                    array_unshift($f8, "{$YX}\x3d{$QJ}");
                    I8:
                }
                OC:
                eG:
                vp:
            }
            HS:
            $Ez = implode("\54", $f8);
            Ap:
            $BF = $eA->createElementNS(self::XMLDSIGNS, $Iw . "\x58\65\x30\71\123\165\x62\152\145\x63\164\116\141\155\x65", $Ez);
            $E7->appendChild($BF);
            gq:
            if (!($dd && !empty($YH["\151\x73\x73\x75\145\x72"]) && !empty($YH["\x73\x65\x72\x69\x61\154\x4e\x75\x6d\x62\145\162"]))) {
                goto Ma;
            }
            if (is_array($YH["\151\163\163\x75\x65\162"])) {
                goto Hw;
            }
            $tc = $YH["\151\163\x73\165\x65\162"];
            goto ki;
            Hw:
            $f8 = array();
            foreach ($YH["\151\163\163\x75\x65\162"] as $YX => $yS) {
                array_unshift($f8, "{$YX}\x3d{$yS}");
                tw:
            }
            RO:
            $tc = implode("\x2c", $f8);
            ki:
            $vC = $eA->createElementNS(self::XMLDSIGNS, $Iw . "\x58\x35\60\x39\111\x73\163\165\x65\162\x53\145\x72\x69\x61\154");
            $E7->appendChild($vC);
            $ro = $eA->createElementNS(self::XMLDSIGNS, $Iw . "\x58\x35\x30\71\x49\x73\163\x75\x65\x72\x4e\x61\x6d\145", $tc);
            $vC->appendChild($ro);
            $ro = $eA->createElementNS(self::XMLDSIGNS, $Iw . "\x58\x35\60\71\x53\x65\x72\151\x61\x6c\116\x75\155\x62\x65\x72", $YH["\163\145\x72\x69\141\x6c\x4e\165\155\142\145\162"]);
            $vC->appendChild($ro);
            Ma:
            S4:
            w_:
            $wq = $eA->createElementNS(self::XMLDSIGNS, $Iw . "\x58\65\x30\71\103\145\x72\x74\x69\x66\x69\x63\x61\164\145", $sr);
            $E7->appendChild($wq);
            sb:
        }
        A0:
    }
    public function add509Cert($Pd, $hx = true, $Hg = false, $OX = null)
    {
        if (!($Ne = $this->getXPathObj())) {
            goto dx;
        }
        self::staticAdd509Cert($this->sigNode, $Pd, $hx, $Hg, $Ne, $OX);
        dx:
    }
    public function appendToKeyInfo($aB)
    {
        $yD = $this->sigNode;
        $eA = $yD->ownerDocument;
        $Ne = $this->getXPathObj();
        if (!empty($Ne)) {
            goto eg;
        }
        $Ne = new DOMXPath($yD->ownerDocument);
        $Ne->registerNamespace("\x73\145\x63\144\163\x69\147", self::XMLDSIGNS);
        eg:
        $XK = "\x2e\x2f\x73\x65\143\x64\x73\x69\x67\72\x4b\145\x79\x49\x6e\146\x6f";
        $gD = $Ne->query($XK, $yD);
        $LN = $gD->item(0);
        if ($LN) {
            goto Ug;
        }
        $Iw = '';
        $Fd = $yD->lookupPrefix(self::XMLDSIGNS);
        if (empty($Fd)) {
            goto SC;
        }
        $Iw = $Fd . "\x3a";
        SC:
        $eG = false;
        $LN = $eA->createElementNS(self::XMLDSIGNS, $Iw . "\113\x65\171\x49\x6e\146\x6f");
        $XK = "\56\x2f\163\x65\x63\x64\163\151\x67\72\x4f\x62\152\x65\x63\x74";
        $gD = $Ne->query($XK, $yD);
        if (!($HN = $gD->item(0))) {
            goto nP;
        }
        $HN->parentNode->insertBefore($LN, $HN);
        $eG = true;
        nP:
        if ($eG) {
            goto tV;
        }
        $yD->appendChild($LN);
        tV:
        Ug:
        $LN->appendChild($aB);
        return $LN;
    }
    public function getValidatedNodes()
    {
        return $this->validatedNodes;
    }
}
