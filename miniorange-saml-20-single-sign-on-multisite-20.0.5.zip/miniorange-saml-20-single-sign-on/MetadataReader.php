<?php


include_once "\x55\164\151\x6c\x69\x74\151\145\x73\56\160\x68\x70";
class MetadataReader
{
    private $identityProviders;
    private $serviceProviders;
    public function __construct(DOMNode $Pk = NULL)
    {
        $this->identityProviders = array();
        $this->serviceProviders = array();
        $wg = Utilities::xpQuery($Pk, "\x2e\x2f\163\141\x6d\x6c\x5f\x6d\x65\164\141\x64\141\x74\x61\72\x45\156\164\151\164\x69\x65\x73\x44\x65\163\x63\x72\151\x70\164\x6f\x72");
        if (!empty($wg)) {
            goto pW;
        }
        $Hf = Utilities::xpQuery($Pk, "\56\57\x73\141\155\154\x5f\x6d\145\x74\x61\144\x61\164\x61\72\105\156\164\151\164\171\x44\x65\163\143\x72\151\x70\164\157\x72");
        goto T8;
        pW:
        $Hf = Utilities::xpQuery($wg[0], "\56\x2f\163\141\155\x6c\137\155\145\x74\141\144\x61\x74\x61\x3a\x45\156\x74\x69\x74\171\x44\145\x73\143\x72\x69\x70\x74\x6f\162");
        T8:
        foreach ($Hf as $uS) {
            $xX = Utilities::xpQuery($uS, "\x2e\x2f\x73\141\155\154\137\155\x65\164\x61\144\141\164\141\x3a\x49\x44\120\123\123\117\x44\145\x73\x63\162\151\160\164\157\x72");
            if (!(isset($xX) && !empty($xX))) {
                goto G1;
            }
            array_push($this->identityProviders, new IdentityProviders($uS));
            G1:
            jq:
        }
        R8:
    }
    public function getIdentityProviders()
    {
        return $this->identityProviders;
    }
    public function getServiceProviders()
    {
        return $this->serviceProviders;
    }
}
class IdentityProviders
{
    private $idpName;
    private $entityID;
    private $loginDetails;
    private $logoutDetails;
    private $signingCertificate;
    private $encryptionCertificate;
    private $signedRequest;
    private $loginbinding;
    private $logoutbinding;
    public function __construct(DOMElement $Pk = NULL)
    {
        $this->idpName = '';
        $this->loginDetails = array();
        $this->logoutDetails = array();
        $this->signingCertificate = array();
        $this->encryptionCertificate = array();
        if (!$Pk->hasAttribute("\x65\156\164\151\x74\x79\x49\104")) {
            goto tf;
        }
        $this->entityID = $Pk->getAttribute("\145\x6e\x74\151\164\x79\111\x44");
        tf:
        if (!$Pk->hasAttribute("\x57\141\x6e\x74\x41\165\164\x68\x6e\x52\x65\x71\x75\x65\x73\164\163\x53\151\147\156\145\x64")) {
            goto Oy;
        }
        $this->signedRequest = $Pk->getAttribute("\127\x61\x6e\164\x41\165\164\x68\x6e\x52\145\161\165\x65\163\x74\163\123\x69\147\156\145\144");
        Oy:
        $xX = Utilities::xpQuery($Pk, "\56\x2f\163\141\155\154\137\x6d\145\x74\141\144\x61\164\141\x3a\111\x44\120\x53\x53\117\x44\145\x73\x63\162\151\x70\164\x6f\x72");
        if (count($xX) > 1) {
            goto vL;
        }
        if (empty($xX)) {
            goto TX;
        }
        goto LL;
        vL:
        throw new Exception("\x4d\x6f\162\x65\x20\x74\x68\x61\x6e\40\157\x6e\145\40\x3c\x49\104\120\x53\123\117\104\x65\163\143\x72\x69\x70\164\157\x72\76\40\x69\156\x20\x3c\105\156\x74\x69\x74\171\104\145\163\x63\162\151\160\x74\157\x72\76\56");
        goto LL;
        TX:
        throw new Exception("\115\151\163\163\x69\x6e\x67\x20\x72\145\161\165\151\x72\x65\144\x20\74\x49\x44\120\123\x53\117\104\145\163\x63\162\x69\160\x74\157\x72\76\x20\x69\156\40\x3c\105\x6e\164\151\164\171\104\x65\x73\x63\x72\151\x70\x74\157\x72\x3e\x2e");
        LL:
        $xg = $xX[0];
        $ML = Utilities::xpQuery($Pk, "\56\x2f\x73\x61\x6d\x6c\137\x6d\x65\164\x61\x64\x61\x74\141\72\x45\170\x74\145\156\x73\151\x6f\156\163");
        if (!$ML) {
            goto PA;
        }
        $this->parseInfo($xg);
        PA:
        $this->parseSSOService($xg);
        $this->parseSLOService($xg);
        $this->parsex509Certificate($xg);
    }
    private function parseInfo($Pk)
    {
        $ZI = Utilities::xpQuery($Pk, "\x2e\57\155\144\165\151\72\125\111\111\156\146\x6f\x2f\x6d\x64\165\151\72\104\151\x73\160\154\x61\x79\x4e\x61\155\x65");
        foreach ($ZI as $GN) {
            if (!($GN->hasAttribute("\x78\155\154\72\x6c\x61\x6e\147") && $GN->getAttribute("\x78\155\x6c\x3a\x6c\x61\156\x67") == "\x65\x6e")) {
                goto ur;
            }
            $this->idpName = $GN->textContent;
            ur:
            Rk:
        }
        JM:
    }
    private function parseSSOService($Pk)
    {
        $Zs = Utilities::xpQuery($Pk, "\x2e\x2f\x73\x61\155\154\137\x6d\145\x74\x61\144\x61\164\x61\x3a\123\151\156\x67\x6c\145\x53\x69\x67\x6e\x4f\156\123\x65\162\x76\x69\x63\145");
        $vc = 0;
        foreach ($Zs as $pY) {
            $kq = str_replace("\165\162\x6e\72\x6f\141\x73\151\x73\x3a\x6e\141\155\145\x73\x3a\x74\143\72\x53\101\115\x4c\72\x32\56\60\72\x62\x69\156\144\151\156\x67\163\72", '', $pY->getAttribute("\x42\151\x6e\144\x69\156\x67"));
            $this->loginDetails = array_merge($this->loginDetails, array($kq => $pY->getAttribute("\114\157\143\x61\x74\151\x6f\x6e")));
            if (!($kq == "\110\x54\x54\x50\55\122\x65\144\151\162\145\x63\x74")) {
                goto Ih;
            }
            $vc = 1;
            $this->loginbinding = "\110\164\x74\x70\122\145\144\x69\x72\x65\x63\164";
            Ih:
            ll:
        }
        Vj:
        if ($vc) {
            goto wX;
        }
        $this->loginbinding = "\x48\164\x74\160\x50\157\x73\164";
        wX:
    }
    private function parseSLOService($Pk)
    {
        $vc = 0;
        $xm = Utilities::xpQuery($Pk, "\56\57\x73\141\155\x6c\137\155\145\164\x61\x64\x61\x74\x61\72\x53\x69\156\147\154\145\114\157\147\157\165\x74\123\x65\162\166\x69\143\x65");
        foreach ($xm as $rG) {
            $kq = str_replace("\165\x72\156\72\x6f\141\x73\151\163\x3a\156\x61\155\145\x73\72\164\x63\72\123\101\x4d\114\x3a\62\56\x30\72\x62\x69\156\144\x69\x6e\147\x73\72", '', $rG->getAttribute("\102\x69\156\144\151\x6e\147"));
            $this->logoutDetails = array_merge($this->logoutDetails, array($kq => $rG->getAttribute("\x4c\x6f\143\141\x74\151\x6f\x6e")));
            if (!($kq == "\x48\124\124\120\x2d\x52\145\x64\151\x72\x65\x63\164")) {
                goto lc;
            }
            $vc = 1;
            $this->logoutbinding = "\x48\164\x74\160\122\x65\x64\151\162\x65\143\x74";
            lc:
            Gm:
        }
        vg:
        if (!empty($this->logoutbinding)) {
            goto ak;
        }
        $this->logoutbinding = "\x48\164\164\160\x50\157\163\x74";
        ak:
    }
    private function parsex509Certificate($Pk)
    {
        foreach (Utilities::xpQuery($Pk, "\56\x2f\163\x61\x6d\x6c\137\x6d\x65\164\x61\x64\141\164\141\72\x4b\x65\x79\x44\145\x73\143\x72\151\x70\x74\x6f\162") as $Al) {
            if ($Al->hasAttribute("\x75\x73\x65")) {
                goto fc;
            }
            $this->parseSigningCertificate($Al);
            goto t5;
            fc:
            if ($Al->getAttribute("\x75\163\145") == "\x65\x6e\143\162\x79\160\164\151\157\x6e") {
                goto WN;
            }
            $this->parseSigningCertificate($Al);
            goto Br;
            WN:
            $this->parseEncryptionCertificate($Al);
            Br:
            t5:
            dt:
        }
        kk:
    }
    private function parseSigningCertificate($Pk)
    {
        $F9 = Utilities::xpQuery($Pk, "\56\x2f\144\x73\x3a\113\145\171\x49\x6e\146\x6f\x2f\144\163\x3a\x58\x35\x30\x39\104\x61\x74\141\57\144\x73\x3a\x58\65\x30\x39\103\x65\162\x74\x69\146\x69\143\x61\x74\x65");
        $YH = trim($F9[0]->textContent);
        $YH = str_replace(array("\xd", "\12", "\x9", "\40"), '', $YH);
        if (empty($F9)) {
            goto V9;
        }
        array_push($this->signingCertificate, $YH);
        V9:
    }
    private function parseEncryptionCertificate($Pk)
    {
        $F9 = Utilities::xpQuery($Pk, "\x2e\x2f\144\163\x3a\113\x65\171\x49\x6e\146\x6f\57\x64\x73\x3a\x58\x35\x30\71\104\x61\x74\141\x2f\144\163\x3a\130\65\x30\71\103\145\x72\x74\x69\x66\x69\x63\x61\164\x65");
        $YH = trim($F9[0]->textContent);
        $YH = str_replace(array("\xd", "\12", "\11", "\40"), '', $YH);
        if (empty($F9)) {
            goto nK;
        }
        array_push($this->encryptionCertificate, $YH);
        nK:
    }
    public function getIdpName()
    {
        return $this->idpName;
    }
    public function getEntityID()
    {
        return $this->entityID;
    }
    public function getLoginURL($kq)
    {
        return $this->loginDetails[$kq];
    }
    public function getLogoutURL($kq)
    {
        return $this->logoutDetails[$kq];
    }
    public function getLoginDetails()
    {
        return $this->loginDetails;
    }
    public function getLogoutDetails()
    {
        return $this->logoutDetails;
    }
    public function getSigningCertificate()
    {
        return $this->signingCertificate;
    }
    public function getEncryptionCertificate()
    {
        return $this->encryptionCertificate[0];
    }
    public function isRequestSigned()
    {
        return $this->signedRequest;
    }
    public function getBindingLogin()
    {
        return $this->loginbinding;
    }
    public function getBindingLogout()
    {
        return $this->logoutbinding;
    }
}
class ServiceProviders
{
}
