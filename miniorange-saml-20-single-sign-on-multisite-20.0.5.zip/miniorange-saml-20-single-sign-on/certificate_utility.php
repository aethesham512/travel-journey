<?php


class CertificateUtility
{
    public static function generate_certificate($bg, $JK, $aK)
    {
        $wL = openssl_pkey_new();
        $HX = openssl_csr_new($bg, $wL, $JK);
        $oE = openssl_csr_sign($HX, null, $wL, $aK, $JK, time());
        openssl_csr_export($HX, $nr);
        openssl_x509_export($oE, $F_);
        openssl_pkey_export($wL, $n_);
        O4:
        if (!(($L7 = openssl_error_string()) !== false)) {
            goto Fa;
        }
        error_log("\x43\x65\162\x74\x69\x66\151\x63\141\164\145\x55\164\151\x6c\151\x74\x79\x3a\40\x45\162\x72\157\x72\40\147\145\x6e\145\162\x61\164\x69\x6e\147\40\143\145\162\x74\151\146\151\143\141\x74\145\56\40" . $L7);
        goto O4;
        Fa:
        $vb = array("\160\x75\142\x6c\x69\x63\x5f\153\x65\x79" => $F_, "\x70\162\151\x76\x61\164\x65\x5f\153\x65\x79" => $n_);
        return $vb;
    }
}
