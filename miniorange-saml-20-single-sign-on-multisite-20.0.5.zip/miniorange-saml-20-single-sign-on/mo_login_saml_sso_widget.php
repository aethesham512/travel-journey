<?php


include_once dirname(__FILE__) . "\x2f\x55\x74\151\154\151\x74\x69\145\163\56\160\150\160";
include_once dirname(__FILE__) . "\x2f\x52\145\163\160\x6f\156\163\x65\56\x70\x68\160";
include_once dirname(__FILE__) . "\x2f\x4c\157\147\x6f\x75\x74\x52\x65\x71\165\145\163\164\56\160\150\160";
require_once dirname(__FILE__) . "\57\151\156\x63\154\x75\144\x65\x73\x2f\154\151\x62\57\x65\x6e\143\x72\x79\x70\164\x69\157\156\56\160\x68\x70";
include_once "\170\x6d\x6c\163\x65\x63\x6c\x69\x62\x73\56\x70\x68\x70";
use RobRichards\XMLSecLibs\XMLSecurityKey;
use RobRichards\XMLSecLibs\XMLSecurityDSig;
use RobRichards\XMLSecLibs\XMLSecEnc;
class mo_login_wid extends WP_Widget
{
    public function __construct()
    {
        $uO = get_site_option("\x73\x61\155\154\137\151\144\145\156\164\x69\164\171\137\156\x61\x6d\x65");
        parent::__construct("\x53\x61\x6d\x6c\x5f\114\157\x67\x69\x6e\x5f\127\151\x64\147\145\x74", "\114\157\147\151\x6e\40\167\151\x74\x68\40" . $uO, array("\144\145\x73\x63\162\151\x70\164\151\x6f\156" => __("\124\150\151\x73\40\x69\163\x20\x61\x20\155\151\156\151\117\x72\x61\156\147\145\x20\123\101\x4d\x4c\40\x6c\x6f\x67\151\x6e\40\x77\151\144\147\145\x74\x2e", "\x6d\x6f\x73\x61\x6d\154")));
    }
    public function widget($d9, $nB)
    {
        extract($d9);
        $EN = apply_filters("\167\x69\144\x67\x65\x74\137\x74\151\x74\x6c\145", $nB["\167\x69\144\137\x74\x69\164\x6c\145"]);
        echo $d9["\x62\145\x66\157\162\x65\x5f\x77\151\x64\147\145\164"];
        if (empty($EN)) {
            goto C5;
        }
        echo $d9["\x62\145\x66\157\162\145\137\164\x69\x74\x6c\x65"] . $EN . $d9["\141\146\x74\x65\162\137\164\151\164\x6c\x65"];
        C5:
        $this->loginForm();
        echo $d9["\141\146\164\145\x72\x5f\167\x69\x64\147\x65\x74"];
    }
    public function update($WA, $xK)
    {
        $nB = array();
        $nB["\167\151\144\x5f\164\151\x74\x6c\x65"] = strip_tags($WA["\x77\151\x64\x5f\164\x69\164\x6c\x65"]);
        return $nB;
    }
    public function form($nB)
    {
        $EN = '';
        if (!array_key_exists("\167\151\144\x5f\164\151\x74\x6c\145", $nB)) {
            goto Vl;
        }
        $EN = $nB["\167\151\x64\x5f\x74\151\x74\x6c\145"];
        Vl:
        echo "\15\12\x9\11\74\160\x3e\74\x6c\141\142\x65\x6c\x20\146\157\x72\x3d\42" . $this->get_field_id("\x77\151\144\137\x74\x69\x74\x6c\145") . "\40\x22\76" . _e("\124\x69\164\x6c\x65\72") . "\x20\x3c\57\154\x61\x62\x65\154\x3e\xd\12\x9\11\x9\74\x69\x6e\160\x75\x74\x20\143\x6c\x61\163\163\x3d\42\x77\x69\144\x65\x66\x61\164\x22\x20\x69\x64\75\42" . $this->get_field_id("\x77\151\144\137\x74\151\164\x6c\x65") . "\42\x20\x6e\141\x6d\145\x3d\42" . $this->get_field_name("\x77\151\x64\x5f\x74\151\164\154\x65") . "\x22\40\164\x79\160\145\x3d\x22\x74\145\170\164\x22\x20\166\x61\154\x75\145\75\x22" . $EN . "\x22\40\x2f\76\xd\12\11\x9\x3c\x2f\160\76";
    }
    public function loginForm()
    {
        global $post;
        $dr = get_site_option("\x73\141\x6d\154\137\163\163\x6f\137\x73\145\164\164\151\156\147\163");
        $y1 = get_current_blog_id();
        $Uo = Utilities::get_active_sites();
        if (in_array($y1, $Uo)) {
            goto oU;
        }
        return;
        oU:
        if (!(empty($dr[$y1]) && !empty($dr["\104\x45\x46\x41\125\x4c\x54"]))) {
            goto pI;
        }
        $dr[$y1] = $dr["\x44\105\x46\x41\125\x4c\124"];
        pI:
        if (!is_user_logged_in()) {
            goto D5;
        }
        $current_user = wp_get_current_user();
        $CT = "\x48\x65\154\154\x6f\x2c";
        if (empty($dr[$y1]["\x6d\x6f\137\x73\141\x6d\154\137\143\165\163\164\x6f\155\137\147\x72\145\x65\x74\151\x6e\x67\137\164\145\170\164"])) {
            goto MJ;
        }
        $CT = $dr[$y1]["\155\x6f\x5f\x73\141\155\x6c\137\143\x75\x73\164\x6f\x6d\137\147\x72\x65\145\164\151\x6e\x67\x5f\x74\x65\170\x74"];
        MJ:
        $YP = '';
        if (empty($dr[$y1]["\155\x6f\137\163\141\x6d\154\137\147\162\x65\145\164\151\x6e\147\137\x6e\x61\155\145"])) {
            goto hb;
        }
        switch ($dr[$y1]["\x6d\157\137\163\x61\x6d\154\137\147\x72\145\145\164\151\x6e\x67\137\x6e\x61\155\145"]) {
            case "\x55\x53\x45\122\116\101\x4d\x45":
                $YP = $current_user->user_login;
                goto Ht;
            case "\105\x4d\101\111\x4c":
                $YP = $current_user->user_email;
                goto Ht;
            case "\106\x4e\x41\115\x45":
                $YP = $current_user->user_firstname;
                goto Ht;
            case "\x4c\116\x41\x4d\105":
                $YP = $current_user->user_lastname;
                goto Ht;
            case "\x46\x4e\101\115\105\137\114\116\101\x4d\x45":
                $YP = $current_user->user_firstname . "\40" . $current_user->user_lastname;
                goto Ht;
            case "\114\x4e\x41\x4d\x45\137\x46\116\x41\115\x45":
                $YP = $current_user->user_lastname . "\x20" . $current_user->user_firstname;
                goto Ht;
            default:
                $YP = $current_user->user_login;
        }
        Pv:
        Ht:
        hb:
        if (!empty(trim($YP))) {
            goto W6;
        }
        $YP = $current_user->user_login;
        W6:
        $a3 = $CT . "\40" . $YP;
        $y3 = "\114\x6f\147\157\x75\164";
        if (empty($dr[$y1]["\155\x6f\137\163\141\155\154\137\x63\165\163\x74\157\155\x5f\154\x6f\x67\x6f\165\x74\137\164\145\x78\x74"])) {
            goto xL;
        }
        $y3 = $dr[$y1]["\x6d\x6f\137\163\x61\x6d\154\137\143\165\163\164\157\x6d\x5f\154\x6f\147\x6f\x75\164\x5f\164\145\x78\x74"];
        xL:
        echo $a3 . "\40\174\x20\74\141\x20\150\162\x65\146\x3d\x22" . wp_logout_url(home_url()) . "\42\x20\164\151\164\x6c\145\75\42\154\157\147\x6f\x75\x74\42\40\76" . $y3 . "\74\x2f\141\x3e\74\57\154\x69\x3e";
        goto fS;
        D5:
        echo "\15\xa\x9\x9\11\74\x73\x63\162\x69\x70\x74\76\xd\xa\x9\x9\x9\x9\146\x75\x6e\143\x74\x69\157\156\40\163\165\x62\155\x69\164\x53\x61\x6d\154\x46\x6f\162\155\x28\x29\x7b\x20\x64\x6f\143\x75\x6d\x65\156\164\56\x67\x65\x74\x45\x6c\145\155\x65\156\164\102\x79\111\144\50\x22\x6c\157\147\x69\x6e\x22\51\56\x73\165\x62\x6d\151\x74\50\x29\x3b\x20\175\xd\12\11\x9\x9\x3c\x2f\163\x63\x72\151\160\x74\x3e\xd\xa\x9\x9\x9\74\146\157\162\x6d\x20\x6e\141\x6d\145\75\42\x6c\x6f\x67\x69\156\42\x20\x69\144\x3d\x22\154\157\147\151\x6e\x22\x20\x6d\x65\164\150\x6f\144\75\x22\160\157\163\x74\x22\40\141\x63\164\x69\157\x6e\75\x22\42\76\xd\xa\x9\x9\x9\11\74\x69\156\160\165\x74\x20\x74\x79\160\145\75\42\150\151\144\x64\145\x6e\42\x20\x6e\141\155\145\x3d\x22\157\x70\x74\151\157\x6e\42\40\x76\141\154\x75\x65\x3d\42\x73\x61\x6d\154\x5f\x75\x73\145\162\137\x6c\157\147\151\x6e\x22\40\57\76\xd\12\15\xa\11\x9\x9\11\x3c\146\157\x6e\x74\40\x73\x69\x7a\x65\x3d\42\53\x31\42\x20\x73\x74\171\x6c\x65\x3d\x22\x76\x65\162\x74\151\x63\141\154\55\141\154\x69\x67\156\x3a\164\x6f\160\73\42\x3e\x20\x3c\x2f\x66\x6f\156\x74\76";
        $Yy = get_site_option("\x73\141\x6d\x6c\x5f\x69\x64\x65\x6e\164\151\164\x79\137\156\141\155\145");
        $Zx = get_site_option("\x73\141\x6d\x6c\137\170\x35\60\x39\137\143\145\162\164\x69\146\151\143\x61\164\145");
        if (!empty($Yy) && !empty($Zx)) {
            goto zi;
        }
        echo "\120\154\145\x61\x73\x65\40\x63\x6f\x6e\146\x69\147\165\162\145\x20\164\150\145\40\155\x69\x6e\x69\x4f\162\x61\156\147\x65\40\x53\x41\115\x4c\40\x50\154\x75\147\151\156\x20\x66\x69\162\x73\x74\56";
        goto Ln;
        zi:
        $Of = "\x4c\x6f\147\151\156\40\167\x69\x74\x68\x20\43\x23\x49\104\x50\x23\x23";
        if (empty($dr[$y1]["\155\x6f\x5f\163\x61\x6d\x6c\137\143\165\163\164\157\155\x5f\154\157\147\151\156\x5f\x74\x65\170\164"])) {
            goto Ou;
        }
        $Of = $dr[$y1]["\x6d\x6f\137\x73\141\155\154\137\143\x75\163\x74\157\155\137\x6c\x6f\x67\151\156\x5f\164\x65\170\164"];
        Ou:
        $Of = str_replace("\43\43\111\x44\x50\x23\x23", $Yy, $Of);
        $lu = false;
        if (!(isset($dr[$y1]["\155\157\x5f\163\x61\x6d\x6c\137\x75\163\x65\x5f\142\165\x74\x74\x6f\156\x5f\141\x73\137\167\x69\x64\147\x65\x74"]) && $dr[$y1]["\x6d\x6f\x5f\x73\141\x6d\154\x5f\165\x73\x65\x5f\142\165\164\164\x6f\156\137\x61\x73\137\167\x69\144\147\x65\x74"] == "\164\x72\165\x65")) {
            goto kL;
        }
        $lu = true;
        kL:
        if (!$lu) {
            goto Y5;
        }
        $ZC = isset($dr[$y1]["\155\157\x5f\163\141\155\154\137\142\165\x74\x74\157\156\137\x77\151\144\164\x68"]) ? $dr[$y1]["\x6d\x6f\137\x73\141\x6d\x6c\137\142\165\164\x74\157\x6e\x5f\x77\x69\144\x74\150"] : "\x31\60\x30";
        $xU = isset($dr[$y1]["\155\157\137\x73\141\155\154\137\x62\x75\164\164\157\x6e\137\x68\145\151\x67\150\x74"]) ? $dr[$y1]["\155\x6f\x5f\x73\141\155\x6c\137\142\x75\164\164\157\x6e\x5f\150\145\151\x67\x68\164"] : "\x35\60";
        $QX = isset($dr[$y1]["\x6d\x6f\137\x73\141\x6d\154\x5f\x62\165\x74\x74\x6f\156\x5f\x73\151\x7a\x65"]) ? $dr[$y1]["\155\x6f\137\x73\141\x6d\154\137\x62\165\x74\x74\x6f\156\x5f\x73\151\172\x65"] : "\x35\x30";
        $K3 = isset($dr[$y1]["\x6d\157\137\x73\x61\x6d\154\137\142\x75\x74\x74\x6f\x6e\137\x63\x75\x72\166\x65"]) ? $dr[$y1]["\155\x6f\x5f\x73\x61\155\x6c\x5f\142\x75\164\164\157\156\137\x63\165\162\x76\145"] : "\x35";
        $fY = isset($dr[$y1]["\155\157\137\163\x61\155\154\137\142\165\x74\x74\157\156\137\x63\157\154\157\x72"]) ? $dr[$y1]["\x6d\157\137\163\141\x6d\x6c\137\x62\x75\x74\164\157\156\137\143\x6f\x6c\x6f\162"] : "\60\x30\x38\65\142\141";
        $X4 = isset($dr[$y1]["\x6d\x6f\x5f\163\x61\x6d\154\137\x62\x75\x74\164\x6f\156\x5f\x74\x68\x65\x6d\145"]) ? $dr[$y1]["\x6d\x6f\137\163\x61\155\x6c\x5f\142\165\x74\164\x6f\x6e\x5f\164\x68\145\x6d\145"] : "\x6c\x6f\x6e\147\x62\165\x74\164\x6f\x6e";
        $QR = isset($dr[$y1]["\x6d\x6f\137\x73\141\x6d\154\137\x62\165\164\x74\x6f\156\137\x74\x65\x78\x74"]) ? $dr[$y1]["\155\x6f\137\163\x61\155\154\x5f\142\165\164\x74\x6f\156\137\164\x65\170\x74"] : (get_site_option("\163\x61\155\154\x5f\x69\x64\145\x6e\164\x69\x74\x79\x5f\x6e\141\x6d\145") ? get_site_option("\x73\x61\155\154\x5f\x69\144\x65\156\164\151\164\x79\x5f\156\x61\155\x65") : "\114\157\x67\x69\x6e");
        $wT = isset($dr[$y1]["\x6d\157\x5f\x73\x61\x6d\x6c\137\x66\x6f\156\164\x5f\x63\x6f\x6c\157\162"]) ? $dr[$y1]["\155\157\x5f\x73\141\155\154\137\146\x6f\x6e\x74\x5f\x63\x6f\154\157\162"] : "\146\146\146\146\x66\146";
        $B6 = isset($dr[$y1]["\x6d\x6f\x5f\163\141\155\x6c\x5f\x66\x6f\x6e\x74\x5f\163\151\x7a\145"]) ? $dr[$y1]["\155\157\137\163\141\x6d\x6c\x5f\146\x6f\156\164\137\163\x69\x7a\145"] : "\x32\x30";
        $Jp = isset($dr[$y1]["\x73\163\157\x5f\142\x75\164\x74\157\156\137\154\157\147\151\156\x5f\146\x6f\162\155\x5f\x70\x6f\163\x69\x74\151\x6f\156"]) ? $dr[$y1]["\163\x73\157\137\x62\165\164\164\157\x6e\x5f\154\157\x67\151\156\x5f\x66\x6f\x72\155\137\x70\x6f\x73\x69\x74\x69\x6f\x6e"] : "\x61\x62\x6f\166\145";
        $Of = "\74\151\x6e\160\x75\x74\40\x74\x79\160\145\75\x22\142\165\164\x74\157\156\42\40\156\x61\155\145\75\42\x6d\x6f\137\163\141\155\154\x5f\167\x70\x5f\163\163\157\x5f\142\165\x74\x74\157\156\x22\40\166\x61\154\x75\x65\x3d\42" . $QR . "\x22\x20\x73\164\171\x6c\145\x3d\x22";
        $Ls = '';
        if ($X4 == "\154\157\x6e\147\x62\165\164\x74\x6f\156") {
            goto KI;
        }
        if ($X4 == "\x63\151\x72\143\154\145") {
            goto A_;
        }
        if ($X4 == "\157\166\141\154") {
            goto pQ;
        }
        if ($X4 == "\x73\x71\165\141\162\145") {
            goto JF;
        }
        goto D1;
        A_:
        $Ls = $Ls . "\x77\x69\144\x74\150\x3a" . $QX . "\160\170\73";
        $Ls = $Ls . "\150\x65\x69\147\x68\164\x3a" . $QX . "\160\170\x3b";
        $Ls = $Ls . "\142\157\x72\x64\x65\x72\x2d\x72\141\144\151\x75\x73\x3a\71\71\71\x70\x78\73";
        goto D1;
        pQ:
        $Ls = $Ls . "\167\x69\x64\x74\x68\72" . $QX . "\160\x78\x3b";
        $Ls = $Ls . "\150\x65\x69\147\150\164\x3a" . $QX . "\160\170\x3b";
        $Ls = $Ls . "\x62\x6f\162\144\x65\162\x2d\x72\141\x64\151\x75\163\x3a\x35\x70\x78\73";
        goto D1;
        JF:
        $Ls = $Ls . "\x77\151\144\x74\x68\72" . $QX . "\x70\x78\x3b";
        $Ls = $Ls . "\150\145\151\147\150\164\x3a" . $QX . "\160\170\x3b";
        $Ls = $Ls . "\x62\x6f\162\x64\145\162\x2d\x72\141\144\x69\x75\x73\x3a\x30\x70\170\x3b";
        D1:
        goto ml;
        KI:
        $Ls = $Ls . "\167\x69\x64\164\x68\x3a" . $ZC . "\160\170\x3b";
        $Ls = $Ls . "\150\x65\x69\x67\x68\x74\x3a" . $xU . "\x70\170\x3b";
        $Ls = $Ls . "\x62\x6f\x72\x64\145\x72\x2d\x72\x61\x64\x69\x75\x73\72" . $K3 . "\160\x78\73";
        ml:
        $Ls = $Ls . "\142\x61\143\x6b\147\162\157\x75\156\x64\x2d\x63\x6f\154\157\x72\72\x23" . $fY . "\x3b";
        $Ls = $Ls . "\142\x6f\162\x64\145\x72\x2d\143\157\x6c\157\162\72\164\162\141\x6e\x73\x70\x61\x72\145\x6e\x74\73";
        $Ls = $Ls . "\x63\157\x6c\157\162\x3a\x23" . $wT . "\73";
        $Ls = $Ls . "\146\157\x6e\x74\55\163\151\172\145\x3a" . $B6 . "\x70\170\x3b";
        $Ls = $Ls . "\x70\141\144\x64\x69\x6e\147\x3a\60\x70\x78\x3b";
        $Of = $Of . $Ls . "\x22\57\x3e";
        Y5:
        echo "\x20\74\x61\x20\150\x72\145\x66\x3d\42\x23\x22\40\x6f\156\x43\154\x69\x63\x6b\75\42\163\x75\x62\x6d\x69\x74\123\x61\155\154\x46\157\162\155\50\x29\42\x3e";
        echo $Of;
        echo "\74\x2f\141\x3e\74\x2f\x66\x6f\162\x6d\76\x20";
        Ln:
        if ($this->mo_saml_check_empty_or_null_val(get_site_option("\x6d\157\137\163\x61\155\x6c\x5f\x72\145\144\151\x72\145\143\164\137\145\x72\162\157\162\x5f\x63\157\x64\145"))) {
            goto bK;
        }
        echo "\74\x64\x69\166\x3e\x3c\x2f\144\x69\166\x3e\74\x64\151\166\40\x74\151\x74\154\145\x3d\42\x4c\x6f\x67\151\156\x20\105\162\x72\157\x72\x22\x3e\74\x66\x6f\156\x74\40\x63\157\154\157\x72\75\x22\162\x65\x64\x22\x3e\x57\x65\40\143\x6f\165\x6c\144\x20\156\157\x74\x20\163\151\x67\156\40\171\x6f\165\40\151\156\56\40\x50\154\145\141\x73\145\40\143\x6f\156\x74\x61\x63\164\40\171\157\165\x72\x20\101\x64\x6d\x69\156\x69\163\164\162\x61\x74\157\x72\56\74\x2f\146\157\156\164\x3e\74\x2f\x64\x69\166\x3e";
        delete_site_option("\x6d\x6f\x5f\x73\x61\155\154\x5f\x72\x65\144\x69\x72\x65\143\x74\x5f\x65\162\162\x6f\x72\x5f\143\157\144\145");
        delete_site_option("\x6d\x6f\137\x73\141\x6d\154\137\162\145\144\151\162\x65\x63\x74\x5f\145\162\162\x6f\x72\137\x72\145\141\x73\x6f\x6e");
        bK:
        echo "\x3c\141\40\x68\x72\x65\146\75\42\150\x74\164\160\72\57\x2f\x6d\151\x6e\x69\157\162\x61\x6e\147\x65\x2e\143\157\x6d\57\167\x6f\x72\144\160\162\145\x73\x73\55\x6c\144\141\160\55\154\x6f\147\x69\156\x22\x20\163\x74\171\x6c\145\x3d\42\x64\x69\x73\x70\x6c\141\171\x3a\156\157\156\145\42\x3e\x4c\x6f\x67\151\x6e\x20\164\157\40\127\x6f\x72\144\x50\x72\145\x73\163\x20\x75\163\151\x6e\147\x20\x4c\104\101\120\x3c\57\141\76\xd\xa\11\x9\x9\11\74\141\x20\x68\162\145\x66\x3d\42\x68\164\164\160\72\57\x2f\155\151\156\x69\x6f\x72\141\x6e\x67\x65\56\x63\x6f\155\x2f\x63\154\157\165\x64\55\151\144\145\156\x74\x69\164\x79\x2d\x62\162\x6f\x6b\145\162\x2d\x73\145\x72\x76\x69\143\x65\x22\40\163\x74\171\x6c\x65\75\x22\144\151\x73\160\154\x61\x79\x3a\156\x6f\x6e\145\42\x3e\103\x6c\157\165\x64\x20\111\x64\x65\156\164\151\164\171\x20\x62\x72\x6f\153\145\162\x20\x73\x65\162\166\x69\143\145\74\57\141\x3e\xd\xa\11\x9\x9\11\74\141\x20\150\162\145\146\75\42\150\x74\164\160\x3a\57\57\155\151\156\151\x6f\x72\141\156\x67\145\x2e\x63\157\155\57\x73\x74\162\157\x6e\x67\x5f\141\x75\x74\150\x22\40\x73\164\171\x6c\x65\x3d\x22\x64\151\163\x70\154\141\x79\72\156\157\156\x65\73\42\76\74\57\x61\76\xd\xa\11\11\11\x9\x3c\x61\40\150\x72\145\146\x3d\x22\150\x74\164\x70\x3a\x2f\x2f\x6d\151\156\151\x6f\x72\141\x6e\147\145\56\143\157\x6d\57\163\x69\156\147\x6c\x65\x2d\163\151\x67\x6e\x2d\157\156\55\163\x73\157\x22\x20\163\164\x79\154\x65\x3d\x22\x64\x69\x73\160\154\141\171\x3a\156\157\156\x65\73\x22\76\x3c\x2f\141\x3e\15\12\x9\11\11\x9\74\141\x20\x68\162\145\146\75\42\150\164\x74\x70\72\57\57\155\x69\156\151\x6f\x72\141\156\147\145\x2e\143\157\155\x2f\146\162\x61\x75\144\x22\x20\163\x74\x79\154\x65\x3d\x22\x64\151\x73\x70\154\x61\171\x3a\x6e\x6f\x6e\145\x3b\x22\x3e\x3c\x2f\x61\76\15\12\xd\12\11\11\11\x3c\x2f\x75\x6c\76\xd\xa\11\x9\74\57\146\157\162\x6d\x3e";
        fS:
    }
    public function mo_saml_check_empty_or_null_val($yS)
    {
        if (!(!isset($yS) || empty($yS))) {
            goto zL;
        }
        return true;
        zL:
        return false;
    }
    function mo_saml_logout($h1, $Ej, $user)
    {
        $zG = get_site_option("\163\141\155\x6c\137\154\x6f\x67\157\165\164\x5f\x75\x72\x6c");
        $ed = get_site_option("\163\141\x6d\154\x5f\x6c\x6f\x67\157\x75\164\137\x62\151\x6e\x64\151\156\147\x5f\164\171\x70\145");
        $current_user = $user;
        $Uq = get_user_meta($current_user->ID, "\x6d\157\137\x73\x61\x6d\154\x5f\x69\144\160\137\154\157\147\x69\x6e");
        $Uq = isset($Uq[0]) ? $Uq[0] : '';
        $Ue = wp_get_referer();
        if (!empty($Ue)) {
            goto Du;
        }
        $Ue = !empty(get_site_option("\x6d\157\137\163\x61\x6d\x6c\x5f\163\160\x5f\142\141\x73\145\137\165\x72\154")) ? get_site_option("\x6d\x6f\x5f\x73\141\155\x6c\137\163\160\137\142\141\163\145\x5f\x75\162\154") : get_network_site_url();
        Du:
        if (!empty($zG)) {
            goto Un;
        }
        wp_redirect($Ue);
        exit;
        goto WP;
        Un:
        if (!(!session_id() || session_id() == '' || !isset($_SESSION))) {
            goto Tg;
        }
        session_start();
        Tg:
        if (isset($_SESSION["\x6d\157\137\x73\141\x6d\x6c\137\x6c\x6f\x67\157\165\x74\137\162\x65\161\165\x65\x73\164"])) {
            goto YO;
        }
        if ($Uq == "\x74\x72\x75\145") {
            goto xu;
        }
        wp_redirect($Ue);
        exit;
        goto Wb;
        YO:
        self::createLogoutResponseAndRedirect($zG, $ed);
        exit;
        goto Wb;
        xu:
        delete_user_meta($current_user->ID, "\x6d\157\x5f\163\x61\155\x6c\137\151\144\160\x5f\154\x6f\x67\x69\156");
        $LV = get_user_meta($current_user->ID, "\x6d\157\x5f\x73\141\155\154\137\156\x61\155\x65\137\x69\x64");
        $F0 = get_user_meta($current_user->ID, "\155\157\x5f\x73\141\x6d\154\x5f\163\x65\163\163\151\x6f\x6e\137\151\x6e\144\145\x78");
        $H2 = get_site_option("\155\x6f\x5f\163\141\155\x6c\137\163\x70\137\x62\141\163\145\x5f\x75\162\154");
        if (!empty($H2)) {
            goto g4;
        }
        $H2 = get_network_site_url();
        g4:
        $iB = get_site_option("\155\x6f\x5f\x73\141\155\x6c\137\x73\160\x5f\x65\x6e\x74\151\164\171\x5f\151\144");
        if (!empty($iB)) {
            goto w0;
        }
        $iB = $H2 . "\x2f\167\x70\x2d\x63\157\156\x74\x65\x6e\x74\x2f\x70\x6c\165\x67\151\156\163\57\155\151\x6e\x69\x6f\162\141\156\147\x65\55\163\141\x6d\154\x2d\x32\60\55\x73\151\x6e\147\154\145\55\163\x69\147\156\55\x6f\156\57";
        w0:
        $vq = $zG;
        $yc = $Ue;
        if (!empty($yc)) {
            goto uE;
        }
        $yc = saml_get_current_page_url();
        if (!strpos($yc, "\x3f")) {
            goto IY;
        }
        $yc = get_network_site_url();
        IY:
        uE:
        $yc = mo_saml_relaystate_url($yc);
        $P7 = Utilities::createLogoutRequest($LV, $iB, $vq, $F0, $ed);
        if (empty($ed) || $ed == "\x48\x74\164\x70\x52\145\x64\x69\162\145\143\x74") {
            goto m3;
        }
        if (!(get_site_option("\163\x61\155\x6c\x5f\162\145\x71\x75\145\x73\164\x5f\163\x69\x67\156\x65\x64") == "\165\x6e\x63\150\x65\143\x6b\x65\144")) {
            goto CO;
        }
        $hl = base64_encode($P7);
        Utilities::postSAMLRequest($zG, $hl, $yc);
        exit;
        CO:
        $yl = '';
        $W6 = '';
        $hl = Utilities::signXML($P7, "\x4e\141\x6d\x65\111\104\x50\157\x6c\x69\x63\x79");
        Utilities::postSAMLRequest($zG, $hl, $yc);
        goto DB;
        m3:
        $pR = $zG;
        if (strpos($zG, "\x3f") !== false) {
            goto Ri;
        }
        $pR .= "\x3f";
        goto Mk;
        Ri:
        $pR .= "\x26";
        Mk:
        if (!(get_site_option("\x73\141\x6d\154\137\162\x65\161\x75\145\x73\164\137\x73\151\147\x6e\x65\x64") == "\x75\156\143\150\x65\143\x6b\x65\x64")) {
            goto Lf;
        }
        $pR .= "\123\x41\115\x4c\x52\145\161\165\145\163\x74\x3d" . $P7 . "\46\x52\145\x6c\141\171\123\x74\141\164\145\x3d" . urlencode($yc);
        header("\x4c\157\x63\x61\164\151\157\x6e\x3a\40" . $pR);
        exit;
        Lf:
        $P7 = "\x53\101\x4d\114\x52\x65\161\x75\x65\163\x74\75" . $P7 . "\46\x52\x65\x6c\x61\171\123\x74\141\x74\x65\75" . urlencode($yc) . "\x26\x53\x69\x67\101\154\147\x3d" . urlencode(XMLSecurityKey::RSA_SHA256);
        $Kd = array("\164\x79\160\x65" => "\160\162\x69\x76\x61\164\x65");
        $YX = new XMLSecurityKey(XMLSecurityKey::RSA_SHA256, $Kd);
        $Q2 = get_site_option("\x6d\157\137\x73\x61\155\154\137\x63\x75\x72\x72\145\156\164\137\x63\x65\162\164\137\160\x72\151\x76\141\x74\145\137\x6b\145\171");
        $YX->loadKey($Q2, FALSE);
        $pS = new XMLSecurityDSig();
        $Od = $YX->signData($P7);
        $Od = base64_encode($Od);
        $pR .= $P7 . "\46\123\151\x67\x6e\141\x74\x75\x72\145\x3d" . urlencode($Od);
        header("\x4c\157\143\x61\164\151\x6f\x6e\x3a" . $pR);
        exit;
        DB:
        Wb:
        WP:
    }
    function createLogoutResponseAndRedirect($zG, $ed)
    {
        $H2 = get_site_option("\155\x6f\137\x73\x61\155\x6c\x5f\163\x70\x5f\x62\141\x73\145\137\165\x72\x6c");
        if (!empty($H2)) {
            goto Wj;
        }
        $H2 = get_network_site_url();
        Wj:
        $OU = $_SESSION["\x6d\x6f\x5f\163\x61\x6d\154\137\154\157\x67\x6f\x75\x74\x5f\162\145\x71\165\145\163\x74"];
        $zN = $_SESSION["\155\x6f\137\x73\141\155\x6c\137\x6c\x6f\147\157\165\164\137\x72\x65\154\x61\x79\137\163\164\141\164\x65"];
        unset($_SESSION["\x6d\x6f\x5f\163\141\x6d\x6c\x5f\x6c\x6f\x67\157\x75\164\137\x72\x65\161\165\145\163\164"]);
        unset($_SESSION["\x6d\x6f\137\163\141\155\x6c\x5f\x6c\x6f\147\157\x75\x74\x5f\x72\x65\x6c\x61\171\x5f\163\x74\141\x74\x65"]);
        $CP = new DOMDocument();
        $CP->loadXML($OU);
        $OU = $CP->firstChild;
        if (!($OU->localName == "\x4c\x6f\147\x6f\165\164\122\145\x71\165\145\x73\x74")) {
            goto W2;
        }
        $cA = new SAML2_LogoutRequest($OU);
        $iB = get_site_option("\155\157\x5f\163\141\155\x6c\137\163\160\x5f\145\156\164\151\164\x79\137\151\144");
        if (!empty($iB)) {
            goto Q1;
        }
        $iB = $H2 . "\x2f\x77\x70\x2d\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x70\154\165\x67\x69\x6e\163\x2f\x6d\x69\x6e\x69\157\x72\x61\x6e\x67\x65\x2d\163\x61\x6d\x6c\55\62\x30\55\x73\151\x6e\147\154\145\x2d\x73\151\x67\x6e\55\157\x6e\57";
        Q1:
        $vq = $zG;
        $tn = Utilities::createLogoutResponse($cA->getId(), $iB, $vq, $ed);
        if (empty($ed) || $ed == "\110\164\x74\160\122\145\x64\151\162\x65\x63\164") {
            goto RA;
        }
        if (!(get_site_option("\163\141\155\x6c\137\162\x65\161\x75\145\163\x74\x5f\x73\x69\147\156\145\144") == "\x75\156\x63\x68\x65\143\x6b\145\144")) {
            goto X2;
        }
        $hl = base64_encode($tn);
        Utilities::postSAMLResponse($zG, $hl, $zN);
        exit;
        X2:
        $yl = '';
        $W6 = '';
        $hl = Utilities::signXML($tn, "\x53\164\141\164\165\x73");
        Utilities::postSAMLResponse($zG, $hl, $zN);
        goto FC;
        RA:
        $pR = $zG;
        if (strpos($zG, "\x3f") !== false) {
            goto Af;
        }
        $pR .= "\77";
        goto dg;
        Af:
        $pR .= "\46";
        dg:
        if (!(get_site_option("\x73\x61\155\154\x5f\x72\145\x71\x75\x65\x73\x74\137\x73\151\x67\x6e\145\144") == "\165\156\x63\x68\x65\x63\x6b\x65\144")) {
            goto RX;
        }
        $pR .= "\123\x41\115\114\x52\x65\x73\x70\x6f\x6e\163\145\75" . $tn . "\x26\x52\145\154\141\171\x53\x74\x61\164\x65\75" . urlencode($zN);
        header("\114\157\143\x61\x74\x69\x6f\156\72\x20" . $pR);
        exit;
        RX:
        $pR .= "\123\x41\x4d\x4c\122\x65\163\x70\157\156\163\145\x3d" . $tn . "\x26\122\145\x6c\x61\x79\x53\164\x61\164\145\75" . urlencode($zN);
        header("\x4c\x6f\x63\141\x74\151\157\156\72\x20" . $pR);
        exit;
        FC:
        W2:
    }
}
function mo_login_validate()
{
    if (!(isset($_REQUEST["\x6f\160\x74\151\x6f\156"]) && $_REQUEST["\157\160\164\x69\x6f\x6e"] == "\155\x6f\x73\x61\155\154\x5f\155\x65\x74\141\144\x61\x74\141")) {
        goto ss;
    }
    miniorange_generate_metadata();
    ss:
    if (!mo_saml_is_customer_license_verified()) {
        goto pS;
    }
    if (!(isset($_REQUEST["\157\160\164\x69\x6f\156"]) && $_REQUEST["\157\160\164\151\157\156"] == "\x73\141\x6d\154\137\x75\163\x65\162\x5f\154\x6f\147\151\156" || isset($_REQUEST["\x6f\160\164\151\157\156"]) && $_REQUEST["\157\x70\164\151\x6f\x6e"] == "\164\x65\163\164\103\157\x6e\x66\151\x67" || isset($_REQUEST["\x6f\x70\x74\x69\157\x6e"]) && $_REQUEST["\x6f\160\x74\151\157\x6e"] == "\x67\x65\164\163\x61\155\154\162\x65\x71\x75\x65\163\164" || isset($_REQUEST["\157\160\x74\151\x6f\156"]) && $_REQUEST["\157\160\164\151\x6f\x6e"] == "\147\x65\x74\163\141\x6d\154\162\145\x73\x70\157\x6e\163\x65")) {
        goto TL;
    }
    if (mo_saml_is_sp_configured()) {
        goto Nn;
    }
    if (!is_user_logged_in()) {
        goto zK;
    }
    if (!isset($_REQUEST["\162\x65\x64\151\x72\x65\x63\164\x5f\164\x6f"])) {
        goto ew;
    }
    $RD = htmlspecialchars($_REQUEST["\162\145\144\x69\162\x65\143\164\137\x74\157"]);
    header("\114\x6f\143\141\x74\151\x6f\x6e\72\x20" . $RD);
    exit;
    ew:
    zK:
    goto n8;
    Nn:
    if (!(is_user_logged_in() and $_REQUEST["\157\160\x74\x69\157\156"] == "\x73\141\155\x6c\x5f\165\163\145\x72\x5f\154\157\147\151\x6e")) {
        goto fx;
    }
    if (!isset($_REQUEST["\x72\x65\144\151\162\x65\x63\164\x5f\x74\x6f"])) {
        goto Jj;
    }
    $RD = htmlspecialchars($_REQUEST["\162\x65\144\151\x72\145\143\164\137\164\157"]);
    header("\x4c\157\x63\x61\x74\x69\157\x6e\72\40" . $RD);
    exit;
    Jj:
    return;
    fx:
    $H2 = get_site_option("\x6d\x6f\137\163\x61\x6d\154\x5f\x73\x70\137\x62\x61\x73\x65\137\x75\162\154");
    if (!empty($H2)) {
        goto oD;
    }
    $H2 = get_network_site_url();
    oD:
    $dr = get_site_option("\163\x61\155\x6c\x5f\x73\163\157\137\163\145\x74\164\x69\156\x67\x73");
    $y1 = get_current_blog_id();
    $Uo = Utilities::get_active_sites();
    if (in_array($y1, $Uo)) {
        goto cW;
    }
    return;
    cW:
    if (!(empty($dr[$y1]) && !empty($dr["\104\x45\x46\101\125\x4c\x54"]))) {
        goto xI;
    }
    $dr[$y1] = $dr["\104\x45\x46\101\125\x4c\124"];
    xI:
    if ($_REQUEST["\x6f\160\x74\151\x6f\156"] == "\x74\145\163\164\103\157\x6e\146\x69\147" and array_key_exists("\156\145\167\x63\x65\x72\x74", $_REQUEST)) {
        goto lz;
    }
    if ($_REQUEST["\157\x70\x74\x69\x6f\x6e"] == "\x74\x65\x73\164\103\x6f\156\146\151\x67") {
        goto vO;
    }
    if ($_REQUEST["\157\x70\x74\x69\157\x6e"] == "\x67\x65\x74\163\x61\155\x6c\162\145\161\165\x65\x73\164") {
        goto wu;
    }
    if ($_REQUEST["\157\160\164\151\157\x6e"] == "\x67\x65\164\x73\x61\155\154\x72\145\163\x70\x6f\156\x73\x65") {
        goto wV;
    }
    if (!empty($dr[$y1]["\155\x6f\137\163\141\155\x6c\137\162\x65\x6c\x61\171\137\x73\164\141\164\x65"])) {
        goto SW;
    }
    if (isset($_REQUEST["\162\145\x64\x69\162\x65\x63\164\x5f\x74\x6f"])) {
        goto HU;
    }
    $yc = saml_get_current_page_url();
    goto vq;
    HU:
    $yc = $_REQUEST["\x72\145\144\x69\162\x65\x63\164\137\164\x6f"];
    vq:
    goto y3;
    SW:
    $yc = $dr[$y1]["\x6d\157\x5f\163\141\155\154\137\x72\145\x6c\x61\171\137\x73\164\141\x74\145"];
    y3:
    goto le;
    wV:
    $yc = "\144\x69\x73\160\154\x61\171\123\101\x4d\x4c\122\x65\163\160\157\x6e\x73\145";
    le:
    goto MA;
    wu:
    $yc = "\x64\x69\163\160\154\141\x79\123\x41\x4d\x4c\x52\145\161\165\x65\163\164";
    MA:
    goto JG;
    vO:
    $yc = "\x74\x65\x73\164\x56\141\x6c\151\x64\x61\x74\145";
    JG:
    goto bm;
    lz:
    $yc = "\x74\x65\163\x74\x4e\x65\x77\103\145\x72\164\151\x66\x69\x63\x61\x74\x65";
    bm:
    $mu = get_site_option("\163\141\155\x6c\137\154\157\x67\x69\156\x5f\165\x72\x6c");
    $Kx = !empty(get_site_option("\x73\141\155\154\137\154\157\147\151\156\137\142\151\156\144\151\x6e\147\137\x74\171\x70\145")) ? get_site_option("\x73\141\155\154\137\154\x6f\x67\151\x6e\137\142\x69\x6e\144\151\156\147\137\x74\x79\x70\145") : "\110\x74\x74\160\120\157\163\x74";
    $dr = get_site_option("\163\x61\x6d\154\x5f\x73\163\157\137\163\145\x74\164\151\156\147\x73");
    $y1 = get_current_blog_id();
    $Uo = Utilities::get_active_sites();
    if (in_array($y1, $Uo)) {
        goto CN;
    }
    return;
    CN:
    if (!(empty($dr[$y1]) && !empty($dr["\x44\x45\x46\101\x55\114\124"]))) {
        goto lI;
    }
    $dr[$y1] = $dr["\x44\105\x46\101\125\114\x54"];
    lI:
    $m8 = isset($dr[$y1]["\155\x6f\x5f\163\x61\x6d\x6c\137\x66\x6f\x72\x63\x65\137\141\x75\x74\150\x65\156\164\x69\143\x61\x74\x69\157\156"]) ? $dr[$y1]["\155\157\x5f\163\x61\155\154\x5f\x66\x6f\162\x63\145\137\x61\x75\164\150\x65\x6e\x74\151\x63\141\164\151\157\156"] : '';
    $Vr = $H2 . "\x2f";
    $iB = get_site_option("\155\x6f\137\x73\x61\x6d\154\137\x73\160\137\145\156\x74\151\164\x79\x5f\151\x64");
    $MD = get_site_option("\163\x61\155\x6c\137\x6e\141\155\x65\151\x64\x5f\146\157\162\155\x61\164");
    if (!empty($MD)) {
        goto O2;
    }
    $MD = "\61\x2e\61\72\156\141\x6d\145\x69\x64\55\x66\157\x72\x6d\141\x74\x3a\x75\x6e\x73\160\x65\143\x69\x66\151\x65\x64";
    O2:
    if (!empty($iB)) {
        goto aY;
    }
    $iB = $H2 . "\57\167\160\x2d\x63\x6f\156\164\145\156\x74\57\x70\154\165\x67\x69\156\x73\x2f\x6d\151\156\151\x6f\162\x61\x6e\x67\145\55\163\141\155\x6c\x2d\62\x30\55\x73\x69\156\147\x6c\145\x2d\163\151\147\156\x2d\157\x6e\x2f";
    aY:
    $P7 = Utilities::createAuthnRequest($Vr, $iB, $mu, $m8, $Kx, $MD);
    if (!($yc == "\144\151\163\x70\x6c\141\x79\123\x41\115\114\x52\x65\161\165\x65\x73\x74")) {
        goto Iu;
    }
    mo_saml_show_SAML_log(Utilities::createAuthnRequest($Vr, $iB, $mu, $m8, "\110\164\x74\x70\x50\157\x73\x74", $MD), $yc);
    Iu:
    $pR = htmlspecialchars_decode($mu);
    if (strpos($mu, "\x3f") !== false) {
        goto KY;
    }
    $pR .= "\x3f";
    goto C2;
    KY:
    $pR .= "\46";
    C2:
    $yc = mo_saml_relaystate_url($yc);
    if ($Kx == "\x48\x74\164\x70\x52\145\144\x69\x72\x65\x63\x74") {
        goto P8;
    }
    if (!(get_site_option("\163\141\x6d\x6c\137\x72\x65\x71\x75\145\x73\164\x5f\x73\x69\147\x6e\x65\x64") == "\x75\156\143\x68\145\x63\x6b\145\144")) {
        goto bT;
    }
    $hl = base64_encode($P7);
    Utilities::postSAMLRequest($mu, $hl, $yc);
    exit;
    bT:
    $yl = '';
    $W6 = '';
    if ($_REQUEST["\157\160\164\x69\x6f\156"] == "\x74\145\163\164\x43\x6f\156\x66\x69\x67" && array_key_exists("\x6e\145\x77\143\145\162\x74", $_REQUEST)) {
        goto F8;
    }
    $hl = Utilities::signXML($P7, "\x4e\x61\x6d\145\x49\104\120\x6f\154\x69\x63\171");
    goto Qr;
    F8:
    $hl = Utilities::signXML($P7, "\116\x61\155\145\x49\104\x50\157\x6c\x69\143\x79", true);
    Qr:
    Utilities::postSAMLRequest($mu, $hl, $yc);
    update_site_option("\x6d\x6f\x5f\163\x61\x6d\x6c\137\156\x65\167\x5f\143\x65\162\164\137\164\x65\x73\164", true);
    goto rC;
    P8:
    if (!(get_site_option("\x73\141\x6d\x6c\137\x72\145\161\165\145\163\x74\x5f\x73\151\x67\156\145\x64") == "\x75\x6e\x63\150\145\143\x6b\x65\144")) {
        goto sF;
    }
    $pR .= "\x53\x41\x4d\x4c\x52\145\x71\x75\x65\163\164\75" . $P7 . "\x26\x52\x65\x6c\x61\171\123\x74\x61\164\145\75" . urlencode($yc);
    header("\x4c\157\143\x61\164\151\x6f\x6e\x3a\40" . $pR);
    exit;
    sF:
    $P7 = "\123\101\115\x4c\122\x65\161\x75\145\x73\x74\75" . $P7 . "\x26\x52\145\x6c\x61\171\x53\x74\141\164\145\75" . urlencode($yc) . "\x26\123\151\147\101\154\x67\x3d" . urlencode(XMLSecurityKey::RSA_SHA256);
    $Kd = array("\164\x79\160\x65" => "\x70\162\151\x76\141\x74\x65");
    $YX = new XMLSecurityKey(XMLSecurityKey::RSA_SHA256, $Kd);
    if ($_REQUEST["\x6f\x70\x74\151\x6f\156"] == "\x74\x65\163\164\x43\157\x6e\146\x69\x67" && array_key_exists("\156\x65\x77\x63\x65\x72\164", $_REQUEST)) {
        goto u0;
    }
    $Q2 = get_site_option("\x6d\x6f\137\x73\141\x6d\154\137\143\x75\x72\162\x65\156\164\x5f\143\x65\162\164\137\160\x72\151\x76\141\164\145\137\x6b\x65\171");
    goto yX;
    u0:
    $Q2 = file_get_contents(plugin_dir_path(__FILE__) . "\162\x65\x73\x6f\x75\x72\143\x65\x73" . DIRECTORY_SEPARATOR . mo_options_enum_default_sp_certificate::SP_Private_Key);
    yX:
    $YX->loadKey($Q2, FALSE);
    $pS = new XMLSecurityDSig();
    $Od = $YX->signData($P7);
    $Od = base64_encode($Od);
    $pR .= $P7 . "\46\x53\151\147\156\141\164\x75\162\145\75" . urlencode($Od);
    header("\114\x6f\143\141\x74\x69\157\x6e\x3a\x20" . $pR);
    exit;
    rC:
    n8:
    TL:
    if (!(array_key_exists("\x53\x41\x4d\114\122\145\163\160\x6f\156\163\145", $_REQUEST) && !empty($_REQUEST["\123\101\115\x4c\122\145\163\x70\x6f\156\163\145"]))) {
        goto Dl;
    }
    if (array_key_exists("\122\145\x6c\x61\x79\123\x74\x61\x74\x65", $_POST) && !empty($_POST["\122\145\154\x61\171\x53\164\x61\164\x65"]) && $_POST["\x52\145\154\141\171\123\x74\141\x74\x65"] != "\57") {
        goto W_;
    }
    $md = '';
    goto TB;
    W_:
    $md = $_POST["\x52\145\154\x61\x79\x53\164\x61\164\145"];
    TB:
    $md = mo_saml_parse_url($md);
    $H2 = get_site_option("\155\157\137\163\141\x6d\x6c\x5f\163\160\x5f\x62\x61\x73\x65\x5f\x75\x72\154");
    if (!empty($H2)) {
        goto FW;
    }
    $H2 = get_network_site_url();
    FW:
    $DZ = $_REQUEST["\123\101\115\x4c\x52\x65\163\x70\x6f\156\163\145"];
    $DZ = base64_decode($DZ);
    if (!($md == "\x64\151\x73\160\x6c\x61\171\x53\x41\x4d\x4c\x52\145\x73\x70\157\156\163\x65")) {
        goto d_;
    }
    mo_saml_show_SAML_log($DZ, $md);
    d_:
    if (!(array_key_exists("\x53\x41\x4d\x4c\x52\145\x73\x70\157\x6e\x73\x65", $_GET) && !empty($_GET["\123\x41\115\x4c\122\x65\x73\160\x6f\156\163\145"]))) {
        goto YJ;
    }
    $DZ = gzinflate($DZ);
    YJ:
    $CP = new DOMDocument();
    $CP->loadXML($DZ);
    $C5 = $CP->firstChild;
    $o7 = $CP->documentElement;
    $Ne = new DOMXpath($CP);
    $Ne->registerNamespace("\x73\x61\x6d\x6c\160", "\x75\x72\x6e\x3a\157\141\163\151\163\x3a\x6e\x61\x6d\145\x73\72\x74\x63\72\123\x41\115\114\x3a\62\56\x30\72\160\162\x6f\164\x6f\x63\x6f\x6c");
    $Ne->registerNamespace("\x73\x61\x6d\x6c", "\x75\x72\x6e\x3a\x6f\141\163\151\x73\72\x6e\x61\155\145\x73\72\x74\x63\72\123\x41\x4d\114\x3a\62\x2e\60\72\141\x73\163\x65\162\x74\151\157\x6e");
    if ($C5->localName == "\114\157\x67\x6f\x75\x74\x52\x65\163\x70\x6f\x6e\x73\145") {
        goto bg;
    }
    $qz = $Ne->query("\57\163\x61\155\x6c\160\x3a\x52\x65\163\x70\157\x6e\x73\145\x2f\x73\141\155\154\160\x3a\123\x74\141\x74\x75\163\x2f\163\x61\155\x6c\160\72\x53\x74\141\164\x75\163\103\157\x64\x65", $o7);
    $k0 = isset($qz) ? $qz->item(0)->getAttribute("\126\x61\154\x75\145") : '';
    $sM = explode("\x3a", $k0);
    if (!array_key_exists(7, $sM)) {
        goto Sr;
    }
    $qz = $sM[7];
    Sr:
    $YN = $Ne->query("\x2f\x73\x61\x6d\154\160\72\122\x65\x73\160\x6f\156\x73\145\57\x73\x61\x6d\x6c\160\x3a\123\164\x61\x74\165\163\x2f\163\141\x6d\x6c\x70\x3a\x53\164\x61\x74\165\163\x4d\145\x73\x73\x61\147\x65", $o7);
    $xb = isset($YN) ? $YN->item(0) : '';
    if (empty($xb)) {
        goto Hh;
    }
    $xb = $xb->nodeValue;
    Hh:
    if (array_key_exists("\x52\x65\154\x61\171\x53\164\x61\x74\145", $_POST) && !empty($_POST["\122\x65\x6c\x61\x79\123\164\141\x74\x65"]) && $_POST["\x52\x65\154\141\171\x53\164\141\164\145"] != "\x2f") {
        goto mJ;
    }
    $md = '';
    goto n3;
    mJ:
    $md = $_POST["\x52\x65\154\141\x79\x53\164\141\164\145"];
    $md = mo_saml_parse_url($md);
    n3:
    if (!($qz != "\123\x75\x63\143\x65\x73\x73")) {
        goto yc;
    }
    show_status_error($qz, $md, $xb);
    yc:
    if (!($md !== "\x74\x65\x73\164\x56\x61\x6c\x69\144\141\164\145" && $md !== "\164\x65\163\x74\116\x65\167\103\x65\x72\x74\151\x66\x69\143\141\x74\x65")) {
        goto UJ;
    }
    $a4 = parse_url($md, PHP_URL_HOST);
    $mz = parse_url($H2, PHP_URL_HOST);
    $Ra = parse_url(get_current_base_url(), PHP_URL_HOST);
    if (!empty($md)) {
        goto ek;
    }
    $md = "\57";
    goto WZ;
    ek:
    $md = mo_saml_parse_url($md);
    WZ:
    if (!(!empty($a4) && $a4 != $Ra)) {
        goto zV;
    }
    Utilities::postSAMLResponse($md, $_REQUEST["\123\x41\x4d\x4c\x52\145\x73\x70\157\156\x73\x65"], mo_saml_relaystate_url($md));
    zV:
    UJ:
    $Nk = maybe_unserialize(get_site_option("\163\141\x6d\x6c\137\170\65\60\x39\137\143\145\x72\164\x69\x66\x69\143\141\164\145"));
    update_site_option("\x6d\x6f\137\163\x61\155\154\137\x72\145\x73\x70\157\x6e\163\x65", base64_encode($DZ));
    foreach ($Nk as $YX => $yS) {
        if (@openssl_x509_read($yS)) {
            goto em;
        }
        unset($Nk[$YX]);
        em:
        iq:
    }
    OW:
    $Vr = $H2 . "\x2f";
    if ($md == "\164\145\163\x74\x4e\145\x77\103\x65\x72\164\x69\x66\151\x63\x61\164\x65") {
        goto RP;
    }
    $DZ = new SAML2_Response($C5, get_site_option("\x6d\x6f\137\x73\141\155\x6c\137\143\x75\x72\x72\x65\156\164\x5f\x63\x65\x72\164\x5f\160\x72\151\x76\x61\164\x65\137\153\145\171"));
    goto xl;
    RP:
    $n2 = file_get_contents(plugin_dir_path(__FILE__) . "\162\x65\x73\x6f\165\x72\x63\x65\x73" . DIRECTORY_SEPARATOR . mo_options_enum_default_sp_certificate::SP_Private_Key);
    $DZ = new SAML2_Response($C5, $n2);
    xl:
    $oL = $DZ->getSignatureData();
    $qd = current($DZ->getAssertions())->getSignatureData();
    if (!(empty($qd) && empty($oL))) {
        goto kI;
    }
    if ($md == "\x74\x65\x73\x74\126\141\x6c\151\144\x61\164\145" or $md == "\164\x65\163\164\x4e\145\167\x43\x65\x72\164\151\146\151\x63\x61\x74\145") {
        goto PG;
    }
    wp_die("\x57\x65\x20\143\157\x75\x6c\144\40\156\157\x74\40\163\x69\147\156\40\171\157\x75\x20\x69\156\x2e\x20\120\x6c\145\141\163\145\x20\x63\x6f\x6e\164\141\143\x74\x20\x61\x64\x6d\x69\156\151\163\x74\x72\141\x74\x6f\x72", "\x45\x72\162\x6f\162\72\40\111\x6e\166\x61\x6c\x69\144\x20\123\101\x4d\x4c\x20\x52\145\163\x70\x6f\x6e\163\145");
    goto nQ;
    PG:
    $Xo = mo_options_error_constants::Error_no_certificate;
    $WF = mo_options_error_constants::Cause_no_certificate;
    echo "\74\144\x69\166\x20\163\x74\171\x6c\145\x3d\x22\146\x6f\x6e\164\55\x66\x61\155\151\x6c\x79\72\103\141\x6c\x69\x62\162\151\73\x70\x61\x64\144\151\x6e\147\x3a\60\x20\x33\x25\x3b\x22\x3e\xd\xa\11\x9\11\11\11\11\74\x64\x69\166\40\163\x74\x79\154\x65\75\x22\143\157\x6c\157\162\x3a\40\x23\141\x39\64\x34\64\62\x3b\x62\141\143\x6b\x67\162\157\x75\x6e\x64\55\x63\157\154\157\x72\72\40\43\146\62\x64\145\144\x65\73\160\x61\144\x64\x69\x6e\x67\72\x20\x31\x35\x70\x78\73\155\141\x72\147\x69\156\55\142\157\164\164\x6f\155\72\40\62\60\160\x78\x3b\x74\145\x78\x74\55\x61\154\x69\147\x6e\x3a\x63\145\x6e\164\145\x72\73\x62\157\x72\x64\x65\x72\72\x31\x70\x78\x20\163\x6f\154\x69\144\x20\x23\105\x36\102\63\x42\62\73\146\157\156\x74\55\163\x69\x7a\x65\x3a\61\70\x70\x74\x3b\x22\76\x20\x45\122\x52\117\122\74\x2f\144\x69\166\76\xd\xa\11\11\x9\x9\x9\x9\x3c\144\151\166\40\x73\x74\x79\154\x65\75\42\x63\x6f\154\157\x72\x3a\40\43\141\71\x34\64\x34\x32\73\146\157\156\x74\55\x73\151\172\x65\72\61\64\160\x74\73\x20\155\141\162\147\151\156\55\x62\x6f\x74\x74\x6f\x6d\x3a\62\x30\x70\170\x3b\42\x3e\x3c\x70\x3e\74\163\164\162\x6f\156\147\x3e\x45\x72\162\x6f\x72\40\40\x3a" . $Xo . "\x20\74\57\x73\x74\162\x6f\156\147\x3e\74\57\160\x3e\xd\xa\x9\11\x9\x9\x9\x9\15\xa\11\x9\x9\x9\11\x9\74\160\x3e\x3c\163\164\x72\157\156\x67\76\x50\157\163\163\151\142\154\145\x20\x43\x61\165\x73\x65\x3a\40" . $WF . "\74\57\163\x74\162\x6f\156\x67\x3e\x3c\x2f\160\x3e\15\xa\11\11\x9\11\11\x9\xd\12\11\11\x9\x9\x9\x9\x3c\x2f\144\151\x76\x3e\74\x2f\144\151\166\x3e";
    mo_saml_download_logs($Xo, $WF);
    exit;
    nQ:
    kI:
    $lQ = '';
    if (is_array($Nk)) {
        goto Bi;
    }
    $sR = XMLSecurityKey::getRawThumbprint($Nk);
    $sR = mo_saml_convert_to_windows_iconv($sR);
    $sR = preg_replace("\x2f\134\x73\x2b\x2f", '', $sR);
    if (empty($oL)) {
        goto vw;
    }
    $lQ = Utilities::processResponse($Vr, $sR, $oL, $DZ, 0, $md);
    vw:
    if (empty($qd)) {
        goto qJ;
    }
    $lQ = Utilities::processResponse($Vr, $sR, $qd, $DZ, 0, $md);
    qJ:
    goto EX;
    Bi:
    foreach ($Nk as $YX => $yS) {
        $sR = XMLSecurityKey::getRawThumbprint($yS);
        $sR = mo_saml_convert_to_windows_iconv($sR);
        $sR = preg_replace("\57\x5c\163\x2b\57", '', $sR);
        if (empty($oL)) {
            goto fL;
        }
        $lQ = Utilities::processResponse($Vr, $sR, $oL, $DZ, $YX, $md);
        fL:
        if (empty($qd)) {
            goto sk;
        }
        $lQ = Utilities::processResponse($Vr, $sR, $qd, $DZ, $YX, $md);
        sk:
        if (!$lQ) {
            goto cC;
        }
        goto Bb;
        cC:
        mZ:
    }
    Bb:
    EX:
    if (empty($oL)) {
        goto Zo;
    }
    $Uc = $oL["\x43\145\x72\164\x69\146\151\143\x61\x74\145\163"][0];
    goto ad;
    Zo:
    $Uc = $qd["\x43\145\162\x74\151\146\x69\x63\x61\164\145\x73"][0];
    ad:
    if ($lQ) {
        goto o5;
    }
    if ($md == "\x74\x65\163\x74\x56\x61\154\x69\x64\141\x74\145" or $md == "\x74\x65\163\164\x4e\145\167\x43\145\x72\164\x69\146\151\143\x61\164\x65") {
        goto Ti;
    }
    wp_die("\x57\145\x20\143\157\165\x6c\144\40\x6e\157\164\40\x73\151\147\156\40\x79\157\165\40\x69\156\x2e\x20\x50\x6c\145\x61\x73\145\40\143\x6f\156\x74\141\x63\x74\x20\x79\x6f\165\x72\40\101\144\155\x69\x6e\151\163\x74\x72\141\x74\157\x72", "\x45\x72\162\x6f\x72\40\x3a\103\145\162\164\151\146\151\143\141\164\145\x20\x6e\157\164\x20\146\157\165\x6e\144");
    goto Dg;
    Ti:
    $Xo = mo_options_error_constants::Error_wrong_certificate;
    $WF = mo_options_error_constants::Cause_wrong_certificate;
    $c_ = "\55\55\x2d\x2d\55\x42\105\x47\111\116\x20\x43\105\x52\124\x49\106\111\103\x41\x54\105\x2d\55\55\x2d\x2d\74\x62\x72\76" . chunk_split($Uc, 64) . "\x3c\142\x72\76\x2d\55\55\55\x2d\105\x4e\104\x20\x43\x45\122\x54\111\106\111\x43\101\x54\105\55\x2d\x2d\x2d\55";
    echo "\x3c\x64\x69\166\x20\x73\164\x79\x6c\145\75\42\x66\157\156\164\x2d\x66\141\155\151\x6c\171\72\x43\141\154\x69\142\162\151\73\x70\x61\144\144\x69\156\x67\x3a\x30\x20\63\45\73\42\76";
    echo "\74\x64\x69\166\40\163\x74\x79\154\x65\x3d\x22\143\x6f\154\x6f\x72\x3a\40\43\141\x39\x34\x34\x34\x32\73\x62\141\x63\153\147\162\x6f\x75\156\x64\55\x63\x6f\154\157\x72\72\x20\43\x66\62\144\145\144\x65\73\x70\141\144\x64\x69\156\x67\x3a\x20\61\x35\x70\x78\73\x6d\x61\162\147\151\156\x2d\x62\x6f\164\164\157\x6d\72\x20\62\60\x70\170\73\164\145\170\164\x2d\141\154\151\x67\x6e\72\x63\x65\x6e\164\145\x72\x3b\x62\x6f\162\x64\145\162\x3a\x31\x70\170\40\163\157\154\151\x64\x20\x23\x45\x36\102\x33\102\x32\73\146\x6f\156\x74\x2d\163\151\172\145\72\61\70\160\164\73\x22\x3e\x20\105\122\122\x4f\122\x3c\x2f\x64\151\166\x3e\xd\xa\x9\x9\x9\11\x9\x9\x9\11\74\144\x69\x76\x20\163\x74\x79\x6c\145\x3d\x22\143\157\x6c\x6f\162\72\x20\43\x61\x39\x34\64\x34\62\x3b\x66\x6f\156\164\x2d\x73\151\172\x65\72\61\x34\160\164\73\x20\155\141\162\147\x69\x6e\x2d\x62\x6f\x74\164\157\155\72\x32\x30\160\170\73\x22\76\74\160\76\x3c\x73\x74\x72\157\x6e\147\76\105\162\162\x6f\162\x3a\40\x3c\57\x73\x74\162\x6f\x6e\147\x3e\125\156\x61\x62\x6c\x65\40\164\x6f\x20\x66\x69\x6e\x64\x20\141\40\x63\145\x72\164\x69\146\151\143\x61\164\145\40\x6d\x61\164\143\x68\x69\x6e\x67\x20\164\150\145\x20\143\x6f\x6e\146\x69\x67\x75\162\145\144\40\x66\x69\156\x67\145\x72\160\162\x69\x6e\164\x2e\x3c\57\160\x3e\15\xa\11\11\11\x9\x9\11\x9\x9\11\x3c\x70\x3e\120\x6c\x65\x61\163\145\x20\x63\x6f\x6e\164\141\x63\x74\40\171\157\165\162\x20\x61\144\155\x69\x6e\151\163\164\x72\141\164\x6f\162\40\x61\156\144\x20\x72\x65\x70\x6f\x72\164\40\164\x68\145\x20\146\x6f\154\x6c\x6f\167\x69\x6e\x67\x20\x65\162\x72\x6f\162\72\74\x2f\x70\76\15\12\x9\x9\x9\x9\11\x9\11\x9\11\74\160\x3e\x3c\x73\x74\162\157\x6e\147\x3e\120\x6f\163\x73\x69\x62\x6c\145\x20\x43\x61\x75\x73\145\72\40\74\57\163\x74\x72\x6f\x6e\147\x3e\47\130\56\x35\60\71\x20\x43\x65\x72\x74\151\x66\151\x63\141\164\145\x27\x20\x66\151\145\x6c\x64\40\151\156\x20\160\x6c\165\147\x69\156\x20\144\157\145\x73\40\x6e\x6f\164\x20\x6d\x61\164\x63\x68\x20\x74\x68\x65\x20\x63\145\162\x74\151\146\151\x63\141\164\145\40\x66\x6f\x75\156\144\40\x69\156\40\123\x41\x4d\x4c\40\x52\145\163\x70\x6f\x6e\163\x65\x2e\x3c\57\160\x3e\15\xa\11\11\x9\x9\x9\x9\11\x9\x9\x3c\160\76\x3c\x73\x74\x72\x6f\156\x67\76\x43\145\x72\164\x69\146\151\143\141\164\145\x20\x66\x6f\x75\156\144\40\151\x6e\x20\x53\101\115\x4c\40\122\x65\x73\160\x6f\x6e\163\x65\x3a\40\74\x2f\x73\x74\x72\x6f\156\147\76\x3c\146\157\x6e\164\x20\146\x61\x63\x65\75\x22\x43\x6f\165\162\x69\x65\x72\x20\x4e\145\167\42\76\x3c\x62\x72\x3e\x3c\142\x72\x3e" . $c_ . "\74\57\x70\x3e\x3c\x2f\x66\x6f\x6e\x74\x3e\xd\xa\11\x9\11\11\11\11\x9\11\x9\x3c\x70\x3e\x3c\163\x74\162\157\x6e\x67\76\x53\x6f\x6c\x75\x74\x69\157\156\72\x20\74\x2f\163\x74\x72\157\156\147\x3e\x3c\57\160\x3e\15\xa\11\11\11\11\11\x9\11\11\x9\x3c\157\154\76\xd\12\x9\11\11\x9\11\11\11\11\11\x20\x20\40\x3c\154\151\76\x43\157\x70\171\x20\160\x61\x73\164\x65\x20\x74\150\145\x20\143\x65\162\164\x69\x66\x69\143\141\164\x65\x20\x70\x72\157\166\x69\144\145\144\x20\x61\x62\x6f\166\145\x20\151\x6e\x20\130\65\x30\x39\x20\x43\145\x72\x74\x69\x66\151\143\141\164\145\40\165\156\x64\145\162\40\123\145\x72\166\x69\143\145\x20\x50\162\157\x76\x69\144\x65\x72\40\123\x65\x74\165\x70\x20\x74\141\142\x2e\x3c\x2f\154\x69\x3e\xd\12\11\x9\11\x9\x9\x9\x9\11\x9\40\40\40\x3c\154\x69\x3e\111\x66\x20\x69\163\x73\165\145\x20\x70\145\x72\163\x69\x73\x74\163\40\144\151\163\x61\142\154\x65\x20\74\142\76\x43\x68\x61\x72\141\x63\164\x65\x72\40\145\156\x63\157\144\x69\156\x67\x3c\57\x62\76\x20\x75\156\x64\145\x72\40\123\145\162\x76\x69\x63\x65\x20\x50\x72\x6f\x76\x64\x65\x72\x20\x53\x65\x74\165\x70\40\x74\x61\142\56\x3c\57\x6c\151\76\xd\xa\11\x9\x9\x9\11\x9\11\x9\x9\x3c\x2f\x6f\x6c\76\15\12\x9\11\11\x9\x9\11\11\11\11\74\x2f\144\151\166\x3e\xd\12\x9\11\x9\x9\11\11\11\x9\74\144\x69\x76\x20\163\x74\171\154\x65\75\42\x6d\x61\x72\x67\x69\156\72\63\x25\73\x64\x69\x73\160\154\141\x79\72\x62\154\157\x63\153\x3b\x74\x65\x78\164\x2d\x61\x6c\151\147\156\72\143\x65\x6e\x74\145\162\73\42\76\xd\12\x9\x9\11\x9\x9\11\11\x9\x9\x9\74\144\x69\x76\x20\163\x74\171\154\145\x3d\42\155\141\162\147\x69\156\72\63\x25\x3b\144\151\163\160\154\141\171\72\x62\x6c\x6f\143\153\x3b\164\145\170\x74\x2d\x61\x6c\151\147\156\x3a\143\x65\x6e\x74\x65\x72\x3b\x22\76\74\151\156\160\165\x74\x20\163\x74\171\154\145\x3d\x22\x70\141\144\x64\x69\x6e\x67\x3a\61\x25\73\x77\151\144\x74\150\72\61\x30\60\160\170\x3b\142\141\143\x6b\x67\162\x6f\165\156\144\72\40\43\60\x30\71\61\x43\104\x20\156\157\x6e\x65\40\162\145\x70\145\x61\164\x20\163\143\162\157\154\x6c\40\60\x25\x20\60\45\x3b\143\165\162\x73\157\162\72\40\160\157\151\x6e\164\145\162\x3b\x66\x6f\156\164\x2d\x73\x69\x7a\145\72\61\x35\160\170\73\142\157\162\x64\x65\x72\55\x77\x69\x64\x74\x68\72\x20\x31\x70\x78\73\142\157\x72\x64\x65\162\x2d\x73\x74\x79\154\145\x3a\40\x73\157\x6c\151\x64\x3b\x62\x6f\x72\144\x65\162\x2d\162\x61\x64\151\165\x73\x3a\40\x33\160\170\73\x77\150\151\164\145\55\163\160\x61\x63\145\x3a\40\156\x6f\167\x72\141\x70\x3b\x62\x6f\x78\x2d\x73\151\x7a\151\x6e\x67\72\x20\x62\x6f\162\144\x65\162\55\142\x6f\x78\73\x62\157\x72\x64\x65\162\55\x63\x6f\x6c\157\x72\72\x20\x23\60\60\67\x33\101\x41\73\x62\157\x78\x2d\x73\150\141\x64\157\167\x3a\40\60\x70\170\40\61\x70\x78\x20\x30\160\x78\40\162\x67\142\x61\x28\x31\62\60\54\40\x32\60\60\x2c\x20\62\x33\60\x2c\x20\x30\x2e\x36\x29\x20\x69\x6e\x73\145\x74\x3b\x63\157\x6c\157\x72\x3a\x20\x23\x46\106\x46\73\42\x74\x79\x70\145\75\42\x62\x75\164\x74\157\156\x22\x20\x76\141\154\165\145\75\42\x44\x6f\x6e\x65\x22\40\157\156\x43\154\151\x63\153\x3d\42\163\x65\x6c\x66\x2e\143\154\157\x73\x65\50\x29\x3b\42\x3e\74\57\x64\x69\166\x3e";
    mo_saml_download_logs($Xo, $WF);
    exit;
    Dg:
    o5:
    $CL = get_site_option("\x73\x61\x6d\x6c\x5f\x69\163\x73\x75\145\x72");
    $iB = get_site_option("\155\x6f\x5f\163\141\x6d\x6c\x5f\x73\x70\137\x65\x6e\x74\151\x74\x79\x5f\151\144");
    if (!empty($iB)) {
        goto V6;
    }
    $iB = $H2 . "\x2f\x77\160\55\143\x6f\156\x74\145\x6e\164\x2f\160\x6c\165\x67\151\x6e\163\x2f\155\x69\156\151\x6f\162\141\x6e\147\x65\55\x73\141\155\x6c\x2d\x32\x30\x2d\163\x69\x6e\147\154\145\55\163\x69\147\156\x2d\x6f\156\57";
    V6:
    Utilities::validateIssuerAndAudience($DZ, $iB, $CL, $md);
    $EX = current(current($DZ->getAssertions())->getNameId());
    $l1 = current($DZ->getAssertions())->getAttributes();
    $l1["\x4e\141\155\x65\x49\x44"] = array("\60" => $EX);
    $F0 = current($DZ->getAssertions())->getSessionIndex();
    mo_saml_checkMapping($l1, $md, $F0);
    goto Gv;
    bg:
    if (!isset($_REQUEST["\122\x65\154\141\x79\123\164\x61\x74\x65"])) {
        goto FQ;
    }
    $zN = $_REQUEST["\x52\145\154\x61\171\123\x74\x61\164\x65"];
    FQ:
    wp_logout();
    if (empty($zN)) {
        goto CS;
    }
    $zN = mo_saml_parse_url($zN);
    goto GD;
    CS:
    $zN = $H2;
    GD:
    header("\x4c\157\143\x61\164\x69\x6f\x6e\x3a" . $zN);
    exit;
    Gv:
    Dl:
    if (!(array_key_exists("\x53\101\115\x4c\122\145\x71\165\x65\163\x74", $_REQUEST) && !empty($_REQUEST["\x53\101\x4d\x4c\x52\145\x71\x75\145\163\x74"]))) {
        goto qs;
    }
    $P7 = $_REQUEST["\123\x41\x4d\x4c\x52\145\161\x75\x65\163\164"];
    $md = "\57";
    if (!array_key_exists("\x52\145\154\x61\171\x53\164\141\164\x65", $_REQUEST)) {
        goto WQ;
    }
    $md = $_REQUEST["\122\x65\x6c\x61\x79\x53\x74\141\x74\145"];
    WQ:
    $P7 = base64_decode($P7);
    if (!(array_key_exists("\x53\101\x4d\114\122\x65\161\165\x65\x73\164", $_GET) && !empty($_GET["\123\101\x4d\114\122\x65\161\x75\145\x73\164"]))) {
        goto Ly;
    }
    $P7 = gzinflate($P7);
    Ly:
    $CP = new DOMDocument();
    $CP->loadXML($P7);
    $rv = $CP->firstChild;
    if (!($rv->localName == "\x4c\157\147\157\x75\164\122\x65\x71\165\x65\163\x74")) {
        goto ut;
    }
    $cA = new SAML2_LogoutRequest($rv);
    if (!(!session_id() || session_id() == '' || !isset($_SESSION))) {
        goto wd;
    }
    session_start();
    wd:
    $_SESSION["\155\x6f\137\163\141\155\154\137\x6c\157\x67\x6f\165\164\137\162\145\x71\x75\145\163\x74"] = $P7;
    $_SESSION["\155\x6f\137\163\x61\x6d\x6c\x5f\x6c\x6f\x67\157\x75\x74\x5f\162\145\x6c\x61\171\x5f\163\164\141\164\x65"] = $md;
    wp_redirect(htmlspecialchars_decode(wp_logout_url()));
    exit;
    ut:
    qs:
    if (!(isset($_REQUEST["\157\x70\x74\x69\157\156"]) and !is_array($_REQUEST["\157\x70\164\x69\x6f\x6e"]) and strpos($_REQUEST["\x6f\x70\164\151\x6f\156"], "\162\145\x61\144\x73\141\x6d\154\154\x6f\147\151\156") !== false)) {
        goto m0;
    }
    require_once dirname(__FILE__) . "\57\151\x6e\143\154\165\x64\x65\163\x2f\x6c\x69\142\57\145\x6e\143\x72\x79\x70\x74\151\157\x6e\56\x70\150\160";
    if (isset($_POST["\123\124\101\124\125\123"]) && $_POST["\x53\x54\x41\x54\125\123"] == "\x45\x52\x52\x4f\x52") {
        goto hq;
    }
    if (!(isset($_POST["\x53\124\x41\124\x55\x53"]) && $_POST["\x53\124\x41\124\125\123"] == "\x53\x55\x43\103\105\123\x53")) {
        goto Yb;
    }
    $h1 = '';
    if (!(isset($_REQUEST["\x72\145\144\x69\x72\x65\143\164\137\164\x6f"]) && !empty($_REQUEST["\x72\x65\144\x69\162\145\143\164\x5f\164\157"]) && $_REQUEST["\x72\x65\x64\151\162\x65\x63\164\137\164\157"] != "\x2f")) {
        goto ZS;
    }
    $h1 = $_REQUEST["\x72\x65\144\x69\162\145\x63\x74\x5f\164\157"];
    ZS:
    delete_site_option("\x6d\157\137\x73\x61\155\x6c\137\x72\x65\x64\x69\162\145\x63\164\x5f\145\x72\x72\157\x72\137\x63\157\x64\145");
    delete_site_option("\x6d\x6f\137\x73\x61\x6d\x6c\x5f\162\x65\144\151\162\145\x63\x74\137\x65\162\162\157\162\x5f\162\145\x61\x73\157\x6e");
    try {
        $AR = get_site_option("\163\141\x6d\x6c\x5f\141\x6d\x5f\x65\x6d\141\x69\x6c");
        $wE = get_site_option("\163\141\x6d\x6c\137\141\x6d\x5f\x75\163\145\x72\x6e\x61\x6d\x65");
        $kT = get_site_option("\163\141\x6d\x6c\137\x61\155\x5f\146\151\x72\x73\164\x5f\156\141\x6d\x65");
        $G0 = get_site_option("\x73\141\x6d\154\x5f\x61\x6d\137\x6c\141\163\164\x5f\x6e\141\x6d\x65");
        $jN = get_site_option("\x73\141\x6d\x6c\137\x61\155\x5f\x67\x72\157\165\x70\137\x6e\141\x6d\145");
        $Dt = get_site_option("\x73\141\x6d\154\137\x61\x6d\x5f\144\145\146\x61\x75\x6c\x74\x5f\x75\x73\x65\x72\x5f\x72\x6f\x6c\x65");
        $eW = get_site_option("\x73\x61\x6d\x6c\137\x61\155\137\x64\157\x6e\x74\137\141\154\x6c\157\x77\x5f\165\156\x6c\x69\x73\164\x65\x64\x5f\x75\163\145\162\137\162\157\154\x65");
        $T0 = get_site_option("\x73\141\x6d\154\x5f\141\x6d\137\141\143\x63\157\x75\156\x74\137\x6d\141\164\x63\x68\145\162");
        $kG = '';
        $OT = '';
        $kT = str_replace("\56", "\137", $kT);
        $kT = str_replace("\x20", "\137", $kT);
        if (!(!empty($kT) && array_key_exists($kT, $_POST))) {
            goto e4;
        }
        $kT = $_POST[$kT];
        e4:
        $G0 = str_replace("\x2e", "\x5f", $G0);
        $G0 = str_replace("\40", "\x5f", $G0);
        if (!(!empty($G0) && array_key_exists($G0, $_POST))) {
            goto V2;
        }
        $G0 = $_POST[$G0];
        V2:
        $wE = str_replace("\56", "\x5f", $wE);
        $wE = str_replace("\40", "\x5f", $wE);
        if (!empty($wE) && array_key_exists($wE, $_POST)) {
            goto LB;
        }
        $OT = $_POST["\x4e\x61\155\145\111\104"];
        goto eH;
        LB:
        $OT = $_POST[$wE];
        eH:
        $kG = str_replace("\x2e", "\x5f", $AR);
        $kG = str_replace("\40", "\137", $AR);
        if (!empty($AR) && array_key_exists($AR, $_POST)) {
            goto iQ;
        }
        $kG = $_POST["\116\x61\x6d\145\111\x44"];
        goto gP;
        iQ:
        $kG = $_POST[$AR];
        gP:
        $jN = str_replace("\56", "\x5f", $jN);
        $jN = str_replace("\40", "\x5f", $jN);
        if (!(!empty($jN) && array_key_exists($jN, $_POST))) {
            goto Lj;
        }
        $jN = $_POST[$jN];
        Lj:
        if (!empty($T0)) {
            goto vo;
        }
        $T0 = "\x65\155\141\x69\154";
        vo:
        $YX = get_site_option("\155\157\x5f\163\x61\155\154\x5f\x63\x75\163\x74\157\155\145\162\x5f\164\157\153\145\x6e");
        if (!(isset($YX) || trim($YX) != '')) {
            goto l5;
        }
        $Cd = AESEncryption::decrypt_data($kG, $YX);
        $kG = $Cd;
        l5:
        if (!(!empty($kT) && !empty($YX))) {
            goto yf;
        }
        $H_ = AESEncryption::decrypt_data($kT, $YX);
        $kT = $H_;
        yf:
        if (!(!empty($G0) && !empty($YX))) {
            goto W9;
        }
        $cF = AESEncryption::decrypt_data($G0, $YX);
        $G0 = $cF;
        W9:
        if (!(!empty($OT) && !empty($YX))) {
            goto eE;
        }
        $oj = AESEncryption::decrypt_data($OT, $YX);
        $OT = $oj;
        eE:
        if (!(!empty($jN) && !empty($YX))) {
            goto Ds;
        }
        $vB = AESEncryption::decrypt_data($jN, $YX);
        $jN = $vB;
        Ds:
    } catch (Exception $L7) {
        echo sprintf("\101\x6e\x20\x65\x72\162\157\162\40\x6f\143\143\165\x72\x72\x65\x64\40\167\x68\x69\154\145\40\160\162\157\x63\x65\163\x73\151\156\x67\x20\x74\150\145\40\x53\101\x4d\x4c\x20\x52\145\163\160\x6f\156\x73\145\56");
        exit;
    }
    $yf = array($jN);
    mo_saml_login_user($kG, $kT, $G0, $OT, $yf, $eW, $Dt, $h1, $T0);
    Yb:
    goto v7;
    hq:
    update_site_option("\155\157\137\x73\x61\x6d\154\x5f\162\145\x64\151\x72\x65\143\164\x5f\x65\162\162\x6f\x72\x5f\143\x6f\x64\145", $_POST["\x45\x52\122\117\122\x5f\122\x45\x41\123\x4f\x4e"]);
    update_site_option("\x6d\x6f\137\163\x61\155\x6c\137\162\x65\144\x69\x72\x65\143\164\137\x65\x72\x72\x6f\x72\x5f\162\x65\141\163\x6f\156", $_POST["\105\122\122\x4f\122\x5f\115\105\123\x53\x41\107\105"]);
    v7:
    m0:
    pS:
}
function mo_saml_relaystate_url($md)
{
    $Qb = parse_url($md, PHP_URL_SCHEME);
    $md = str_replace($Qb . "\x3a\57\x2f", '', $md);
    return $md;
}
function mo_saml_hash_relaystate($md)
{
    $Qb = parse_url($md, PHP_URL_SCHEME);
    $md = str_replace($Qb . "\x3a\57\x2f", '', $md);
    $md = base64_encode($md);
    $nG = cdjsurkhh($md);
    $md = $md . "\56" . $nG;
    return $md;
}
function mo_saml_get_relaystate($md)
{
    if (!filter_var($md, FILTER_VALIDATE_URL)) {
        goto bUZ;
    }
    return $md;
    bUZ:
    $CM = strpos($md, "\56");
    if ($CM) {
        goto Zpt;
    }
    wp_die("\101\x6e\x20\x65\162\x72\x6f\162\x20\157\143\143\x75\162\x65\x64\56\x20\x50\154\145\x61\163\x65\x20\x63\x6f\156\x74\x61\x63\164\x20\x79\157\x75\x72\40\x61\x64\x6d\151\156\151\x73\164\162\x61\x74\x6f\162\56", "\105\x72\x72\157\162\40\72\40\116\157\164\40\x61\x20\164\x72\165\x73\x74\145\x64\x20\163\x6f\x75\162\143\145\x20\157\x66\40\164\150\145\40\123\x41\x4d\x4c\40\162\145\x73\x70\x6f\x6e\x73\x65");
    exit;
    Zpt:
    $zN = substr($md, 0, $CM);
    $tr = substr($md, $CM + 1);
    $VC = cdjsurkhh($zN);
    if (!($tr !== $VC)) {
        goto pqe;
    }
    wp_die("\101\x6e\x20\x65\x72\162\x6f\162\x20\157\143\x63\x75\x72\x65\144\56\40\120\x6c\x65\141\163\x65\x20\143\157\156\x74\141\x63\164\x20\x79\157\x75\162\40\x61\x64\x6d\x69\156\151\163\164\x72\141\x74\x6f\x72\56", "\105\x72\162\x6f\x72\40\x3a\40\116\157\x74\40\141\x20\164\x72\165\x73\x74\145\144\40\163\x6f\165\x72\143\x65\40\x6f\146\40\164\x68\145\x20\123\x41\x4d\114\x20\162\145\163\160\x6f\x6e\x73\145");
    exit;
    pqe:
    $zN = base64_decode($zN);
    return $zN;
}
function cdjsurkhh($pg)
{
    $nG = hash("\x73\x68\x61\65\61\x32", $pg);
    $Yj = substr($nG, 7, 14);
    return $Yj;
}
function mo_saml_parse_url($md)
{
    if (!($md != "\x74\x65\x73\164\x56\141\x6c\x69\x64\x61\164\x65" && $md != "\164\145\163\164\x4e\x65\167\103\145\162\x74\x69\x66\x69\143\x61\x74\145")) {
        goto SZl;
    }
    $H2 = get_site_option("\x6d\157\x5f\x73\x61\x6d\x6c\137\x73\160\137\142\x61\x73\145\137\165\162\154");
    if (!empty($H2)) {
        goto lDw;
    }
    $H2 = get_network_site_url();
    lDw:
    $Qb = parse_url($H2, PHP_URL_SCHEME);
    if (filter_var($md, FILTER_VALIDATE_URL)) {
        goto HDQ;
    }
    $md = $Qb . "\x3a\57\x2f" . $md;
    HDQ:
    SZl:
    return $md;
}
function mo_saml_is_subsite($md)
{
    $o_ = parse_url($md, PHP_URL_HOST);
    $Yq = parse_url($md, PHP_URL_PATH);
    if (is_subdomain_install()) {
        goto PDA;
    }
    $zr = strpos($Yq, "\x2f", 1) != false ? strpos($Yq, "\x2f", 1) : strlen($Yq) - 1;
    $Yq = substr($Yq, 0, $zr + 1);
    $blog_id = get_blog_id_from_url($o_, $Yq);
    goto BTy;
    PDA:
    $blog_id = get_blog_id_from_url($o_);
    BTy:
    if ($blog_id !== 0) {
        goto ANN;
    }
    return false;
    goto MnZ;
    ANN:
    return true;
    MnZ:
}
function mo_saml_show_SAML_log($rv, $Oj)
{
    header("\x43\x6f\x6e\164\145\156\164\x2d\x54\171\160\x65\72\x20\x74\145\170\164\57\150\x74\155\x6c");
    $o7 = new DOMDocument();
    $o7->preserveWhiteSpace = false;
    $o7->formatOutput = true;
    $o7->loadXML($rv);
    if ($Oj == "\x64\x69\163\x70\x6c\141\171\123\x41\115\114\122\145\x71\165\x65\x73\164") {
        goto XV0;
    }
    $Xh = "\123\101\115\x4c\x20\122\x65\163\x70\x6f\x6e\x73\x65";
    goto uNV;
    XV0:
    $Xh = "\x53\101\115\x4c\x20\122\x65\161\165\x65\x73\164";
    uNV:
    $Mg = $o7->saveXML();
    $CE = htmlentities($Mg);
    $CE = rtrim($CE);
    $Pk = simplexml_load_string($Mg);
    $vZ = json_encode($Pk);
    $VB = json_decode($vZ);
    $lf = plugins_url("\x69\156\143\154\x75\x64\x65\x73\57\x63\163\x73\57\x73\164\171\x6c\x65\x5f\x73\x65\164\164\x69\156\147\163\56\143\x73\x73\77\166\x65\162\75\64\x2e\x38\56\64\60", __FILE__);
    echo "\74\154\151\x6e\x6b\x20\x72\x65\x6c\75\47\163\x74\171\x6c\145\x73\150\x65\x65\164\47\40\151\144\x3d\x27\x6d\157\x5f\x73\141\x6d\154\x5f\x61\144\x6d\151\156\137\x73\145\164\164\151\156\x67\163\x5f\163\x74\171\154\x65\x2d\143\x73\163\x27\x20\40\x68\162\145\146\75\47" . $lf . "\x27\40\x74\x79\x70\x65\75\47\164\x65\x78\164\x2f\143\163\163\x27\40\155\145\x64\151\x61\x3d\x27\141\154\x6c\x27\40\57\76\15\xa\x20\x20\x20\x20\x20\40\40\x20\x20\40\x20\x20\15\xa\11\11\11\74\x64\x69\x76\x20\143\x6c\141\163\163\75\x22\155\157\x2d\x64\151\163\x70\x6c\141\x79\55\x6c\157\147\163\42\40\x3e\74\160\x20\164\x79\x70\x65\75\42\x74\x65\170\164\42\40\40\x20\151\144\75\42\x53\x41\x4d\114\x5f\x74\x79\x70\x65\42\x3e" . $Xh . "\74\x2f\x70\x3e\74\x2f\144\151\x76\76\15\xa\x9\11\11\11\xd\12\11\11\11\x3c\144\x69\166\x20\x74\171\160\x65\75\42\164\x65\x78\x74\42\40\151\x64\x3d\x22\x53\101\115\114\137\144\x69\163\160\154\141\x79\42\x20\143\154\141\x73\x73\75\42\155\x6f\x2d\144\151\x73\x70\x6c\x61\171\x2d\142\x6c\157\x63\153\x22\x3e\74\x70\x72\x65\x20\143\154\x61\x73\163\75\47\142\162\x75\163\x68\72\40\x78\x6d\x6c\73\x27\76" . $CE . "\x3c\x2f\x70\x72\145\76\x3c\x2f\x64\x69\166\x3e\xd\12\11\x9\11\74\x62\162\76\xd\12\x9\x9\x9\74\x64\151\x76\11\40\163\x74\171\x6c\x65\x3d\42\155\x61\x72\147\x69\156\x3a\63\45\x3b\144\x69\163\x70\154\141\171\72\142\x6c\x6f\143\153\x3b\x74\x65\x78\164\x2d\141\154\x69\147\156\x3a\x63\x65\x6e\164\145\162\x3b\x22\x3e\15\xa\x20\x20\x20\40\x20\x20\x20\40\40\x20\40\x20\xd\12\11\11\x9\x3c\144\x69\x76\x20\x73\x74\x79\x6c\145\x3d\42\x6d\x61\162\x67\x69\x6e\72\63\45\x3b\x64\151\163\160\x6c\141\171\72\142\154\157\x63\x6b\73\x74\145\170\164\55\x61\x6c\151\x67\156\x3a\x63\145\156\164\145\162\73\x22\40\x3e\xd\xa\x9\15\xa\40\x20\x20\x20\x20\x20\40\x20\x20\x20\40\40\74\x2f\x64\x69\166\76\xd\12\x9\x9\x9\74\142\165\164\x74\157\x6e\40\x69\144\75\x22\x63\x6f\x70\x79\42\x20\x6f\156\143\154\151\x63\x6b\75\42\x63\157\160\x79\104\x69\166\x54\x6f\103\154\151\160\x62\x6f\141\162\144\50\x29\x22\40\40\163\164\x79\154\x65\x3d\x22\160\x61\144\x64\151\156\x67\72\61\x25\x3b\x77\151\144\164\150\x3a\x31\x30\x30\160\x78\x3b\x62\x61\143\x6b\x67\162\x6f\165\x6e\144\72\x20\x23\60\60\x39\x31\x43\x44\x20\x6e\157\x6e\145\x20\x72\145\160\x65\141\164\x20\163\143\x72\157\x6c\154\x20\60\x25\40\60\45\73\x63\x75\x72\163\x6f\162\72\x20\160\x6f\151\156\x74\x65\162\73\x66\x6f\x6e\x74\x2d\x73\x69\172\145\72\61\65\x70\x78\x3b\142\x6f\x72\x64\x65\x72\x2d\167\151\x64\x74\x68\72\40\x31\160\170\x3b\142\157\162\144\x65\x72\x2d\163\164\171\154\x65\72\x20\163\x6f\154\151\144\x3b\x62\157\162\144\145\x72\55\x72\x61\x64\151\x75\x73\x3a\x20\63\160\170\x3b\x77\150\x69\x74\145\55\x73\x70\141\143\x65\72\40\156\157\167\162\x61\x70\x3b\x62\157\x78\x2d\163\x69\x7a\151\x6e\x67\x3a\x20\x62\x6f\x72\144\145\x72\55\x62\x6f\x78\73\142\x6f\162\144\x65\162\55\143\157\154\157\x72\72\x20\43\x30\x30\x37\x33\101\101\x3b\142\x6f\x78\x2d\163\x68\141\144\x6f\x77\72\40\60\160\170\x20\x31\x70\170\40\x30\x70\170\x20\162\147\142\x61\x28\61\62\x30\54\x20\62\60\x30\x2c\x20\x32\x33\x30\54\40\x30\x2e\x36\51\40\151\156\x73\145\x74\x3b\x63\157\x6c\157\x72\72\x20\43\x46\x46\106\x3b\42\x20\x3e\103\x6f\160\171\74\x2f\142\x75\x74\164\157\x6e\x3e\15\xa\11\11\x9\46\x6e\142\163\160\x3b\xd\12\x20\40\x20\40\40\40\x20\x20\40\40\x20\40\x20\40\x20\74\151\x6e\160\x75\x74\40\x69\x64\x3d\42\144\x77\x6e\x2d\x62\164\x6e\42\40\x73\x74\171\154\145\75\x22\x70\x61\144\144\151\156\147\x3a\61\45\x3b\x77\x69\144\x74\150\72\61\x30\60\160\170\73\142\141\143\x6b\147\162\x6f\165\156\x64\72\x20\43\x30\60\71\61\103\x44\x20\x6e\157\x6e\x65\x20\162\145\160\145\141\164\x20\163\x63\x72\157\154\x6c\x20\x30\x25\40\x30\x25\x3b\x63\165\162\x73\x6f\x72\x3a\x20\x70\157\x69\156\164\145\x72\73\x66\157\x6e\x74\55\163\x69\x7a\x65\72\61\x35\x70\170\x3b\142\x6f\162\x64\x65\162\55\x77\x69\144\164\150\72\40\61\160\x78\x3b\x62\x6f\x72\x64\145\x72\x2d\x73\x74\171\x6c\x65\72\x20\x73\157\x6c\151\x64\73\142\157\162\x64\145\162\x2d\x72\x61\144\x69\165\163\72\40\x33\x70\170\73\167\150\151\164\x65\x2d\x73\x70\141\x63\145\x3a\x20\x6e\x6f\x77\x72\141\x70\73\142\157\x78\55\163\151\172\x69\156\x67\72\x20\142\x6f\x72\x64\x65\162\55\142\157\x78\x3b\142\x6f\x72\144\x65\162\x2d\x63\157\x6c\157\162\72\x20\43\60\60\x37\x33\101\101\73\x62\157\170\x2d\x73\150\x61\x64\157\x77\72\40\60\x70\170\40\61\160\170\x20\x30\x70\x78\40\162\147\142\x61\50\x31\62\60\54\40\x32\x30\x30\x2c\40\62\63\x30\54\x20\x30\56\66\x29\x20\x69\156\163\145\164\x3b\143\x6f\x6c\x6f\x72\72\40\x23\106\x46\106\73\42\x74\171\x70\x65\x3d\x22\142\x75\164\x74\157\156\42\x20\x76\x61\154\165\145\75\x22\104\157\167\156\154\157\141\144\x22\x20\15\xa\40\x20\40\40\x20\40\40\x20\x20\40\40\x20\40\40\40\42\x3e\15\12\x9\x9\11\x3c\57\144\151\x76\x3e\xd\12\11\11\x9\x3c\x2f\144\151\166\76\xd\12\11\x9\11\xd\xa\x9\11\xd\xa\11\x9\11";
    ob_end_flush();
    echo "\xd\12\x9\74\x73\143\x72\151\x70\x74\76\xd\12\xd\xa\40\x20\40\x20\40\x20\40\x20\146\165\x6e\143\164\151\157\156\x20\143\157\160\171\x44\151\166\124\157\x43\x6c\x69\x70\x62\x6f\x61\x72\144\x28\x29\40\173\xd\xa\x20\x20\x20\40\40\x20\40\40\40\40\x20\40\x76\141\162\40\x61\x75\x78\40\x3d\40\144\x6f\143\x75\x6d\145\156\164\56\x63\x72\x65\x61\164\145\x45\x6c\145\155\145\156\x74\50\x22\x69\x6e\160\165\164\x22\51\73\xd\12\40\40\40\x20\40\40\40\x20\40\x20\40\40\141\165\x78\x2e\163\x65\x74\101\164\164\x72\x69\x62\165\164\x65\50\x22\166\x61\154\165\x65\42\x2c\40\144\157\143\165\x6d\145\156\x74\x2e\147\145\164\x45\154\x65\x6d\145\156\x74\x42\x79\111\144\x28\x22\x53\x41\115\114\137\x64\151\163\x70\154\141\x79\42\51\x2e\x74\145\170\x74\103\157\156\x74\x65\x6e\164\x29\x3b\15\xa\40\40\40\40\x20\x20\x20\x20\x20\x20\40\40\144\157\143\x75\x6d\145\156\164\x2e\x62\157\144\x79\56\141\x70\160\145\156\144\103\150\151\154\x64\50\141\x75\x78\51\x3b\15\12\40\40\40\40\x20\x20\x20\x20\40\x20\40\x20\x61\x75\170\x2e\163\145\154\145\x63\164\50\x29\x3b\xd\xa\x20\40\x20\x20\x20\x20\40\40\x20\x20\40\40\x64\x6f\x63\165\155\145\156\x74\56\145\x78\x65\x63\103\157\155\155\141\156\x64\50\x22\143\157\160\171\x22\51\73\15\xa\40\40\x20\x20\x20\40\40\x20\x20\40\x20\40\144\157\x63\165\155\145\156\164\x2e\142\x6f\x64\x79\56\x72\x65\155\x6f\166\145\103\150\151\x6c\144\50\x61\x75\170\x29\x3b\xd\12\x20\40\x20\x20\40\40\40\40\x20\x20\40\x20\x64\157\143\x75\155\x65\156\164\x2e\x67\x65\x74\105\154\x65\x6d\145\156\164\102\171\x49\144\50\47\x63\157\160\x79\x27\51\56\164\x65\170\164\103\x6f\156\164\x65\156\x74\40\x3d\40\x22\103\x6f\160\151\x65\x64\42\73\15\xa\40\40\40\x20\40\x20\40\x20\40\x20\x20\x20\144\157\x63\x75\x6d\x65\x6e\x74\56\147\145\164\x45\x6c\145\x6d\x65\x6e\x74\x42\x79\x49\144\x28\47\x63\x6f\x70\171\47\51\x2e\x73\164\x79\154\x65\56\x62\x61\143\x6b\x67\162\157\165\156\x64\x20\x3d\40\42\x67\162\x65\171\42\x3b\xd\12\x20\40\x20\40\x20\x20\40\x20\40\40\x20\x20\x77\x69\x6e\144\157\167\x2e\x67\x65\164\x53\x65\154\x65\x63\x74\151\x6f\x6e\x28\x29\56\163\145\x6c\145\x63\164\101\x6c\154\x43\x68\151\x6c\144\162\145\156\50\x20\x64\x6f\x63\165\155\145\x6e\x74\x2e\x67\x65\x74\x45\154\145\155\145\x6e\164\102\171\x49\x64\x28\x20\42\x53\x41\115\x4c\137\x64\x69\x73\x70\154\141\171\x22\x20\51\x20\51\x3b\15\12\xd\12\40\40\40\x20\40\40\40\x20\175\xd\xa\xd\xa\40\40\40\x20\x20\x20\40\40\x66\165\x6e\x63\x74\151\x6f\156\40\144\x6f\167\156\154\x6f\x61\x64\x28\x66\x69\154\145\156\141\x6d\x65\54\40\164\145\170\164\x29\x20\173\xd\xa\x20\x20\40\40\x20\40\40\40\40\x20\x20\x20\166\x61\x72\40\x65\x6c\x65\155\x65\156\x74\40\75\40\x64\x6f\143\165\x6d\x65\156\164\56\x63\x72\x65\141\164\x65\x45\154\145\155\145\x6e\x74\50\x27\x61\x27\51\x3b\15\xa\x20\40\40\x20\x20\x20\x20\x20\40\40\x20\40\x65\154\145\155\145\156\x74\56\x73\145\164\x41\x74\x74\x72\x69\142\x75\164\x65\x28\x27\x68\x72\145\146\47\x2c\x20\47\x64\x61\164\x61\x3a\x41\x70\160\x6c\151\143\x61\x74\x69\x6f\x6e\x2f\x6f\143\164\145\164\55\163\x74\162\x65\x61\x6d\x3b\143\150\141\162\163\145\x74\75\165\164\146\x2d\70\x2c\47\40\x2b\x20\145\x6e\143\x6f\144\145\125\x52\x49\x43\157\155\x70\x6f\156\x65\x6e\x74\x28\164\x65\170\x74\51\x29\73\15\12\x20\x20\40\x20\x20\40\40\x20\x20\x20\40\x20\145\x6c\x65\x6d\145\x6e\x74\x2e\163\x65\x74\x41\x74\164\x72\x69\x62\165\x74\145\x28\x27\x64\157\167\156\x6c\157\x61\144\x27\x2c\x20\146\x69\x6c\x65\156\141\155\x65\51\73\15\12\15\xa\40\x20\40\x20\40\x20\40\40\40\x20\x20\40\145\x6c\145\x6d\145\156\x74\x2e\x73\x74\x79\154\x65\x2e\144\x69\x73\160\154\x61\171\x20\75\40\x27\x6e\x6f\x6e\x65\47\x3b\xd\xa\x20\40\40\40\40\40\x20\x20\x20\x20\40\x20\x64\x6f\x63\165\x6d\x65\156\x74\x2e\142\x6f\x64\x79\x2e\141\x70\160\145\156\144\x43\x68\x69\154\144\50\145\x6c\x65\155\145\156\164\51\x3b\15\12\15\xa\40\40\x20\x20\x20\40\x20\x20\40\x20\x20\40\145\x6c\x65\x6d\145\156\x74\x2e\143\154\151\x63\x6b\50\51\x3b\15\12\xd\xa\x20\40\x20\40\x20\40\40\x20\x20\x20\x20\x20\144\x6f\x63\x75\155\x65\156\164\56\142\x6f\144\x79\56\162\x65\x6d\x6f\x76\145\103\150\151\x6c\144\x28\x65\154\x65\x6d\x65\x6e\164\51\73\xd\xa\x20\x20\x20\40\x20\x20\40\40\x7d\xd\xa\15\xa\40\40\40\40\40\x20\x20\x20\x64\157\x63\x75\x6d\145\x6e\x74\x2e\147\x65\x74\x45\x6c\x65\x6d\x65\156\x74\102\x79\111\144\x28\42\x64\x77\x6e\x2d\142\164\x6e\42\51\x2e\x61\144\144\x45\166\145\x6e\x74\x4c\x69\163\164\145\156\145\162\x28\x22\143\x6c\x69\x63\x6b\x22\x2c\40\x66\165\156\143\x74\151\157\x6e\40\x28\51\40\x7b\xd\xa\xd\xa\x20\40\40\40\x20\x20\40\40\x20\x20\40\40\166\x61\162\x20\146\151\154\145\156\x61\x6d\x65\40\x3d\40\144\x6f\143\x75\155\145\156\164\x2e\x67\x65\x74\105\x6c\x65\x6d\x65\x6e\x74\x42\171\111\x64\x28\42\123\101\x4d\114\137\164\x79\x70\x65\x22\51\x2e\x74\145\170\164\103\157\156\x74\x65\x6e\x74\53\42\56\170\x6d\154\42\x3b\15\xa\x20\x20\40\x20\40\40\40\40\40\x20\x20\40\x76\141\x72\x20\x6e\157\x64\x65\40\75\x20\x64\x6f\x63\165\x6d\x65\156\x74\x2e\x67\145\x74\x45\x6c\145\x6d\x65\x6e\x74\x42\171\111\144\x28\x22\123\101\x4d\x4c\x5f\144\x69\163\x70\154\141\x79\x22\51\73\15\12\x20\40\x20\40\x20\40\40\x20\x20\40\40\x20\150\x74\x6d\154\103\157\156\164\x65\x6e\x74\x20\75\x20\156\x6f\x64\x65\x2e\151\x6e\156\x65\162\110\124\x4d\x4c\73\xd\xa\40\x20\x20\40\x20\x20\x20\x20\40\40\x20\x20\164\x65\170\164\40\75\x20\156\x6f\x64\145\x2e\164\145\170\164\x43\157\156\x74\x65\x6e\x74\x3b\xd\xa\40\40\40\40\x20\40\x20\40\x20\x20\x20\x20\143\157\156\163\157\x6c\x65\56\x6c\157\147\50\x74\145\170\x74\51\x3b\15\xa\x20\x20\x20\40\x20\40\40\x20\x20\x20\40\x20\144\x6f\x77\156\x6c\x6f\141\x64\50\x66\x69\x6c\145\x6e\x61\155\x65\x2c\x20\x74\145\170\164\x29\73\15\xa\x20\x20\40\40\x20\40\40\x20\175\54\40\146\x61\x6c\163\145\x29\73\15\xa\xd\12\15\12\xd\xa\xd\12\xd\xa\x20\40\x20\40\74\x2f\x73\143\x72\151\160\164\x3e\15\12";
    exit;
}
function mo_saml_checkMapping($l1, $md, $F0)
{
    try {
        $AR = get_site_option("\x73\141\x6d\x6c\x5f\x61\155\x5f\x65\x6d\141\x69\154");
        $wE = get_site_option("\x73\x61\x6d\154\x5f\141\x6d\x5f\165\x73\x65\162\156\141\x6d\145");
        $kT = get_site_option("\x73\141\155\154\x5f\141\155\137\146\x69\162\163\164\137\x6e\141\155\x65");
        $G0 = get_site_option("\163\x61\155\154\x5f\x61\155\137\154\x61\x73\164\x5f\x6e\x61\x6d\x65");
        $jN = get_site_option("\163\141\x6d\154\x5f\x61\x6d\x5f\147\162\x6f\x75\x70\137\156\141\x6d\145");
        $tM = array();
        $tM = maybe_unserialize(get_site_option("\x73\x61\155\x6c\137\x61\155\137\162\x6f\154\x65\137\155\x61\160\160\x69\x6e\x67"));
        $T0 = get_site_option("\163\141\155\x6c\137\141\x6d\137\x61\x63\x63\157\165\156\x74\x5f\x6d\x61\x74\x63\x68\145\x72");
        $kG = '';
        $OT = '';
        if (empty($l1)) {
            goto gh9;
        }
        if (!empty($kT) && array_key_exists($kT, $l1)) {
            goto nhl;
        }
        $kT = '';
        goto X9s;
        nhl:
        $kT = $l1[$kT][0];
        X9s:
        if (!empty($G0) && array_key_exists($G0, $l1)) {
            goto jKj;
        }
        $G0 = '';
        goto ARb;
        jKj:
        $G0 = $l1[$G0][0];
        ARb:
        if (!empty($wE) && array_key_exists($wE, $l1)) {
            goto qkm;
        }
        $OT = $l1["\116\141\155\145\x49\x44"][0];
        goto n7Y;
        qkm:
        $OT = $l1[$wE][0];
        n7Y:
        if (!empty($AR) && array_key_exists($AR, $l1)) {
            goto XBo;
        }
        $kG = $l1["\116\141\x6d\145\x49\x44"][0];
        goto chT;
        XBo:
        $kG = $l1[$AR][0];
        chT:
        if (!empty($jN) && array_key_exists($jN, $l1)) {
            goto E72;
        }
        $jN = array();
        goto GlU;
        E72:
        $jN = $l1[$jN];
        GlU:
        if (!empty($T0)) {
            goto l3t;
        }
        $T0 = "\x65\155\141\x69\x6c";
        l3t:
        gh9:
        if ($md == "\x74\x65\x73\x74\126\141\x6c\151\144\x61\164\x65") {
            goto KKk;
        }
        if ($md == "\164\145\163\164\x4e\x65\x77\x43\x65\x72\164\x69\146\x69\x63\x61\164\x65") {
            goto jcO;
        }
        mo_saml_login_user($kG, $kT, $G0, $OT, $jN, $tM, $md, $T0, $F0, $l1["\x4e\141\x6d\x65\111\x44"][0], $l1);
        goto kNA;
        KKk:
        update_site_option("\x6d\x6f\137\x73\141\155\154\137\164\x65\163\164", "\x54\x65\x73\164\40\123\165\143\x63\x65\163\163\146\165\x6c");
        mo_saml_show_test_result($kT, $G0, $kG, $jN, $l1, $md);
        goto kNA;
        jcO:
        update_site_option("\155\x6f\x5f\163\x61\x6d\154\x5f\x74\145\163\164\137\156\x65\167\137\x63\x65\162\164", "\124\x65\x73\164\40\x73\165\x63\x63\145\163\x73\x66\165\154");
        mo_saml_show_test_result($kT, $G0, $kG, $jN, $l1, $md);
        kNA:
    } catch (Exception $L7) {
        echo sprintf("\101\156\40\145\x72\162\x6f\x72\40\x6f\x63\x63\165\x72\162\x65\x64\40\x77\x68\151\x6c\145\40\x70\162\x6f\143\145\163\x73\x69\156\x67\x20\x74\x68\x65\40\123\x41\115\x4c\x20\x52\x65\163\160\157\156\x73\x65\x2e");
        exit;
    }
}
function mo_saml_show_test_result($kT, $G0, $kG, $jN, $l1, $md)
{
    echo "\74\144\151\166\40\x73\164\x79\x6c\x65\75\x22\146\157\156\x74\x2d\x66\141\155\x69\x6c\x79\72\103\141\154\151\142\162\x69\73\160\141\144\144\x69\x6e\x67\72\x30\x20\63\45\x3b\42\76";
    if (!empty($kG)) {
        goto HBD;
    }
    echo "\x3c\x64\151\x76\40\x73\164\171\154\x65\x3d\42\x63\x6f\154\x6f\162\x3a\x20\x23\x61\x39\64\x34\64\x32\73\x62\x61\x63\x6b\x67\x72\157\x75\x6e\x64\55\x63\x6f\154\x6f\x72\72\40\43\146\x32\144\x65\x64\145\73\160\x61\144\x64\x69\156\x67\72\40\x31\65\160\x78\x3b\155\x61\162\x67\x69\x6e\55\142\x6f\x74\164\157\x6d\x3a\x20\x32\60\160\x78\x3b\x74\145\x78\164\55\x61\154\151\x67\x6e\72\143\x65\156\x74\x65\x72\x3b\142\157\x72\144\145\162\72\x31\160\170\40\x73\x6f\154\151\144\x20\43\x45\66\102\x33\102\x32\x3b\x66\157\x6e\x74\55\x73\x69\172\145\72\x31\x38\x70\x74\73\x22\76\124\x45\x53\x54\40\106\101\111\x4c\105\104\74\57\144\x69\x76\76\xd\xa\11\11\x9\11\x9\x9\x3c\144\x69\x76\x20\x73\x74\x79\154\145\x3d\x22\143\157\154\157\x72\x3a\40\43\141\x39\64\x34\x34\x32\73\146\x6f\x6e\164\x2d\163\151\172\x65\x3a\61\x34\160\x74\x3b\40\x6d\141\162\147\x69\156\x2d\142\157\164\164\157\x6d\72\62\60\160\x78\73\x22\x3e\x57\x41\122\116\x49\116\x47\x3a\x20\123\x6f\155\x65\40\x41\164\164\x72\151\x62\x75\x74\x65\x73\40\x44\x69\144\x20\x4e\x6f\x74\40\115\x61\164\143\150\x2e\74\x2f\x64\151\166\76\15\xa\11\11\x9\11\11\11\x3c\x64\x69\166\x20\163\x74\171\x6c\x65\x3d\x22\x64\x69\x73\x70\154\141\x79\x3a\142\154\x6f\x63\153\x3b\x74\x65\x78\164\x2d\x61\154\x69\x67\156\x3a\x63\145\156\x74\145\162\x3b\155\x61\162\147\151\x6e\x2d\142\157\164\x74\157\155\x3a\64\45\x3b\42\76\x3c\151\x6d\x67\x20\x73\164\x79\x6c\145\x3d\x22\x77\151\144\x74\150\72\x31\65\45\x3b\42\163\162\143\75\x22" . plugin_dir_url(__FILE__) . "\151\x6d\141\147\x65\163\57\x77\162\x6f\x6e\147\56\x70\156\x67\x22\76\74\57\x64\151\x76\x3e";
    goto S7V;
    HBD:
    update_site_option("\155\x6f\137\x73\141\x6d\154\x5f\x74\145\x73\x74\x5f\x63\x6f\156\x66\151\x67\x5f\x61\164\x74\162\163", $l1);
    echo "\x3c\144\151\x76\40\x73\x74\171\x6c\x65\75\x22\143\x6f\x6c\157\162\x3a\40\x23\63\143\67\x36\x33\x64\x3b\xd\12\11\11\x9\11\x9\x9\x62\141\x63\x6b\147\162\157\x75\156\x64\x2d\143\157\x6c\157\162\72\x20\43\x64\x66\146\x30\144\x38\73\x20\x70\x61\144\144\151\156\x67\x3a\62\45\x3b\x6d\x61\162\x67\151\x6e\55\142\x6f\x74\164\x6f\x6d\72\62\x30\x70\170\x3b\164\x65\170\x74\55\x61\154\151\147\x6e\72\x63\145\156\x74\x65\x72\73\x20\142\x6f\x72\144\145\x72\72\x31\160\x78\40\163\x6f\154\151\144\40\43\x41\105\x44\102\71\101\73\40\x66\x6f\x6e\x74\55\x73\151\172\x65\72\61\x38\160\164\x3b\x22\76\x54\x45\x53\x54\x20\x53\x55\103\x43\x45\x53\123\106\x55\x4c\x3c\x2f\144\151\x76\x3e\xd\12\11\x9\x9\11\x9\x9\74\x64\151\x76\x20\x73\x74\171\x6c\x65\x3d\x22\144\x69\x73\160\x6c\141\171\72\142\x6c\157\143\153\73\164\145\170\x74\55\x61\x6c\151\147\x6e\x3a\143\145\x6e\164\145\162\x3b\155\x61\162\x67\x69\x6e\x2d\142\157\164\x74\157\155\72\64\x25\73\42\x3e\x3c\151\x6d\x67\40\163\164\x79\x6c\145\x3d\x22\x77\151\144\x74\150\72\x31\65\45\x3b\42\163\x72\x63\75\42" . plugin_dir_url(__FILE__) . "\151\155\x61\147\x65\x73\57\x67\162\145\145\x6e\x5f\x63\150\x65\x63\x6b\56\x70\156\x67\x22\x3e\x3c\x2f\x64\x69\x76\76";
    S7V:
    $u7 = $md == "\164\145\163\x74\x4e\x65\x77\103\145\x72\x74\151\146\151\x63\141\x74\145" ? "\x64\151\163\x70\154\x61\x79\72\x6e\157\x6e\145" : '';
    $OP = get_site_option("\163\x61\155\154\x5f\141\x6d\137\141\143\x63\157\x75\x6e\x74\137\155\141\x74\143\150\x65\x72") ? get_site_option("\163\x61\155\x6c\x5f\x61\155\x5f\x61\x63\x63\x6f\165\156\x74\x5f\155\141\164\143\x68\145\162") : "\145\x6d\x61\x69\x6c";
    if (!($OP == "\x65\155\141\x69\x6c" && !filter_var($l1["\116\141\x6d\x65\x49\x44"][0], FILTER_VALIDATE_EMAIL))) {
        goto YXm;
    }
    echo "\74\x70\76\x3c\146\x6f\x6e\164\40\x63\x6f\x6c\x6f\162\x3d\x22\x23\x46\x46\60\x30\60\60\x22\40\x73\164\x79\154\x65\75\42\x66\157\156\x74\55\x73\x69\x7a\x65\72\x31\64\x70\x74\x22\x3e\x28\x57\x61\162\156\151\156\x67\x3a\40\x54\x68\x65\x20\116\141\155\145\x49\104\x20\166\141\154\165\145\40\x69\163\x20\x6e\157\x74\40\x61\x20\x76\x61\x6c\151\144\x20\x45\155\141\x69\x6c\40\x49\x44\51\x3c\x2f\146\157\156\164\x3e\x3c\57\160\76";
    YXm:
    echo "\74\163\x70\141\156\x20\163\164\x79\154\x65\75\x22\x66\x6f\156\x74\55\163\151\172\145\x3a\x31\64\x70\164\x3b\42\x3e\x3c\x62\76\110\145\x6c\x6c\157\x3c\57\142\x3e\x2c\40" . $kG . "\x3c\57\163\x70\141\156\x3e\x3c\142\162\57\x3e\74\x70\40\163\164\x79\154\x65\x3d\42\146\157\x6e\x74\x2d\x77\145\x69\147\x68\x74\x3a\142\x6f\154\x64\x3b\x66\157\156\x74\x2d\163\151\172\x65\72\61\x34\160\164\73\155\x61\x72\147\x69\156\x2d\154\x65\146\164\x3a\x31\45\x3b\42\76\101\124\x54\x52\x49\102\x55\x54\105\123\40\x52\x45\x43\105\x49\x56\x45\x44\x3a\74\57\x70\76\15\xa\x9\11\11\11\x9\x3c\164\141\142\x6c\x65\40\x73\164\171\x6c\145\x3d\42\x62\x6f\162\x64\x65\162\55\x63\157\x6c\154\x61\160\163\145\72\143\157\154\x6c\x61\160\x73\145\x3b\142\157\x72\x64\x65\x72\55\163\160\141\143\151\156\147\72\60\x3b\x20\x64\151\x73\x70\x6c\x61\x79\x3a\x74\x61\x62\154\x65\x3b\x77\x69\x64\x74\x68\72\x31\x30\x30\x25\x3b\40\x66\x6f\x6e\x74\x2d\163\151\x7a\145\x3a\x31\64\160\164\x3b\142\x61\143\153\x67\162\x6f\165\156\144\x2d\143\157\x6c\157\x72\x3a\x23\105\x44\105\x44\105\104\73\42\76\15\xa\x9\11\x9\11\x9\x9\x3c\x74\x72\40\163\x74\171\154\x65\75\x22\164\x65\x78\164\55\141\154\x69\x67\x6e\72\143\x65\x6e\x74\x65\162\x3b\x22\x3e\x3c\164\x64\40\163\164\171\154\x65\x3d\x22\146\x6f\156\x74\55\x77\x65\151\x67\x68\x74\72\142\x6f\x6c\144\73\142\x6f\x72\144\145\x72\72\62\160\x78\x20\163\157\154\x69\144\x20\43\x39\x34\71\x30\71\60\x3b\160\141\144\x64\151\156\147\72\62\x25\73\x22\76\101\124\124\122\x49\x42\125\124\x45\x20\116\x41\x4d\x45\x3c\x2f\x74\144\76\x3c\164\144\40\163\164\x79\154\x65\75\42\146\157\x6e\x74\55\x77\145\151\x67\150\x74\72\142\157\154\144\x3b\160\x61\x64\x64\151\156\147\x3a\x32\45\x3b\142\x6f\x72\144\145\x72\x3a\62\x70\170\40\x73\157\x6c\151\144\40\x23\71\64\x39\60\x39\x30\73\x20\167\157\x72\x64\x2d\167\x72\x61\160\72\142\x72\x65\141\x6b\x2d\167\157\162\x64\73\42\x3e\x41\x54\x54\x52\111\102\125\124\105\40\x56\x41\114\125\x45\74\57\164\x64\x3e\x3c\57\164\162\76";
    if (!empty($l1)) {
        goto hoW;
    }
    echo "\x4e\157\x20\x41\x74\x74\162\151\x62\165\x74\145\163\x20\x52\x65\143\x65\x69\x76\x65\144\56";
    goto yWt;
    hoW:
    foreach ($l1 as $YX => $yS) {
        echo "\74\x74\162\76\74\x74\x64\x20\163\x74\171\154\145\x3d\47\146\157\x6e\164\x2d\x77\145\x69\147\150\164\x3a\142\157\x6c\x64\73\142\x6f\x72\x64\x65\x72\72\x32\160\x78\x20\x73\x6f\154\x69\x64\x20\43\71\64\x39\x30\71\60\x3b\160\141\144\x64\151\x6e\x67\x3a\x32\45\73\x27\x3e" . $YX . "\x3c\x2f\164\x64\x3e\74\x74\144\x20\x73\x74\171\154\145\x3d\47\160\141\x64\x64\151\x6e\x67\x3a\x32\x25\73\x62\x6f\162\x64\x65\162\72\62\x70\170\40\163\157\x6c\x69\x64\40\43\x39\x34\71\60\x39\x30\73\x20\x77\x6f\162\144\55\167\162\x61\x70\x3a\x62\162\145\x61\153\x2d\167\x6f\x72\x64\73\x27\76" . implode("\x3c\x68\162\x2f\x3e", $yS) . "\74\x2f\164\144\76\74\x2f\164\162\x3e";
        nK2:
    }
    f5H:
    yWt:
    echo "\74\57\164\x61\142\154\145\x3e\x3c\57\x64\x69\x76\x3e";
    echo "\74\x64\x69\166\40\163\x74\x79\154\145\75\42\155\x61\162\x67\x69\156\72\x33\45\73\144\151\x73\160\x6c\141\171\72\142\x6c\157\143\153\x3b\x74\145\170\164\x2d\141\154\151\x67\156\72\143\x65\x6e\164\145\x72\73\x22\76\xd\12\x9\x9\11\x9\x9\11\11\x3c\151\156\x70\x75\164\40\163\164\171\154\x65\75\x22\160\141\x64\x64\151\x6e\x67\72\61\45\73\x77\151\x64\x74\x68\x3a\x32\x35\x30\x70\170\73\142\x61\x63\153\x67\162\x6f\165\156\144\x3a\40\x23\x30\60\x39\x31\103\104\40\x6e\157\156\145\40\162\x65\x70\x65\x61\164\x20\x73\x63\162\x6f\154\x6c\x20\x30\45\40\60\x25\73\15\12\x9\11\x9\11\11\11\11\x63\x75\x72\x73\157\162\72\40\x70\x6f\x69\x6e\x74\x65\162\73\146\157\x6e\x74\x2d\x73\151\172\145\72\x31\65\160\x78\x3b\142\x6f\162\144\145\x72\55\x77\151\144\x74\x68\x3a\40\x31\x70\x78\x3b\142\x6f\x72\x64\x65\x72\x2d\x73\164\x79\154\145\72\40\163\157\x6c\x69\144\x3b\142\x6f\x72\x64\x65\x72\55\x72\x61\144\x69\x75\163\72\40\x33\x70\170\73\x77\150\151\164\145\x2d\x73\160\x61\x63\145\72\15\xa\11\x9\11\11\11\x9\11\156\x6f\x77\162\141\160\73\x62\x6f\x78\55\x73\151\172\151\x6e\147\x3a\40\x62\157\x72\144\145\x72\55\x62\157\170\x3b\142\157\162\x64\145\x72\x2d\x63\157\x6c\x6f\x72\x3a\40\43\x30\x30\x37\x33\101\101\73\x62\157\x78\55\163\150\x61\x64\157\167\72\40\60\160\x78\x20\x31\x70\170\40\60\160\170\x20\162\147\142\141\50\61\x32\60\54\x20\x32\60\x30\x2c\x20\62\63\x30\54\40\x30\x2e\x36\x29\40\x69\x6e\163\145\164\x3b\143\x6f\154\157\162\x3a\40\43\106\106\x46\x3b" . $u7 . "\x22\xd\12\x9\x9\11\11\11\x9\x9\x9\x74\171\x70\145\x3d\x22\142\x75\164\x74\x6f\156\x22\40\x76\141\x6c\x75\x65\75\42\x43\157\x6e\146\x69\147\165\x72\x65\x20\x41\x74\164\x72\x69\x62\x75\164\x65\57\122\157\x6c\x65\x20\x4d\141\160\x70\x69\156\x67\42\40\x6f\156\103\154\x69\143\153\75\42\143\x6c\x6f\x73\145\137\x61\156\144\x5f\162\x65\x64\151\162\x65\143\164\50\x29\x3b\x22\x3e\40\46\x6e\x62\x73\160\x3b\40\15\xa\x9\x9\11\11\11\x9\x9\11\15\xa\11\x9\x9\x9\x9\x9\11\74\151\x6e\x70\165\164\40\163\164\171\x6c\145\x3d\42\x70\x61\144\144\151\x6e\x67\x3a\x31\45\73\x77\x69\x64\x74\x68\x3a\61\x30\x30\160\x78\73\x62\141\143\x6b\x67\162\157\x75\x6e\144\72\40\43\x30\60\71\x31\x43\x44\x20\156\x6f\x6e\145\40\162\145\160\145\x61\x74\x20\x73\x63\162\157\x6c\154\40\60\x25\40\60\x25\73\x63\x75\162\163\x6f\162\x3a\40\160\x6f\151\x6e\x74\145\x72\x3b\x66\157\156\164\55\x73\x69\172\145\x3a\x31\x35\x70\170\x3b\x62\x6f\x72\x64\145\x72\x2d\167\151\x64\164\x68\x3a\x20\x31\x70\x78\x3b\x62\x6f\x72\x64\x65\162\55\163\164\171\154\145\x3a\40\x73\157\154\151\144\73\142\157\x72\x64\x65\162\55\x72\x61\144\151\x75\163\x3a\40\63\x70\170\x3b\x77\150\x69\x74\145\55\163\x70\x61\143\x65\72\x20\x6e\157\x77\162\x61\x70\x3b\x62\x6f\170\55\x73\x69\172\151\156\147\x3a\x20\x62\x6f\x72\x64\145\x72\x2d\x62\x6f\x78\73\x62\157\x72\x64\145\162\x2d\x63\157\154\x6f\162\72\x20\x23\x30\60\x37\63\x41\x41\73\142\157\x78\x2d\163\150\x61\144\x6f\167\x3a\x20\x30\160\x78\x20\x31\160\x78\x20\x30\x70\x78\x20\x72\x67\142\x61\x28\x31\x32\x30\x2c\x20\x32\x30\60\x2c\x20\62\63\x30\54\x20\x30\x2e\66\x29\x20\x69\x6e\163\x65\x74\73\143\x6f\154\x6f\162\x3a\40\43\106\x46\x46\73\x22\x74\171\160\145\75\x22\x62\165\x74\x74\x6f\156\x22\x20\166\141\x6c\x75\x65\75\42\104\157\156\x65\x22\x20\x6f\156\103\154\x69\143\153\75\x22\x73\145\154\146\x2e\x63\x6c\x6f\163\145\x28\x29\x3b\x22\x3e\74\x2f\144\151\x76\76\xd\12\x9\x9\x9\11\11\x9\x9\x9\x9\x9\x9\x9\74\x73\143\x72\151\160\x74\76\15\12\x20\40\40\x20\40\40\40\x20\x20\x20\x20\x20\15\12\x9\x9\x9\11\11\x9\x9\146\x75\x6e\143\x74\x69\157\156\40\x63\154\x6f\163\x65\x5f\x61\x6e\x64\x5f\162\145\x64\x69\162\x65\143\x74\x28\51\x7b\15\12\x9\x9\x9\x9\11\x9\11\11\x77\151\156\144\157\167\56\x6f\x70\x65\156\145\x72\x2e\162\x65\x64\x69\162\x65\143\164\x5f\x74\x6f\137\141\164\164\x72\x69\x62\x75\x74\x65\x5f\x6d\x61\x70\x70\151\156\x67\50\x29\x3b\15\xa\11\x9\11\x9\11\x9\x9\11\163\x65\x6c\146\x2e\x63\154\157\163\145\50\51\73\15\xa\11\x9\x9\11\11\x9\x9\175\15\xa\11\11\11\x9\x9\11\x9\xd\12\x9\x9\11\11\x9\x9\11\146\165\156\143\x74\151\x6f\156\x20\x72\x65\x66\x72\145\163\150\x50\141\162\145\156\x74\50\51\40\x7b\xd\12\11\x9\x9\11\11\11\x9\x9\x77\x69\x6e\x64\x6f\167\56\157\x70\x65\x6e\x65\162\x2e\x6c\157\x63\141\164\151\x6f\156\x2e\162\x65\x6c\157\x61\144\x28\x29\x3b\xd\12\11\x9\x9\x9\x9\11\x9\175\15\12\x9\11\11\x9\x9\x9\11\x3c\57\163\x63\x72\x69\x70\164\x3e";
    exit;
}
function mo_saml_convert_to_windows_iconv($sR)
{
    $BU = get_site_option("\155\157\137\x73\x61\x6d\154\137\145\156\143\x6f\x64\151\156\x67\137\x65\x6e\x61\x62\154\x65\x64");
    if (!($BU === '')) {
        goto tYk;
    }
    return $sR;
    tYk:
    return iconv("\125\x54\106\x2d\x38", "\103\x50\x31\62\65\62\x2f\x2f\x49\x47\116\x4f\122\105", $sR);
}
function mo_saml_login_user($kG, $kT, $G0, $OT, $jN, $tM, $md, $T0, $F0 = '', $LV = '', $l1 = null)
{
    do_action("\x6d\157\x5f\x61\x62\x72\137\146\x69\x6c\164\145\162\x5f\154\157\x67\x69\156", $l1);
    $OT = mo_saml_sanitize_username($OT);
    if (get_site_option("\x6d\157\x5f\163\141\155\x6c\x5f\x64\x69\163\x61\x62\x6c\x65\x5f\162\x6f\x6c\x65\x5f\x6d\141\160\160\151\x6e\x67")) {
        goto mLT;
    }
    check_if_user_allowed_to_login_due_to_role_restriction($jN);
    mLT:
    $H2 = get_site_option("\155\157\137\x73\x61\155\154\137\x73\x70\137\x62\141\x73\145\x5f\x75\162\x6c");
    mo_saml_restrict_users_based_on_domain($kG);
    if (!empty($tM)) {
        goto Tj3;
    }
    $tM["\x44\x45\x46\x41\x55\x4c\x54"]["\144\x65\146\141\x75\154\x74\137\162\157\154\x65"] = "\x73\x75\x62\163\x63\162\x69\x62\145\x72";
    $tM["\x44\105\106\x41\x55\114\x54"]["\144\157\x6e\x74\x5f\141\154\x6c\x6f\167\x5f\x75\156\154\151\x73\x74\145\144\137\x75\x73\145\x72"] = '';
    $tM["\104\x45\106\101\x55\114\x54"]["\144\x6f\156\x74\137\143\162\x65\x61\x74\145\137\x75\163\145\162"] = '';
    $tM["\104\x45\106\x41\x55\x4c\124"]["\x6b\145\x65\x70\x5f\x65\x78\x69\x73\164\x69\x6e\x67\137\165\163\145\162\x73\x5f\162\157\154\x65"] = '';
    $tM["\104\105\x46\x41\125\114\124"]["\155\157\137\163\x61\x6d\x6c\x5f\144\157\156\164\137\141\154\154\157\x77\137\x75\163\x65\x72\x5f\164\x6f\154\x6f\x67\151\x6e\x5f\143\x72\145\x61\164\145\137\x77\x69\x74\150\x5f\147\x69\166\x65\156\x5f\x67\162\x6f\165\x70\x73"] = '';
    $tM["\104\x45\x46\x41\125\114\124"]["\x6d\x6f\137\x73\x61\x6d\154\137\162\145\163\x74\x72\151\x63\x74\x5f\x75\x73\x65\162\x73\x5f\x77\x69\x74\150\x5f\147\162\157\165\160\x73"] = '';
    Tj3:
    global $wpdb;
    $Wb = get_current_blog_id();
    $lh = "\165\156\143\150\145\143\153\145\x64";
    if (!empty($H2)) {
        goto mbd;
    }
    $H2 = get_network_site_url();
    mbd:
    if (email_exists($kG) || username_exists($OT)) {
        goto l13;
    }
    $Tb = Utilities::get_active_sites();
    $DP = get_site_option("\155\157\x5f\141\x70\x70\x6c\x79\137\162\157\154\145\137\155\x61\160\160\x69\x6e\147\137\146\157\x72\x5f\163\x69\x74\145\163");
    if (!get_site_option("\155\x6f\x5f\x73\141\x6d\x6c\137\x64\x69\163\141\142\154\145\x5f\162\157\x6c\145\x5f\155\141\x70\x70\151\x6e\147")) {
        goto gDI;
    }
    $NZ = wp_generate_password(12, false);
    $ZJ = wpmu_create_user($OT, $NZ, $kG);
    goto Frg;
    gDI:
    $ZJ = mo_saml_assign_roles_to_new_user($Tb, $DP, $tM, $jN, $OT, $kG);
    Frg:
    switch_to_blog($Wb);
    if (!empty($ZJ)) {
        goto f95;
    }
    if (!get_site_option("\155\x6f\137\163\x61\155\x6c\x5f\144\151\x73\141\x62\x6c\145\137\162\x6f\154\145\x5f\155\141\x70\x70\151\156\147")) {
        goto JaO;
    }
    wp_die("\x57\145\40\143\157\165\154\x64\40\x6e\x6f\x74\40\163\151\x67\156\x20\x79\x6f\x75\40\151\156\56\40\120\x6c\145\141\x73\145\x20\143\x6f\156\x74\141\143\164\40\x61\x64\x6d\x69\156\x69\163\164\162\x61\x74\x6f\162", "\x4c\157\147\x69\x6e\x20\106\141\151\154\145\144\41");
    goto s7b;
    JaO:
    $H6 = get_site_option("\155\157\137\x73\x61\x6d\x6c\x5f\x61\143\x63\x6f\x75\x6e\x74\137\143\x72\145\141\164\151\x6f\x6e\137\144\x69\163\x61\x62\x6c\145\144\137\x6d\x73\147");
    if (!empty($H6)) {
        goto qDt;
    }
    $H6 = "\x57\145\40\143\x6f\x75\x6c\144\x20\x6e\157\164\40\163\x69\x67\x6e\x20\171\x6f\x75\40\151\156\x2e\40\x50\154\145\x61\x73\x65\x20\x63\157\156\164\141\x63\x74\40\x79\x6f\165\x72\x20\101\144\155\151\x6e\151\163\x74\162\x61\164\157\162\x2e";
    qDt:
    wp_die($H6, "\105\x72\x72\157\162\72\x20\116\x6f\x74\40\141\40\127\x6f\162\144\x50\162\145\163\x73\40\115\x65\x6d\142\145\x72");
    s7b:
    f95:
    $user = get_user_by("\151\x64", $ZJ);
    mo_saml_map_basic_attributes($user, $kT, $G0, $l1);
    mo_saml_map_custom_attributes($ZJ, $l1);
    $db = mo_saml_get_redirect_url($H2, $md);
    do_action("\x6d\151\x6e\151\x6f\x72\x61\x6e\x67\x65\137\160\157\163\164\137\x61\x75\164\150\145\156\164\x69\x63\x61\164\145\137\x75\163\145\162\137\154\x6f\x67\x69\156", $user, null, $db, true);
    mo_saml_set_auth_cookie($user, $F0, $LV, true);
    do_action("\x6d\x6f\137\x73\141\155\154\x5f\x61\164\x74\162\x69\142\165\x74\x65\163", $OT, $kG, $kT, $G0, $jN, null, true);
    goto KZf;
    l13:
    if (email_exists($kG)) {
        goto fDy;
    }
    $user = get_user_by("\x6c\157\x67\x69\156", $OT);
    goto jbd;
    fDy:
    $user = get_user_by("\145\x6d\x61\151\x6c", $kG);
    jbd:
    $ZJ = $user->ID;
    if (!(!empty($kG) and strcasecmp($kG, $user->user_email) != 0)) {
        goto vqK;
    }
    $ZJ = wp_update_user(array("\x49\104" => $ZJ, "\x75\x73\x65\162\137\145\155\x61\151\154" => $kG));
    vqK:
    mo_saml_map_basic_attributes($user, $kT, $G0, $l1);
    mo_saml_map_custom_attributes($ZJ, $l1);
    $Tb = Utilities::get_active_sites();
    $DP = get_site_option("\x6d\157\137\141\x70\160\154\x79\x5f\x72\x6f\154\x65\x5f\x6d\141\160\160\151\156\147\x5f\x66\157\x72\137\163\151\x74\x65\x73");
    if (get_site_option("\x6d\157\137\x73\x61\x6d\x6c\137\144\151\x73\141\142\154\145\x5f\162\157\x6c\145\x5f\155\x61\160\x70\151\x6e\x67")) {
        goto aGN;
    }
    foreach ($Tb as $blog_id) {
        switch_to_blog($blog_id);
        $user = get_user_by("\151\x64", $ZJ);
        $r6 = '';
        if ($DP) {
            goto HEo;
        }
        $r6 = $blog_id;
        goto JXk;
        HEo:
        $r6 = 0;
        JXk:
        if (empty($tM)) {
            goto N0p;
        }
        if (!empty($tM[$r6])) {
            goto SOQ;
        }
        if (!empty($tM["\104\x45\x46\x41\125\x4c\x54"])) {
            goto bt2;
        }
        $Dt = "\x73\x75\142\163\143\x72\x69\x62\x65\x72";
        $eW = '';
        $lh = '';
        $pp = '';
        goto r3_;
        bt2:
        $Dt = isset($tM["\104\105\x46\x41\125\x4c\x54"]["\x64\145\146\x61\165\x6c\164\x5f\x72\x6f\154\145"]) ? $tM["\104\105\x46\101\125\x4c\x54"]["\144\145\x66\141\x75\154\x74\x5f\x72\157\x6c\145"] : "\x73\x75\x62\x73\143\x72\151\142\x65\x72";
        $eW = isset($tM["\104\105\x46\101\125\x4c\x54"]["\144\157\x6e\x74\x5f\x61\154\x6c\x6f\x77\x5f\x75\x6e\154\x69\x73\x74\145\x64\137\165\x73\x65\162"]) ? $tM["\104\105\x46\101\125\114\x54"]["\144\157\156\x74\x5f\x61\154\x6c\x6f\x77\137\x75\x6e\154\151\163\164\145\144\137\165\163\145\x72"] : '';
        $lh = isset($tM["\104\105\x46\101\125\114\124"]["\144\157\x6e\x74\x5f\x63\162\145\x61\164\x65\137\165\x73\145\162"]) ? $tM["\x44\105\106\x41\125\x4c\124"]["\x64\157\x6e\x74\137\143\162\x65\141\x74\145\137\x75\163\145\162"] : '';
        $pp = isset($tM["\104\x45\x46\101\125\114\x54"]["\x6b\x65\145\160\x5f\145\170\151\163\x74\x69\156\x67\137\x75\163\x65\x72\163\137\x72\157\154\145"]) ? $tM["\x44\105\x46\x41\x55\x4c\x54"]["\153\145\x65\x70\137\x65\x78\x69\163\x74\151\x6e\147\x5f\x75\x73\x65\x72\163\x5f\x72\x6f\154\x65"] : '';
        r3_:
        goto QFm;
        SOQ:
        $Dt = isset($tM[$r6]["\144\145\146\x61\x75\x6c\164\137\162\157\x6c\145"]) ? $tM[$r6]["\x64\145\x66\141\x75\x6c\164\x5f\162\x6f\x6c\x65"] : '';
        $eW = isset($tM[$r6]["\144\x6f\156\164\x5f\x61\x6c\x6c\x6f\167\137\x75\156\x6c\151\x73\164\145\144\137\x75\x73\145\x72"]) ? $tM[$r6]["\x64\157\156\x74\137\x61\154\154\x6f\x77\x5f\x75\x6e\x6c\151\163\x74\145\x64\137\165\x73\x65\162"] : '';
        $lh = isset($tM[$r6]["\144\x6f\x6e\x74\x5f\143\162\x65\141\x74\145\x5f\x75\163\x65\x72"]) ? $tM[$r6]["\144\x6f\x6e\x74\x5f\x63\x72\x65\141\x74\x65\137\165\x73\x65\162"] : '';
        $pp = isset($tM[$r6]["\153\x65\145\160\x5f\145\x78\x69\163\x74\x69\156\x67\137\165\163\145\162\163\x5f\x72\x6f\x6c\x65"]) ? $tM[$r6]["\153\145\x65\x70\x5f\145\x78\151\x73\164\x69\x6e\147\x5f\165\x73\145\x72\163\137\x72\x6f\x6c\145"] : '';
        QFm:
        N0p:
        if (!is_user_member_of_blog($ZJ, $blog_id)) {
            goto KUE;
        }
        if (isset($pp) && $pp == "\x63\150\145\x63\x6b\145\x64") {
            goto WVa;
        }
        $N1 = assign_roles_to_user($user, $tM, $blog_id, $jN, $r6);
        goto kVX;
        WVa:
        $N1 = false;
        kVX:
        if (is_administrator_user($user)) {
            goto Jtc;
        }
        if (isset($pp) && $pp == "\143\150\x65\x63\153\145\144") {
            goto Ft1;
        }
        if ($N1 !== true && !empty($eW) && $eW == "\x63\x68\145\143\153\x65\144") {
            goto E6d;
        }
        if ($N1 !== true && !empty($Dt) && $Dt !== "\x66\x61\154\163\145") {
            goto zBK;
        }
        if ($N1 !== true && is_user_member_of_blog($ZJ, $blog_id)) {
            goto uBV;
        }
        goto XTU;
        Ft1:
        goto XTU;
        E6d:
        $ZJ = wp_update_user(array("\111\x44" => $ZJ, "\162\x6f\154\145" => false));
        goto XTU;
        zBK:
        $ZJ = wp_update_user(array("\111\x44" => $ZJ, "\x72\x6f\154\x65" => $Dt));
        goto XTU;
        uBV:
        $KS = get_site_option("\x64\x65\x66\141\165\154\x74\x5f\162\x6f\x6c\145");
        $ZJ = wp_update_user(array("\x49\104" => $ZJ, "\x72\x6f\154\x65" => $KS));
        XTU:
        Jtc:
        goto jj1;
        KUE:
        $Vq = TRUE;
        $dr = get_site_option("\x73\141\x6d\x6c\x5f\x73\163\157\x5f\x73\x65\164\x74\151\x6e\x67\163");
        if (!empty($dr[$blog_id])) {
            goto MIx;
        }
        $dr[$blog_id] = $dr["\x44\x45\x46\101\125\x4c\x54"];
        MIx:
        if (empty($tM)) {
            goto OXQ;
        }
        if (array_key_exists($r6, $tM)) {
            goto jx4;
        }
        if (!array_key_exists("\x44\105\106\101\x55\x4c\124", $tM)) {
            goto PR4;
        }
        $AG = get_saml_roles_to_assign($tM, $r6, $jN);
        if (!(empty($AG) && strcmp($tM["\x44\105\106\x41\x55\x4c\124"]["\144\x6f\x6e\164\x5f\143\x72\x65\x61\x74\x65\x5f\165\163\x65\x72"], "\143\150\145\143\x6b\145\144") == 0)) {
            goto zyU;
        }
        $Vq = FALSE;
        zyU:
        PR4:
        goto qYj;
        jx4:
        $AG = get_saml_roles_to_assign($tM, $r6, $jN);
        if (!(empty($AG) && strcmp($tM[$r6]["\x64\x6f\156\164\137\143\x72\x65\x61\x74\x65\x5f\165\x73\x65\x72"], "\x63\x68\145\x63\153\x65\x64") == 0)) {
            goto xey;
        }
        $Vq = FALSE;
        xey:
        qYj:
        OXQ:
        if (!$Vq) {
            goto i9C;
        }
        add_user_to_blog($blog_id, $ZJ, false);
        $N1 = assign_roles_to_user($user, $tM, $blog_id, $jN, $r6);
        if ($N1 !== true && !empty($eW) && $eW == "\x63\x68\x65\x63\x6b\145\144") {
            goto oxa;
        }
        if ($N1 !== true && !empty($Dt) && $Dt !== "\x66\x61\x6c\163\x65") {
            goto p9I;
        }
        if ($N1 !== true) {
            goto cLp;
        }
        goto U0_;
        oxa:
        $ZJ = wp_update_user(array("\111\x44" => $ZJ, "\162\157\x6c\x65" => false));
        goto U0_;
        p9I:
        $ZJ = wp_update_user(array("\x49\104" => $ZJ, "\x72\157\x6c\145" => $Dt));
        goto U0_;
        cLp:
        $KS = get_site_option("\x64\x65\146\x61\x75\x6c\164\x5f\162\x6f\154\145");
        $ZJ = wp_update_user(array("\x49\x44" => $ZJ, "\x72\x6f\154\x65" => $KS));
        U0_:
        i9C:
        jj1:
        Mib:
    }
    v9D:
    aGN:
    switch_to_blog($Wb);
    if ($ZJ) {
        goto nEU;
    }
    wp_die("\x49\156\166\141\154\151\x64\x20\x75\x73\x65\x72\x2e\40\120\x6c\x65\x61\x73\145\x20\164\162\171\40\x61\147\141\x69\156\56");
    nEU:
    $user = get_user_by("\151\144", $ZJ);
    mo_saml_set_auth_cookie($user, $F0, $LV, true);
    do_action("\155\157\137\163\141\155\154\x5f\141\164\x74\162\x69\142\x75\164\145\163", $OT, $kG, $kT, $G0, $jN);
    KZf:
    mo_saml_post_login_redirection($H2, $md);
}
function mo_saml_add_user_to_blog($kG, $OT, $blog_id = 0)
{
    if (email_exists($kG)) {
        goto nO1;
    }
    if (!empty($OT)) {
        goto qt8;
    }
    $ZJ = mo_saml_create_user($kG, $kG, $blog_id);
    goto S4R;
    qt8:
    $ZJ = mo_saml_create_user($OT, $kG, $blog_id);
    S4R:
    goto jMO;
    nO1:
    $user = get_user_by("\x65\155\141\151\154", $kG);
    $ZJ = $user->ID;
    if (empty($blog_id)) {
        goto RMk;
    }
    add_user_to_blog($blog_id, $ZJ, false);
    RMk:
    jMO:
    return $ZJ;
}
function mo_saml_create_user($OT, $kG, $blog_id)
{
    $de = wp_generate_password(10, false);
    if (username_exists($OT)) {
        goto Y0Y;
    }
    $ZJ = wp_create_user($OT, $de, $kG);
    goto QI2;
    Y0Y:
    $user = get_user_by("\x6c\157\147\151\x6e", $OT);
    $ZJ = $user->ID;
    if (!$blog_id) {
        goto NlP;
    }
    add_user_to_blog($blog_id, $ZJ, false);
    NlP:
    QI2:
    if (!is_wp_error($ZJ)) {
        goto Dmz;
    }
    echo "\74\163\x74\x72\157\156\147\76\x45\x52\122\x4f\x52\74\57\x73\164\x72\x6f\x6e\x67\76\x3a\40\x45\155\160\164\x79\40\125\x73\145\162\x20\116\x61\x6d\145\40\141\156\x64\40\105\155\x61\x69\x6c\x2e\40\x50\x6c\145\x61\x73\x65\40\143\x6f\x6e\x74\x61\143\x74\40\x79\157\165\162\40\x61\144\155\151\156\151\x73\164\x72\141\x74\x6f\x72\x2e";
    exit;
    Dmz:
    return $ZJ;
}
function mo_saml_assign_roles_to_new_user($Tb, $DP, $tM, $jN, $OT, $kG)
{
    global $wpdb;
    $user = NULL;
    $WI = false;
    foreach ($Tb as $blog_id) {
        $b7 = TRUE;
        $r6 = '';
        if ($DP) {
            goto kSW;
        }
        $r6 = $blog_id;
        goto G4Q;
        kSW:
        $r6 = 0;
        G4Q:
        $dr = get_site_option("\x73\x61\155\154\x5f\163\163\x6f\137\163\145\164\x74\x69\x6e\x67\x73");
        if (!empty($dr[$blog_id])) {
            goto pG5;
        }
        $dr[$blog_id] = $dr["\x44\x45\106\101\x55\x4c\124"];
        pG5:
        if (empty($tM)) {
            goto k6O;
        }
        if (!empty($tM[$r6])) {
            goto l1s;
        }
        if (!empty($tM["\x44\x45\106\x41\125\x4c\x54"])) {
            goto Av7;
        }
        $Dt = "\x73\165\142\163\x63\x72\x69\x62\x65\162";
        $eW = '';
        $pp = '';
        $AG = '';
        goto tU1;
        Av7:
        $Dt = isset($tM["\104\105\x46\x41\x55\114\124"]["\144\x65\x66\x61\x75\154\164\x5f\x72\x6f\x6c\145"]) ? $tM["\x44\x45\x46\x41\x55\x4c\124"]["\x64\x65\146\141\165\x6c\164\x5f\162\157\154\x65"] : '';
        $eW = isset($tM["\104\x45\x46\101\125\x4c\x54"]["\144\x6f\156\164\x5f\x61\x6c\x6c\x6f\167\x5f\x75\156\x6c\151\x73\164\x65\x64\137\165\163\145\162"]) ? $tM["\104\x45\x46\x41\x55\114\124"]["\x64\x6f\x6e\x74\137\141\154\x6c\x6f\167\137\x75\156\x6c\x69\x73\x74\145\x64\137\x75\x73\145\x72"] : '';
        $pp = array_key_exists("\153\145\145\160\x5f\145\170\151\163\x74\151\156\x67\137\x75\x73\x65\162\x73\x5f\x72\157\154\145", $tM["\x44\105\106\x41\125\x4c\x54"]) ? $tM["\x44\x45\106\101\125\x4c\124"]["\x6b\145\x65\x70\x5f\145\170\x69\x73\164\151\x6e\147\137\165\163\145\162\163\137\162\x6f\x6c\145"] : '';
        $AG = get_saml_roles_to_assign($tM, $r6, $jN);
        if (!(empty($AG) && strcmp($tM["\x44\105\106\x41\x55\x4c\x54"]["\144\x6f\156\x74\x5f\143\162\x65\x61\x74\x65\x5f\x75\x73\145\162"], "\x63\150\x65\143\153\145\144") == 0)) {
            goto mXh;
        }
        $b7 = FALSE;
        mXh:
        tU1:
        goto iKb;
        l1s:
        $Dt = isset($tM[$r6]["\x64\x65\146\x61\165\154\x74\137\162\x6f\154\145"]) ? $tM[$r6]["\x64\145\146\x61\x75\154\164\x5f\x72\x6f\x6c\x65"] : '';
        $eW = isset($tM[$r6]["\x64\x6f\x6e\x74\x5f\x61\x6c\154\x6f\x77\x5f\165\156\154\151\x73\x74\145\144\137\x75\x73\145\162"]) ? $tM[$r6]["\144\x6f\156\164\137\x61\154\x6c\157\167\137\165\x6e\154\151\x73\164\x65\x64\x5f\165\x73\145\x72"] : '';
        $pp = array_key_exists("\153\x65\145\160\137\145\x78\151\163\x74\x69\156\x67\x5f\165\163\145\x72\x73\137\x72\157\154\145", $tM[$r6]) ? $tM[$r6]["\153\145\145\x70\x5f\x65\170\151\163\164\x69\156\x67\x5f\165\163\145\162\x73\x5f\162\157\154\x65"] : '';
        $AG = get_saml_roles_to_assign($tM, $r6, $jN);
        if (!(empty($AG) && strcmp($tM[$r6]["\144\x6f\x6e\x74\137\143\162\145\141\x74\145\x5f\x75\163\x65\x72"], "\143\150\x65\143\153\x65\x64") == 0)) {
            goto MEs;
        }
        $b7 = FALSE;
        MEs:
        iKb:
        k6O:
        if (!$b7) {
            goto qze;
        }
        $ZJ = NULL;
        switch_to_blog($blog_id);
        $ZJ = mo_saml_add_user_to_blog($kG, $OT, $blog_id);
        $user = get_user_by("\151\144", $ZJ);
        $N1 = assign_roles_to_user($user, $tM, $blog_id, $jN, $r6);
        if ($N1 !== true && !empty($eW) && $eW == "\x63\150\x65\143\153\x65\144") {
            goto Kd_;
        }
        if ($N1 !== true && !empty($Dt) && $Dt !== "\x66\141\x6c\x73\x65") {
            goto CxJ;
        }
        if ($N1 !== true) {
            goto Yne;
        }
        goto T0y;
        Kd_:
        $ZJ = wp_update_user(array("\111\104" => $ZJ, "\162\x6f\154\145" => false));
        goto T0y;
        CxJ:
        $ZJ = wp_update_user(array("\x49\104" => $ZJ, "\162\x6f\x6c\x65" => $Dt));
        goto T0y;
        Yne:
        $KS = get_site_option("\144\x65\146\141\165\154\x74\137\x72\157\x6c\x65");
        $ZJ = wp_update_user(array("\111\x44" => $ZJ, "\x72\157\154\145" => $KS));
        T0y:
        $vr = $user->{$wpdb->prefix . "\x63\141\x70\x61\142\151\154\x69\164\x69\x65\163"};
        if (isset($wp_roles)) {
            goto tfL;
        }
        $wp_roles = new WP_Roles($r6);
        tfL:
        qze:
        JQt:
    }
    E1v:
    if (!empty($user)) {
        goto bH9;
    }
    return;
    goto pHq;
    bH9:
    return $user->ID;
    pHq:
}
function mo_saml_sanitize_username($OT)
{
    $xt = sanitize_user($OT, true);
    $w4 = apply_filters("\x70\162\x65\x5f\165\163\x65\x72\137\x6c\157\147\x69\x6e", $xt);
    $OT = trim($w4);
    return $OT;
}
function mo_saml_map_basic_attributes($user, $kT, $G0, $l1)
{
    $ZJ = $user->ID;
    if (empty($kT)) {
        goto HUf;
    }
    $ZJ = wp_update_user(array("\x49\x44" => $ZJ, "\x66\x69\x72\x73\x74\137\156\x61\x6d\145" => $kT));
    HUf:
    if (empty($G0)) {
        goto ZZV;
    }
    $ZJ = wp_update_user(array("\111\x44" => $ZJ, "\154\141\163\164\137\x6e\141\155\x65" => $G0));
    ZZV:
    if (is_null($l1)) {
        goto lZj;
    }
    update_user_meta($ZJ, "\x6d\157\x5f\163\141\x6d\x6c\x5f\165\x73\x65\x72\137\141\x74\x74\162\151\x62\x75\x74\x65\163", $l1);
    $Xg = get_site_option("\163\141\155\x6c\x5f\141\155\137\x64\151\x73\x70\154\x61\171\137\x6e\141\155\x65");
    if (empty($Xg)) {
        goto xEC;
    }
    if (strcmp($Xg, "\x55\x53\105\122\116\101\x4d\x45") == 0) {
        goto aKw;
    }
    if (strcmp($Xg, "\106\116\x41\115\105") == 0 && !empty($kT)) {
        goto csb;
    }
    if (strcmp($Xg, "\114\116\101\115\105") == 0 && !empty($G0)) {
        goto igc;
    }
    if (strcmp($Xg, "\106\x4e\x41\115\x45\x5f\114\116\x41\x4d\105") == 0 && !empty($G0) && !empty($kT)) {
        goto vjU;
    }
    if (!(strcmp($Xg, "\114\x4e\101\x4d\x45\x5f\106\116\x41\115\105") == 0 && !empty($G0) && !empty($kT))) {
        goto E6O;
    }
    $ZJ = wp_update_user(array("\111\x44" => $ZJ, "\144\x69\x73\x70\x6c\141\x79\137\156\x61\x6d\145" => $G0 . "\x20" . $kT));
    E6O:
    goto A1L;
    vjU:
    $ZJ = wp_update_user(array("\111\x44" => $ZJ, "\144\x69\x73\x70\154\141\x79\x5f\x6e\141\155\x65" => $kT . "\x20" . $G0));
    A1L:
    goto vvC;
    igc:
    $ZJ = wp_update_user(array("\111\104" => $ZJ, "\144\x69\163\160\154\141\171\x5f\156\x61\155\x65" => $G0));
    vvC:
    goto ls2;
    csb:
    $ZJ = wp_update_user(array("\111\104" => $ZJ, "\144\x69\x73\160\x6c\141\x79\x5f\156\x61\x6d\x65" => $kT));
    ls2:
    goto cbI;
    aKw:
    $ZJ = wp_update_user(array("\111\x44" => $ZJ, "\x64\x69\x73\x70\x6c\141\x79\x5f\x6e\141\155\145" => $user->user_login));
    cbI:
    xEC:
    lZj:
}
function mo_saml_map_custom_attributes($ZJ, $l1)
{
    if (!get_site_option("\155\x6f\x5f\163\141\x6d\154\x5f\x63\165\x73\164\x6f\155\x5f\141\x74\164\x72\x73\137\155\x61\160\x70\151\x6e\147")) {
        goto noa;
    }
    $dV = maybe_unserialize(get_site_option("\155\157\x5f\x73\x61\x6d\x6c\137\x63\165\163\164\x6f\155\137\x61\164\164\162\163\x5f\155\141\x70\x70\151\x6e\x67"));
    foreach ($dV as $YX => $yS) {
        if (!array_key_exists($yS, $l1)) {
            goto MpU;
        }
        $Jn = false;
        if (!(count($l1[$yS]) == 1)) {
            goto Wye;
        }
        $Jn = true;
        Wye:
        if (!$Jn) {
            goto YXL;
        }
        update_user_meta($ZJ, $YX, $l1[$yS][0]);
        goto lHW;
        YXL:
        $lr = array();
        foreach ($l1[$yS] as $PL) {
            array_push($lr, $PL);
            idK:
        }
        FZR:
        update_user_meta($ZJ, $YX, $lr);
        lHW:
        MpU:
        WC2:
    }
    hOZ:
    noa:
}
function mo_saml_restrict_users_based_on_domain($kG)
{
    $rj = get_site_option("\x6d\x6f\x5f\163\141\155\154\137\145\156\x61\x62\x6c\145\x5f\144\x6f\155\141\151\x6e\137\x72\x65\x73\164\162\151\143\x74\151\x6f\x6e\137\x6c\x6f\x67\x69\156");
    if (!$rj) {
        goto t71;
    }
    $R9 = get_site_option("\x73\141\155\154\137\x61\x6d\x5f\145\x6d\141\x69\x6c\x5f\x64\157\x6d\141\x69\156\x73");
    $F2 = explode("\x3b", $R9);
    $Q0 = explode("\100", $kG);
    $P5 = array_key_exists("\x31", $Q0) ? $Q0[1] : '';
    $QN = get_site_option("\155\x6f\137\x73\x61\x6d\154\x5f\x61\154\154\157\x77\137\144\x65\x6e\171\x5f\165\x73\x65\x72\137\167\151\164\150\x5f\144\x6f\x6d\141\151\156");
    $H6 = get_site_option("\x6d\157\137\x73\x61\155\154\137\162\145\x73\x74\162\x69\x63\x74\x65\x64\x5f\144\157\x6d\x61\x69\156\x5f\145\162\162\157\162\137\x6d\163\147");
    if (!empty($H6)) {
        goto eNP;
    }
    $H6 = "\x59\157\165\40\x61\x72\145\x20\156\x6f\164\40\141\x6c\x6c\157\x77\145\x64\x20\x74\157\40\x6c\x6f\x67\151\x6e\56\40\120\154\x65\x61\163\x65\x20\x63\157\x6e\164\141\x63\x74\x20\x79\157\165\162\x20\101\x64\155\x69\x6e\x69\163\x74\162\141\164\157\x72\56";
    eNP:
    if (!empty($QN) && $QN == "\144\145\156\x79") {
        goto jEM;
    }
    if (in_array($P5, $F2)) {
        goto KG4;
    }
    wp_die($H6, "\x50\145\x72\x6d\x69\163\163\151\157\156\40\x44\145\x6e\151\145\x64\x20\x45\x72\x72\157\x72\40\x2d\40\62");
    KG4:
    goto G3G;
    jEM:
    if (!in_array($P5, $F2)) {
        goto Pzi;
    }
    wp_die($H6, "\x50\145\x72\x6d\151\163\x73\x69\157\156\40\104\x65\x6e\151\x65\144\x20\x45\x72\162\157\x72\x20\55\40\61");
    Pzi:
    G3G:
    t71:
}
function mo_saml_set_auth_cookie($user, $F0, $LV, $br)
{
    $ZJ = $user->ID;
    do_action("\167\x70\x5f\x6c\x6f\147\151\156", $user->user_login, $user);
    if (empty($F0)) {
        goto aUo;
    }
    update_user_meta($ZJ, "\x6d\157\137\x73\x61\155\x6c\137\163\x65\163\163\x69\157\x6e\137\151\x6e\x64\145\170", $F0);
    aUo:
    if (empty($LV)) {
        goto e_5;
    }
    update_user_meta($ZJ, "\x6d\157\x5f\163\141\155\154\x5f\x6e\141\155\x65\137\x69\144", $LV);
    e_5:
    if (!(!session_id() || session_id() == '' || !isset($_SESSION))) {
        goto Q9o;
    }
    session_start();
    Q9o:
    $_SESSION["\x6d\x6f\x5f\x73\141\x6d\x6c"]["\154\x6f\147\x67\145\144\137\x69\156\137\167\x69\x74\150\x5f\x69\144\160"] = TRUE;
    update_user_meta($ZJ, "\155\x6f\x5f\x73\141\x6d\154\137\151\144\160\137\154\x6f\147\151\156", "\164\162\x75\x65");
    wp_set_current_user($ZJ);
    $g2 = false;
    $g2 = apply_filters("\x6d\157\x5f\x72\145\155\145\155\142\145\x72\x5f\x6d\145", $g2);
    wp_set_auth_cookie($ZJ, $g2);
    if (!$br) {
        goto tcX;
    }
    do_action("\x75\x73\x65\x72\x5f\x72\145\x67\x69\163\164\145\162", $ZJ);
    tcX:
}
function mo_saml_post_login_redirection($H2, $md)
{
    $RD = mo_saml_get_redirect_url($H2, $md);
    wp_redirect($RD);
    exit;
}
function mo_saml_get_redirect_url($H2, $md)
{
    $db = '';
    $dr = get_site_option("\163\141\155\x6c\x5f\163\163\x6f\137\x73\x65\164\164\151\x6e\147\163");
    $y1 = get_current_blog_id();
    if (!(empty($dr[$y1]) && !empty($dr["\x44\105\106\x41\125\114\124"]))) {
        goto Pu4;
    }
    $dr[$y1] = $dr["\104\105\x46\x41\x55\x4c\124"];
    Pu4:
    $oK = isset($dr[$y1]["\155\x6f\137\163\x61\155\x6c\x5f\x72\x65\154\x61\x79\137\163\x74\x61\164\145"]) ? $dr[$y1]["\x6d\157\x5f\163\141\155\154\137\162\x65\x6c\x61\x79\137\x73\164\x61\164\x65"] : '';
    if (!empty($oK)) {
        goto fP4;
    }
    if (!empty($md)) {
        goto TOQ;
    }
    $db = $H2;
    goto uaQ;
    TOQ:
    $db = $md;
    uaQ:
    goto jbt;
    fP4:
    $db = $oK;
    jbt:
    return $db;
}
function check_if_user_allowed_to_login($user, $H2)
{
    $ZJ = $user->ID;
    global $wpdb;
    if (get_user_meta($ZJ, "\x6d\x6f\x5f\163\141\x6d\x6c\x5f\165\163\x65\x72\x5f\164\x79\160\145", true)) {
        goto hV_;
    }
    if (get_site_option("\x6d\157\137\163\x61\155\154\137\x75\163\162\x5f\x6c\x6d\164")) {
        goto s40;
    }
    update_user_meta($ZJ, "\155\x6f\x5f\x73\x61\155\x6c\x5f\165\x73\145\x72\137\164\x79\x70\x65", "\x73\163\157\x5f\x75\x73\145\x72");
    goto pa7;
    s40:
    $YX = get_site_option("\x6d\x6f\137\x73\x61\155\154\x5f\x63\x75\163\164\157\155\145\x72\137\164\x6f\153\x65\x6e");
    $O9 = AESEncryption::decrypt_data(get_site_option("\155\157\137\163\x61\155\x6c\137\x75\163\x72\137\154\x6d\x74"), $YX);
    $XK = "\x53\x45\x4c\x45\x43\x54\40\103\117\125\116\124\50\52\51\x20\106\x52\x4f\x4d\40" . $wpdb->prefix . "\165\x73\145\x72\x6d\x65\164\x61\x20\127\110\x45\x52\105\x20\x6d\x65\164\x61\x5f\x6b\145\x79\x3d\47\x6d\157\137\x73\141\155\154\137\x75\x73\x65\162\137\x74\x79\160\145\47";
    $y2 = $wpdb->get_var($XK);
    if ($y2 >= $O9) {
        goto VxS;
    }
    update_user_meta($ZJ, "\x6d\x6f\137\x73\141\x6d\x6c\137\165\x73\145\x72\137\x74\171\x70\x65", "\x73\x73\157\137\165\163\145\x72");
    goto muy;
    VxS:
    if (get_site_option("\x75\163\x65\162\x5f\141\x6c\x65\x72\x74\137\145\155\141\x69\154\x5f\163\x65\x6e\164")) {
        goto lAy;
    }
    $OA = new Customersaml();
    $OA->mo_saml_send_user_exceeded_alert_email($O9, $this);
    lAy:
    if (is_administrator_user($user)) {
        goto DIF;
    }
    wp_redirect($H2);
    exit;
    goto obC;
    DIF:
    update_user_meta($ZJ, "\155\157\137\163\141\155\154\137\x75\163\145\162\137\x74\171\160\145", "\x73\163\x6f\x5f\165\x73\x65\162");
    obC:
    muy:
    pa7:
    hV_:
}
function check_if_user_allowed_to_login_due_to_role_restriction($jN)
{
    $tM = maybe_unserialize(get_site_option("\163\x61\155\154\x5f\x61\x6d\137\162\157\154\145\x5f\155\141\x70\x70\x69\156\x67"));
    $Tb = Utilities::get_active_sites();
    $DP = get_site_option("\x6d\157\x5f\141\x70\x70\154\x79\x5f\x72\157\154\x65\137\x6d\141\x70\160\x69\x6e\147\137\146\x6f\x72\137\163\x69\164\x65\x73");
    if ($tM) {
        goto QCM;
    }
    $tM = array();
    QCM:
    if (array_key_exists("\104\105\106\101\125\114\x54", $tM)) {
        goto sPq;
    }
    $tM["\x44\x45\106\101\x55\114\124"] = array();
    sPq:
    foreach ($Tb as $blog_id) {
        if ($DP) {
            goto qMZ;
        }
        $r6 = $blog_id;
        goto QDQ;
        qMZ:
        $r6 = 0;
        QDQ:
        if (isset($tM[$r6])) {
            goto HyT;
        }
        $rg = $tM["\x44\105\106\x41\x55\114\124"];
        goto YyK;
        HyT:
        $rg = $tM[$r6];
        YyK:
        if (empty($rg)) {
            goto nGo;
        }
        $fc = isset($rg["\155\157\137\163\141\155\x6c\137\144\x6f\156\x74\137\x61\154\154\157\167\137\x75\163\145\x72\x5f\x74\157\x6c\x6f\x67\x69\x6e\x5f\143\x72\145\x61\x74\145\x5f\167\x69\164\x68\137\147\151\x76\x65\x6e\x5f\147\162\x6f\165\160\163"]) ? $rg["\x6d\157\137\163\x61\x6d\154\137\x64\x6f\156\164\137\141\x6c\154\157\167\x5f\x75\x73\145\162\137\x74\x6f\x6c\x6f\147\151\156\137\x63\162\x65\x61\164\145\x5f\x77\x69\x74\x68\137\147\x69\166\145\156\x5f\147\x72\x6f\165\x70\163"] : '';
        if (!($fc == "\143\x68\145\x63\153\145\x64")) {
            goto ckn;
        }
        if (empty($jN)) {
            goto bia;
        }
        $Sf = $rg["\x6d\x6f\x5f\163\x61\x6d\x6c\x5f\x72\145\163\164\x72\151\x63\164\x5f\165\x73\145\x72\x73\137\167\x69\164\x68\x5f\147\x72\x6f\x75\x70\163"];
        $tB = explode("\73", $Sf);
        foreach ($tB as $cJ) {
            foreach ($jN as $Uu) {
                $Uu = trim($Uu);
                if (!(!empty($Uu) && $Uu == $cJ)) {
                    goto gVn;
                }
                wp_die("\x59\x6f\165\x20\x61\162\x65\x20\x6e\157\164\40\141\165\x74\150\157\162\151\x7a\x65\144\x20\x74\157\x20\x6c\157\147\x69\x6e\x2e\40\x50\154\x65\x61\x73\x65\40\x63\x6f\156\x74\141\143\x74\x20\171\157\165\x72\x20\x61\x64\x6d\x69\x6e\x69\163\164\x72\141\x74\157\162\x2e", "\105\x72\162\x6f\162");
                gVn:
                XKE:
            }
            mfI:
            Qws:
        }
        ESl:
        bia:
        ckn:
        nGo:
        EAf:
    }
    ROn:
}
function assign_roles_to_user($user, $tM, $blog_id, $jN, $r6)
{
    $N1 = false;
    if (!(!empty($jN) && !empty($tM) && !is_administrator_user($user) && is_user_member_of_blog($user->ID, $blog_id))) {
        goto fQx;
    }
    if (!empty($tM[$r6])) {
        goto Sa_;
    }
    if (empty($tM["\x44\105\106\101\125\x4c\124"])) {
        goto Opa;
    }
    $rg = $tM["\x44\105\106\x41\x55\x4c\124"];
    Opa:
    goto kdB;
    Sa_:
    $rg = $tM[$r6];
    kdB:
    if (empty($rg)) {
        goto ZdG;
    }
    $user->set_role(false);
    $T9 = '';
    $rN = false;
    unset($rg["\x64\145\x66\x61\x75\154\x74\x5f\162\157\154\145"]);
    unset($rg["\144\x6f\156\164\x5f\143\162\145\x61\164\x65\137\x75\163\145\x72"]);
    unset($rg["\x64\x6f\156\164\x5f\x61\154\154\x6f\x77\x5f\165\156\x6c\151\163\x74\145\144\x5f\165\x73\x65\x72"]);
    unset($rg["\153\x65\145\x70\137\145\170\x69\163\164\x69\156\147\137\x75\163\x65\x72\x73\x5f\162\157\154\x65"]);
    unset($rg["\155\157\137\163\x61\x6d\x6c\x5f\144\x6f\156\x74\137\x61\x6c\154\x6f\x77\x5f\x75\163\x65\x72\137\x74\x6f\154\157\x67\x69\156\x5f\143\x72\145\x61\x74\145\x5f\x77\x69\164\150\137\x67\151\166\x65\x6e\x5f\x67\x72\x6f\165\x70\163"]);
    unset($rg["\155\x6f\x5f\163\141\x6d\x6c\x5f\x72\x65\x73\x74\x72\x69\143\164\137\165\x73\x65\x72\x73\x5f\x77\x69\164\x68\137\x67\162\x6f\x75\160\163"]);
    foreach ($rg as $Wp => $xQ) {
        $tB = explode("\x3b", $xQ);
        foreach ($tB as $cJ) {
            if (!(!empty($cJ) && in_array($cJ, $jN))) {
                goto LLq;
            }
            $N1 = true;
            $user->add_role($Wp);
            LLq:
            WIW:
        }
        xnd:
        W_O:
    }
    RE0:
    ZdG:
    fQx:
    $nR = get_site_option("\x6d\157\137\163\141\x6d\x6c\x5f\163\x75\160\145\x72\137\x61\x64\155\x69\156\137\x72\157\x6c\145\137\x6d\x61\x70\x70\151\156\x67");
    $nH = array();
    if (empty($nR)) {
        goto RZn;
    }
    $nH = explode("\73", $nR);
    RZn:
    if (!(!empty($jN) && !empty($nH))) {
        goto iMT;
    }
    foreach ($nH as $cJ) {
        if (!in_array($cJ, $jN)) {
            goto juI;
        }
        grant_super_admin($user->ID);
        juI:
        f3_:
    }
    NDn:
    iMT:
    return $N1;
}
function get_saml_roles_to_assign($tM, $blog_id, $jN)
{
    $AG = array();
    if (!(!empty($jN) && !empty($tM))) {
        goto M1v;
    }
    if (!empty($tM[$blog_id])) {
        goto kLM;
    }
    if (empty($tM["\104\105\106\x41\125\x4c\x54"])) {
        goto iLP;
    }
    $rg = $tM["\104\x45\x46\101\125\x4c\x54"];
    iLP:
    goto GIu;
    kLM:
    $rg = $tM[$blog_id];
    GIu:
    if (empty($rg)) {
        goto F4M;
    }
    unset($rg["\x64\145\146\141\x75\x6c\164\x5f\162\x6f\154\x65"]);
    unset($rg["\x64\x6f\156\164\x5f\x63\162\x65\141\x74\x65\137\165\x73\x65\x72"]);
    unset($rg["\144\157\x6e\164\137\141\x6c\x6c\x6f\167\137\x75\156\154\151\x73\164\x65\144\x5f\x75\163\x65\x72"]);
    unset($rg["\x6b\x65\x65\x70\137\145\x78\x69\163\x74\x69\156\x67\137\165\163\145\162\x73\137\162\157\x6c\x65"]);
    unset($rg["\x6d\157\137\163\141\155\x6c\137\x64\x6f\x6e\x74\137\141\154\154\x6f\167\x5f\x75\163\x65\x72\x5f\x74\157\154\157\x67\151\x6e\x5f\143\x72\145\141\x74\145\x5f\167\x69\x74\x68\x5f\147\151\x76\145\x6e\137\147\162\157\165\160\163"]);
    unset($rg["\155\x6f\137\x73\x61\x6d\x6c\137\x72\145\163\x74\x72\x69\143\x74\x5f\x75\x73\x65\x72\x73\x5f\x77\x69\x74\150\137\147\162\157\165\160\x73"]);
    foreach ($rg as $Wp => $xQ) {
        $tB = explode("\x3b", $xQ);
        foreach ($tB as $cJ) {
            if (!(!empty($cJ) and in_array($cJ, $jN))) {
                goto ifT;
            }
            array_push($AG, $Wp);
            ifT:
            q11:
        }
        XfJ:
        aKA:
    }
    xJ2:
    F4M:
    M1v:
    return $AG;
}
function is_administrator_user($user)
{
    $fA = $user->roles;
    if (!is_null($fA) && in_array("\x61\144\155\151\156\151\x73\164\162\141\x74\x6f\x72", $fA)) {
        goto a1Y;
    }
    return false;
    goto Rf8;
    a1Y:
    return true;
    Rf8:
}
function mo_saml_is_customer_registered()
{
    $v2 = get_site_option("\x6d\x6f\137\x73\141\x6d\154\x5f\141\144\x6d\151\156\x5f\145\x6d\x61\x69\154");
    $Cn = get_site_option("\x6d\157\137\163\141\x6d\154\137\x61\x64\155\x69\156\x5f\x63\165\163\x74\157\155\x65\x72\x5f\153\145\171");
    if (!$v2 || !$Cn || !is_numeric(trim($Cn))) {
        goto cvN;
    }
    return 1;
    goto xlR;
    cvN:
    return 0;
    xlR:
}
function mo_saml_is_customer_license_verified()
{
    $YX = get_site_option("\x6d\x6f\x5f\163\x61\155\154\137\x63\x75\x73\164\157\x6d\145\x72\137\164\157\153\x65\x6e");
    $oW = AESEncryption::decrypt_data(get_site_option("\x74\x5f\x73\151\x74\x65\137\x73\164\141\164\165\x73"), $YX);
    $KY = get_site_option("\163\155\x6c\137\x6c\153");
    $v2 = get_site_option("\x6d\157\137\163\x61\x6d\154\137\x61\x64\155\151\x6e\x5f\145\x6d\x61\x69\x6c");
    $Cn = get_site_option("\x6d\157\x5f\x73\x61\155\154\x5f\141\x64\155\151\x6e\137\x63\165\163\x74\x6f\x6d\145\162\x5f\153\x65\171");
    $XO = AESEncryption::decrypt_data(get_site_option("\x6e\x6f\137\x73\142\x73"), $YX);
    $O3 = false;
    if (!get_site_option("\156\x6f\137\x73\142\163")) {
        goto xa8;
    }
    $cl = Utilities::get_sites();
    $O3 = $XO < count($cl);
    xa8:
    if ($oW != "\164\162\x75\x65" && !$KY || !$v2 || !$Cn || !is_numeric(trim($Cn)) || $O3) {
        goto cpf;
    }
    return 1;
    goto BGb;
    cpf:
    return 0;
    BGb:
}
function show_status_error($As, $md)
{
    if ($md == "\164\x65\x73\164\x56\141\154\x69\x64\x61\164\x65" or $md == "\x74\145\163\x74\x4e\x65\x77\x43\x65\162\x74\151\x66\151\143\141\x74\145") {
        goto yV9;
    }
    wp_die("\x57\x65\x20\x63\x6f\x75\154\144\x20\x6e\157\x74\40\x73\151\x67\156\x20\x79\x6f\165\x20\x69\156\x2e\x20\120\x6c\x65\141\x73\x65\x20\x63\157\156\164\x61\143\164\x20\x79\157\x75\x72\x20\x41\144\155\x69\x6e\151\x73\164\x72\141\x74\x6f\162\x2e", "\x45\x72\x72\157\x72\x3a\40\x49\x6e\x76\x61\x6c\151\x64\x20\x53\101\x4d\114\40\x52\x65\163\160\157\156\163\x65\40\123\164\x61\x74\165\x73");
    goto yby;
    yV9:
    echo "\74\144\x69\166\x20\163\x74\x79\x6c\x65\x3d\42\x66\x6f\156\164\x2d\x66\141\155\151\x6c\171\72\103\x61\x6c\x69\x62\x72\151\x3b\x70\141\x64\144\151\156\147\x3a\60\40\63\x25\x3b\42\x3e";
    echo "\74\144\x69\x76\40\x73\164\x79\x6c\145\75\42\143\157\154\157\x72\x3a\x20\43\141\71\64\x34\64\x32\73\x62\141\x63\153\x67\x72\157\165\x6e\x64\55\143\157\154\157\x72\x3a\40\x23\x66\x32\x64\145\144\x65\x3b\x70\x61\x64\x64\151\x6e\147\x3a\40\x31\x35\x70\x78\x3b\155\x61\162\147\151\156\x2d\x62\157\164\164\157\155\72\40\62\60\x70\x78\73\164\x65\170\x74\55\x61\x6c\151\147\156\x3a\x63\145\156\x74\145\162\73\142\x6f\162\x64\x65\162\72\61\x70\x78\40\163\x6f\154\x69\144\x20\43\105\x36\x42\63\x42\62\x3b\x66\x6f\156\164\55\163\x69\172\x65\72\x31\x38\x70\164\x3b\42\76\40\x45\122\122\117\122\x3c\57\x64\151\166\76\15\xa\x9\11\11\11\11\x9\11\74\144\x69\166\x20\x73\x74\x79\x6c\x65\75\42\x63\157\x6c\157\x72\72\40\43\x61\x39\x34\64\x34\62\x3b\146\157\x6e\x74\x2d\163\x69\172\x65\x3a\61\x34\x70\x74\x3b\x20\x6d\141\162\147\x69\x6e\x2d\142\157\164\164\157\x6d\72\62\x30\x70\x78\x3b\42\76\74\160\76\x3c\x73\164\162\157\156\x67\x3e\x45\x72\162\157\x72\72\40\74\x2f\163\164\x72\x6f\x6e\x67\x3e\40\x49\x6e\166\141\154\x69\144\40\x53\x41\115\114\x20\x52\x65\163\x70\x6f\156\163\x65\x20\x53\x74\x61\x74\x75\163\x2e\74\57\160\76\15\xa\11\x9\x9\11\x9\11\x9\11\74\x70\76\x3c\x73\x74\x72\157\x6e\x67\x3e\x43\x61\165\163\145\x73\74\x2f\x73\164\162\157\x6e\x67\x3e\x3a\x20\111\144\145\x6e\164\151\164\171\x20\120\162\x6f\166\x69\144\145\162\x20\x68\x61\163\40\x73\145\156\x74\x20\x27" . $As . "\x27\x20\163\x74\141\164\165\163\x20\143\157\x64\x65\40\151\156\40\x53\x41\x4d\x4c\x20\122\x65\163\160\x6f\x6e\163\145\56\x20\x3c\x2f\x70\76\xd\12\x9\11\11\11\x9\11\11\11\x3c\x70\x3e\x3c\163\164\162\157\x6e\x67\x3e\x52\x65\141\163\157\156\74\57\x73\164\x72\x6f\156\x67\76\x3a\x20" . get_status_message($As) . "\74\57\x70\76\x3c\x62\x72\76";
    if (empty($dH)) {
        goto BL2;
    }
    echo "\x3c\x70\76\74\x73\164\162\157\156\147\x3e\123\x74\x61\x74\x75\x73\x20\115\145\x73\163\x61\147\145\40\151\156\40\x74\150\145\40\x53\101\115\x4c\x20\x52\145\163\160\x6f\156\x73\145\x3a\x3c\x2f\x73\x74\162\x6f\x6e\147\x3e\40\x3c\x62\x72\57\x3e" . $dH . "\74\x2f\x70\76\x3c\142\162\76";
    BL2:
    echo "\15\12\11\11\11\11\x9\11\11\x3c\x2f\144\x69\166\x3e\xd\12\xd\xa\11\11\x9\x9\x9\11\11\x3c\x64\x69\166\x20\163\x74\171\x6c\x65\75\42\x6d\141\x72\147\x69\156\x3a\63\45\x3b\x64\151\163\x70\x6c\x61\171\72\x62\154\157\143\x6b\73\164\x65\170\x74\x2d\141\154\x69\147\156\72\x63\145\156\x74\145\x72\x3b\x22\76\xd\12\x9\11\11\11\x9\x9\x9\x9\74\x64\151\x76\x20\x73\x74\x79\x6c\x65\x3d\42\155\x61\x72\147\151\156\x3a\x33\45\73\144\151\x73\x70\154\141\171\x3a\142\154\157\143\153\x3b\x74\145\170\164\55\141\x6c\151\147\x6e\72\x63\145\156\x74\145\162\x3b\42\x3e\74\x69\156\160\165\x74\40\x73\164\x79\154\x65\75\x22\160\x61\144\144\151\x6e\x67\72\x31\45\73\x77\x69\144\164\150\x3a\x31\x30\60\x70\x78\x3b\142\141\x63\153\x67\162\x6f\165\x6e\x64\x3a\x20\43\60\60\71\61\103\104\40\156\x6f\x6e\x65\x20\162\x65\x70\x65\141\164\x20\x73\143\x72\x6f\154\x6c\x20\x30\45\x20\60\x25\x3b\x63\165\x72\163\x6f\x72\72\x20\160\157\x69\156\164\145\162\x3b\x66\157\x6e\x74\55\163\151\x7a\145\x3a\x31\65\160\x78\x3b\x62\x6f\162\x64\x65\x72\x2d\x77\151\144\x74\150\72\40\61\160\170\73\142\x6f\162\144\x65\x72\x2d\x73\x74\171\x6c\145\72\x20\163\157\154\x69\x64\73\142\157\162\144\145\162\x2d\162\x61\144\x69\165\163\72\40\63\x70\170\x3b\167\x68\151\164\145\55\163\x70\x61\143\x65\x3a\40\x6e\x6f\167\162\x61\160\73\x62\157\170\55\163\151\x7a\x69\x6e\x67\x3a\x20\142\x6f\162\x64\145\162\x2d\x62\x6f\x78\x3b\142\157\x72\x64\x65\162\x2d\143\157\x6c\157\162\72\x20\x23\60\x30\x37\63\101\x41\73\x62\x6f\x78\55\x73\x68\141\x64\x6f\167\72\x20\x30\x70\170\x20\61\160\x78\40\60\160\170\40\x72\x67\x62\141\50\x31\62\60\54\x20\x32\60\x30\54\40\x32\x33\60\x2c\x20\60\x2e\66\x29\40\x69\156\163\145\x74\x3b\x63\x6f\x6c\x6f\x72\x3a\40\x23\106\106\106\x3b\x22\164\171\x70\145\x3d\42\142\165\x74\x74\x6f\156\42\x20\166\141\x6c\x75\x65\x3d\42\104\157\156\145\x22\x20\x6f\156\x43\x6c\151\x63\x6b\75\42\x73\x65\x6c\146\x2e\x63\154\157\163\145\x28\x29\x3b\42\x3e\74\57\x64\x69\x76\x3e";
    exit;
    yby:
}
function addLink($N5, $a7)
{
    $Em = "\x3c\141\x20\x68\x72\x65\146\75\x22" . $a7 . "\x22\x3e" . $N5 . "\74\57\x61\x3e";
    return $Em;
}
function get_status_message($As)
{
    switch ($As) {
        case "\x52\x65\x71\165\145\x73\x74\x65\162":
            return "\x54\150\145\x20\162\145\x71\165\x65\163\164\40\143\157\165\x6c\x64\x20\156\x6f\x74\x20\142\145\40\x70\x65\162\146\x6f\x72\x6d\145\144\x20\x64\165\145\x20\164\x6f\x20\x61\156\40\145\x72\162\x6f\162\x20\x6f\x6e\x20\x74\x68\x65\x20\160\x61\162\x74\x20\x6f\146\40\164\150\x65\40\x72\x65\x71\165\x65\163\x74\145\x72\x2e";
            goto Czd;
        case "\x52\x65\163\x70\x6f\156\144\145\x72":
            return "\x54\x68\x65\x20\x72\x65\x71\165\x65\x73\x74\40\x63\157\165\x6c\144\40\156\157\164\x20\x62\x65\40\x70\145\162\x66\x6f\162\x6d\x65\x64\x20\144\165\x65\x20\x74\157\x20\141\156\x20\145\162\x72\x6f\x72\40\157\156\x20\164\x68\145\x20\160\x61\x72\164\40\x6f\146\x20\x74\x68\x65\40\123\x41\115\114\x20\x72\145\x73\160\157\x6e\144\145\162\x20\157\162\40\123\x41\x4d\x4c\40\141\x75\164\x68\157\x72\x69\164\171\56";
            goto Czd;
        case "\126\x65\162\163\x69\x6f\x6e\x4d\x69\x73\x6d\x61\164\x63\x68":
            return "\124\150\145\40\x53\x41\115\114\x20\162\x65\x73\x70\157\156\x64\145\162\40\143\x6f\x75\x6c\x64\x20\156\157\164\x20\160\x72\x6f\143\x65\163\163\x20\x74\x68\x65\x20\162\145\x71\165\145\x73\164\40\142\x65\143\141\x75\x73\145\40\x74\x68\x65\x20\x76\x65\x72\x73\151\157\156\40\x6f\146\40\164\x68\145\x20\162\145\x71\x75\x65\163\164\x20\155\145\163\163\x61\x67\x65\x20\167\141\163\x20\x69\156\x63\157\x72\162\145\143\164\x2e";
            goto Czd;
        default:
            return "\125\x6e\153\x6e\x6f\x77\156";
    }
    HBQ:
    Czd:
}
function saml_get_current_page_url()
{
    $am = $_SERVER["\x48\x54\124\x50\137\110\x4f\123\124"];
    if (!(substr($am, -1) == "\57")) {
        goto kFE;
    }
    $am = substr($am, 0, -1);
    kFE:
    $Bg = $_SERVER["\x52\x45\x51\x55\105\x53\x54\137\x55\122\111"];
    if (!(substr($Bg, 0, 1) == "\x2f")) {
        goto f_k;
    }
    $Bg = substr($Bg, 1);
    f_k:
    $zP = isset($_SERVER["\x48\124\x54\120\123"]) && strcasecmp($_SERVER["\x48\x54\x54\x50\x53"], "\x6f\x6e") == 0;
    $zN = "\150\164\x74\x70" . ($zP ? "\163" : '') . "\x3a\x2f\x2f" . $am . "\x2f" . $Bg;
    return $zN;
}
function get_network_site_url()
{
    $lf = network_site_url();
    if (!(substr($lf, -1) == "\x2f")) {
        goto NZC;
    }
    $lf = substr($lf, 0, -1);
    NZC:
    return $lf;
}
function get_current_base_url()
{
    return sprintf("\x25\x73\x3a\57\x2f\45\163\x2f", isset($_SERVER["\x48\x54\124\x50\123"]) && $_SERVER["\110\x54\124\x50\x53"] != "\x6f\x66\146" ? "\150\164\x74\160\163" : "\150\x74\164\160", $_SERVER["\110\124\124\120\x5f\x48\x4f\123\x54"]);
}
add_action("\x77\151\144\x67\x65\164\163\137\151\156\x69\x74", function () {
    register_widget("\155\x6f\x5f\x6c\x6f\147\151\x6e\137\167\151\x64");
});
add_action("\x69\x6e\151\164", "\x6d\157\137\x6c\x6f\147\x69\156\137\x76\141\x6c\151\144\x61\164\x65");
