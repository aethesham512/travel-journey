<?php


if (defined("\x57\x50\x49\116\x43")) {
    goto i_A;
}
die;
i_A:
