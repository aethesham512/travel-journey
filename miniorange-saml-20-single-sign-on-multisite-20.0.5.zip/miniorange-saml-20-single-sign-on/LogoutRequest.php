<?php


include_once "\125\164\151\x6c\151\x74\151\x65\163\56\x70\x68\x70";
include_once "\170\x6d\154\x73\145\x63\x6c\x69\x62\x73\56\x70\x68\160";
use RobRichards\XMLSecLibs\XMLSecurityKey;
use RobRichards\XMLSecLibs\XMLSecurityDSig;
use RobRichards\XMLSecLibs\XMLSecEnc;
class SAML2_LogoutRequest
{
    private $tagName;
    private $id;
    private $issuer;
    private $destination;
    private $issueInstant;
    private $certificates;
    private $validators;
    private $notOnOrAfter;
    private $encryptedNameId;
    private $nameId;
    private $sessionIndexes;
    public function __construct(DOMElement $Pk = NULL)
    {
        $this->tagName = "\114\157\x67\157\x75\x74\122\145\x71\x75\145\163\164";
        $this->id = Utilities::generateID();
        $this->issueInstant = time();
        $this->certificates = array();
        $this->validators = array();
        if (!($Pk === NULL)) {
            goto LR;
        }
        return;
        LR:
        if ($Pk->hasAttribute("\111\104")) {
            goto MK;
        }
        throw new Exception("\x4d\151\x73\163\x69\x6e\147\40\111\104\40\141\164\164\162\151\142\x75\x74\145\x20\x6f\x6e\x20\123\x41\x4d\x4c\40\x6d\x65\x73\x73\x61\147\145\56");
        MK:
        $this->id = $Pk->getAttribute("\x49\x44");
        if (!($Pk->getAttribute("\126\x65\x72\163\151\157\x6e") !== "\x32\x2e\60")) {
            goto UC;
        }
        throw new Exception("\x55\x6e\x73\x75\x70\x70\157\162\164\x65\144\40\x76\x65\x72\x73\151\157\156\x3a\40" . $Pk->getAttribute("\x56\145\x72\163\x69\x6f\x6e"));
        UC:
        $this->issueInstant = Utilities::xsDateTimeToTimestamp($Pk->getAttribute("\111\163\x73\x75\x65\x49\x6e\163\x74\x61\x6e\x74"));
        if (!$Pk->hasAttribute("\x44\x65\x73\x74\x69\x6e\141\x74\151\157\156")) {
            goto T7;
        }
        $this->destination = $Pk->getAttribute("\104\145\x73\x74\151\x6e\x61\164\x69\x6f\x6e");
        T7:
        $CL = Utilities::xpQuery($Pk, "\56\57\163\x61\155\154\137\x61\163\x73\145\162\x74\151\x6f\156\72\111\163\163\x75\x65\162");
        if (empty($CL)) {
            goto iY;
        }
        $this->issuer = trim($CL[0]->textContent);
        iY:
        try {
            $qD = Utilities::validateElement($Pk);
            if (!($qD !== FALSE)) {
                goto bu;
            }
            $this->certificates = $qD["\x43\145\x72\x74\151\146\151\x63\x61\164\x65\163"];
            $this->validators[] = array("\106\x75\156\143\164\151\x6f\x6e" => array("\x55\x74\151\x6c\151\164\x69\x65\163", "\166\x61\154\151\x64\141\164\x65\123\151\147\x6e\141\x74\x75\x72\x65"), "\x44\x61\164\141" => $qD);
            bu:
        } catch (Exception $L7) {
        }
        $this->sessionIndexes = array();
        if (!$Pk->hasAttribute("\x4e\157\x74\117\x6e\117\x72\x41\x66\x74\145\162")) {
            goto ZA;
        }
        $this->notOnOrAfter = Utilities::xsDateTimeToTimestamp($Pk->getAttribute("\x4e\157\x74\x4f\x6e\x4f\162\x41\x66\164\x65\x72"));
        ZA:
        $LV = Utilities::xpQuery($Pk, "\56\57\163\x61\x6d\x6c\x5f\x61\x73\x73\x65\x72\x74\x69\x6f\156\x3a\x4e\141\x6d\x65\111\104\40\174\40\56\x2f\x73\141\155\154\137\141\x73\163\x65\162\164\151\x6f\156\72\105\x6e\x63\x72\x79\x70\x74\x65\144\111\x44\x2f\170\145\x6e\x63\x3a\105\x6e\x63\x72\x79\160\164\x65\144\x44\141\164\141");
        if (empty($LV)) {
            goto M3;
        }
        if (count($LV) > 1) {
            goto m4;
        }
        goto aK;
        M3:
        throw new Exception("\x4d\151\x73\x73\151\156\x67\40\74\x73\x61\x6d\x6c\x3a\x4e\x61\155\145\111\104\76\40\x6f\162\40\x3c\163\x61\155\154\x3a\105\156\143\x72\171\x70\x74\145\x64\111\x44\76\40\x69\156\x20\74\x73\141\x6d\154\160\x3a\x4c\x6f\147\157\165\x74\x52\145\x71\165\145\163\x74\x3e\56");
        goto aK;
        m4:
        throw new Exception("\x4d\x6f\x72\x65\40\x74\x68\x61\156\x20\157\156\x65\40\x3c\163\x61\155\154\x3a\x4e\x61\155\x65\111\104\76\x20\x6f\x72\40\x3c\163\141\x6d\x6c\72\105\156\143\162\171\160\164\x65\144\x44\x3e\x20\151\156\x20\74\x73\x61\155\154\160\72\x4c\x6f\147\x6f\165\164\x52\145\161\x75\145\x73\164\x3e\x2e");
        aK:
        $LV = $LV[0];
        if ($LV->localName === "\105\156\143\x72\171\160\x74\x65\x64\104\x61\164\x61") {
            goto sr;
        }
        $this->nameId = Utilities::parseNameId($LV);
        goto cb;
        sr:
        $this->encryptedNameId = $LV;
        cb:
        $DK = Utilities::xpQuery($Pk, "\56\x2f\163\141\x6d\154\137\160\x72\x6f\164\157\x63\x6f\x6c\x3a\123\x65\x73\163\151\157\x6e\111\156\x64\145\x78");
        foreach ($DK as $F0) {
            $this->sessionIndexes[] = trim($F0->textContent);
            li:
        }
        xz:
    }
    public function getNotOnOrAfter()
    {
        return $this->notOnOrAfter;
    }
    public function setNotOnOrAfter($ph)
    {
        $this->notOnOrAfter = $ph;
    }
    public function isNameIdEncrypted()
    {
        if (!($this->encryptedNameId !== NULL)) {
            goto mI;
        }
        return TRUE;
        mI:
        return FALSE;
    }
    public function encryptNameId(XMLSecurityKey $YX)
    {
        $o7 = new DOMDocument();
        $Wq = $o7->createElement("\162\157\157\x74");
        $o7->appendChild($Wq);
        SAML2_Utils::addNameId($Wq, $this->nameId);
        $LV = $Wq->firstChild;
        SAML2_Utils::getContainer()->debugMessage($LV, "\x65\x6e\143\162\171\x70\164");
        $tu = new XMLSecEnc();
        $tu->setNode($LV);
        $tu->type = XMLSecEnc::Element;
        $GV = new XMLSecurityKey(XMLSecurityKey::AES128_CBC);
        $GV->generateSessionKey();
        $tu->encryptKey($YX, $GV);
        $this->encryptedNameId = $tu->encryptNode($GV);
        $this->nameId = NULL;
    }
    public function decryptNameId(XMLSecurityKey $YX, array $Sh = array())
    {
        if (!($this->encryptedNameId === NULL)) {
            goto Im;
        }
        return;
        Im:
        $LV = SAML2_Utils::decryptElement($this->encryptedNameId, $YX, $Sh);
        SAML2_Utils::getContainer()->debugMessage($LV, "\144\145\143\x72\x79\x70\x74");
        $this->nameId = SAML2_Utils::parseNameId($LV);
        $this->encryptedNameId = NULL;
    }
    public function getNameId()
    {
        if (!($this->encryptedNameId !== NULL)) {
            goto zS;
        }
        throw new Exception("\x41\164\164\x65\x6d\160\x74\145\x64\x20\164\x6f\40\x72\x65\x74\162\x69\145\x76\x65\x20\x65\x6e\143\x72\x79\x70\x74\145\144\40\116\141\x6d\x65\111\104\40\x77\x69\164\150\x6f\x75\164\40\x64\x65\x63\x72\x79\x70\164\x69\156\x67\40\x69\x74\40\x66\151\162\163\x74\x2e");
        zS:
        return $this->nameId;
    }
    public function setNameId($LV)
    {
        $this->nameId = $LV;
    }
    public function getSessionIndexes()
    {
        return $this->sessionIndexes;
    }
    public function setSessionIndexes(array $DK)
    {
        $this->sessionIndexes = $DK;
    }
    public function getSessionIndex()
    {
        if (!empty($this->sessionIndexes)) {
            goto Jk;
        }
        return NULL;
        Jk:
        return $this->sessionIndexes[0];
    }
    public function setSessionIndex($F0)
    {
        if (is_null($F0)) {
            goto Gy;
        }
        $this->sessionIndexes = array($F0);
        goto g0;
        Gy:
        $this->sessionIndexes = array();
        g0:
    }
    public function getId()
    {
        return $this->id;
    }
    public function setId($JC)
    {
        $this->id = $JC;
    }
    public function getIssueInstant()
    {
        return $this->issueInstant;
    }
    public function setIssueInstant($gI)
    {
        $this->issueInstant = $gI;
    }
    public function getDestination()
    {
        return $this->destination;
    }
    public function setDestination($vq)
    {
        $this->destination = $vq;
    }
    public function getIssuer()
    {
        return $this->issuer;
    }
    public function setIssuer($CL)
    {
        $this->issuer = $CL;
    }
}
