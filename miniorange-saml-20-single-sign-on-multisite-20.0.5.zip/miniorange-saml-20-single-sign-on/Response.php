<?php


include "\101\163\163\x65\x72\x74\151\157\x6e\56\160\x68\160";
class SAML2_Response
{
    private $assertions;
    private $destination;
    private $certificates;
    private $signatureData;
    public function __construct(DOMElement $Pk = NULL, $MR)
    {
        $this->assertions = array();
        $this->certificates = array();
        if (!($Pk === NULL)) {
            goto YlV;
        }
        return;
        YlV:
        $qD = Utilities::validateElement($Pk);
        if (!($qD !== FALSE)) {
            goto KMp;
        }
        $this->certificates = $qD["\x43\145\x72\x74\x69\146\151\x63\141\164\145\163"];
        $this->signatureData = $qD;
        KMp:
        if (!$Pk->hasAttribute("\104\x65\x73\164\151\156\x61\x74\x69\x6f\x6e")) {
            goto ziD;
        }
        $this->destination = $Pk->getAttribute("\x44\x65\163\164\151\x6e\x61\x74\151\157\156");
        ziD:
        $aB = $Pk->firstChild;
        jo5:
        if (!($aB !== NULL)) {
            goto rjS;
        }
        if (!($aB->namespaceURI !== "\165\x72\x6e\72\x6f\x61\x73\151\x73\72\x6e\141\155\x65\163\x3a\x74\x63\72\123\x41\x4d\x4c\x3a\x32\x2e\60\72\x61\x73\x73\x65\x72\x74\x69\157\x6e")) {
            goto N5s;
        }
        goto AlW;
        N5s:
        if (!($aB->localName === "\x41\163\x73\145\x72\164\151\x6f\x6e" || $aB->localName === "\x45\156\x63\x72\x79\x70\164\145\x64\101\x73\x73\x65\162\x74\151\157\x6e")) {
            goto n6l;
        }
        $this->assertions[] = new SAML2_Assertion($aB, $MR);
        n6l:
        AlW:
        $aB = $aB->nextSibling;
        goto jo5;
        rjS:
    }
    public function getAssertions()
    {
        return $this->assertions;
    }
    public function setAssertions(array $U2)
    {
        $this->assertions = $U2;
    }
    public function getDestination()
    {
        return $this->destination;
    }
    public function getCertificates()
    {
        return $this->certificates;
    }
    public function getSignatureData()
    {
        return $this->signatureData;
    }
}
