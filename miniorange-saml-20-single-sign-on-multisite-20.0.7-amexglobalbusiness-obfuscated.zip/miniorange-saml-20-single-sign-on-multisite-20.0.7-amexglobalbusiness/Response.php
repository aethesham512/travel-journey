<?php


include "\x41\x73\163\145\162\x74\x69\x6f\x6e\56\160\x68\160";
class SAML2_Response
{
    private $assertions;
    private $destination;
    private $certificates;
    private $signatureData;
    public function __construct(DOMElement $O3 = NULL, $Kg)
    {
        $this->assertions = array();
        $this->certificates = array();
        if (!($O3 === NULL)) {
            goto aw2;
        }
        return;
        aw2:
        $eQ = Utilities::validateElement($O3);
        if (!($eQ !== FALSE)) {
            goto clM;
        }
        $this->certificates = $eQ["\x43\145\x72\164\x69\x66\151\x63\x61\164\145\163"];
        $this->signatureData = $eQ;
        clM:
        if (!$O3->hasAttribute("\104\145\x73\164\151\156\x61\x74\151\x6f\156")) {
            goto z2g;
        }
        $this->destination = $O3->getAttribute("\x44\145\x73\164\x69\x6e\x61\164\x69\x6f\x6e");
        z2g:
        $y9 = $O3->firstChild;
        Ikh:
        if (!($y9 !== NULL)) {
            goto Vz5;
        }
        if (!($y9->namespaceURI !== "\165\162\156\x3a\157\141\x73\151\x73\72\x6e\141\x6d\x65\163\x3a\x74\x63\72\123\x41\x4d\114\x3a\62\x2e\x30\x3a\x61\163\163\145\x72\x74\151\x6f\156")) {
            goto TCr;
        }
        goto gO3;
        TCr:
        if (!($y9->localName === "\101\x73\163\145\x72\164\x69\157\156" || $y9->localName === "\105\x6e\x63\162\171\160\164\145\x64\x41\163\163\x65\162\x74\x69\157\156")) {
            goto qwB;
        }
        $this->assertions[] = new SAML2_Assertion($y9, $Kg);
        qwB:
        gO3:
        $y9 = $y9->nextSibling;
        goto Ikh;
        Vz5:
    }
    public function getAssertions()
    {
        return $this->assertions;
    }
    public function setAssertions(array $iV)
    {
        $this->assertions = $iV;
    }
    public function getDestination()
    {
        return $this->destination;
    }
    public function getCertificates()
    {
        return $this->certificates;
    }
    public function getSignatureData()
    {
        return $this->signatureData;
    }
}
