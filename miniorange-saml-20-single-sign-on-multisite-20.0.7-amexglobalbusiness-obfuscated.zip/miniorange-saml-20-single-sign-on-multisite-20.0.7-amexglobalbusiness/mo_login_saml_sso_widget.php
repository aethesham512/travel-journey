<?php


include_once dirname(__FILE__) . "\57\x55\x74\x69\x6c\x69\164\x69\145\x73\x2e\160\x68\x70";
include_once dirname(__FILE__) . "\57\x52\x65\x73\160\157\156\x73\x65\x2e\160\150\160";
include_once dirname(__FILE__) . "\x2f\114\157\147\x6f\165\164\x52\145\x71\x75\x65\163\164\x2e\160\150\x70";
require_once dirname(__FILE__) . "\57\x69\x6e\143\154\x75\x64\145\163\x2f\x6c\x69\x62\57\x65\x6e\x63\x72\171\160\164\x69\157\x6e\x2e\160\150\160";
include_once "\170\x6d\x6c\x73\145\x63\154\x69\142\163\56\x70\150\160";
use RobRichards\XMLSecLibs\XMLSecurityKey;
use RobRichards\XMLSecLibs\XMLSecurityDSig;
use RobRichards\XMLSecLibs\XMLSecEnc;
class mo_login_wid extends WP_Widget
{
    public function __construct()
    {
        $Px = get_site_option("\x73\141\155\x6c\x5f\151\x64\145\156\164\151\164\171\137\156\x61\155\145");
        parent::__construct("\x53\x61\155\x6c\x5f\x4c\x6f\x67\151\156\x5f\x57\x69\x64\147\145\164", "\x4c\x6f\x67\x69\156\40\167\151\164\x68\x20" . $Px, array("\144\145\163\x63\162\x69\160\x74\151\x6f\156" => __("\x54\150\x69\163\x20\x69\163\40\141\x20\155\151\156\x69\117\x72\x61\x6e\x67\x65\40\123\x41\x4d\x4c\40\154\157\x67\x69\156\x20\167\151\x64\147\x65\164\56", "\155\157\x73\141\x6d\154")));
    }
    public function widget($FJ, $OW)
    {
        extract($FJ);
        $rQ = apply_filters("\167\x69\144\147\x65\x74\x5f\x74\x69\164\154\145", $OW["\167\x69\144\x5f\x74\151\164\x6c\145"]);
        echo $FJ["\142\x65\x66\x6f\162\145\x5f\167\151\x64\x67\145\164"];
        if (empty($rQ)) {
            goto ui;
        }
        echo $FJ["\142\145\x66\157\x72\145\137\x74\x69\x74\154\x65"] . $rQ . $FJ["\x61\x66\164\145\162\x5f\x74\x69\164\154\x65"];
        ui:
        $this->loginForm();
        echo $FJ["\x61\x66\x74\145\162\x5f\167\x69\144\147\145\164"];
    }
    public function update($Q2, $mW)
    {
        $OW = array();
        $OW["\167\151\144\137\x74\151\164\154\145"] = strip_tags($Q2["\167\x69\x64\137\x74\x69\x74\x6c\x65"]);
        return $OW;
    }
    public function form($OW)
    {
        $rQ = '';
        if (!array_key_exists("\167\151\x64\137\164\x69\164\154\x65", $OW)) {
            goto TY;
        }
        $rQ = $OW["\167\151\144\x5f\164\151\x74\154\145"];
        TY:
        echo "\xd\xa\x9\x9\x3c\160\76\x3c\154\141\142\x65\154\40\146\157\x72\75\x22" . $this->get_field_id("\x77\x69\144\137\x74\x69\164\154\x65") . "\x20\x22\76" . _e("\124\151\164\x6c\145\72") . "\40\74\x2f\x6c\141\142\145\154\76\15\xa\x9\x9\11\x3c\x69\x6e\160\x75\x74\x20\143\x6c\141\x73\163\x3d\x22\x77\x69\144\145\x66\x61\164\x22\x20\151\x64\75\42" . $this->get_field_id("\x77\151\x64\137\x74\x69\x74\154\x65") . "\x22\40\x6e\x61\155\145\75\42" . $this->get_field_name("\x77\x69\144\137\164\151\x74\x6c\x65") . "\42\x20\164\171\160\145\x3d\x22\164\x65\170\164\x22\x20\x76\141\x6c\x75\145\x3d\x22" . $rQ . "\x22\40\57\76\xd\xa\x9\11\x3c\x2f\x70\x3e";
    }
    public function loginForm()
    {
        global $post;
        $vJ = get_site_option("\163\x61\155\x6c\x5f\163\x73\x6f\137\163\x65\x74\x74\151\x6e\147\x73");
        $cB = get_current_blog_id();
        $pJ = Utilities::get_active_sites();
        if (in_array($cB, $pJ)) {
            goto Rc;
        }
        return;
        Rc:
        if (!(empty($vJ[$cB]) && !empty($vJ["\104\x45\x46\101\125\114\124"]))) {
            goto P5;
        }
        $vJ[$cB] = $vJ["\104\105\x46\101\x55\114\124"];
        P5:
        if (!is_user_logged_in()) {
            goto ey;
        }
        $current_user = wp_get_current_user();
        $j6 = "\110\x65\x6c\x6c\x6f\54";
        if (empty($vJ[$cB]["\x6d\x6f\137\x73\x61\155\154\x5f\143\x75\163\164\x6f\x6d\137\x67\x72\145\x65\164\151\156\x67\x5f\164\145\170\x74"])) {
            goto ri;
        }
        $j6 = $vJ[$cB]["\x6d\x6f\x5f\x73\x61\155\154\x5f\x63\x75\163\164\x6f\155\137\x67\162\145\145\x74\151\x6e\147\x5f\x74\145\x78\164"];
        ri:
        $fc = '';
        if (empty($vJ[$cB]["\x6d\157\x5f\x73\141\155\x6c\x5f\x67\x72\145\x65\x74\151\156\x67\137\x6e\141\x6d\145"])) {
            goto XN;
        }
        switch ($vJ[$cB]["\155\x6f\x5f\163\x61\x6d\x6c\x5f\x67\x72\x65\x65\x74\x69\x6e\147\x5f\156\x61\155\x65"]) {
            case "\125\123\105\x52\x4e\101\x4d\x45":
                $fc = $current_user->user_login;
                goto F5;
            case "\x45\115\101\111\114":
                $fc = $current_user->user_email;
                goto F5;
            case "\x46\116\101\115\105":
                $fc = $current_user->user_firstname;
                goto F5;
            case "\x4c\116\101\x4d\x45":
                $fc = $current_user->user_lastname;
                goto F5;
            case "\x46\116\x41\x4d\105\x5f\114\116\101\115\105":
                $fc = $current_user->user_firstname . "\40" . $current_user->user_lastname;
                goto F5;
            case "\114\116\x41\x4d\105\137\x46\x4e\101\x4d\105":
                $fc = $current_user->user_lastname . "\x20" . $current_user->user_firstname;
                goto F5;
            default:
                $fc = $current_user->user_login;
        }
        oj:
        F5:
        XN:
        if (!empty(trim($fc))) {
            goto tM;
        }
        $fc = $current_user->user_login;
        tM:
        $hK = $j6 . "\x20" . $fc;
        $p4 = "\x4c\157\x67\x6f\x75\164";
        if (empty($vJ[$cB]["\x6d\157\137\x73\x61\x6d\x6c\137\x63\x75\163\x74\x6f\x6d\x5f\x6c\x6f\147\x6f\x75\x74\x5f\164\x65\170\x74"])) {
            goto EH;
        }
        $p4 = $vJ[$cB]["\x6d\x6f\137\x73\141\x6d\154\137\143\165\163\164\x6f\x6d\x5f\154\157\x67\x6f\x75\164\137\x74\145\x78\164"];
        EH:
        echo $hK . "\40\174\40\x3c\141\40\150\162\x65\146\75\x22" . wp_logout_url(home_url()) . "\42\40\164\151\x74\154\145\x3d\x22\x6c\x6f\x67\157\x75\x74\x22\40\x3e" . $p4 . "\74\x2f\141\76\74\x2f\154\x69\76";
        goto O7;
        ey:
        echo "\15\12\11\11\11\74\163\x63\162\x69\160\164\x3e\15\12\x9\11\x9\x9\x66\165\156\143\164\151\157\156\40\x73\165\142\x6d\151\164\x53\141\x6d\x6c\106\157\162\155\x28\x29\x7b\40\x64\157\x63\165\x6d\145\x6e\164\56\x67\145\x74\105\x6c\x65\155\x65\156\x74\102\171\111\144\50\x22\154\x6f\147\x69\156\x22\51\x2e\x73\x75\x62\155\151\164\x28\x29\73\40\x7d\15\12\11\x9\x9\74\x2f\163\143\x72\151\160\x74\76\xd\xa\11\11\11\x3c\146\x6f\x72\x6d\x20\156\x61\155\145\x3d\42\154\x6f\x67\151\x6e\x22\40\151\144\75\x22\x6c\157\x67\151\156\42\x20\x6d\145\164\150\157\x64\75\42\x70\x6f\x73\x74\x22\x20\141\143\164\151\x6f\x6e\75\x22\42\x3e\15\xa\11\x9\x9\x9\x3c\x69\156\x70\165\164\x20\164\171\x70\145\75\x22\150\151\x64\144\x65\x6e\42\x20\x6e\141\155\x65\75\x22\x6f\x70\164\151\x6f\x6e\x22\x20\166\x61\154\x75\x65\75\x22\x73\x61\155\154\x5f\x75\163\x65\x72\137\x6c\157\147\151\x6e\42\x20\x2f\76\15\xa\15\12\x9\x9\11\11\x3c\x66\x6f\156\x74\40\163\151\172\x65\75\x22\x2b\61\x22\40\163\164\x79\x6c\x65\75\x22\166\x65\162\164\151\143\x61\x6c\55\141\154\x69\x67\x6e\x3a\x74\157\160\73\x22\x3e\40\x3c\57\146\x6f\x6e\164\x3e";
        $pQ = get_site_option("\x73\x61\x6d\x6c\137\x69\x64\145\156\164\151\164\171\137\x6e\141\x6d\145");
        $py = get_site_option("\x73\x61\155\154\x5f\170\65\60\71\137\143\145\162\x74\151\146\151\x63\141\164\x65");
        if (!empty($pQ) && !empty($py)) {
            goto VC;
        }
        echo "\120\154\145\141\163\x65\x20\143\157\156\x66\151\147\x75\x72\145\40\x74\x68\145\40\x6d\151\156\151\117\162\141\x6e\147\145\40\123\101\x4d\114\40\120\x6c\x75\x67\x69\x6e\40\146\151\162\x73\x74\56";
        goto l3;
        VC:
        $ce = "\114\157\x67\151\156\x20\x77\151\x74\150\x20\x23\x23\x49\104\x50\43\43";
        if (empty($vJ[$cB]["\155\x6f\137\x73\x61\x6d\154\137\143\165\x73\164\157\x6d\137\154\x6f\x67\151\x6e\137\164\x65\x78\164"])) {
            goto Ke;
        }
        $ce = $vJ[$cB]["\x6d\x6f\137\x73\x61\155\x6c\137\x63\165\163\x74\157\x6d\137\x6c\157\147\151\x6e\x5f\x74\145\170\x74"];
        Ke:
        $ce = str_replace("\x23\x23\x49\x44\120\x23\43", $pQ, $ce);
        $yR = false;
        if (!(isset($vJ[$cB]["\x6d\157\x5f\x73\x61\x6d\x6c\137\165\x73\145\x5f\142\x75\164\164\157\156\x5f\141\x73\x5f\167\151\x64\x67\x65\x74"]) && $vJ[$cB]["\155\x6f\137\163\141\x6d\x6c\137\x75\x73\x65\x5f\142\x75\x74\x74\157\x6e\137\141\163\x5f\x77\x69\144\x67\145\164"] == "\x74\162\x75\x65")) {
            goto ik;
        }
        $yR = true;
        ik:
        if (!$yR) {
            goto iP;
        }
        $lb = isset($vJ[$cB]["\155\x6f\x5f\x73\141\155\x6c\137\x62\x75\x74\164\x6f\x6e\x5f\167\x69\144\x74\x68"]) ? $vJ[$cB]["\x6d\x6f\x5f\x73\141\155\154\x5f\142\x75\164\164\157\x6e\137\x77\x69\144\164\x68"] : "\x31\x30\60";
        $cK = isset($vJ[$cB]["\x6d\x6f\x5f\163\x61\x6d\x6c\x5f\x62\165\164\164\157\x6e\x5f\x68\145\x69\x67\x68\x74"]) ? $vJ[$cB]["\155\x6f\x5f\x73\x61\x6d\154\137\x62\x75\x74\x74\157\x6e\137\x68\x65\151\x67\x68\x74"] : "\65\x30";
        $K0 = isset($vJ[$cB]["\x6d\x6f\x5f\163\141\x6d\x6c\x5f\142\x75\164\x74\x6f\156\137\x73\x69\172\145"]) ? $vJ[$cB]["\155\x6f\137\x73\x61\155\x6c\137\142\x75\x74\x74\x6f\156\x5f\163\x69\172\x65"] : "\x35\x30";
        $P1 = isset($vJ[$cB]["\155\x6f\x5f\x73\141\x6d\x6c\137\x62\x75\164\164\x6f\x6e\137\143\165\x72\166\x65"]) ? $vJ[$cB]["\155\157\x5f\163\141\x6d\x6c\137\x62\x75\164\x74\157\156\137\x63\165\x72\166\x65"] : "\x35";
        $Gc = isset($vJ[$cB]["\x6d\157\x5f\x73\x61\x6d\x6c\137\142\x75\164\x74\157\156\137\x63\157\154\x6f\x72"]) ? $vJ[$cB]["\x6d\x6f\x5f\x73\x61\155\x6c\137\142\165\164\x74\x6f\156\x5f\x63\157\154\x6f\x72"] : "\x30\60\70\x35\142\x61";
        $DW = isset($vJ[$cB]["\155\157\137\x73\x61\155\x6c\x5f\142\x75\164\164\157\x6e\137\164\150\x65\155\145"]) ? $vJ[$cB]["\155\157\x5f\x73\141\x6d\x6c\x5f\142\165\x74\164\x6f\x6e\x5f\164\150\x65\155\145"] : "\154\x6f\x6e\x67\142\x75\x74\164\157\x6e";
        $Zt = isset($vJ[$cB]["\155\x6f\x5f\x73\x61\155\154\x5f\x62\165\x74\164\157\156\137\164\x65\x78\x74"]) ? $vJ[$cB]["\x6d\157\x5f\x73\141\155\x6c\137\142\165\164\x74\157\156\x5f\x74\145\x78\x74"] : (get_site_option("\163\x61\x6d\154\x5f\x69\x64\x65\x6e\x74\151\x74\171\x5f\156\x61\155\145") ? get_site_option("\x73\x61\x6d\154\137\151\144\145\x6e\164\151\x74\x79\137\156\x61\155\x65") : "\x4c\157\147\151\x6e");
        $tD = isset($vJ[$cB]["\x6d\x6f\x5f\x73\x61\x6d\x6c\x5f\146\157\156\164\137\143\x6f\154\x6f\162"]) ? $vJ[$cB]["\x6d\157\x5f\163\141\155\x6c\x5f\146\x6f\156\164\x5f\143\157\154\157\x72"] : "\x66\x66\x66\146\x66\146";
        $AH = isset($vJ[$cB]["\x6d\157\x5f\163\x61\155\x6c\x5f\x66\x6f\x6e\x74\x5f\163\x69\x7a\145"]) ? $vJ[$cB]["\x6d\157\x5f\163\141\155\x6c\137\x66\157\x6e\164\137\163\x69\172\x65"] : "\62\60";
        $zl = isset($vJ[$cB]["\x73\x73\157\x5f\142\x75\x74\164\157\156\137\x6c\157\147\151\x6e\137\x66\157\x72\155\137\x70\157\163\x69\x74\x69\x6f\x6e"]) ? $vJ[$cB]["\163\163\x6f\x5f\142\x75\x74\x74\157\156\x5f\154\157\x67\x69\156\x5f\146\157\162\x6d\137\x70\x6f\163\151\x74\151\x6f\x6e"] : "\x61\x62\x6f\166\x65";
        $ce = "\x3c\x69\x6e\x70\165\164\40\164\171\x70\x65\75\x22\142\x75\x74\164\157\x6e\42\40\x6e\x61\x6d\145\75\42\x6d\157\x5f\x73\141\155\x6c\137\167\160\137\x73\x73\x6f\137\142\x75\164\x74\157\156\x22\x20\166\141\154\x75\145\75\42" . $Zt . "\x22\40\163\x74\171\154\145\x3d\42";
        $xg = '';
        if ($DW == "\x6c\x6f\156\x67\x62\165\164\164\157\x6e") {
            goto Hb;
        }
        if ($DW == "\143\151\162\143\154\x65") {
            goto D_;
        }
        if ($DW == "\x6f\166\141\x6c") {
            goto EI;
        }
        if ($DW == "\x73\161\x75\x61\x72\145") {
            goto Yi;
        }
        goto Kh;
        D_:
        $xg = $xg . "\x77\151\144\164\x68\72" . $K0 . "\160\170\x3b";
        $xg = $xg . "\x68\x65\x69\147\x68\x74\72" . $K0 . "\160\170\x3b";
        $xg = $xg . "\142\157\162\x64\x65\x72\x2d\x72\x61\x64\151\165\163\x3a\x39\x39\71\x70\x78\x3b";
        goto Kh;
        EI:
        $xg = $xg . "\x77\x69\144\x74\x68\x3a" . $K0 . "\x70\x78\x3b";
        $xg = $xg . "\150\x65\151\147\150\x74\72" . $K0 . "\x70\x78\73";
        $xg = $xg . "\142\x6f\x72\144\x65\x72\55\x72\x61\x64\151\x75\x73\72\x35\x70\170\x3b";
        goto Kh;
        Yi:
        $xg = $xg . "\167\151\144\164\150\72" . $K0 . "\160\170\x3b";
        $xg = $xg . "\x68\x65\x69\x67\x68\164\x3a" . $K0 . "\160\170\73";
        $xg = $xg . "\142\157\162\x64\x65\162\x2d\x72\x61\x64\151\x75\x73\x3a\60\160\x78\x3b";
        Kh:
        goto Mu;
        Hb:
        $xg = $xg . "\x77\x69\x64\x74\150\x3a" . $lb . "\x70\170\x3b";
        $xg = $xg . "\x68\x65\x69\147\x68\164\72" . $cK . "\160\x78\73";
        $xg = $xg . "\142\157\x72\144\x65\x72\x2d\x72\x61\144\151\x75\x73\72" . $P1 . "\x70\170\x3b";
        Mu:
        $xg = $xg . "\x62\141\143\153\x67\162\157\x75\x6e\144\55\x63\x6f\x6c\157\162\x3a\x23" . $Gc . "\x3b";
        $xg = $xg . "\142\x6f\162\144\x65\162\x2d\x63\157\x6c\x6f\162\72\x74\x72\x61\x6e\163\x70\x61\162\x65\x6e\164\73";
        $xg = $xg . "\x63\157\154\x6f\x72\x3a\43" . $tD . "\73";
        $xg = $xg . "\x66\157\156\x74\55\x73\x69\172\145\72" . $AH . "\x70\x78\x3b";
        $xg = $xg . "\160\x61\144\144\151\156\147\x3a\60\160\x78\73";
        $ce = $ce . $xg . "\x22\x2f\76";
        iP:
        echo "\x20\x3c\141\40\x68\162\x65\146\x3d\x22\x23\x22\x20\x6f\156\x43\x6c\x69\x63\x6b\x3d\42\x73\x75\x62\155\151\x74\123\141\155\154\x46\157\x72\x6d\50\x29\x22\76";
        echo $ce;
        echo "\x3c\x2f\141\76\74\57\x66\x6f\162\155\76\x20";
        l3:
        if ($this->mo_saml_check_empty_or_null_val(get_site_option("\x6d\x6f\x5f\163\x61\155\x6c\137\162\145\x64\151\x72\x65\x63\164\137\x65\x72\x72\157\x72\137\x63\x6f\144\x65"))) {
            goto ct;
        }
        echo "\x3c\144\151\x76\x3e\74\x2f\144\x69\166\76\74\144\151\x76\40\x74\x69\x74\x6c\x65\75\42\114\157\x67\151\156\x20\x45\162\x72\157\162\42\76\74\x66\157\x6e\x74\40\143\x6f\x6c\x6f\162\x3d\42\x72\x65\144\x22\76\127\145\40\x63\157\x75\154\x64\40\x6e\157\x74\40\x73\x69\x67\156\x20\x79\157\165\40\151\156\56\40\x50\x6c\x65\x61\163\x65\x20\143\157\x6e\x74\141\x63\x74\x20\171\x6f\x75\x72\x20\x41\x64\155\151\156\x69\x73\x74\x72\x61\164\157\x72\x2e\x3c\57\146\157\x6e\164\76\74\57\x64\x69\166\76";
        delete_site_option("\155\x6f\x5f\163\x61\x6d\x6c\x5f\162\x65\144\151\162\145\143\164\137\145\162\x72\x6f\162\137\x63\157\144\145");
        delete_site_option("\x6d\157\x5f\x73\x61\155\x6c\x5f\162\x65\x64\x69\162\x65\x63\164\x5f\145\162\x72\x6f\x72\x5f\x72\145\141\x73\157\156");
        ct:
        echo "\74\x61\x20\150\x72\x65\146\75\42\x68\x74\164\x70\72\x2f\x2f\x6d\151\x6e\x69\x6f\x72\141\156\x67\x65\56\143\x6f\x6d\x2f\x77\157\162\144\x70\162\x65\163\x73\x2d\x6c\x64\x61\x70\x2d\154\x6f\147\x69\x6e\x22\40\x73\164\171\154\x65\75\42\144\151\x73\x70\154\141\171\72\x6e\x6f\x6e\x65\x22\x3e\x4c\x6f\147\151\156\x20\164\157\x20\x57\x6f\162\x64\120\x72\145\x73\163\40\165\163\151\x6e\x67\40\114\104\101\x50\x3c\57\141\76\xd\12\11\11\x9\11\74\x61\x20\x68\x72\x65\x66\75\x22\150\164\x74\160\72\57\57\155\x69\x6e\x69\x6f\162\x61\156\147\x65\56\143\x6f\x6d\57\143\154\x6f\165\x64\55\x69\144\145\156\x74\x69\x74\x79\55\x62\x72\157\x6b\x65\x72\55\163\x65\x72\x76\151\x63\x65\42\x20\163\164\171\154\x65\x3d\42\144\x69\x73\x70\x6c\141\x79\x3a\x6e\x6f\x6e\x65\x22\76\x43\x6c\x6f\165\144\x20\x49\144\145\x6e\x74\x69\x74\x79\x20\142\x72\157\153\x65\162\40\163\x65\x72\166\x69\143\145\x3c\57\x61\x3e\xd\xa\11\x9\x9\11\74\x61\40\150\162\x65\146\x3d\42\150\x74\164\160\72\x2f\x2f\155\x69\x6e\151\x6f\x72\x61\x6e\x67\x65\x2e\143\x6f\x6d\x2f\x73\x74\162\x6f\x6e\147\x5f\x61\x75\x74\x68\42\x20\163\x74\x79\154\145\75\42\x64\151\x73\x70\x6c\141\x79\x3a\x6e\157\156\x65\x3b\x22\76\x3c\57\141\x3e\15\12\x9\x9\x9\x9\74\141\40\150\162\145\x66\75\42\150\x74\x74\160\x3a\57\x2f\x6d\151\156\151\x6f\x72\x61\x6e\x67\x65\x2e\x63\x6f\155\x2f\x73\151\x6e\147\154\145\x2d\163\x69\x67\156\55\x6f\156\x2d\163\x73\157\42\40\x73\164\171\x6c\145\x3d\42\x64\x69\163\160\154\141\171\x3a\x6e\x6f\x6e\x65\73\x22\76\74\x2f\141\x3e\15\12\11\11\11\x9\x3c\141\40\150\162\145\x66\75\42\150\x74\x74\160\72\57\x2f\155\x69\x6e\x69\157\x72\x61\156\x67\x65\x2e\x63\x6f\155\x2f\x66\162\141\165\144\x22\x20\x73\164\x79\x6c\x65\x3d\x22\x64\x69\163\x70\x6c\x61\x79\x3a\156\x6f\x6e\145\73\42\76\74\x2f\141\x3e\15\12\xd\xa\x9\x9\x9\x3c\x2f\165\154\x3e\xd\xa\x9\x9\74\x2f\x66\157\x72\155\x3e";
        O7:
    }
    public function mo_saml_check_empty_or_null_val($nY)
    {
        if (!(!isset($nY) || empty($nY))) {
            goto v0;
        }
        return true;
        v0:
        return false;
    }
    function mo_saml_logout($LK)
    {
        $user = get_user_by("\x69\144", $LK);
        $lo = get_site_option("\163\141\x6d\154\137\154\157\x67\x6f\x75\164\137\x75\162\x6c");
        $BM = get_site_option("\163\x61\x6d\154\137\154\x6f\147\x6f\x75\164\x5f\142\151\156\144\x69\156\147\x5f\164\171\x70\x65");
        $current_user = $user;
        $FL = get_user_meta($current_user->ID, "\x6d\x6f\x5f\163\141\155\154\137\151\x64\160\137\x6c\x6f\147\x69\x6e");
        $FL = isset($FL[0]) ? $FL[0] : '';
        $Z1 = wp_get_referer();
        if (!empty($Z1)) {
            goto Jr;
        }
        $Z1 = !empty(get_site_option("\155\x6f\137\163\141\x6d\x6c\137\163\160\x5f\x62\x61\163\x65\137\165\162\x6c")) ? get_site_option("\155\x6f\x5f\163\141\155\154\137\163\160\137\x62\141\163\x65\x5f\x75\x72\154") : get_network_site_url();
        Jr:
        if (empty($lo)) {
            goto Oe;
        }
        if (!(!session_id() || session_id() == '' || !isset($_SESSION))) {
            goto PB;
        }
        session_start();
        PB:
        if (isset($_SESSION["\x6d\x6f\137\163\x61\155\x6c\137\x6c\157\147\157\165\164\x5f\162\145\x71\165\145\x73\164"])) {
            goto dN;
        }
        if ($FL == "\164\162\x75\145") {
            goto B3;
        }
        goto mj;
        dN:
        self::createLogoutResponseAndRedirect($lo, $BM);
        exit;
        goto mj;
        B3:
        delete_user_meta($current_user->ID, "\x6d\157\137\x73\x61\155\x6c\x5f\151\144\x70\137\x6c\x6f\147\x69\156");
        $jK = get_user_meta($current_user->ID, "\155\x6f\137\x73\x61\155\x6c\137\156\141\155\x65\137\x69\x64");
        $LF = get_user_meta($current_user->ID, "\155\157\137\x73\x61\x6d\x6c\137\163\145\x73\163\151\x6f\156\x5f\x69\156\144\145\170");
        mo_saml_create_logout_request($jK, $LF, $lo, $BM, $Z1);
        mj:
        Oe:
        wp_redirect($Z1);
        exit;
    }
    function createLogoutResponseAndRedirect($lo, $BM)
    {
        $IQ = get_site_option("\x6d\x6f\137\x73\x61\155\x6c\137\163\x70\x5f\142\141\163\x65\x5f\165\x72\x6c");
        if (!empty($IQ)) {
            goto kp;
        }
        $IQ = get_network_site_url();
        kp:
        $b9 = $_SESSION["\x6d\x6f\137\x73\x61\155\x6c\137\154\x6f\147\157\x75\x74\x5f\x72\145\161\165\145\x73\164"];
        $Gl = $_SESSION["\155\x6f\x5f\x73\x61\x6d\154\x5f\x6c\x6f\147\x6f\165\x74\137\x72\145\154\141\171\x5f\163\x74\x61\x74\145"];
        unset($_SESSION["\155\157\x5f\x73\141\155\154\137\154\157\x67\157\x75\164\137\x72\145\161\165\145\x73\x74"]);
        unset($_SESSION["\x6d\x6f\x5f\x73\141\x6d\x6c\x5f\154\157\x67\x6f\x75\x74\x5f\162\145\154\x61\x79\137\163\164\141\164\145"]);
        $i1 = new DOMDocument();
        $i1->loadXML($b9);
        $b9 = $i1->firstChild;
        if (!($b9->localName == "\x4c\157\147\x6f\165\164\x52\145\161\x75\x65\x73\164")) {
            goto UB;
        }
        $oU = new SAML2_LogoutRequest($b9);
        $VH = get_site_option("\155\x6f\137\x73\x61\155\x6c\x5f\x73\160\137\x65\156\x74\151\x74\x79\x5f\x69\x64");
        if (!empty($VH)) {
            goto Ad;
        }
        $VH = $IQ . "\57\167\x70\55\x63\157\156\164\145\156\x74\x2f\160\x6c\x75\147\151\x6e\x73\57\x6d\x69\156\x69\157\x72\141\156\147\145\x2d\163\141\x6d\x6c\x2d\x32\60\55\x73\151\x6e\x67\x6c\145\x2d\x73\151\147\156\55\157\156\57";
        Ad:
        $gg = $lo;
        $Pz = Utilities::createLogoutResponse($oU->getId(), $VH, $gg, $BM);
        if (empty($BM) || $BM == "\x48\164\x74\160\x52\145\144\x69\162\145\x63\164") {
            goto xe;
        }
        if (!(get_site_option("\163\x61\x6d\154\x5f\x72\145\x71\165\x65\x73\164\x5f\163\x69\x67\156\145\x64") == "\165\156\143\x68\x65\143\x6b\x65\144")) {
            goto cj;
        }
        $i3 = base64_encode($Pz);
        Utilities::postSAMLResponse($lo, $i3, $Gl);
        exit;
        cj:
        $Ie = '';
        $dO = '';
        $i3 = Utilities::signXML($Pz, "\123\164\x61\x74\165\x73");
        Utilities::postSAMLResponse($lo, $i3, $Gl);
        goto Hg;
        xe:
        $Bq = $lo;
        if (strpos($lo, "\x3f") !== false) {
            goto uN;
        }
        $Bq .= "\x3f";
        goto tz;
        uN:
        $Bq .= "\x26";
        tz:
        if (!(get_site_option("\x73\141\155\154\x5f\162\x65\x71\165\145\x73\164\137\163\151\147\156\x65\x64") == "\165\x6e\x63\150\x65\x63\153\x65\144")) {
            goto bU;
        }
        $Bq .= "\123\x41\x4d\x4c\122\x65\163\x70\157\x6e\x73\x65\x3d" . $Pz . "\46\x52\x65\x6c\141\171\123\164\141\x74\145\75" . urlencode($Gl);
        header("\x4c\157\x63\141\x74\x69\157\156\72\40" . $Bq);
        exit;
        bU:
        $Bq .= "\x53\101\115\x4c\122\145\x73\160\157\x6e\x73\x65\75" . $Pz . "\46\x52\145\154\x61\x79\x53\x74\141\x74\145\75" . urlencode($Gl);
        header("\x4c\x6f\x63\x61\x74\151\157\x6e\72\x20" . $Bq);
        exit;
        Hg:
        UB:
    }
}
function mo_saml_create_logout_request($jK, $LF, $lo, $BM, $Z1)
{
    $IQ = get_site_option("\155\157\137\x73\x61\x6d\154\x5f\x73\160\137\142\141\x73\x65\137\165\162\154");
    if (!empty($IQ)) {
        goto q2;
    }
    $IQ = get_network_site_url();
    q2:
    $VH = get_site_option("\155\157\137\x73\x61\x6d\x6c\137\x73\160\137\145\x6e\x74\151\164\171\x5f\x69\x64");
    if (!empty($VH)) {
        goto yn;
    }
    $VH = $IQ . "\x2f\167\160\55\143\x6f\156\x74\145\156\164\x2f\x70\x6c\165\147\151\156\163\x2f\x6d\151\156\x69\x6f\x72\x61\156\x67\145\x2d\163\x61\x6d\154\55\62\x30\55\163\x69\x6e\x67\x6c\145\55\x73\x69\147\156\55\157\x6e\57";
    yn:
    $gg = $lo;
    $fJ = $Z1;
    if (!empty($fJ)) {
        goto Xc;
    }
    $fJ = saml_get_current_page_url();
    if (!strpos($fJ, "\x3f")) {
        goto H0;
    }
    $fJ = get_network_site_url();
    H0:
    Xc:
    $fJ = mo_saml_relaystate_url($fJ);
    $zg = Utilities::createLogoutRequest($jK, $VH, $gg, $LF, $BM);
    if (empty($BM) || $BM == "\x48\x74\x74\x70\x52\145\x64\151\x72\145\143\164") {
        goto JM;
    }
    if (!(get_site_option("\163\141\x6d\154\x5f\162\x65\161\x75\x65\x73\x74\137\163\x69\x67\x6e\x65\144") == "\x75\156\x63\x68\x65\143\153\x65\x64")) {
        goto Jv;
    }
    $i3 = base64_encode($zg);
    Utilities::postSAMLRequest($lo, $i3, $fJ);
    exit;
    Jv:
    $Ie = '';
    $dO = '';
    $i3 = Utilities::signXML($zg, "\x4e\141\155\x65\111\104\120\157\x6c\x69\x63\171");
    Utilities::postSAMLRequest($lo, $i3, $fJ);
    goto Gb;
    JM:
    $Bq = $lo;
    if (strpos($lo, "\x3f") !== false) {
        goto h1;
    }
    $Bq .= "\x3f";
    goto ma;
    h1:
    $Bq .= "\x26";
    ma:
    if (!(get_site_option("\x73\141\155\x6c\137\162\x65\x71\x75\145\x73\164\x5f\163\151\x67\156\145\144") == "\x75\156\x63\150\145\x63\153\145\x64")) {
        goto Bb;
    }
    $Bq .= "\x53\101\x4d\x4c\122\x65\161\x75\145\x73\x74\75" . $zg . "\x26\122\145\x6c\141\171\123\164\141\164\145\75" . urlencode($fJ);
    header("\x4c\157\143\141\x74\151\157\156\72\40" . $Bq);
    exit;
    Bb:
    $zg = "\x53\x41\115\x4c\x52\145\161\x75\145\163\x74\x3d" . $zg . "\x26\x52\x65\x6c\x61\x79\123\164\x61\x74\145\x3d" . urlencode($fJ) . "\x26\x53\151\x67\x41\x6c\147\75" . urlencode(XMLSecurityKey::RSA_SHA256);
    $h5 = array("\164\x79\x70\145" => "\160\x72\151\166\141\x74\x65");
    $q3 = new XMLSecurityKey(XMLSecurityKey::RSA_SHA256, $h5);
    $ad = get_site_option("\155\157\137\163\x61\x6d\154\137\143\165\x72\x72\x65\x6e\x74\x5f\143\x65\x72\x74\137\x70\x72\x69\166\141\164\145\137\153\x65\x79");
    $q3->loadKey($ad, FALSE);
    $f1 = new XMLSecurityDSig();
    $XC = $q3->signData($zg);
    $XC = base64_encode($XC);
    $Bq .= $zg . "\46\x53\x69\147\x6e\x61\x74\165\162\145\75" . urlencode($XC);
    header("\114\157\x63\x61\x74\151\157\156\x3a" . $Bq);
    exit;
    Gb:
}
function mo_login_validate()
{
    if (!(isset($_REQUEST["\157\160\x74\x69\157\x6e"]) && $_REQUEST["\157\x70\164\151\157\156"] == "\x6d\157\x73\141\155\154\137\x6d\x65\164\141\144\141\164\141")) {
        goto EG;
    }
    miniorange_generate_metadata();
    EG:
    if (!mo_saml_is_customer_license_verified()) {
        goto WH;
    }
    if (!(isset($_REQUEST["\157\x70\x74\x69\x6f\x6e"]) && $_REQUEST["\x6f\160\164\x69\x6f\156"] == "\x73\141\x6d\154\137\165\x73\145\162\137\x6c\157\147\x69\156" || isset($_REQUEST["\157\x70\164\151\x6f\156"]) && $_REQUEST["\x6f\160\x74\x69\157\156"] == "\164\x65\x73\x74\x43\x6f\x6e\146\x69\x67" || isset($_REQUEST["\157\160\x74\x69\157\x6e"]) && $_REQUEST["\157\160\164\x69\x6f\156"] == "\x67\145\164\x73\141\x6d\154\x72\x65\161\165\x65\163\164" || isset($_REQUEST["\x6f\160\x74\x69\x6f\156"]) && $_REQUEST["\x6f\x70\164\x69\157\156"] == "\x67\145\x74\x73\141\x6d\154\x72\x65\163\160\x6f\156\163\145")) {
        goto LK;
    }
    if (mo_saml_is_sp_configured()) {
        goto u5;
    }
    if (!is_user_logged_in()) {
        goto SG;
    }
    if (!isset($_REQUEST["\x72\x65\144\x69\x72\145\143\x74\137\x74\x6f"])) {
        goto DY;
    }
    $S0 = htmlspecialchars($_REQUEST["\x72\145\144\x69\x72\145\x63\164\137\x74\x6f"]);
    wp_safe_redirect($S0);
    exit;
    DY:
    SG:
    goto Wp;
    u5:
    if (!(is_user_logged_in() and $_REQUEST["\157\x70\164\151\x6f\x6e"] == "\x73\141\x6d\154\x5f\x75\x73\x65\162\x5f\x6c\157\147\x69\156")) {
        goto m5;
    }
    if (!isset($_REQUEST["\162\145\x64\x69\162\x65\x63\164\137\164\x6f"])) {
        goto iz;
    }
    $S0 = htmlspecialchars($_REQUEST["\x72\x65\x64\x69\x72\x65\143\164\137\x74\157"]);
    wp_safe_redirect($S0);
    exit;
    iz:
    return;
    m5:
    $IQ = get_site_option("\x6d\157\137\163\x61\x6d\154\137\x73\160\x5f\142\141\x73\145\137\165\162\154");
    if (!empty($IQ)) {
        goto zC;
    }
    $IQ = get_network_site_url();
    zC:
    $vJ = get_site_option("\x73\x61\155\x6c\x5f\x73\163\157\137\163\x65\x74\164\151\156\147\163");
    $cB = get_current_blog_id();
    $pJ = Utilities::get_active_sites();
    if (in_array($cB, $pJ)) {
        goto y9;
    }
    return;
    y9:
    if (!(empty($vJ[$cB]) && !empty($vJ["\104\105\106\101\125\114\x54"]))) {
        goto AV;
    }
    $vJ[$cB] = $vJ["\104\x45\106\101\125\x4c\x54"];
    AV:
    if ($_REQUEST["\x6f\160\x74\x69\x6f\156"] == "\164\x65\163\x74\x43\157\x6e\x66\151\147" and array_key_exists("\x6e\145\167\143\145\162\x74", $_REQUEST)) {
        goto Jn;
    }
    if ($_REQUEST["\157\x70\164\x69\x6f\156"] == "\x74\145\x73\x74\x43\x6f\x6e\x66\151\147") {
        goto Ae;
    }
    if ($_REQUEST["\x6f\x70\164\151\x6f\156"] == "\x67\145\x74\163\141\x6d\154\162\x65\x71\x75\145\163\164") {
        goto x4;
    }
    if ($_REQUEST["\x6f\160\x74\x69\157\156"] == "\x67\x65\x74\x73\x61\155\154\x72\145\163\160\157\x6e\163\145") {
        goto rD;
    }
    if (!empty($vJ[$cB]["\155\157\x5f\163\x61\x6d\154\137\x72\145\154\141\x79\x5f\163\x74\141\x74\x65"])) {
        goto D3;
    }
    if (isset($_REQUEST["\x72\145\x64\x69\x72\x65\143\164\x5f\164\157"])) {
        goto kr;
    }
    $fJ = saml_get_current_page_url();
    goto YO;
    kr:
    $fJ = $_REQUEST["\x72\145\144\151\162\x65\x63\x74\137\x74\x6f"];
    YO:
    goto lH;
    D3:
    $fJ = $vJ[$cB]["\x6d\157\x5f\x73\x61\155\154\137\162\x65\154\141\x79\137\x73\x74\141\x74\145"];
    lH:
    goto le;
    rD:
    $fJ = "\x64\151\163\x70\x6c\x61\x79\x53\x41\x4d\x4c\122\x65\163\x70\157\156\163\145";
    le:
    goto O4;
    x4:
    $fJ = "\144\151\163\x70\154\141\x79\x53\x41\115\x4c\122\145\161\165\x65\163\x74";
    O4:
    goto Nf;
    Ae:
    $fJ = "\164\x65\x73\x74\126\x61\154\151\144\x61\164\145";
    Nf:
    goto OG;
    Jn:
    $fJ = "\164\145\x73\x74\x4e\145\x77\x43\x65\162\164\x69\146\x69\x63\x61\164\145";
    OG:
    $wJ = get_site_option("\x73\x61\155\154\137\154\157\x67\x69\x6e\x5f\x75\x72\x6c");
    $dU = !empty(get_site_option("\163\141\x6d\x6c\x5f\154\157\x67\151\156\x5f\x62\151\x6e\144\151\x6e\x67\x5f\164\171\160\x65")) ? get_site_option("\x73\141\155\154\x5f\154\x6f\x67\151\156\x5f\x62\x69\x6e\x64\x69\x6e\x67\137\164\x79\x70\145") : "\110\x74\164\160\x50\157\163\x74";
    $vJ = get_site_option("\x73\141\155\154\x5f\x73\163\157\x5f\163\x65\164\x74\151\x6e\x67\x73");
    $cB = get_current_blog_id();
    $pJ = Utilities::get_active_sites();
    if (in_array($cB, $pJ)) {
        goto eF;
    }
    return;
    eF:
    if (!(empty($vJ[$cB]) && !empty($vJ["\104\105\x46\101\125\x4c\x54"]))) {
        goto hF;
    }
    $vJ[$cB] = $vJ["\x44\x45\x46\101\125\114\124"];
    hF:
    $zT = isset($vJ[$cB]["\155\x6f\137\163\141\155\x6c\137\146\157\162\143\x65\x5f\141\x75\164\x68\145\x6e\164\x69\x63\x61\x74\x69\x6f\x6e"]) ? $vJ[$cB]["\x6d\157\x5f\x73\x61\155\154\x5f\x66\157\162\143\x65\137\x61\x75\x74\150\145\x6e\164\x69\143\141\x74\151\x6f\156"] : '';
    $w5 = $IQ . "\x2f";
    $VH = get_site_option("\x6d\x6f\137\x73\141\x6d\x6c\137\163\160\137\145\156\x74\x69\x74\x79\x5f\151\144");
    $Mn = get_site_option("\x73\x61\155\154\x5f\156\141\x6d\x65\151\x64\137\146\157\x72\x6d\x61\x74");
    if (!empty($Mn)) {
        goto kn;
    }
    $Mn = "\x31\56\x31\x3a\156\141\x6d\x65\x69\x64\x2d\146\157\162\x6d\x61\x74\x3a\165\x6e\163\160\x65\x63\151\146\151\145\144";
    kn:
    if (!empty($VH)) {
        goto IH;
    }
    $VH = $IQ . "\x2f\x77\160\55\143\157\156\x74\x65\156\x74\57\160\x6c\165\x67\151\x6e\x73\57\x6d\x69\x6e\151\x6f\x72\x61\156\147\145\55\163\141\155\x6c\55\62\60\x2d\x73\151\x6e\147\x6c\x65\55\163\151\x67\x6e\x2d\x6f\x6e\57";
    IH:
    $zg = Utilities::createAuthnRequest($w5, $VH, $wJ, $zT, $dU, $Mn);
    if (!($fJ == "\144\x69\x73\x70\x6c\x61\171\123\101\115\x4c\x52\x65\x71\165\x65\163\x74")) {
        goto V9;
    }
    mo_saml_show_SAML_log(Utilities::createAuthnRequest($w5, $VH, $wJ, $zT, "\x48\x74\164\x70\120\157\163\x74", $Mn), $fJ);
    V9:
    $Bq = htmlspecialchars_decode($wJ);
    if (strpos($wJ, "\77") !== false) {
        goto gM;
    }
    $Bq .= "\x3f";
    goto Q2;
    gM:
    $Bq .= "\46";
    Q2:
    $fJ = mo_saml_relaystate_url($fJ);
    if ($dU == "\110\x74\x74\160\x52\145\144\x69\x72\x65\143\x74") {
        goto fh;
    }
    if (!(get_site_option("\x73\141\155\154\x5f\x72\145\x71\x75\x65\x73\x74\x5f\163\x69\147\156\145\144") == "\x75\x6e\x63\150\x65\143\x6b\x65\144")) {
        goto Zg;
    }
    $i3 = base64_encode($zg);
    Utilities::postSAMLRequest($wJ, $i3, $fJ);
    exit;
    Zg:
    $Ie = '';
    $dO = '';
    if ($_REQUEST["\x6f\160\164\x69\x6f\156"] == "\x74\145\x73\164\x43\157\156\146\151\147" && array_key_exists("\156\x65\167\x63\145\162\164", $_REQUEST)) {
        goto QA;
    }
    $i3 = Utilities::signXML($zg, "\x4e\x61\155\x65\111\x44\x50\157\154\x69\143\171");
    goto bf;
    QA:
    $i3 = Utilities::signXML($zg, "\116\141\155\x65\111\104\120\157\154\151\143\x79", true);
    bf:
    Utilities::postSAMLRequest($wJ, $i3, $fJ);
    update_site_option("\x6d\x6f\137\163\x61\x6d\154\137\156\x65\167\x5f\x63\x65\162\x74\x5f\164\145\x73\164", true);
    goto Sv;
    fh:
    if (!(get_site_option("\x73\x61\155\154\x5f\x72\x65\x71\x75\x65\x73\x74\137\163\x69\x67\156\x65\x64") == "\x75\156\x63\x68\145\x63\153\145\x64")) {
        goto ua;
    }
    $Bq .= "\123\101\115\x4c\x52\145\161\x75\145\x73\x74\75" . $zg . "\x26\122\145\154\141\171\x53\164\x61\164\x65\x3d" . urlencode($fJ);
    header("\x4c\157\x63\x61\164\151\157\x6e\x3a\40" . $Bq);
    exit;
    ua:
    $zg = "\123\101\x4d\x4c\x52\145\x71\x75\145\163\x74\x3d" . $zg . "\46\122\145\x6c\x61\x79\x53\164\x61\x74\x65\75" . urlencode($fJ) . "\46\x53\x69\147\x41\154\147\x3d" . urlencode(XMLSecurityKey::RSA_SHA256);
    $h5 = array("\164\x79\160\145" => "\160\162\x69\x76\x61\164\x65");
    $q3 = new XMLSecurityKey(XMLSecurityKey::RSA_SHA256, $h5);
    if ($_REQUEST["\157\x70\164\x69\157\156"] == "\164\x65\163\x74\103\x6f\156\x66\x69\147" && array_key_exists("\156\145\167\x63\x65\162\164", $_REQUEST)) {
        goto jO;
    }
    $ad = get_site_option("\155\157\137\x73\141\x6d\x6c\137\x63\x75\162\x72\x65\x6e\164\x5f\x63\145\x72\x74\137\x70\162\151\x76\x61\164\145\x5f\x6b\x65\171");
    goto oW;
    jO:
    $ad = file_get_contents(plugin_dir_path(__FILE__) . "\162\145\x73\x6f\x75\162\143\145\x73" . DIRECTORY_SEPARATOR . mo_options_enum_default_sp_certificate::SP_Private_Key);
    oW:
    $q3->loadKey($ad, FALSE);
    $f1 = new XMLSecurityDSig();
    $XC = $q3->signData($zg);
    $XC = base64_encode($XC);
    $Bq .= $zg . "\46\123\151\x67\156\x61\164\165\x72\145\75" . urlencode($XC);
    header("\x4c\x6f\143\141\x74\x69\157\156\72\x20" . $Bq);
    exit;
    Sv:
    Wp:
    LK:
    if (!(array_key_exists("\x53\x41\x4d\114\122\145\163\160\157\156\163\145", $_REQUEST) && !empty($_REQUEST["\123\x41\115\x4c\x52\x65\163\160\x6f\156\163\145"]))) {
        goto K5;
    }
    if (array_key_exists("\x52\x65\x6c\141\x79\123\164\141\164\145", $_POST) && !empty($_POST["\122\145\x6c\141\x79\x53\x74\x61\x74\x65"]) && $_POST["\x52\145\154\141\171\x53\164\141\164\145"] != "\x2f") {
        goto eY;
    }
    $lV = '';
    goto nJ;
    eY:
    $lV = $_POST["\122\x65\154\x61\x79\x53\164\141\x74\x65"];
    nJ:
    $lV = mo_saml_parse_url($lV);
    $IQ = get_site_option("\x6d\157\137\163\x61\x6d\154\x5f\x73\160\x5f\x62\x61\x73\x65\137\165\x72\154");
    if (!empty($IQ)) {
        goto Kb;
    }
    $IQ = get_network_site_url();
    Kb:
    $Ik = $_REQUEST["\x53\x41\115\114\x52\x65\x73\x70\157\x6e\x73\x65"];
    $Ik = base64_decode($Ik);
    if (!($lV == "\144\x69\x73\x70\x6c\141\x79\123\x41\x4d\x4c\122\145\x73\160\x6f\156\x73\145")) {
        goto uK;
    }
    mo_saml_show_SAML_log($Ik, $lV);
    uK:
    if (!(array_key_exists("\x53\x41\115\x4c\x52\x65\163\x70\157\x6e\x73\x65", $_GET) && !empty($_GET["\123\101\x4d\114\122\145\163\x70\x6f\156\163\x65"]))) {
        goto rE;
    }
    $Ik = gzinflate($Ik);
    rE:
    $i1 = new DOMDocument();
    $i1->loadXML($Ik);
    $Eq = $i1->firstChild;
    $fT = $i1->documentElement;
    $G1 = new DOMXpath($i1);
    $G1->registerNamespace("\163\141\155\x6c\160", "\165\162\156\x3a\157\x61\x73\x69\163\72\x6e\141\x6d\145\x73\72\164\143\72\x53\x41\115\x4c\x3a\62\56\60\x3a\x70\x72\157\164\157\143\x6f\154");
    $G1->registerNamespace("\163\x61\x6d\154", "\x75\162\x6e\72\x6f\141\163\151\163\72\x6e\141\x6d\145\163\x3a\x74\143\72\123\101\x4d\x4c\72\x32\x2e\60\x3a\141\163\x73\x65\x72\164\151\x6f\156");
    if ($Eq->localName == "\x4c\157\x67\x6f\165\164\122\x65\x73\x70\x6f\x6e\163\x65") {
        goto z7;
    }
    $vj = $G1->query("\57\x73\x61\x6d\x6c\x70\72\x52\145\163\160\x6f\x6e\163\145\x2f\x73\x61\155\154\x70\72\123\x74\141\164\x75\x73\57\x73\141\x6d\154\160\72\123\164\141\164\x75\x73\x43\157\144\145", $fT);
    $V4 = isset($vj) ? $vj->item(0)->getAttribute("\126\141\154\165\x65") : '';
    $KF = explode("\72", $V4);
    if (!array_key_exists(7, $KF)) {
        goto fa;
    }
    $vj = $KF[7];
    fa:
    $iK = $G1->query("\x2f\x73\x61\x6d\154\x70\72\122\145\x73\160\x6f\x6e\x73\145\57\x73\x61\155\154\160\x3a\123\164\x61\164\x75\x73\x2f\x73\141\x6d\154\x70\72\123\x74\x61\x74\x75\x73\x4d\x65\163\163\x61\x67\145", $fT);
    $hM = isset($iK) ? $iK->item(0) : '';
    if (empty($hM)) {
        goto hH;
    }
    $hM = $hM->nodeValue;
    hH:
    if (array_key_exists("\x52\x65\154\x61\x79\123\x74\141\164\145", $_POST) && !empty($_POST["\x52\x65\154\141\171\x53\x74\x61\164\145"]) && $_POST["\x52\145\154\141\171\x53\164\x61\164\145"] != "\57") {
        goto eb;
    }
    $lV = '';
    goto sC;
    eb:
    $lV = $_POST["\x52\x65\x6c\x61\171\x53\x74\141\x74\145"];
    $lV = mo_saml_parse_url($lV);
    sC:
    if (!($vj != "\123\165\143\143\x65\163\163")) {
        goto HR;
    }
    show_status_error($vj, $lV, $hM);
    HR:
    if (!($lV !== "\164\x65\x73\164\126\141\154\151\x64\x61\x74\x65" && $lV !== "\x74\x65\163\x74\116\x65\x77\x43\x65\162\x74\151\146\151\x63\x61\164\145")) {
        goto Zx;
    }
    $jE = parse_url($lV, PHP_URL_HOST);
    $QM = parse_url($IQ, PHP_URL_HOST);
    $mQ = parse_url(get_current_base_url(), PHP_URL_HOST);
    if (!empty($lV)) {
        goto UZ;
    }
    $lV = "\x2f";
    goto mZ;
    UZ:
    $lV = mo_saml_parse_url($lV);
    mZ:
    if (!(!empty($jE) && $jE != $mQ)) {
        goto tq;
    }
    Utilities::postSAMLResponse($lV, $_REQUEST["\123\x41\x4d\114\x52\x65\x73\160\x6f\156\163\x65"], mo_saml_relaystate_url($lV));
    tq:
    Zx:
    $L3 = maybe_unserialize(get_site_option("\163\x61\155\154\x5f\x78\65\60\71\137\x63\x65\162\x74\x69\x66\151\x63\x61\x74\x65"));
    update_site_option("\155\x6f\x5f\x73\x61\x6d\154\x5f\x72\x65\163\x70\x6f\156\163\145", base64_encode($Ik));
    foreach ($L3 as $q3 => $nY) {
        if (@openssl_x509_read($nY)) {
            goto D7;
        }
        unset($L3[$q3]);
        D7:
        rs:
    }
    pt:
    $w5 = $IQ . "\x2f";
    if ($lV == "\x74\145\163\x74\116\x65\167\x43\145\x72\x74\151\x66\151\143\x61\164\145") {
        goto Gp;
    }
    $Ik = new SAML2_Response($Eq, get_site_option("\x6d\x6f\137\x73\x61\155\x6c\137\143\165\162\x72\x65\x6e\164\137\x63\x65\162\x74\137\160\162\151\x76\141\x74\x65\x5f\x6b\145\171"));
    goto zP;
    Gp:
    $rC = file_get_contents(plugin_dir_path(__FILE__) . "\x72\145\163\157\165\x72\143\145\163" . DIRECTORY_SEPARATOR . mo_options_enum_default_sp_certificate::SP_Private_Key);
    $Ik = new SAML2_Response($Eq, $rC);
    zP:
    $sq = $Ik->getSignatureData();
    $ve = current($Ik->getAssertions())->getSignatureData();
    if (!(empty($ve) && empty($sq))) {
        goto pX;
    }
    if ($lV == "\x74\145\x73\164\126\x61\x6c\151\x64\141\x74\x65" or $lV == "\x74\x65\x73\164\x4e\x65\x77\103\x65\162\x74\x69\146\x69\x63\x61\x74\145") {
        goto Ow;
    }
    wp_die("\x57\145\x20\x63\x6f\x75\x6c\144\x20\x6e\x6f\164\x20\163\151\x67\156\x20\171\157\165\x20\151\156\x2e\x20\120\x6c\x65\x61\x73\145\40\143\x6f\156\x74\141\x63\x74\x20\141\x64\x6d\x69\156\151\x73\164\x72\x61\164\x6f\x72", "\x45\162\162\157\x72\72\40\111\156\x76\x61\154\151\144\40\x53\101\115\114\x20\x52\x65\163\160\157\x6e\x73\x65");
    goto S9;
    Ow:
    $ti = mo_options_error_constants::Error_no_certificate;
    $V2 = mo_options_error_constants::Cause_no_certificate;
    echo "\x3c\144\x69\x76\x20\x73\x74\x79\x6c\x65\x3d\42\x66\157\x6e\x74\x2d\x66\x61\x6d\x69\154\x79\x3a\x43\x61\x6c\151\x62\162\151\x3b\160\141\x64\x64\x69\156\147\x3a\60\40\x33\x25\73\42\76\15\xa\11\x9\11\11\x9\x9\x3c\x64\151\166\x20\x73\164\x79\x6c\145\x3d\x22\x63\157\x6c\x6f\x72\72\40\43\141\x39\x34\64\x34\62\x3b\x62\x61\143\x6b\147\162\x6f\165\156\144\55\x63\x6f\154\157\162\x3a\40\43\146\62\x64\145\144\145\73\160\141\x64\144\151\x6e\x67\72\x20\61\65\160\170\73\x6d\141\x72\x67\151\156\55\142\157\164\x74\157\155\x3a\x20\62\60\160\170\73\164\145\x78\164\55\x61\154\151\147\156\72\x63\x65\x6e\x74\x65\x72\73\142\157\162\144\145\162\72\61\x70\170\x20\x73\157\x6c\x69\144\x20\x23\x45\66\x42\63\102\62\73\x66\157\156\x74\x2d\x73\x69\x7a\145\x3a\61\x38\x70\x74\x3b\x22\x3e\40\105\x52\x52\x4f\122\x3c\57\144\151\x76\76\15\12\11\x9\x9\11\x9\11\74\144\x69\166\x20\x73\164\171\x6c\x65\x3d\42\143\x6f\154\x6f\x72\x3a\x20\43\141\x39\x34\64\64\62\73\146\x6f\x6e\x74\x2d\163\151\x7a\x65\72\x31\x34\x70\164\73\40\155\x61\x72\x67\x69\x6e\x2d\x62\x6f\x74\x74\157\x6d\72\62\60\160\170\x3b\x22\x3e\x3c\x70\x3e\74\x73\164\x72\x6f\x6e\x67\76\105\162\x72\157\162\x20\x20\x3a" . esc_html($ti) . "\x20\74\57\163\164\162\x6f\156\x67\76\x3c\57\160\76\15\12\11\x9\11\x9\11\x9\xd\12\x9\11\x9\11\11\11\74\160\76\x3c\x73\x74\162\157\x6e\x67\76\120\157\163\x73\151\x62\x6c\145\x20\x43\141\165\x73\x65\x3a\40" . esc_html($V2) . "\x3c\57\163\164\x72\x6f\156\147\x3e\x3c\57\160\76\xd\12\x9\11\x9\x9\11\11\xd\xa\x9\x9\11\11\x9\11\x3c\57\x64\151\166\76\x3c\x2f\144\x69\166\x3e";
    mo_saml_download_logs($ti, $V2);
    exit;
    S9:
    pX:
    $bv = '';
    if (is_array($L3)) {
        goto km;
    }
    $yt = XMLSecurityKey::getRawThumbprint($L3);
    $yt = mo_saml_convert_to_windows_iconv($yt);
    $yt = preg_replace("\57\x5c\x73\53\57", '', $yt);
    if (empty($sq)) {
        goto Tn;
    }
    $bv = Utilities::processResponse($w5, $yt, $sq, $Ik, 0, $lV);
    Tn:
    if (empty($ve)) {
        goto Et;
    }
    $bv = Utilities::processResponse($w5, $yt, $ve, $Ik, 0, $lV);
    Et:
    goto HN;
    km:
    foreach ($L3 as $q3 => $nY) {
        $yt = XMLSecurityKey::getRawThumbprint($nY);
        $yt = mo_saml_convert_to_windows_iconv($yt);
        $yt = preg_replace("\x2f\x5c\163\53\x2f", '', $yt);
        if (empty($sq)) {
            goto KU;
        }
        $bv = Utilities::processResponse($w5, $yt, $sq, $Ik, $q3, $lV);
        KU:
        if (empty($ve)) {
            goto BW;
        }
        $bv = Utilities::processResponse($w5, $yt, $ve, $Ik, $q3, $lV);
        BW:
        if (!$bv) {
            goto yE;
        }
        goto bK;
        yE:
        mE:
    }
    bK:
    HN:
    if (empty($sq)) {
        goto NT;
    }
    $z4 = $sq["\x43\x65\162\164\151\146\x69\x63\141\164\x65\163"][0];
    goto MP;
    NT:
    $z4 = $ve["\103\145\162\164\151\146\x69\x63\141\x74\x65\163"][0];
    MP:
    if ($bv) {
        goto N8;
    }
    if ($lV == "\x74\145\x73\164\126\x61\154\151\x64\x61\x74\x65" or $lV == "\164\145\x73\x74\x4e\x65\x77\103\x65\162\164\x69\146\151\143\x61\164\x65") {
        goto B8;
    }
    wp_die("\x57\x65\x20\x63\x6f\x75\x6c\x64\x20\156\157\164\40\163\151\x67\x6e\40\171\157\x75\x20\151\156\56\x20\x50\x6c\x65\x61\x73\x65\40\143\157\x6e\164\141\143\x74\x20\x79\x6f\x75\162\x20\x41\144\x6d\151\x6e\151\x73\x74\x72\141\164\157\x72", "\x45\162\x72\157\162\40\72\103\x65\x72\164\151\x66\x69\x63\141\164\145\40\x6e\157\164\x20\146\157\x75\156\144");
    goto us;
    B8:
    $ti = mo_options_error_constants::Error_wrong_certificate;
    $V2 = mo_options_error_constants::Cause_wrong_certificate;
    $MW = "\x2d\x2d\x2d\x2d\55\102\x45\107\x49\x4e\40\103\105\x52\124\111\x46\x49\103\101\124\x45\x2d\x2d\x2d\x2d\55\74\142\x72\76" . chunk_split($z4, 64) . "\x3c\142\x72\76\55\55\55\x2d\55\105\116\x44\x20\x43\x45\x52\x54\x49\x46\111\103\101\124\x45\x2d\x2d\x2d\55\x2d";
    echo "\x3c\x64\x69\x76\40\163\x74\x79\154\145\x3d\x22\146\x6f\x6e\x74\x2d\x66\x61\x6d\151\154\171\72\103\x61\x6c\x69\142\162\x69\73\160\x61\144\x64\151\x6e\147\72\60\40\x33\45\73\x22\x3e";
    echo "\x3c\144\x69\166\40\163\164\x79\154\x65\x3d\42\x63\157\x6c\x6f\x72\x3a\x20\43\141\71\x34\x34\64\62\73\x62\141\143\x6b\x67\162\157\x75\156\144\x2d\143\157\154\157\162\x3a\x20\43\x66\62\144\145\x64\145\x3b\x70\141\144\144\151\156\x67\72\x20\x31\x35\160\170\73\155\141\162\x67\x69\x6e\x2d\142\x6f\164\x74\157\155\72\40\62\60\160\170\73\164\145\170\x74\x2d\141\154\x69\147\x6e\72\x63\x65\x6e\164\145\x72\73\142\x6f\162\x64\145\162\x3a\61\160\x78\x20\x73\157\x6c\151\144\40\43\x45\x36\x42\x33\x42\62\73\x66\157\156\x74\x2d\x73\x69\x7a\145\72\61\x38\160\164\x3b\42\x3e\x20\105\122\122\x4f\122\74\x2f\x64\151\x76\x3e\xd\xa\x20\40\40\40\40\40\40\x20\x20\40\x20\x20\40\x20\40\x20\x20\40\40\40\40\40\40\40\x3c\144\151\x76\x20\x73\164\171\154\145\75\x22\x63\x6f\x6c\x6f\162\x3a\40\43\x61\71\x34\64\64\62\73\x66\157\x6e\164\55\x73\x69\x7a\145\72\61\64\x70\164\x3b\40\155\141\162\x67\x69\x6e\x2d\142\x6f\164\x74\157\155\x3a\62\60\160\170\x3b\x22\76\74\x70\x3e\74\x73\164\162\157\156\147\76\105\162\x72\157\162\x3a\x20\74\x2f\x73\164\x72\x6f\x6e\x67\76\125\x6e\141\142\x6c\x65\40\164\157\40\146\x69\156\x64\40\141\x20\x63\145\162\x74\x69\x66\x69\x63\141\x74\145\x20\155\x61\164\143\x68\151\x6e\x67\x20\164\150\x65\x20\143\x6f\156\x66\151\x67\x75\x72\x65\144\x20\x66\151\x6e\x67\145\x72\x70\162\x69\156\164\x2e\x3c\x2f\160\x3e\15\xa\40\40\x20\40\x20\x20\x20\40\40\x20\40\40\x20\40\x20\40\x20\x20\x20\x20\40\40\40\x20\40\40\40\x20\x3c\x70\76\x50\x6c\145\141\x73\145\x20\143\x6f\156\164\141\143\164\x20\171\157\x75\162\x20\141\x64\155\x69\x6e\x69\163\x74\x72\141\164\157\162\x20\x61\x6e\144\40\162\x65\x70\x6f\162\x74\x20\164\150\x65\x20\x66\157\154\154\x6f\x77\x69\x6e\147\40\x65\x72\x72\157\162\x3a\x3c\57\x70\x3e\xd\12\x20\40\40\x20\40\x20\40\40\x20\40\40\x20\x20\40\40\40\x20\x20\x20\40\40\x20\40\40\40\x20\x20\x20\74\160\x3e\74\163\164\162\157\156\x67\x3e\120\x6f\163\x73\151\x62\154\145\40\x43\141\x75\x73\x65\72\40\74\x2f\x73\164\162\157\156\147\76\47\x58\x2e\65\x30\71\x20\x43\145\162\x74\151\x66\x69\x63\141\x74\145\47\x20\x66\151\x65\154\144\x20\x69\156\40\x70\x6c\x75\x67\151\156\x20\x64\x6f\145\163\x20\x6e\157\x74\40\x6d\141\164\143\x68\x20\164\150\145\x20\143\x65\x72\164\x69\x66\x69\143\141\164\145\40\146\x6f\x75\156\144\x20\151\x6e\40\x53\101\115\x4c\x20\x52\145\163\160\157\156\x73\x65\x2e\74\57\x70\x3e\xd\xa\40\x20\40\40\40\x20\x20\x20\40\x20\40\x20\x20\40\x20\40\40\x20\x20\40\40\x20\x20\40\x20\40\x20\40\74\160\76\74\163\164\x72\x6f\156\147\x3e\x43\145\162\x74\151\146\x69\x63\141\x74\x65\40\146\x6f\x75\156\144\40\x69\156\40\123\x41\115\x4c\x20\122\145\x73\x70\157\x6e\163\145\72\40\x3c\57\163\x74\162\157\x6e\x67\76\74\146\157\156\x74\40\146\x61\x63\145\x3d\x22\103\x6f\165\162\x69\x65\162\40\116\x65\167\42\76\74\142\162\76\74\x62\162\76" . $MW . "\x3c\57\160\76\x3c\57\146\157\x6e\x74\76\15\12\x20\x20\40\x20\x20\40\40\x20\40\40\40\40\x20\40\40\x20\x20\x20\x20\x20\x20\40\x20\x20\x20\40\40\x20\x3c\x70\76\74\163\x74\x72\x6f\156\x67\x3e\x53\x6f\x6c\165\164\x69\x6f\x6e\x3a\40\74\x2f\163\x74\162\x6f\156\147\76\x3c\x2f\160\76\xd\12\x20\x20\x20\x20\40\40\x20\40\x20\40\40\x20\40\x20\x20\40\x20\x20\x20\x20\x20\40\40\x20\40\40\x20\40\x3c\157\x6c\76\xd\xa\x20\40\x20\40\40\40\x20\40\x20\40\40\40\x20\x20\x20\x20\x20\x20\40\40\40\x20\40\x20\x20\x20\x20\x20\40\40\x20\74\x6c\151\x3e\x43\x6f\160\x79\x20\160\141\163\164\x65\40\x74\150\145\x20\x63\x65\x72\164\151\146\x69\x63\x61\164\x65\40\160\162\157\166\151\144\145\144\40\x61\142\157\166\x65\x20\x69\x6e\40\x58\65\60\x39\x20\x43\145\x72\164\x69\146\151\x63\141\164\145\x20\165\156\x64\x65\x72\x20\123\x65\x72\x76\x69\143\145\x20\x50\x72\157\166\151\x64\x65\162\40\x53\x65\x74\x75\160\x20\x74\x61\142\56\74\57\154\x69\76\15\12\40\x20\40\x20\x20\x20\40\40\x20\40\40\x20\40\x20\40\x20\x20\40\x20\x20\x20\x20\40\x20\40\x20\40\x20\40\40\40\x3c\x6c\151\x3e\x49\146\40\x69\163\163\165\145\x20\160\145\x72\163\x69\x73\x74\163\40\144\151\163\141\142\x6c\145\x20\74\142\x3e\103\150\141\162\x61\143\164\145\162\40\145\156\x63\157\x64\x69\156\x67\74\57\x62\x3e\40\x75\156\144\145\x72\x20\123\145\162\x76\151\143\x65\x20\x50\x72\x6f\166\x64\145\162\40\123\145\164\165\x70\40\x74\x61\x62\56\74\57\x6c\151\76\xd\12\40\40\x20\40\40\40\x20\40\40\40\x20\x20\40\x20\x20\x20\x20\x20\40\x20\40\x20\x20\x20\x20\x20\x20\x20\x3c\57\x6f\154\x3e\xd\12\40\40\x20\x20\40\40\x20\x20\x20\x20\40\x20\40\x20\40\40\40\x20\40\40\x20\40\40\40\x20\40\x20\40\x3c\x2f\x64\x69\x76\x3e\15\xa\x20\40\x20\40\x20\x20\40\40\x20\40\40\40\40\x20\40\x20\40\x20\40\x20\x20\40\x20\x20\74\144\151\x76\40\x73\164\171\x6c\x65\x3d\42\155\141\162\x67\151\156\x3a\63\x25\x3b\144\151\163\x70\x6c\x61\171\x3a\142\154\157\x63\153\x3b\164\x65\170\x74\55\x61\x6c\151\x67\x6e\x3a\x63\145\156\164\145\x72\73\42\76\15\xa\40\x20\40\x20\40\x20\40\x20\x20\x20\x20\x20\40\x20\x20\x20\x20\x20\x20\40\x20\40\40\40\40\x20\x20\40\40\x20\40\x20\74\x64\151\x76\40\x73\164\171\154\145\x3d\42\155\x61\162\147\x69\156\72\x33\45\x3b\144\151\163\x70\x6c\x61\x79\x3a\x62\154\157\x63\x6b\73\x74\x65\x78\164\55\x61\154\x69\147\156\72\x63\x65\x6e\164\145\x72\x3b\42\76\x3c\x69\x6e\160\165\x74\40\163\164\x79\x6c\145\x3d\42\x70\x61\144\x64\151\x6e\x67\x3a\x31\x25\73\167\151\144\164\150\x3a\61\x30\x30\x70\170\73\142\141\x63\x6b\x67\x72\x6f\165\x6e\x64\x3a\x20\43\x30\x30\x39\x31\103\104\x20\x6e\x6f\x6e\145\x20\x72\x65\160\145\x61\164\40\x73\x63\162\157\154\x6c\40\60\45\40\x30\x25\73\143\165\x72\163\x6f\x72\x3a\x20\x70\157\x69\156\x74\x65\x72\x3b\x66\x6f\156\x74\x2d\x73\151\172\x65\x3a\x31\65\x70\x78\73\142\x6f\162\144\x65\162\55\x77\151\x64\x74\x68\x3a\40\x31\x70\170\73\x62\x6f\x72\x64\x65\162\55\163\x74\x79\x6c\145\72\40\163\x6f\154\151\144\x3b\x62\x6f\x72\144\145\162\55\x72\x61\144\151\165\163\x3a\x20\63\160\x78\x3b\x77\x68\151\x74\145\55\163\x70\141\143\145\72\x20\156\x6f\167\x72\x61\160\x3b\142\x6f\x78\x2d\163\x69\172\x69\156\147\x3a\40\142\157\x72\144\x65\x72\55\x62\x6f\170\73\142\157\x72\144\145\162\x2d\x63\157\x6c\x6f\x72\x3a\x20\x23\60\60\x37\63\x41\101\73\142\x6f\170\x2d\x73\x68\141\x64\157\x77\72\40\60\160\170\x20\61\x70\170\x20\60\160\170\40\x72\147\142\141\50\61\x32\60\54\40\x32\60\x30\x2c\40\x32\63\x30\x2c\x20\x30\x2e\66\51\x20\x69\x6e\163\145\164\73\143\157\x6c\x6f\x72\x3a\x20\x23\x46\x46\x46\73\42\x74\x79\x70\145\x3d\x22\x62\165\164\164\157\156\x22\40\x76\141\154\165\145\x3d\42\104\157\156\145\x22\x20\157\x6e\103\154\x69\143\153\75\x22\x73\145\x6c\146\56\x63\154\157\163\x65\x28\x29\x3b\42\76\x3c\57\144\x69\x76\x3e";
    mo_saml_download_logs($ti, $V2);
    exit;
    us:
    N8:
    $pi = get_site_option("\163\141\155\x6c\x5f\x69\163\x73\165\145\x72");
    $VH = get_site_option("\155\157\137\x73\141\x6d\x6c\137\163\x70\x5f\145\156\164\x69\164\x79\137\151\x64");
    if (!empty($VH)) {
        goto Uy;
    }
    $VH = $IQ . "\57\x77\160\55\x63\x6f\x6e\x74\145\156\x74\x2f\160\x6c\x75\x67\x69\156\x73\x2f\155\x69\x6e\151\157\x72\141\156\x67\145\x2d\x73\141\155\x6c\55\62\x30\x2d\163\x69\156\x67\x6c\145\x2d\x73\151\147\156\55\157\x6e\57";
    Uy:
    Utilities::validateIssuerAndAudience($Ik, $VH, $pi, $lV);
    $jc = current(current($Ik->getAssertions())->getNameId());
    $Wh = current($Ik->getAssertions())->getAttributes();
    $Wh["\116\141\x6d\x65\111\x44"] = array("\x30" => $jc);
    $LF = current($Ik->getAssertions())->getSessionIndex();
    mo_saml_checkMapping($Wh, $lV, $LF);
    goto Kg;
    z7:
    if (!isset($_REQUEST["\122\145\154\x61\171\123\x74\x61\164\145"])) {
        goto v_;
    }
    $Gl = $_REQUEST["\122\x65\154\x61\x79\123\x74\141\164\x65"];
    v_:
    if (!is_user_logged_in()) {
        goto GG;
    }
    wp_logout();
    GG:
    if (empty($Gl)) {
        goto SC;
    }
    $Gl = mo_saml_parse_url($Gl);
    goto Ww;
    SC:
    $Gl = $IQ;
    Ww:
    header("\x4c\157\x63\141\x74\x69\157\x6e\72" . $Gl);
    exit;
    Kg:
    K5:
    if (!(array_key_exists("\123\101\115\x4c\x52\145\x71\x75\x65\163\164", $_REQUEST) && !empty($_REQUEST["\x53\101\x4d\x4c\x52\x65\161\x75\x65\163\x74"]))) {
        goto MO;
    }
    $zg = $_REQUEST["\123\x41\115\x4c\122\x65\x71\165\145\x73\164"];
    $lV = "\x2f";
    if (!array_key_exists("\x52\x65\x6c\x61\171\123\x74\x61\164\145", $_REQUEST)) {
        goto lf;
    }
    $lV = $_REQUEST["\122\145\x6c\141\171\123\164\141\x74\x65"];
    lf:
    $zg = base64_decode($zg);
    if (!(array_key_exists("\123\101\x4d\114\x52\145\x71\x75\x65\x73\x74", $_GET) && !empty($_GET["\123\101\115\x4c\122\x65\x71\x75\145\x73\x74"]))) {
        goto Wl;
    }
    $zg = gzinflate($zg);
    Wl:
    $i1 = new DOMDocument();
    $i1->loadXML($zg);
    $aO = $i1->firstChild;
    if (!($aO->localName == "\x4c\157\x67\157\x75\x74\122\145\161\165\x65\x73\x74")) {
        goto tE;
    }
    $oU = new SAML2_LogoutRequest($aO);
    if (!(!session_id() || session_id() == '' || !isset($_SESSION))) {
        goto RV;
    }
    session_start();
    RV:
    $_SESSION["\155\x6f\x5f\163\x61\x6d\154\x5f\x6c\157\147\157\165\x74\x5f\162\145\161\165\145\163\164"] = $zg;
    $_SESSION["\x6d\x6f\x5f\x73\141\155\154\x5f\x6c\x6f\x67\x6f\165\x74\137\x72\x65\x6c\141\x79\137\x73\x74\141\164\x65"] = $lV;
    wp_redirect(htmlspecialchars_decode(wp_logout_url()));
    exit;
    tE:
    MO:
    if (!(isset($_REQUEST["\157\x70\x74\151\x6f\156"]) and !is_array($_REQUEST["\x6f\x70\x74\x69\157\156"]) and strpos($_REQUEST["\157\160\x74\151\x6f\156"], "\x72\x65\x61\144\x73\x61\155\154\x6c\157\147\151\x6e") !== false)) {
        goto g3;
    }
    require_once dirname(__FILE__) . "\x2f\151\x6e\143\154\165\x64\x65\x73\57\154\x69\x62\57\x65\156\x63\162\171\160\164\x69\157\156\x2e\x70\150\160";
    if (isset($_POST["\x53\124\101\x54\125\x53"]) && $_POST["\x53\x54\101\x54\125\123"] == "\105\122\122\x4f\122") {
        goto Vf;
    }
    if (!(isset($_POST["\123\124\101\124\125\123"]) && $_POST["\x53\124\x41\124\x55\x53"] == "\x53\125\103\x43\105\x53\x53")) {
        goto v3;
    }
    $u2 = '';
    if (!(isset($_REQUEST["\x72\x65\144\x69\162\145\x63\x74\137\164\157"]) && !empty($_REQUEST["\x72\145\x64\151\162\x65\143\x74\137\164\x6f"]) && $_REQUEST["\x72\145\x64\151\x72\x65\x63\x74\x5f\164\157"] != "\x2f")) {
        goto yT;
    }
    $u2 = $_REQUEST["\162\x65\144\x69\162\145\x63\x74\x5f\164\x6f"];
    yT:
    delete_site_option("\x6d\x6f\137\x73\x61\155\154\137\x72\x65\144\x69\x72\x65\x63\x74\137\145\x72\x72\x6f\162\x5f\143\157\144\x65");
    delete_site_option("\155\157\137\163\x61\x6d\154\137\x72\x65\144\151\162\145\143\164\137\145\162\x72\x6f\162\x5f\x72\145\x61\163\157\156");
    try {
        $Zg = get_site_option("\x73\141\155\154\x5f\x61\x6d\x5f\x65\155\141\x69\154");
        $NW = get_site_option("\x73\x61\155\x6c\137\141\x6d\137\165\163\145\162\x6e\x61\x6d\145");
        $L4 = get_site_option("\163\141\x6d\154\137\141\155\x5f\146\x69\x72\x73\164\137\156\141\x6d\x65");
        $Od = get_site_option("\163\141\x6d\154\137\x61\x6d\137\x6c\141\163\164\x5f\156\141\x6d\x65");
        $Nq = get_site_option("\x73\x61\155\x6c\x5f\x61\155\137\x67\x72\x6f\x75\x70\x5f\156\x61\155\145");
        $GU = get_site_option("\x73\x61\155\154\137\x61\155\x5f\x64\145\146\x61\x75\154\164\137\165\163\x65\162\x5f\162\157\154\145");
        $w0 = get_site_option("\163\141\x6d\154\x5f\141\x6d\x5f\x64\157\x6e\164\137\x61\154\154\x6f\167\x5f\165\x6e\154\151\x73\x74\145\x64\x5f\165\163\145\162\x5f\x72\157\x6c\x65");
        $q4 = get_site_option("\163\x61\x6d\154\x5f\141\155\137\141\x63\x63\x6f\165\156\164\x5f\x6d\141\x74\143\150\x65\162");
        $wE = '';
        $Vv = '';
        $L4 = str_replace("\x2e", "\137", $L4);
        $L4 = str_replace("\x20", "\x5f", $L4);
        if (!(!empty($L4) && array_key_exists($L4, $_POST))) {
            goto Ox;
        }
        $L4 = $_POST[$L4];
        Ox:
        $Od = str_replace("\x2e", "\x5f", $Od);
        $Od = str_replace("\x20", "\137", $Od);
        if (!(!empty($Od) && array_key_exists($Od, $_POST))) {
            goto eA;
        }
        $Od = $_POST[$Od];
        eA:
        $NW = str_replace("\x2e", "\x5f", $NW);
        $NW = str_replace("\x20", "\137", $NW);
        if (!empty($NW) && array_key_exists($NW, $_POST)) {
            goto Vz;
        }
        $Vv = $_POST["\x4e\141\x6d\x65\111\104"];
        goto BX;
        Vz:
        $Vv = $_POST[$NW];
        BX:
        $wE = str_replace("\56", "\137", $Zg);
        $wE = str_replace("\x20", "\137", $Zg);
        if (!empty($Zg) && array_key_exists($Zg, $_POST)) {
            goto Ab;
        }
        $wE = $_POST["\x4e\x61\x6d\x65\111\104"];
        goto WX;
        Ab:
        $wE = $_POST[$Zg];
        WX:
        $Nq = str_replace("\x2e", "\137", $Nq);
        $Nq = str_replace("\x20", "\x5f", $Nq);
        if (!(!empty($Nq) && array_key_exists($Nq, $_POST))) {
            goto Yn;
        }
        $Nq = $_POST[$Nq];
        Yn:
        if (!empty($q4)) {
            goto tx;
        }
        $q4 = "\x65\155\141\151\x6c";
        tx:
        $q3 = get_site_option("\x6d\x6f\x5f\x73\141\x6d\x6c\137\x63\x75\163\x74\157\155\x65\162\137\164\x6f\153\145\x6e");
        if (!(isset($q3) || trim($q3) != '')) {
            goto Um;
        }
        $UV = AESEncryption::decrypt_data($wE, $q3);
        $wE = $UV;
        Um:
        if (!(!empty($L4) && !empty($q3))) {
            goto cb;
        }
        $ow = AESEncryption::decrypt_data($L4, $q3);
        $L4 = $ow;
        cb:
        if (!(!empty($Od) && !empty($q3))) {
            goto R1;
        }
        $m9 = AESEncryption::decrypt_data($Od, $q3);
        $Od = $m9;
        R1:
        if (!(!empty($Vv) && !empty($q3))) {
            goto a0;
        }
        $IT = AESEncryption::decrypt_data($Vv, $q3);
        $Vv = $IT;
        a0:
        if (!(!empty($Nq) && !empty($q3))) {
            goto bv;
        }
        $Kj = AESEncryption::decrypt_data($Nq, $q3);
        $Nq = $Kj;
        bv:
    } catch (Exception $Y4) {
        echo sprintf("\x41\156\x20\x65\x72\162\157\162\x20\157\x63\x63\165\x72\x72\145\144\40\x77\150\x69\154\x65\x20\x70\x72\157\143\x65\163\163\151\x6e\x67\40\x74\x68\x65\40\123\x41\115\114\40\x52\x65\x73\160\157\156\x73\145\56");
        exit;
    }
    $Jh = array($Nq);
    mo_saml_login_user($wE, $L4, $Od, $Vv, $Jh, $w0, $GU, $u2, $q4);
    v3:
    goto Dt;
    Vf:
    update_site_option("\x6d\x6f\137\x73\141\x6d\154\x5f\162\145\144\x69\162\x65\143\x74\x5f\x65\162\162\x6f\x72\x5f\143\157\144\x65", $_POST["\x45\x52\x52\x4f\x52\x5f\122\105\101\123\x4f\116"]);
    update_site_option("\x6d\157\137\163\141\x6d\154\137\x72\145\x64\151\x72\x65\143\x74\137\x65\x72\x72\x6f\162\x5f\162\145\x61\x73\157\x6e", $_POST["\x45\x52\x52\117\122\x5f\x4d\105\x53\123\x41\107\x45"]);
    Dt:
    g3:
    WH:
}
function mo_saml_relaystate_url($lV)
{
    $TU = parse_url($lV, PHP_URL_SCHEME);
    $lV = str_replace($TU . "\x3a\57\x2f", '', $lV);
    return $lV;
}
function mo_saml_hash_relaystate($lV)
{
    $TU = parse_url($lV, PHP_URL_SCHEME);
    $lV = str_replace($TU . "\x3a\57\57", '', $lV);
    $lV = base64_encode($lV);
    $jB = cdjsurkhh($lV);
    $lV = $lV . "\x2e" . $jB;
    return $lV;
}
function mo_saml_get_relaystate($lV)
{
    if (!filter_var($lV, FILTER_VALIDATE_URL)) {
        goto jC;
    }
    return $lV;
    jC:
    $mb = strpos($lV, "\x2e");
    if ($mb) {
        goto Rd;
    }
    wp_die("\101\156\x20\x65\162\x72\x6f\x72\x20\x6f\x63\143\165\x72\x65\x64\56\x20\x50\154\x65\x61\x73\145\40\x63\x6f\156\x74\x61\143\x74\40\x79\157\165\x72\x20\141\x64\155\x69\156\151\163\x74\x72\x61\164\x6f\x72\x2e", "\105\162\162\x6f\162\40\72\40\116\157\x74\40\141\40\164\162\165\163\x74\x65\x64\x20\163\157\165\162\143\x65\x20\157\x66\40\164\150\145\40\x53\101\115\x4c\x20\x72\145\x73\x70\157\x6e\163\145");
    exit;
    Rd:
    $Gl = substr($lV, 0, $mb);
    $gN = substr($lV, $mb + 1);
    $mL = cdjsurkhh($Gl);
    if (!($gN !== $mL)) {
        goto MI;
    }
    wp_die("\101\156\40\x65\x72\162\157\x72\40\x6f\x63\143\165\162\145\144\x2e\x20\120\154\x65\141\x73\x65\x20\x63\x6f\x6e\x74\141\143\x74\x20\x79\x6f\165\x72\40\141\x64\x6d\x69\156\x69\x73\x74\162\141\164\157\x72\x2e", "\x45\162\162\x6f\162\40\72\40\x4e\x6f\164\40\141\x20\164\162\165\x73\x74\145\144\40\x73\157\165\x72\x63\145\x20\x6f\146\x20\x74\x68\145\40\123\x41\115\x4c\40\162\145\163\x70\157\156\163\x65");
    exit;
    MI:
    $Gl = base64_decode($Gl);
    return $Gl;
}
function cdjsurkhh($Xa)
{
    $jB = hash("\163\x68\x61\x35\61\x32", $Xa);
    $AK = substr($jB, 7, 14);
    return $AK;
}
function mo_saml_parse_url($lV)
{
    if (!($lV != "\164\145\x73\164\x56\141\x6c\x69\144\x61\164\145" && $lV != "\x74\145\x73\x74\x4e\145\167\103\x65\162\164\x69\x66\x69\143\x61\164\145")) {
        goto B1;
    }
    $IQ = get_site_option("\x6d\157\137\163\x61\155\x6c\137\x73\x70\137\142\141\x73\145\137\x75\x72\x6c");
    if (!empty($IQ)) {
        goto DT;
    }
    $IQ = get_network_site_url();
    DT:
    $TU = parse_url($IQ, PHP_URL_SCHEME);
    if (filter_var($lV, FILTER_VALIDATE_URL)) {
        goto JA;
    }
    $lV = $TU . "\72\x2f\57" . $lV;
    JA:
    B1:
    return $lV;
}
function mo_saml_is_subsite($lV)
{
    $Oa = parse_url($lV, PHP_URL_HOST);
    $Gq = parse_url($lV, PHP_URL_PATH);
    if (is_subdomain_install()) {
        goto rq;
    }
    $qz = strpos($Gq, "\x2f", 1) != false ? strpos($Gq, "\x2f", 1) : strlen($Gq) - 1;
    $Gq = substr($Gq, 0, $qz + 1);
    $blog_id = get_blog_id_from_url($Oa, $Gq);
    goto l0;
    rq:
    $blog_id = get_blog_id_from_url($Oa);
    l0:
    if ($blog_id !== 0) {
        goto RO;
    }
    return false;
    goto qh;
    RO:
    return true;
    qh:
}
function mo_saml_show_SAML_log($aO, $iS)
{
    header("\103\x6f\x6e\x74\145\x6e\164\x2d\x54\x79\x70\x65\x3a\40\x74\145\x78\164\x2f\x68\x74\155\x6c");
    $fT = new DOMDocument();
    $fT->preserveWhiteSpace = false;
    $fT->formatOutput = true;
    $fT->loadXML($aO);
    if ($iS == "\144\151\x73\160\x6c\x61\x79\x53\x41\x4d\x4c\x52\x65\161\165\x65\163\164") {
        goto n5;
    }
    $Jc = "\x53\101\115\114\40\122\x65\163\x70\157\156\163\145";
    goto bt;
    n5:
    $Jc = "\123\x41\x4d\x4c\40\x52\x65\161\x75\145\x73\x74";
    bt:
    $ZB = $fT->saveXML();
    $Ct = htmlentities($ZB);
    $Ct = rtrim($Ct);
    $O3 = simplexml_load_string($ZB);
    $Kc = json_encode($O3);
    $D2 = json_decode($Kc);
    $Ki = plugins_url("\151\156\143\154\x75\x64\145\163\57\x63\x73\x73\57\163\164\x79\154\145\x5f\x73\x65\x74\164\x69\156\x67\x73\x2e\143\163\163\77\166\145\x72\75\64\56\x38\56\64\x30", __FILE__);
    echo "\x3c\154\151\156\153\x20\x72\145\x6c\x3d\x27\163\164\x79\x6c\x65\x73\x68\145\145\164\47\x20\x69\144\x3d\x27\155\x6f\x5f\x73\141\x6d\154\x5f\141\144\x6d\x69\156\137\163\145\164\164\x69\x6e\x67\163\x5f\x73\164\171\154\145\55\x63\163\163\47\40\40\150\x72\145\x66\75\x27" . $Ki . "\47\40\x74\171\x70\x65\75\47\164\145\170\x74\x2f\x63\163\x73\x27\x20\155\x65\144\151\141\x3d\47\x61\x6c\154\x27\40\57\x3e\15\xa\15\xa\74\x64\151\x76\40\x63\x6c\141\163\x73\75\x22\155\x6f\x2d\x64\x69\163\x70\x6c\x61\171\55\x6c\x6f\x67\163\x22\x20\76\74\160\x20\164\x79\160\x65\x3d\x22\x74\x65\170\164\x22\x20\40\40\151\144\x3d\x22\x53\x41\x4d\114\x5f\x74\x79\x70\x65\42\x3e" . $Jc . "\x3c\x2f\160\x3e\74\57\144\151\x76\x3e\15\12\xd\12\74\x64\x69\x76\x20\164\171\x70\x65\x3d\x22\164\145\170\164\42\x20\x69\144\x3d\42\x53\x41\115\x4c\137\144\x69\x73\x70\x6c\141\171\x22\x20\x63\x6c\x61\x73\x73\75\42\155\157\55\x64\151\x73\x70\154\x61\171\x2d\x62\154\157\143\x6b\42\x3e\x3c\160\162\x65\40\143\x6c\141\x73\x73\x3d\47\x62\x72\x75\163\150\72\x20\170\x6d\x6c\73\47\76" . $Ct . "\74\57\160\x72\x65\76\x3c\x2f\144\x69\166\x3e\xd\xa\x3c\142\162\76\xd\12\x3c\x64\x69\166\11\40\x73\164\x79\154\x65\75\42\x6d\x61\x72\x67\x69\156\72\63\45\73\x64\151\163\x70\x6c\141\171\x3a\142\x6c\x6f\143\153\73\x74\x65\170\x74\x2d\141\154\151\147\156\x3a\143\145\156\x74\x65\162\x3b\42\76\xd\12\xd\12\x3c\x64\x69\x76\x20\163\x74\171\154\x65\75\x22\x6d\141\162\x67\x69\156\x3a\x33\x25\x3b\144\151\x73\x70\154\141\x79\x3a\x62\154\157\x63\153\73\164\145\x78\x74\x2d\141\154\x69\147\x6e\x3a\x63\145\156\164\145\162\73\x22\40\76\xd\xa\xd\xa\x3c\57\144\x69\166\76\xd\xa\x3c\x62\x75\164\x74\157\x6e\40\x69\144\75\42\x63\157\x70\171\42\40\x6f\x6e\143\154\151\x63\153\75\42\x63\x6f\160\x79\104\x69\x76\x54\157\x43\x6c\x69\160\142\x6f\141\x72\x64\x28\x29\42\40\40\x73\x74\171\154\x65\75\42\x70\x61\144\x64\x69\x6e\x67\72\x31\45\x3b\x77\x69\144\x74\150\x3a\x31\x30\60\x70\x78\73\x62\141\143\x6b\x67\162\157\x75\156\144\x3a\40\43\x30\60\71\x31\103\x44\40\x6e\x6f\x6e\x65\x20\162\x65\x70\145\141\x74\x20\163\143\162\x6f\x6c\x6c\40\60\x25\x20\60\x25\x3b\x63\x75\x72\163\x6f\x72\72\40\x70\157\151\156\x74\145\162\73\x66\157\156\x74\55\x73\x69\x7a\145\x3a\61\x35\x70\170\x3b\x62\157\x72\144\145\x72\55\167\151\x64\164\x68\x3a\x20\61\160\170\73\142\x6f\x72\x64\145\162\x2d\163\x74\171\154\145\x3a\40\163\157\154\x69\144\x3b\x62\157\x72\144\x65\162\55\x72\x61\144\151\x75\163\x3a\x20\63\x70\170\x3b\167\150\151\164\145\x2d\x73\160\x61\143\145\72\40\x6e\157\167\x72\x61\160\x3b\x62\x6f\170\x2d\x73\x69\x7a\151\156\x67\x3a\40\x62\157\x72\x64\145\x72\x2d\x62\157\170\x3b\x62\x6f\162\x64\x65\162\55\x63\157\154\x6f\162\72\40\x23\60\60\67\63\101\101\73\142\157\x78\55\163\x68\141\144\x6f\x77\x3a\x20\x30\x70\170\x20\61\x70\170\x20\60\x70\170\x20\162\147\142\141\50\61\62\60\x2c\40\62\x30\x30\54\40\x32\x33\60\x2c\40\x30\x2e\x36\51\x20\x69\x6e\x73\145\x74\x3b\143\x6f\x6c\x6f\162\72\40\43\106\106\106\73\x22\40\x3e\x43\x6f\160\x79\x3c\57\x62\x75\x74\x74\157\x6e\76\15\xa\46\x6e\142\x73\x70\x3b\15\xa\x3c\151\156\160\x75\164\40\151\144\x3d\x22\144\x77\156\55\x62\x74\156\x22\40\x73\164\x79\x6c\145\x3d\42\160\x61\x64\144\151\156\147\x3a\61\45\73\167\151\144\164\x68\x3a\x31\x30\60\160\x78\x3b\x62\141\x63\153\147\162\x6f\x75\x6e\x64\x3a\x20\x23\x30\x30\71\x31\x43\104\40\x6e\157\x6e\x65\40\162\x65\160\145\x61\x74\x20\163\x63\162\157\x6c\x6c\40\x30\x25\40\60\45\73\x63\x75\x72\x73\x6f\162\72\40\x70\x6f\151\x6e\164\145\162\x3b\x66\x6f\156\x74\x2d\163\x69\172\x65\x3a\61\x35\x70\x78\x3b\142\x6f\162\144\x65\162\55\x77\x69\x64\164\150\x3a\x20\61\x70\x78\x3b\x62\157\x72\144\x65\x72\55\163\164\171\x6c\145\x3a\40\163\157\x6c\151\144\x3b\142\157\x72\144\145\162\x2d\162\x61\144\151\165\x73\x3a\40\63\160\170\73\x77\x68\x69\x74\145\x2d\163\x70\x61\143\x65\x3a\x20\x6e\157\167\162\141\160\73\142\157\170\55\163\x69\x7a\x69\x6e\x67\72\x20\x62\x6f\162\x64\x65\162\x2d\x62\157\170\x3b\x62\157\162\x64\145\x72\x2d\143\x6f\x6c\157\162\x3a\x20\x23\60\x30\67\63\101\101\x3b\x62\x6f\170\x2d\x73\x68\x61\144\x6f\x77\x3a\40\60\x70\170\x20\61\160\x78\x20\x30\160\170\40\162\x67\142\x61\x28\61\x32\60\x2c\40\x32\60\x30\x2c\x20\x32\63\60\x2c\40\60\56\66\x29\40\151\x6e\x73\145\164\x3b\143\157\x6c\157\x72\x3a\40\43\x46\x46\106\x3b\x22\164\x79\x70\145\x3d\x22\142\165\164\x74\157\x6e\x22\x20\x76\x61\x6c\x75\145\75\42\104\157\x77\x6e\154\x6f\141\x64\42\40\15\12\x22\76\15\12\74\57\144\151\x76\76\15\12\x3c\57\144\x69\x76\x3e\15\12\15\12\xd\xa";
    ob_end_flush();
    echo "\15\xa\74\163\143\x72\x69\x70\164\x3e\xd\12\15\xa\146\165\x6e\143\x74\x69\x6f\156\40\x63\157\160\x79\x44\151\166\124\157\x43\154\151\160\x62\157\141\x72\x64\x28\x29\40\173\xd\12\166\x61\162\x20\141\x75\x78\x20\75\x20\144\x6f\x63\x75\155\x65\x6e\164\x2e\143\162\x65\x61\164\145\x45\154\x65\x6d\x65\x6e\x74\x28\x22\151\x6e\x70\x75\x74\42\51\73\xd\12\x61\165\x78\56\163\x65\x74\101\x74\164\162\151\x62\165\164\x65\x28\42\166\x61\x6c\165\145\42\x2c\x20\144\x6f\143\165\x6d\145\x6e\164\56\147\145\164\105\x6c\x65\155\145\156\164\102\x79\x49\144\50\42\123\x41\115\x4c\137\x64\x69\163\160\x6c\141\x79\42\51\x2e\164\145\170\164\x43\157\156\164\145\x6e\x74\51\x3b\xd\xa\x64\157\143\165\x6d\x65\156\164\x2e\x62\157\144\x79\56\141\160\160\x65\x6e\144\x43\150\151\154\x64\x28\141\165\x78\51\x3b\xd\12\141\x75\x78\x2e\163\145\x6c\145\143\164\x28\51\73\15\xa\144\x6f\143\x75\155\145\156\x74\56\x65\x78\x65\143\x43\x6f\x6d\x6d\141\156\144\50\42\x63\x6f\160\x79\42\51\x3b\xd\12\x64\157\x63\x75\155\x65\156\x74\56\x62\157\x64\x79\x2e\x72\145\x6d\x6f\166\x65\x43\x68\151\x6c\x64\50\141\165\170\x29\x3b\xd\xa\x64\157\143\165\x6d\145\x6e\164\56\147\x65\164\x45\154\x65\155\x65\x6e\164\x42\x79\x49\144\50\47\143\157\160\x79\x27\51\56\x74\145\x78\x74\x43\x6f\x6e\164\145\x6e\x74\40\x3d\x20\42\x43\157\x70\151\145\144\42\73\xd\12\144\x6f\143\165\155\145\x6e\x74\x2e\147\145\164\105\x6c\145\x6d\x65\x6e\164\102\x79\111\x64\50\x27\143\157\x70\x79\47\51\56\x73\x74\x79\x6c\x65\x2e\142\x61\143\x6b\147\x72\157\165\x6e\x64\x20\x3d\x20\x22\147\162\x65\x79\42\x3b\xd\12\x77\x69\x6e\144\157\167\x2e\147\x65\164\123\x65\154\x65\x63\164\151\157\x6e\x28\x29\56\163\x65\x6c\x65\143\x74\101\154\x6c\x43\150\x69\x6c\144\162\145\x6e\50\x20\x64\157\143\x75\x6d\145\x6e\164\56\x67\145\164\x45\x6c\145\x6d\145\x6e\164\102\x79\111\144\50\40\42\x53\101\x4d\114\137\144\x69\x73\160\x6c\141\171\42\x20\x29\x20\x29\x3b\15\xa\15\12\175\15\12\xd\12\x66\x75\x6e\x63\164\151\x6f\x6e\40\x64\157\x77\156\154\157\x61\144\x28\x66\x69\x6c\x65\x6e\x61\x6d\145\x2c\x20\x74\x65\x78\164\51\40\173\15\12\x76\141\162\x20\x65\x6c\145\x6d\145\156\164\40\75\40\144\x6f\x63\x75\x6d\145\x6e\164\56\143\162\x65\141\x74\145\105\154\145\x6d\145\x6e\x74\50\47\141\47\x29\x3b\xd\12\x65\154\x65\155\145\x6e\x74\56\x73\x65\x74\101\164\x74\162\x69\x62\165\x74\145\50\x27\x68\x72\145\146\47\x2c\40\x27\x64\141\164\141\72\x41\160\160\x6c\x69\143\141\x74\151\x6f\156\57\x6f\143\164\x65\x74\x2d\163\x74\x72\x65\141\x6d\x3b\143\150\141\162\163\x65\164\75\x75\x74\x66\x2d\70\x2c\47\x20\53\40\145\x6e\143\x6f\x64\145\125\122\111\x43\x6f\155\x70\x6f\156\x65\x6e\x74\50\164\145\x78\164\x29\51\73\xd\xa\x65\154\x65\155\x65\156\x74\56\x73\145\164\x41\164\164\x72\x69\142\x75\164\x65\x28\x27\x64\x6f\x77\156\154\157\x61\144\47\54\x20\x66\x69\x6c\x65\x6e\141\x6d\145\51\73\xd\12\15\12\x65\154\145\155\145\156\164\x2e\163\164\x79\x6c\145\56\x64\x69\x73\x70\154\141\x79\x20\x3d\x20\x27\x6e\x6f\156\x65\47\x3b\15\12\x64\x6f\143\x75\155\x65\x6e\164\x2e\142\157\144\171\56\x61\x70\160\145\156\144\103\x68\x69\154\144\50\x65\154\145\155\145\156\x74\51\73\xd\12\xd\xa\145\x6c\145\155\x65\156\x74\56\143\154\x69\143\x6b\50\51\x3b\xd\12\xd\12\x64\x6f\143\165\x6d\x65\156\164\56\x62\157\144\171\x2e\x72\x65\x6d\x6f\166\145\x43\150\x69\x6c\144\50\145\154\x65\x6d\145\156\164\51\x3b\xd\12\x7d\15\xa\xd\xa\x64\157\x63\165\155\145\156\164\x2e\x67\x65\x74\x45\154\x65\155\x65\156\x74\x42\x79\111\144\x28\42\144\x77\x6e\55\x62\164\156\42\51\x2e\141\x64\144\105\x76\x65\x6e\x74\x4c\151\163\164\145\156\x65\162\50\x22\x63\154\x69\x63\153\42\54\x20\x66\x75\156\x63\164\x69\157\156\40\50\x29\40\x7b\xd\12\15\12\x76\141\x72\x20\146\x69\x6c\x65\x6e\141\x6d\145\40\x3d\x20\x64\157\x63\165\155\145\x6e\164\56\x67\x65\x74\x45\154\x65\x6d\x65\x6e\164\x42\171\x49\144\x28\x22\123\x41\115\x4c\137\x74\171\x70\145\42\x29\56\x74\x65\x78\x74\103\x6f\156\164\145\156\x74\x2b\x22\56\170\x6d\154\42\73\15\12\166\141\162\x20\156\157\x64\x65\x20\75\40\144\x6f\x63\165\155\x65\156\164\x2e\147\145\x74\x45\x6c\x65\x6d\145\156\x74\102\x79\x49\x64\x28\42\x53\101\115\x4c\137\x64\x69\x73\160\154\141\x79\x22\51\73\15\xa\x68\x74\155\154\x43\x6f\156\164\x65\x6e\164\x20\x3d\x20\156\157\144\x65\56\x69\156\156\x65\162\110\124\115\114\x3b\15\12\164\145\170\164\x20\75\x20\x6e\157\x64\145\56\x74\x65\x78\164\x43\x6f\156\164\145\156\x74\x3b\15\12\144\x6f\167\x6e\x6c\157\141\144\50\x66\151\x6c\145\x6e\141\155\145\x2c\40\x74\145\170\x74\x29\73\15\12\175\x2c\40\x66\x61\x6c\163\145\x29\x3b\xd\12\15\xa\xd\12\xd\12\15\12\xd\xa\x3c\x2f\x73\143\162\x69\x70\x74\x3e\xd\xa";
    exit;
}
function mo_saml_checkMapping($Wh, $lV, $LF)
{
    try {
        $Zg = get_site_option("\163\141\155\x6c\x5f\x61\155\x5f\145\155\x61\x69\x6c");
        $NW = get_site_option("\x73\141\155\154\x5f\141\155\137\165\163\x65\x72\x6e\141\x6d\145");
        $L4 = get_site_option("\163\x61\155\154\x5f\141\x6d\137\x66\x69\x72\163\x74\137\156\x61\155\x65");
        $Od = get_site_option("\x73\141\155\x6c\x5f\x61\x6d\x5f\x6c\141\x73\x74\137\156\141\x6d\145");
        $Nq = get_site_option("\x73\x61\x6d\154\x5f\141\155\x5f\147\x72\x6f\165\x70\x5f\x6e\141\155\x65");
        $mn = array();
        $mn = maybe_unserialize(get_site_option("\x73\x61\155\x6c\x5f\141\155\137\162\157\x6c\x65\x5f\155\141\x70\x70\x69\156\x67"));
        $q4 = get_site_option("\x73\x61\155\154\x5f\x61\155\x5f\x61\143\x63\x6f\x75\x6e\x74\x5f\155\141\x74\143\x68\145\x72");
        $wE = '';
        $Vv = '';
        if (empty($Wh)) {
            goto pE;
        }
        if (!empty($L4) && array_key_exists($L4, $Wh)) {
            goto wG;
        }
        $L4 = '';
        goto GO;
        wG:
        $L4 = $Wh[$L4][0];
        GO:
        if (!empty($Od) && array_key_exists($Od, $Wh)) {
            goto jj;
        }
        $Od = '';
        goto I3;
        jj:
        $Od = $Wh[$Od][0];
        I3:
        if (!empty($NW) && array_key_exists($NW, $Wh)) {
            goto NQ;
        }
        $Vv = $Wh["\x4e\141\155\145\x49\104"][0];
        goto xD;
        NQ:
        $Vv = $Wh[$NW][0];
        xD:
        if (!empty($Zg) && array_key_exists($Zg, $Wh)) {
            goto I9;
        }
        $wE = $Wh["\x4e\141\155\145\111\104"][0];
        goto Fm;
        I9:
        $wE = $Wh[$Zg][0];
        Fm:
        if (!empty($Nq) && array_key_exists($Nq, $Wh)) {
            goto dl;
        }
        $Nq = array();
        goto nw;
        dl:
        $Nq = $Wh[$Nq];
        nw:
        if (!empty($q4)) {
            goto L4;
        }
        $q4 = "\x65\x6d\x61\x69\154";
        L4:
        pE:
        if ($lV == "\x74\145\163\164\126\x61\154\151\x64\x61\x74\x65") {
            goto g5;
        }
        if ($lV == "\164\145\x73\164\116\x65\x77\x43\145\x72\x74\x69\x66\x69\x63\x61\164\x65") {
            goto oA;
        }
        mo_saml_login_user($wE, $L4, $Od, $Vv, $Nq, $mn, $lV, $q4, $LF, $Wh["\116\141\155\145\x49\x44"][0], $Wh);
        goto U2;
        g5:
        update_site_option("\155\x6f\x5f\163\141\155\x6c\x5f\x74\x65\x73\x74", "\x54\x65\x73\x74\x20\x53\x75\x63\143\x65\163\x73\146\165\154");
        mo_saml_show_test_result($L4, $Od, $wE, $Nq, $Wh, $lV);
        goto U2;
        oA:
        update_site_option("\x6d\x6f\137\163\141\155\154\x5f\x74\145\x73\164\137\x6e\x65\x77\x5f\x63\x65\162\x74", "\124\145\x73\x74\x20\163\x75\x63\x63\x65\163\163\146\165\154");
        mo_saml_show_test_result($L4, $Od, $wE, $Nq, $Wh, $lV);
        U2:
    } catch (Exception $Y4) {
        echo sprintf("\x41\156\40\x65\x72\162\x6f\162\40\x6f\x63\x63\165\162\x72\145\144\x20\167\x68\x69\154\145\40\x70\162\x6f\x63\145\x73\x73\x69\x6e\x67\40\x74\x68\x65\40\123\101\115\x4c\40\122\x65\163\x70\157\x6e\163\145\56");
        exit;
    }
}
function mo_saml_show_test_result($L4, $Od, $wE, $Nq, $Wh, $lV)
{
    echo "\74\x64\151\166\x20\163\164\x79\x6c\x65\x3d\x22\x66\157\x6e\x74\x2d\146\141\155\151\x6c\x79\x3a\103\141\154\x69\x62\x72\x69\x3b\160\x61\x64\x64\151\x6e\x67\x3a\60\x20\63\x25\x3b\x22\76";
    if (!empty($wE)) {
        goto WD;
    }
    echo "\74\x64\x69\166\x20\163\164\x79\154\145\75\x22\143\x6f\154\x6f\x72\72\x20\43\141\x39\x34\x34\64\62\x3b\x62\141\x63\153\x67\162\x6f\165\156\144\x2d\x63\157\x6c\x6f\x72\x3a\40\x23\x66\x32\x64\145\x64\145\73\160\x61\144\x64\151\x6e\x67\72\x20\x31\x35\x70\x78\x3b\155\x61\x72\147\x69\156\55\142\x6f\x74\x74\157\155\72\x20\x32\60\x70\170\x3b\x74\145\x78\x74\55\x61\154\151\147\x6e\x3a\143\x65\156\x74\145\x72\x3b\x62\157\162\144\145\162\x3a\x31\160\170\x20\163\x6f\154\x69\x64\40\x23\105\66\102\x33\102\62\73\146\157\156\164\55\x73\151\x7a\145\72\61\x38\x70\164\73\42\x3e\x54\105\123\124\40\106\x41\x49\114\x45\104\74\x2f\144\x69\166\76\xd\12\x20\40\40\40\x20\x20\40\x20\x3c\x64\151\166\40\163\164\171\x6c\145\x3d\x22\143\157\x6c\157\162\72\40\43\141\x39\x34\x34\x34\62\73\146\157\x6e\x74\55\163\151\172\x65\x3a\x31\64\x70\164\x3b\40\x6d\x61\162\x67\x69\x6e\55\x62\x6f\x74\164\x6f\155\72\x32\60\x70\x78\x3b\42\x3e\127\101\122\116\111\116\107\72\x20\x53\157\155\x65\x20\101\x74\x74\x72\x69\x62\165\x74\145\163\40\x44\x69\x64\40\116\x6f\164\x20\x4d\x61\164\x63\x68\56\74\57\x64\x69\166\x3e\xd\12\x20\x20\x20\x20\x20\40\x20\40\x3c\144\151\x76\40\163\x74\x79\x6c\x65\x3d\42\x64\x69\163\x70\x6c\141\x79\72\x62\x6c\x6f\x63\x6b\x3b\x74\145\x78\x74\55\x61\x6c\151\147\156\x3a\x63\x65\x6e\x74\145\162\x3b\155\141\x72\x67\x69\156\x2d\x62\157\x74\x74\157\x6d\x3a\x34\x25\73\42\76\74\x69\155\x67\x20\x73\x74\x79\154\x65\x3d\42\167\x69\144\x74\150\72\x31\65\45\x3b\x22\x73\162\143\x3d\x22" . plugin_dir_url(__FILE__) . "\151\x6d\141\147\x65\x73\57\x77\x72\157\x6e\x67\56\160\156\x67\x22\76\x3c\57\x64\x69\x76\x3e";
    goto pz;
    WD:
    update_site_option("\155\157\x5f\x73\x61\155\x6c\137\x74\145\163\164\137\143\157\156\x66\x69\147\x5f\x61\164\164\x72\x73", $Wh);
    echo "\x3c\x64\x69\x76\40\163\x74\x79\154\x65\75\x22\143\x6f\x6c\157\x72\72\x20\43\x33\143\x37\x36\x33\144\73\xd\12\x20\x20\x20\x20\40\40\40\40\x62\141\143\x6b\x67\162\x6f\165\156\x64\x2d\143\x6f\154\x6f\162\72\40\43\144\146\146\x30\x64\x38\73\40\x70\141\144\144\x69\x6e\x67\x3a\62\x25\73\155\x61\162\x67\x69\156\55\x62\157\164\x74\157\x6d\72\62\60\160\x78\x3b\x74\x65\x78\164\55\x61\x6c\x69\x67\x6e\72\x63\x65\x6e\x74\x65\162\x3b\40\x62\157\x72\x64\x65\x72\x3a\61\x70\x78\40\163\157\154\x69\x64\40\43\101\x45\x44\102\71\101\73\x20\x66\x6f\x6e\x74\55\163\151\172\x65\x3a\x31\x38\160\x74\73\42\76\124\105\x53\x54\40\123\x55\103\103\x45\x53\x53\106\x55\x4c\74\57\x64\151\x76\x3e\15\xa\40\x20\40\x20\40\40\40\40\x3c\x64\151\166\x20\163\x74\171\154\145\x3d\42\x64\x69\x73\160\x6c\141\171\72\x62\x6c\157\143\x6b\x3b\164\x65\170\x74\x2d\141\154\x69\147\x6e\72\x63\x65\156\164\145\x72\x3b\155\x61\162\147\x69\156\55\142\x6f\x74\164\x6f\x6d\x3a\x34\45\73\x22\x3e\x3c\x69\x6d\147\x20\163\164\x79\154\x65\x3d\42\167\x69\144\x74\150\72\x31\x35\x25\73\x22\x73\x72\143\x3d\42" . plugin_dir_url(__FILE__) . "\151\x6d\141\147\x65\x73\x2f\147\162\x65\145\x6e\x5f\143\x68\x65\x63\153\56\160\x6e\x67\x22\76\x3c\x2f\144\151\166\x3e";
    pz:
    $LO = $lV == "\164\145\163\164\116\x65\x77\x43\x65\x72\164\x69\146\x69\143\x61\164\x65" ? "\x64\151\x73\160\x6c\141\x79\x3a\x6e\157\156\145" : '';
    $A_ = get_site_option("\x73\x61\155\154\x5f\x61\x6d\137\141\x63\x63\x6f\165\156\x74\x5f\155\x61\x74\x63\x68\145\x72") ? get_site_option("\163\x61\155\154\137\x61\x6d\x5f\x61\x63\143\x6f\x75\x6e\164\137\155\x61\x74\143\150\x65\162") : "\145\155\141\151\154";
    if (!($A_ == "\x65\x6d\141\x69\154" && !filter_var($Wh["\x4e\141\155\145\x49\104"][0], FILTER_VALIDATE_EMAIL))) {
        goto Fw;
    }
    echo "\74\160\76\x3c\146\x6f\156\164\x20\143\157\154\157\162\75\x22\x23\106\106\x30\60\x30\60\x22\40\x73\164\x79\x6c\145\75\x22\x66\x6f\156\164\x2d\x73\151\172\145\72\61\x34\160\x74\42\76\50\127\141\162\x6e\151\x6e\147\x3a\40\x54\x68\145\x20\116\x61\x6d\145\111\x44\x20\166\141\x6c\165\x65\x20\151\x73\40\x6e\x6f\164\x20\x61\x20\x76\x61\154\x69\x64\x20\x45\155\141\x69\154\40\x49\x44\51\x3c\x2f\146\157\x6e\164\x3e\x3c\x2f\x70\x3e";
    Fw:
    echo "\x3c\163\x70\141\156\x20\163\x74\x79\154\x65\x3d\42\146\x6f\156\x74\55\x73\x69\x7a\x65\x3a\x31\64\x70\x74\x3b\x22\x3e\74\x62\76\110\x65\154\154\157\x3c\x2f\x62\76\54\40" . $wE . "\x3c\x2f\163\160\x61\x6e\76\x3c\x62\x72\57\x3e\x3c\160\40\x73\x74\171\x6c\x65\75\x22\x66\157\x6e\164\55\167\x65\x69\x67\x68\164\x3a\x62\x6f\154\x64\x3b\x66\157\156\x74\x2d\x73\x69\x7a\x65\x3a\x31\x34\x70\164\x3b\x6d\141\x72\147\151\x6e\x2d\154\145\146\164\x3a\61\45\73\42\76\x41\x54\x54\122\111\x42\x55\124\105\x53\x20\x52\x45\103\105\111\x56\105\104\x3a\74\57\x70\76\15\12\x20\x20\x20\x20\x3c\x74\x61\x62\x6c\x65\x20\163\164\171\154\x65\75\x22\142\157\162\x64\145\x72\55\x63\157\154\154\x61\x70\x73\x65\x3a\143\157\x6c\154\x61\160\163\145\73\142\157\x72\x64\145\162\x2d\x73\160\x61\143\151\x6e\x67\x3a\60\73\x20\144\x69\163\160\x6c\x61\x79\72\164\x61\142\154\x65\73\x77\151\144\164\150\72\61\60\x30\45\73\x20\146\x6f\x6e\x74\x2d\163\x69\172\145\72\61\64\x70\x74\x3b\142\x61\143\153\x67\162\x6f\x75\156\x64\55\x63\157\154\x6f\x72\x3a\43\105\104\x45\104\x45\x44\73\x22\x3e\xd\12\x20\x20\40\40\x20\40\x20\x20\x3c\x74\162\x20\x73\164\x79\x6c\x65\x3d\42\164\x65\170\164\x2d\x61\154\x69\147\156\x3a\143\x65\x6e\164\x65\162\x3b\42\x3e\74\164\144\x20\x73\x74\x79\154\145\x3d\x22\146\x6f\156\x74\55\167\x65\x69\x67\x68\164\72\x62\x6f\154\144\x3b\x62\157\x72\x64\x65\162\x3a\x32\x70\x78\40\x73\x6f\154\x69\144\x20\43\71\64\x39\x30\71\x30\x3b\x70\x61\x64\x64\x69\156\x67\x3a\62\45\73\42\76\101\x54\x54\122\111\102\125\124\105\40\116\101\115\105\74\57\x74\144\76\74\164\144\40\163\164\x79\x6c\145\75\42\146\x6f\156\x74\55\x77\x65\151\147\150\164\x3a\x62\x6f\x6c\144\x3b\x70\x61\x64\x64\x69\156\147\x3a\x32\45\x3b\x62\157\x72\144\x65\162\x3a\62\x70\x78\40\x73\x6f\154\151\x64\x20\43\71\64\71\x30\71\60\73\x20\x77\157\x72\x64\55\167\162\141\160\x3a\142\x72\145\x61\x6b\55\167\157\x72\x64\73\x22\x3e\101\x54\124\122\111\102\x55\124\x45\x20\x56\101\x4c\125\x45\x3c\57\164\144\76\74\x2f\164\162\x3e";
    if (!empty($Wh)) {
        goto up;
    }
    echo "\116\x6f\40\x41\164\x74\162\151\142\165\x74\145\x73\40\122\x65\143\x65\x69\x76\145\x64\x2e";
    goto JV;
    up:
    foreach ($Wh as $q3 => $nY) {
        echo "\x3c\164\162\x3e\x3c\164\x64\x20\x73\x74\171\x6c\145\75\47\146\157\156\164\55\x77\145\151\147\150\164\x3a\142\157\x6c\144\73\142\x6f\162\144\x65\162\72\x32\160\x78\x20\163\157\x6c\x69\144\40\43\71\64\x39\60\71\x30\x3b\160\x61\144\x64\x69\x6e\147\72\x32\x25\x3b\47\x3e" . $q3 . "\x3c\57\164\144\x3e\x3c\164\144\40\x73\164\x79\154\x65\x3d\47\160\141\144\x64\151\x6e\x67\x3a\x32\45\73\x62\157\x72\x64\x65\162\x3a\62\x70\170\40\163\157\x6c\151\x64\40\x23\x39\x34\71\60\71\60\73\x20\x77\157\162\144\55\167\162\x61\x70\72\x62\x72\x65\141\153\x2d\167\157\x72\x64\x3b\47\76" . implode("\x3c\x68\162\57\76", $nY) . "\x3c\x2f\x74\x64\76\x3c\x2f\x74\162\x3e";
        CZ:
    }
    Tg:
    JV:
    echo "\74\x2f\x74\x61\x62\154\145\76\x3c\57\x64\151\166\x3e";
    echo "\x3c\144\151\166\x20\x73\164\171\x6c\x65\75\x22\x6d\141\162\147\x69\x6e\x3a\x33\45\x3b\144\x69\x73\160\154\141\x79\x3a\x62\x6c\157\x63\x6b\73\164\145\170\164\x2d\x61\154\151\x67\156\72\143\145\x6e\164\145\162\73\42\x3e\15\12\40\40\x20\x20\x20\40\x20\x20\x20\x20\40\x20\x3c\x69\156\160\165\164\40\163\164\171\x6c\x65\x3d\42\x70\141\x64\x64\x69\156\147\72\x31\x25\73\167\151\144\x74\150\x3a\62\65\60\160\170\73\x62\141\143\x6b\147\x72\157\165\x6e\144\72\40\x23\60\60\x39\x31\103\x44\x20\156\x6f\156\x65\40\x72\x65\160\x65\x61\164\40\163\x63\x72\157\154\154\x20\60\45\40\x30\45\x3b\xd\12\40\40\40\x20\x20\40\x20\x20\x20\x20\40\x20\143\x75\162\163\x6f\162\x3a\40\160\x6f\x69\x6e\x74\145\x72\x3b\146\x6f\156\164\55\163\151\x7a\145\x3a\61\x35\160\x78\73\x62\x6f\x72\144\145\x72\55\167\151\x64\x74\150\72\x20\x31\x70\170\73\142\157\x72\x64\145\x72\55\x73\164\x79\x6c\x65\x3a\x20\x73\157\154\x69\144\x3b\142\157\162\144\145\x72\x2d\x72\141\144\151\x75\x73\72\x20\x33\160\170\x3b\x77\150\151\x74\145\55\163\160\x61\x63\145\x3a\xd\12\x20\x20\x20\40\x20\x20\x20\40\40\x20\40\x20\x6e\x6f\x77\162\141\x70\73\142\157\x78\55\x73\x69\x7a\151\x6e\x67\x3a\x20\142\157\162\144\145\162\x2d\142\x6f\170\73\x62\x6f\162\x64\x65\162\x2d\x63\x6f\x6c\157\162\x3a\40\x23\x30\x30\67\63\x41\101\x3b\x62\157\170\x2d\163\150\141\144\x6f\167\x3a\40\60\160\x78\x20\61\x70\170\x20\60\160\170\40\162\147\x62\141\50\x31\62\x30\54\x20\x32\60\60\x2c\x20\x32\x33\60\54\x20\x30\x2e\x36\x29\x20\151\156\x73\145\x74\73\143\x6f\154\x6f\162\72\x20\x23\x46\106\106\73" . $LO . "\42\15\12\40\40\x20\40\x20\40\x20\40\40\x20\x20\x20\x20\40\x20\40\x74\171\x70\145\x3d\42\142\x75\x74\164\157\x6e\x22\40\x76\141\154\165\x65\x3d\42\x43\x6f\156\x66\151\x67\165\162\145\x20\101\x74\x74\162\x69\x62\165\x74\x65\57\x52\157\x6c\145\x20\x4d\x61\160\x70\x69\x6e\147\42\40\x6f\x6e\103\154\151\x63\153\75\42\143\154\x6f\163\x65\x5f\141\x6e\x64\x5f\x72\x65\144\x69\162\145\143\x74\50\51\73\42\x3e\40\x26\156\142\163\x70\73\40\15\xa\40\40\40\40\40\x20\40\40\40\x20\x20\x20\x20\40\x20\x20\xd\xa\40\40\x20\40\x20\x20\x20\x20\40\40\x20\x20\x3c\x69\156\x70\165\x74\40\163\164\171\154\145\x3d\42\160\141\144\144\151\x6e\147\x3a\61\45\73\167\151\144\x74\x68\72\61\60\60\x70\170\x3b\142\x61\x63\x6b\147\162\x6f\x75\156\144\72\40\x23\x30\x30\x39\x31\x43\104\40\156\157\156\145\x20\162\x65\x70\x65\141\164\40\163\x63\x72\157\154\154\x20\60\x25\x20\x30\45\73\143\x75\162\x73\x6f\162\72\x20\160\x6f\151\156\164\x65\162\73\x66\x6f\x6e\164\55\163\x69\x7a\x65\x3a\x31\x35\x70\170\x3b\x62\x6f\x72\144\145\162\x2d\x77\x69\144\164\x68\72\40\x31\x70\170\73\x62\x6f\162\x64\x65\162\x2d\x73\164\x79\154\x65\72\x20\x73\x6f\154\151\x64\73\x62\x6f\162\144\145\x72\x2d\x72\x61\144\x69\x75\163\72\40\x33\160\x78\73\x77\x68\x69\x74\145\55\163\160\x61\x63\x65\x3a\40\x6e\x6f\x77\162\x61\x70\x3b\142\157\170\55\163\x69\172\x69\x6e\147\72\40\142\x6f\162\144\x65\x72\x2d\x62\157\170\73\x62\x6f\x72\x64\x65\x72\55\143\x6f\154\157\162\72\40\43\60\60\67\63\101\x41\73\142\157\170\x2d\163\x68\x61\x64\x6f\167\x3a\x20\x30\160\x78\x20\61\160\170\40\x30\x70\170\x20\162\x67\x62\141\50\61\x32\x30\54\40\x32\60\60\54\x20\62\63\60\54\x20\60\56\66\51\x20\x69\156\163\x65\x74\73\143\x6f\x6c\x6f\162\x3a\x20\43\x46\106\x46\73\x22\x74\x79\x70\145\75\x22\x62\165\164\x74\157\156\42\40\166\x61\154\x75\145\x3d\x22\x44\x6f\156\x65\42\x20\x6f\156\x43\x6c\151\x63\x6b\75\x22\163\x65\x6c\x66\56\x63\154\157\163\145\x28\x29\x3b\x22\76\x3c\x2f\144\x69\x76\x3e\15\12\x20\40\x20\x20\40\x20\x20\40\40\x20\x20\x20\40\40\x20\40\40\x20\40\40\x20\x20\x20\40\x20\x20\40\x20\x20\x20\40\x20\x3c\x73\x63\x72\x69\160\x74\x3e\xd\12\15\xa\40\x20\40\x20\x20\x20\40\x20\40\40\x20\40\x66\x75\156\x63\164\x69\157\156\40\143\154\x6f\x73\145\137\x61\156\144\x5f\162\145\x64\151\x72\x65\x63\x74\x28\x29\173\15\xa\40\x20\40\40\x20\40\40\40\x20\x20\x20\40\x20\40\40\x20\167\x69\156\144\x6f\167\x2e\157\x70\145\156\145\162\56\x72\145\x64\x69\x72\x65\x63\x74\137\164\x6f\x5f\x61\x74\164\162\x69\142\x75\x74\x65\137\155\141\160\x70\151\x6e\x67\50\x29\x3b\xd\12\40\x20\x20\x20\x20\40\40\40\x20\x20\40\x20\40\40\x20\40\x73\x65\x6c\146\x2e\x63\x6c\x6f\163\x65\x28\x29\x3b\xd\xa\x20\x20\40\40\x20\x20\40\40\40\x20\40\40\175\15\12\x20\x20\x20\40\x20\40\x20\x20\x20\x20\40\x20\15\xa\40\40\40\40\x20\x20\x20\x20\x20\40\x20\40\146\x75\x6e\143\164\x69\157\x6e\40\x72\x65\146\x72\x65\x73\150\x50\141\162\145\156\164\x28\51\40\x7b\xd\12\x20\40\40\40\40\x20\x20\x20\40\40\40\40\x20\40\x20\40\x77\x69\x6e\144\x6f\x77\x2e\x6f\160\145\156\x65\x72\56\154\x6f\x63\x61\164\151\157\156\x2e\x72\145\154\157\141\144\x28\51\x3b\15\12\40\40\40\40\40\x20\40\40\40\x20\40\x20\x7d\xd\xa\40\x20\40\x20\x20\x20\40\40\40\x20\40\40\x3c\57\x73\x63\162\151\160\164\76";
    exit;
}
function mo_saml_convert_to_windows_iconv($yt)
{
    $e1 = get_site_option("\x6d\x6f\137\x73\141\x6d\154\x5f\x65\x6e\143\157\x64\151\x6e\147\137\x65\156\x61\142\154\x65\144");
    if (!($e1 !== "\x63\150\145\143\x6b\x65\144")) {
        goto QT;
    }
    return $yt;
    QT:
    return iconv("\x55\124\x46\55\x38", "\x43\120\61\62\x35\x32\57\57\111\x47\x4e\x4f\x52\x45", $yt);
}
function mo_saml_login_user($wE, $L4, $Od, $Vv, $Nq, $mn, $lV, $q4, $LF = '', $jK = '', $Wh = null)
{
    do_action("\x6d\x6f\137\141\x62\162\x5f\x66\x69\154\x74\x65\x72\137\x6c\x6f\x67\151\156", $Wh);
    $Vv = mo_saml_sanitize_username($Vv);
    if (get_site_option("\155\157\x5f\163\141\155\x6c\137\x64\151\x73\x61\x62\154\145\x5f\162\x6f\154\145\x5f\x6d\141\x70\x70\x69\x6e\147")) {
        goto IL;
    }
    check_if_user_allowed_to_login_due_to_role_restriction($Nq);
    IL:
    $IQ = get_site_option("\155\157\x5f\x73\141\155\154\x5f\163\160\x5f\x62\141\x73\x65\137\165\x72\154");
    mo_saml_restrict_users_based_on_domain($wE);
    if (!empty($mn)) {
        goto x9;
    }
    $mn["\x44\x45\x46\101\125\x4c\x54"]["\144\145\x66\141\165\154\x74\137\162\157\154\145"] = "\x73\x75\x62\163\x63\162\x69\142\145\x72";
    $mn["\104\x45\x46\101\x55\x4c\124"]["\144\x6f\156\x74\x5f\141\x6c\x6c\157\167\x5f\x75\156\154\x69\163\x74\x65\144\137\x75\163\145\162"] = '';
    $mn["\x44\105\106\x41\125\114\x54"]["\x64\x6f\x6e\164\x5f\x63\x72\x65\141\164\145\x5f\165\163\x65\162"] = '';
    $mn["\x44\105\x46\x41\x55\114\124"]["\x6b\x65\145\160\137\145\x78\x69\163\x74\151\x6e\147\x5f\x75\x73\145\162\x73\x5f\x72\157\154\145"] = '';
    $mn["\104\x45\106\x41\x55\114\124"]["\155\157\x5f\x73\x61\155\154\137\144\157\156\x74\x5f\x61\154\154\x6f\x77\137\165\x73\145\x72\137\164\157\x6c\157\x67\x69\156\x5f\143\x72\145\141\164\x65\137\167\x69\164\x68\x5f\x67\x69\x76\145\156\x5f\147\x72\157\165\x70\163"] = '';
    $mn["\x44\105\106\101\x55\x4c\124"]["\x6d\157\x5f\x73\141\155\154\x5f\162\x65\x73\164\162\x69\143\x74\x5f\165\163\x65\162\x73\x5f\x77\151\164\x68\x5f\x67\x72\x6f\x75\160\x73"] = '';
    x9:
    global $wpdb;
    $ND = get_current_blog_id();
    $v3 = "\165\156\x63\x68\x65\x63\x6b\145\x64";
    if (!empty($IQ)) {
        goto HS;
    }
    $IQ = get_network_site_url();
    HS:
    if (email_exists($wE) || username_exists($Vv)) {
        goto OQ;
    }
    $WM = Utilities::get_active_sites();
    $uq = get_site_option("\155\x6f\137\x61\x70\160\x6c\x79\x5f\x72\x6f\x6c\145\137\155\141\x70\x70\x69\156\x67\x5f\146\x6f\x72\x5f\163\x69\164\145\x73");
    if (!get_site_option("\155\x6f\x5f\x73\141\155\154\x5f\144\x69\163\x61\x62\x6c\145\x5f\x72\x6f\x6c\x65\137\x6d\x61\x70\160\x69\156\147")) {
        goto Xb;
    }
    $U8 = wp_generate_password(12, false);
    $LK = wpmu_create_user($Vv, $U8, $wE);
    goto lF;
    Xb:
    $LK = mo_saml_assign_roles_to_new_user($WM, $uq, $mn, $Nq, $Vv, $wE);
    lF:
    switch_to_blog($ND);
    if (!empty($LK)) {
        goto W7;
    }
    if (!get_site_option("\x6d\x6f\137\163\x61\x6d\x6c\137\x64\151\163\141\x62\x6c\x65\137\x72\157\154\145\x5f\155\141\160\160\x69\x6e\x67")) {
        goto q8;
    }
    wp_die("\127\145\40\143\157\x75\x6c\144\x20\156\157\x74\x20\x73\x69\x67\x6e\40\171\x6f\165\x20\x69\x6e\56\40\120\154\x65\x61\x73\145\x20\143\157\156\164\x61\x63\164\40\x61\144\x6d\x69\156\151\x73\164\x72\x61\164\157\162", "\114\x6f\x67\x69\x6e\x20\106\x61\x69\154\x65\144\41");
    goto pp;
    q8:
    $SM = get_site_option("\x6d\x6f\137\x73\x61\155\154\x5f\141\143\143\157\165\156\164\x5f\x63\162\x65\x61\x74\x69\x6f\x6e\137\144\x69\x73\x61\x62\x6c\145\x64\137\x6d\x73\x67");
    if (!empty($SM)) {
        goto j0;
    }
    $SM = "\127\x65\40\x63\157\165\154\144\40\x6e\x6f\x74\40\x73\x69\x67\x6e\x20\x79\157\165\x20\151\156\x2e\40\120\154\145\x61\163\x65\x20\x63\x6f\x6e\x74\x61\143\164\40\171\157\x75\x72\40\x41\144\x6d\x69\x6e\151\x73\x74\x72\x61\164\157\x72\x2e";
    j0:
    wp_die($SM, "\105\162\x72\157\162\72\x20\116\x6f\164\x20\141\40\x57\157\162\144\120\162\145\x73\163\40\115\x65\x6d\x62\145\162");
    pp:
    W7:
    $user = get_user_by("\151\x64", $LK);
    mo_saml_map_basic_attributes($user, $L4, $Od, $Wh);
    mo_saml_map_custom_attributes($LK, $Wh);
    $qN = mo_saml_get_redirect_url($IQ, $lV);
    do_action("\x6d\x69\156\x69\x6f\162\141\156\x67\x65\137\160\157\x73\x74\137\141\x75\164\150\145\x6e\x74\x69\143\x61\x74\145\x5f\x75\163\145\162\x5f\154\x6f\147\x69\156", $user, null, $qN, true);
    mo_saml_set_auth_cookie($user, $LF, $jK, true);
    do_action("\155\157\x5f\x73\141\x6d\x6c\x5f\141\x74\164\162\x69\142\165\164\145\163", $Vv, $wE, $L4, $Od, $Nq, null, true);
    goto wd;
    OQ:
    if (email_exists($wE)) {
        goto v5;
    }
    $user = get_user_by("\x6c\157\x67\x69\156", $Vv);
    goto R5;
    v5:
    $user = get_user_by("\145\x6d\x61\x69\x6c", $wE);
    R5:
    $LK = $user->ID;
    if (!(!empty($wE) and strcasecmp($wE, $user->user_email) != 0)) {
        goto UW;
    }
    $LK = wp_update_user(array("\111\x44" => $LK, "\165\163\145\162\137\145\x6d\x61\x69\154" => $wE));
    UW:
    mo_saml_map_basic_attributes($user, $L4, $Od, $Wh);
    mo_saml_map_custom_attributes($LK, $Wh);
    $WM = Utilities::get_active_sites();
    $uq = get_site_option("\x6d\157\137\141\x70\x70\x6c\171\137\162\157\154\x65\x5f\155\x61\160\160\x69\x6e\147\x5f\146\157\x72\137\x73\x69\x74\145\163");
    if (get_site_option("\x6d\157\137\163\x61\155\154\137\x64\151\163\x61\x62\154\145\137\x72\157\154\x65\x5f\x6d\141\x70\x70\x69\156\147")) {
        goto u4;
    }
    foreach ($WM as $blog_id) {
        switch_to_blog($blog_id);
        $user = get_user_by("\151\x64", $LK);
        $FH = '';
        if ($uq) {
            goto HG;
        }
        $FH = $blog_id;
        goto S0;
        HG:
        $FH = 0;
        S0:
        if (empty($mn)) {
            goto st;
        }
        if (!empty($mn[$FH])) {
            goto hZ;
        }
        if (!empty($mn["\104\x45\106\x41\x55\114\124"])) {
            goto fR;
        }
        $GU = "\163\165\x62\x73\x63\x72\151\142\145\x72";
        $w0 = '';
        $v3 = '';
        $Dl = '';
        goto EU;
        fR:
        $GU = isset($mn["\x44\105\106\101\125\x4c\124"]["\144\145\146\x61\165\x6c\164\137\x72\157\x6c\145"]) ? $mn["\x44\105\x46\x41\125\x4c\x54"]["\x64\145\146\141\x75\154\164\137\x72\x6f\x6c\145"] : "\163\x75\x62\163\143\x72\x69\142\x65\162";
        $w0 = isset($mn["\104\105\x46\101\x55\114\124"]["\x64\x6f\156\x74\137\141\154\154\157\167\x5f\165\156\x6c\151\x73\164\145\x64\137\x75\x73\145\162"]) ? $mn["\104\x45\x46\x41\125\114\x54"]["\x64\157\x6e\x74\x5f\x61\x6c\154\x6f\167\x5f\x75\x6e\154\151\x73\164\145\144\x5f\165\x73\x65\162"] : '';
        $v3 = isset($mn["\104\x45\106\101\125\114\x54"]["\x64\157\x6e\x74\137\143\x72\x65\x61\x74\x65\137\x75\x73\145\162"]) ? $mn["\104\x45\106\x41\125\x4c\x54"]["\x64\157\156\x74\137\x63\162\x65\x61\164\x65\137\165\x73\145\x72"] : '';
        $Dl = isset($mn["\104\105\x46\x41\x55\114\x54"]["\153\145\145\160\137\x65\x78\151\163\x74\x69\x6e\147\137\165\x73\145\162\163\x5f\162\157\x6c\x65"]) ? $mn["\104\105\x46\x41\x55\114\124"]["\153\145\x65\160\137\145\170\151\163\x74\x69\156\147\137\165\163\x65\x72\x73\x5f\162\x6f\154\x65"] : '';
        EU:
        goto Rh;
        hZ:
        $GU = isset($mn[$FH]["\x64\x65\x66\141\165\154\x74\x5f\162\157\154\x65"]) ? $mn[$FH]["\x64\x65\146\x61\x75\x6c\x74\x5f\162\x6f\x6c\x65"] : '';
        $w0 = isset($mn[$FH]["\x64\x6f\156\164\x5f\141\154\154\157\167\137\165\156\154\151\x73\164\x65\x64\x5f\x75\163\x65\x72"]) ? $mn[$FH]["\x64\x6f\156\x74\x5f\141\154\x6c\x6f\x77\x5f\165\156\x6c\x69\x73\164\145\144\x5f\x75\163\x65\162"] : '';
        $v3 = isset($mn[$FH]["\x64\x6f\x6e\x74\137\x63\162\x65\x61\x74\x65\x5f\x75\163\145\162"]) ? $mn[$FH]["\144\x6f\x6e\164\x5f\x63\162\145\141\164\145\137\165\x73\145\162"] : '';
        $Dl = isset($mn[$FH]["\153\x65\145\160\x5f\x65\170\x69\163\164\x69\156\x67\x5f\x75\163\x65\x72\163\x5f\x72\157\x6c\x65"]) ? $mn[$FH]["\153\145\x65\x70\x5f\145\x78\x69\x73\x74\x69\x6e\x67\x5f\x75\163\x65\162\163\x5f\x72\157\154\145"] : '';
        Rh:
        st:
        if (!is_user_member_of_blog($LK, $blog_id)) {
            goto OH;
        }
        if (isset($Dl) && $Dl == "\143\x68\x65\x63\x6b\x65\144") {
            goto S3;
        }
        $ef = assign_roles_to_user($user, $mn, $blog_id, $Nq, $FH);
        goto ne;
        S3:
        $ef = false;
        ne:
        if (is_administrator_user($user)) {
            goto cr;
        }
        if (isset($Dl) && $Dl == "\143\x68\x65\x63\x6b\145\144") {
            goto Eo;
        }
        if ($ef !== true && !empty($w0) && $w0 == "\x63\150\145\143\x6b\x65\x64") {
            goto Nv;
        }
        if ($ef !== true && !empty($GU) && $GU !== "\146\141\x6c\163\x65") {
            goto Qp;
        }
        if ($ef !== true && is_user_member_of_blog($LK, $blog_id)) {
            goto qs;
        }
        goto cD;
        Eo:
        goto cD;
        Nv:
        $LK = wp_update_user(array("\111\104" => $LK, "\162\157\x6c\x65" => false));
        goto cD;
        Qp:
        $LK = wp_update_user(array("\111\x44" => $LK, "\162\157\x6c\x65" => $GU));
        goto cD;
        qs:
        $p1 = get_site_option("\144\x65\x66\141\165\x6c\164\x5f\x72\157\154\x65");
        $LK = wp_update_user(array("\x49\104" => $LK, "\x72\157\x6c\145" => $p1));
        cD:
        cr:
        goto yO;
        OH:
        $CO = TRUE;
        $vJ = get_site_option("\x73\141\x6d\154\x5f\163\163\x6f\x5f\x73\x65\164\x74\x69\156\147\163");
        if (!empty($vJ[$blog_id])) {
            goto gL;
        }
        $vJ[$blog_id] = $vJ["\104\x45\x46\101\x55\x4c\124"];
        gL:
        if (empty($mn)) {
            goto nH;
        }
        if (array_key_exists($FH, $mn)) {
            goto lB;
        }
        if (!array_key_exists("\104\x45\106\x41\x55\x4c\124", $mn)) {
            goto YK;
        }
        $GT = get_saml_roles_to_assign($mn, $FH, $Nq);
        if (!(empty($GT) && strcmp($mn["\x44\x45\x46\x41\125\x4c\124"]["\x64\x6f\x6e\164\x5f\x63\x72\145\x61\x74\x65\137\x75\163\145\162"], "\143\150\x65\143\x6b\x65\x64") == 0)) {
            goto gF;
        }
        $CO = FALSE;
        gF:
        YK:
        goto ty;
        lB:
        $GT = get_saml_roles_to_assign($mn, $FH, $Nq);
        if (!(empty($GT) && strcmp($mn[$FH]["\x64\157\156\x74\x5f\x63\x72\x65\141\x74\145\x5f\x75\x73\145\x72"], "\x63\150\x65\143\x6b\x65\x64") == 0)) {
            goto cg;
        }
        $CO = FALSE;
        cg:
        ty:
        nH:
        if (!$CO) {
            goto pl;
        }
        add_user_to_blog($blog_id, $LK, false);
        $ef = assign_roles_to_user($user, $mn, $blog_id, $Nq, $FH);
        if ($ef !== true && !empty($w0) && $w0 == "\143\x68\x65\143\x6b\145\144") {
            goto Qb;
        }
        if ($ef !== true && !empty($GU) && $GU !== "\x66\141\x6c\163\145") {
            goto jR;
        }
        if ($ef !== true) {
            goto cp;
        }
        goto gW;
        Qb:
        $LK = wp_update_user(array("\x49\104" => $LK, "\162\x6f\x6c\x65" => false));
        goto gW;
        jR:
        $LK = wp_update_user(array("\111\x44" => $LK, "\x72\x6f\154\x65" => $GU));
        goto gW;
        cp:
        $p1 = get_site_option("\144\x65\x66\x61\165\x6c\x74\x5f\x72\157\x6c\145");
        $LK = wp_update_user(array("\x49\x44" => $LK, "\x72\x6f\154\145" => $p1));
        gW:
        pl:
        yO:
        m0:
    }
    X8:
    u4:
    switch_to_blog($ND);
    if ($LK) {
        goto Jk;
    }
    wp_die("\111\156\x76\x61\x6c\x69\144\x20\165\163\x65\x72\56\40\120\154\x65\x61\x73\145\40\164\x72\171\40\141\147\141\151\x6e\x2e");
    Jk:
    $user = get_user_by("\151\144", $LK);
    mo_saml_set_auth_cookie($user, $LF, $jK, true);
    do_action("\x6d\157\x5f\x73\141\x6d\154\x5f\x61\164\164\162\x69\x62\165\x74\145\x73", $Vv, $wE, $L4, $Od, $Nq);
    wd:
    mo_saml_post_login_redirection($IQ, $lV);
}
function mo_saml_add_user_to_blog($wE, $Vv, $blog_id = 0)
{
    if (email_exists($wE)) {
        goto N2;
    }
    if (!empty($Vv)) {
        goto RZ;
    }
    $LK = mo_saml_create_user($wE, $wE, $blog_id);
    goto yf;
    RZ:
    $LK = mo_saml_create_user($Vv, $wE, $blog_id);
    yf:
    goto Nl;
    N2:
    $user = get_user_by("\x65\155\141\151\x6c", $wE);
    $LK = $user->ID;
    if (empty($blog_id)) {
        goto DQ;
    }
    add_user_to_blog($blog_id, $LK, false);
    DQ:
    Nl:
    return $LK;
}
function mo_saml_create_user($Vv, $wE, $blog_id)
{
    $zr = wp_generate_password(10, false);
    if (username_exists($Vv)) {
        goto yd;
    }
    $LK = wp_create_user($Vv, $zr, $wE);
    goto KJ;
    yd:
    $user = get_user_by("\154\157\147\x69\x6e", $Vv);
    $LK = $user->ID;
    if (!$blog_id) {
        goto rW;
    }
    add_user_to_blog($blog_id, $LK, false);
    rW:
    KJ:
    if (!is_wp_error($LK)) {
        goto AA;
    }
    echo "\x3c\163\x74\162\x6f\x6e\x67\x3e\105\x52\x52\117\x52\x3c\x2f\163\x74\x72\x6f\x6e\x67\x3e\72\x20\x45\155\160\164\171\x20\125\x73\145\162\x20\x4e\x61\155\x65\x20\x61\156\144\40\x45\155\141\151\x6c\x2e\x20\x50\x6c\x65\x61\163\x65\x20\143\157\156\x74\x61\x63\x74\40\x79\157\x75\162\x20\x61\x64\x6d\x69\x6e\151\x73\164\x72\141\x74\157\162\x2e";
    exit;
    AA:
    return $LK;
}
function mo_saml_assign_roles_to_new_user($WM, $uq, $mn, $Nq, $Vv, $wE)
{
    global $wpdb;
    $user = NULL;
    $rw = false;
    foreach ($WM as $blog_id) {
        $pl = TRUE;
        $FH = '';
        if ($uq) {
            goto Vu;
        }
        $FH = $blog_id;
        goto VM;
        Vu:
        $FH = 0;
        VM:
        $vJ = get_site_option("\x73\141\x6d\x6c\137\x73\x73\x6f\x5f\163\145\164\x74\x69\156\147\163");
        if (!empty($vJ[$blog_id])) {
            goto WO;
        }
        $vJ[$blog_id] = $vJ["\x44\105\x46\x41\125\114\124"];
        WO:
        if (empty($mn)) {
            goto rx;
        }
        if (!empty($mn[$FH])) {
            goto Ka;
        }
        if (!empty($mn["\104\x45\x46\x41\x55\114\124"])) {
            goto Uc;
        }
        $GU = "\163\x75\x62\x73\x63\162\x69\x62\x65\162";
        $w0 = '';
        $Dl = '';
        $GT = '';
        goto nL;
        Uc:
        $GU = isset($mn["\104\x45\106\x41\125\114\124"]["\144\x65\146\141\165\154\164\137\162\x6f\154\x65"]) ? $mn["\x44\105\106\101\x55\x4c\124"]["\144\x65\146\x61\x75\154\164\137\x72\157\154\145"] : '';
        $w0 = isset($mn["\104\105\106\101\125\114\124"]["\144\157\x6e\164\x5f\141\154\x6c\157\167\x5f\x75\x6e\154\x69\x73\164\145\x64\x5f\165\163\x65\162"]) ? $mn["\x44\105\x46\101\125\x4c\124"]["\144\x6f\x6e\164\137\141\154\x6c\x6f\167\137\165\x6e\x6c\151\163\164\x65\x64\137\x75\x73\x65\162"] : '';
        $Dl = array_key_exists("\153\145\145\160\137\x65\170\x69\x73\164\x69\156\147\137\165\163\145\162\163\137\162\157\154\x65", $mn["\x44\105\x46\x41\x55\x4c\x54"]) ? $mn["\x44\105\x46\x41\125\114\x54"]["\x6b\145\145\160\137\x65\x78\151\x73\164\151\156\147\137\x75\x73\x65\162\163\x5f\x72\x6f\154\x65"] : '';
        $GT = get_saml_roles_to_assign($mn, $FH, $Nq);
        if (!(empty($GT) && strcmp($mn["\x44\105\106\x41\125\114\124"]["\x64\x6f\x6e\164\137\143\162\x65\141\x74\x65\x5f\x75\163\145\x72"], "\143\x68\x65\x63\153\145\x64") == 0)) {
            goto ML;
        }
        $pl = FALSE;
        ML:
        nL:
        goto pj;
        Ka:
        $GU = isset($mn[$FH]["\x64\x65\146\141\165\154\x74\137\162\x6f\154\x65"]) ? $mn[$FH]["\x64\145\x66\x61\165\x6c\x74\137\162\157\x6c\145"] : '';
        $w0 = isset($mn[$FH]["\144\x6f\x6e\x74\137\x61\x6c\154\x6f\x77\x5f\165\156\x6c\151\x73\x74\145\x64\x5f\x75\x73\145\162"]) ? $mn[$FH]["\144\157\156\x74\137\141\x6c\154\157\167\x5f\x75\156\x6c\x69\163\x74\145\144\137\165\x73\145\162"] : '';
        $Dl = array_key_exists("\x6b\x65\x65\x70\x5f\x65\170\x69\x73\164\151\156\x67\137\165\163\x65\x72\x73\137\162\x6f\154\x65", $mn[$FH]) ? $mn[$FH]["\153\145\x65\x70\137\145\x78\x69\x73\x74\151\x6e\147\137\x75\163\145\162\163\137\x72\157\154\x65"] : '';
        $GT = get_saml_roles_to_assign($mn, $FH, $Nq);
        if (!(empty($GT) && strcmp($mn[$FH]["\144\157\x6e\x74\x5f\143\162\x65\x61\x74\145\137\165\x73\x65\x72"], "\143\x68\145\x63\x6b\x65\x64") == 0)) {
            goto Vw;
        }
        $pl = FALSE;
        Vw:
        pj:
        rx:
        if (!$pl) {
            goto gU;
        }
        $LK = NULL;
        switch_to_blog($blog_id);
        $LK = mo_saml_add_user_to_blog($wE, $Vv, $blog_id);
        $user = get_user_by("\x69\144", $LK);
        $ef = assign_roles_to_user($user, $mn, $blog_id, $Nq, $FH);
        if ($ef !== true && !empty($w0) && $w0 == "\x63\x68\145\143\153\145\144") {
            goto wS;
        }
        if ($ef !== true && !empty($GU) && $GU !== "\146\x61\154\163\x65") {
            goto cB;
        }
        if ($ef !== true) {
            goto cf;
        }
        goto lZ;
        wS:
        $LK = wp_update_user(array("\x49\x44" => $LK, "\x72\x6f\154\145" => false));
        goto lZ;
        cB:
        $LK = wp_update_user(array("\111\x44" => $LK, "\162\157\154\x65" => $GU));
        goto lZ;
        cf:
        $p1 = get_site_option("\x64\x65\146\x61\x75\154\x74\x5f\x72\x6f\154\145");
        $LK = wp_update_user(array("\x49\x44" => $LK, "\x72\x6f\154\145" => $p1));
        lZ:
        $fX = $user->{$wpdb->prefix . "\143\141\160\141\142\151\154\151\164\x69\145\x73"};
        if (isset($wp_roles)) {
            goto kQ;
        }
        $wp_roles = new WP_Roles($FH);
        kQ:
        gU:
        I1:
    }
    v1:
    if (!empty($user)) {
        goto J7;
    }
    return;
    goto kR;
    J7:
    return $user->ID;
    kR:
}
function mo_saml_sanitize_username($Vv)
{
    $Jz = sanitize_user($Vv, true);
    $r0 = apply_filters("\x70\x72\x65\137\165\163\145\x72\x5f\x6c\157\x67\151\x6e", $Jz);
    $Vv = trim($r0);
    return $Vv;
}
function mo_saml_map_basic_attributes($user, $L4, $Od, $Wh)
{
    $LK = $user->ID;
    if (empty($L4)) {
        goto AW;
    }
    $LK = wp_update_user(array("\x49\x44" => $LK, "\146\x69\x72\x73\164\x5f\156\x61\x6d\145" => $L4));
    AW:
    if (empty($Od)) {
        goto mw;
    }
    $LK = wp_update_user(array("\x49\104" => $LK, "\154\x61\163\x74\x5f\156\x61\155\x65" => $Od));
    mw:
    if (is_null($Wh)) {
        goto Me;
    }
    update_user_meta($LK, "\x6d\157\x5f\163\x61\x6d\154\x5f\x75\163\x65\162\x5f\141\x74\x74\162\151\x62\x75\x74\145\x73", $Wh);
    $we = get_site_option("\163\141\x6d\x6c\137\x61\x6d\x5f\x64\151\163\x70\x6c\x61\171\x5f\156\x61\155\x65");
    if (empty($we)) {
        goto nM;
    }
    if (strcmp($we, "\x55\x53\x45\x52\x4e\x41\x4d\x45") == 0) {
        goto NE;
    }
    if (strcmp($we, "\106\116\101\115\x45") == 0 && !empty($L4)) {
        goto O1;
    }
    if (strcmp($we, "\114\x4e\101\x4d\x45") == 0 && !empty($Od)) {
        goto DL;
    }
    if (strcmp($we, "\106\x4e\101\x4d\x45\137\114\116\101\x4d\105") == 0 && !empty($Od) && !empty($L4)) {
        goto Un;
    }
    if (!(strcmp($we, "\114\x4e\101\x4d\x45\137\x46\x4e\x41\115\x45") == 0 && !empty($Od) && !empty($L4))) {
        goto Rl;
    }
    $LK = wp_update_user(array("\111\x44" => $LK, "\x64\151\x73\160\x6c\141\x79\x5f\156\x61\155\145" => $Od . "\40" . $L4));
    Rl:
    goto j4;
    Un:
    $LK = wp_update_user(array("\111\x44" => $LK, "\144\x69\x73\x70\x6c\141\x79\137\156\x61\155\145" => $L4 . "\x20" . $Od));
    j4:
    goto K9;
    DL:
    $LK = wp_update_user(array("\111\x44" => $LK, "\144\151\163\x70\x6c\x61\171\x5f\x6e\141\x6d\145" => $Od));
    K9:
    goto n0;
    O1:
    $LK = wp_update_user(array("\111\104" => $LK, "\144\x69\x73\160\x6c\x61\171\137\156\x61\x6d\145" => $L4));
    n0:
    goto jE;
    NE:
    $LK = wp_update_user(array("\111\x44" => $LK, "\144\151\163\160\154\141\171\x5f\156\141\155\145" => $user->user_login));
    jE:
    nM:
    Me:
}
function mo_saml_map_custom_attributes($LK, $Wh)
{
    if (!get_site_option("\155\x6f\x5f\x73\141\155\154\137\143\x75\x73\x74\157\x6d\137\x61\x74\x74\x72\x73\137\155\x61\x70\160\151\x6e\147")) {
        goto MR;
    }
    $Xt = maybe_unserialize(get_site_option("\x6d\x6f\x5f\x73\141\x6d\x6c\x5f\x63\165\163\164\x6f\155\x5f\x61\164\x74\x72\163\x5f\x6d\x61\x70\x70\151\156\147"));
    foreach ($Xt as $q3 => $nY) {
        if (!array_key_exists($nY, $Wh)) {
            goto oa;
        }
        $q7 = false;
        if (!(count($Wh[$nY]) == 1)) {
            goto av;
        }
        $q7 = true;
        av:
        if (!$q7) {
            goto Sw;
        }
        update_user_meta($LK, $q3, $Wh[$nY][0]);
        goto pQ;
        Sw:
        $mw = array();
        foreach ($Wh[$nY] as $Qu) {
            array_push($mw, $Qu);
            fW:
        }
        AG:
        update_user_meta($LK, $q3, $mw);
        pQ:
        oa:
        zV:
    }
    Dw:
    MR:
}
function mo_saml_restrict_users_based_on_domain($wE)
{
    $ba = get_site_option("\x6d\157\137\x73\x61\x6d\x6c\x5f\x65\156\x61\142\154\x65\x5f\144\157\x6d\141\151\156\x5f\x72\145\163\164\162\151\x63\164\x69\x6f\156\137\x6c\x6f\x67\x69\x6e");
    if (!$ba) {
        goto Ok;
    }
    $gK = get_site_option("\x73\x61\155\154\x5f\x61\x6d\137\145\155\141\x69\154\137\144\x6f\155\x61\x69\156\x73");
    $RI = explode("\73", $gK);
    $cI = explode("\100", $wE);
    $RF = array_key_exists("\x31", $cI) ? $cI[1] : '';
    $Ch = get_site_option("\155\157\137\x73\141\155\x6c\x5f\141\154\x6c\x6f\x77\137\144\x65\156\171\x5f\x75\x73\145\162\x5f\x77\151\164\150\x5f\x64\157\155\141\151\156");
    $SM = get_site_option("\155\157\137\x73\141\x6d\x6c\x5f\162\x65\x73\x74\162\151\x63\164\x65\x64\x5f\144\x6f\x6d\x61\151\156\x5f\145\162\162\157\x72\x5f\155\163\147");
    if (!empty($SM)) {
        goto I_;
    }
    $SM = "\x59\157\x75\40\x61\162\145\40\156\157\x74\40\x61\154\x6c\157\167\145\x64\x20\164\157\x20\x6c\157\x67\x69\156\56\40\x50\154\x65\141\x73\x65\x20\x63\x6f\x6e\x74\141\x63\x74\x20\x79\x6f\x75\162\40\x41\144\x6d\x69\x6e\x69\163\x74\x72\x61\164\157\x72\x2e";
    I_:
    if (!empty($Ch) && $Ch == "\144\145\156\171") {
        goto MF;
    }
    if (in_array($RF, $RI)) {
        goto ya;
    }
    wp_die($SM, "\x50\x65\x72\155\x69\163\x73\x69\x6f\x6e\x20\x44\145\x6e\x69\145\144\40\105\162\x72\x6f\162\40\x2d\x20\62");
    ya:
    goto f3;
    MF:
    if (!in_array($RF, $RI)) {
        goto fs;
    }
    wp_die($SM, "\120\x65\x72\x6d\x69\x73\x73\151\x6f\x6e\x20\x44\x65\156\x69\145\144\x20\105\162\x72\157\x72\x20\55\40\61");
    fs:
    f3:
    Ok:
}
function mo_saml_set_auth_cookie($user, $LF, $jK, $FN)
{
    $LK = $user->ID;
    do_action("\x77\x70\137\154\157\147\151\156", $user->user_login, $user);
    if (empty($LF)) {
        goto lo;
    }
    update_user_meta($LK, "\x6d\157\x5f\163\141\x6d\154\x5f\x73\145\163\x73\x69\157\x6e\137\x69\156\x64\x65\170", $LF);
    lo:
    if (empty($jK)) {
        goto g8;
    }
    update_user_meta($LK, "\x6d\157\x5f\x73\141\155\x6c\137\156\141\x6d\145\x5f\151\x64", $jK);
    g8:
    if (!(!session_id() || session_id() == '' || !isset($_SESSION))) {
        goto Ms;
    }
    session_start();
    Ms:
    $_SESSION["\155\x6f\x5f\163\141\x6d\154"]["\154\x6f\x67\x67\145\x64\137\x69\x6e\137\x77\x69\x74\150\x5f\x69\144\x70"] = TRUE;
    update_user_meta($LK, "\155\157\x5f\x73\141\x6d\x6c\137\x69\144\160\x5f\x6c\157\147\x69\156", "\x74\162\x75\145");
    wp_set_current_user($LK);
    $Yt = false;
    $Yt = apply_filters("\x6d\x6f\137\162\x65\x6d\145\x6d\142\x65\x72\137\x6d\145", $Yt);
    wp_set_auth_cookie($LK, $Yt);
    if (!$FN) {
        goto Qg;
    }
    do_action("\165\x73\x65\x72\x5f\x72\145\x67\151\163\x74\x65\x72", $LK);
    Qg:
}
function mo_saml_post_login_redirection($IQ, $lV)
{
    $S0 = mo_saml_get_redirect_url($IQ, $lV);
    wp_redirect($S0);
    exit;
}
function mo_saml_get_redirect_url($IQ, $lV)
{
    $qN = '';
    $vJ = get_site_option("\x73\141\x6d\x6c\x5f\163\x73\x6f\x5f\163\x65\x74\164\x69\x6e\147\163");
    $cB = get_current_blog_id();
    if (!(empty($vJ[$cB]) && !empty($vJ["\104\x45\x46\101\125\x4c\x54"]))) {
        goto Kf;
    }
    $vJ[$cB] = $vJ["\x44\105\106\x41\125\x4c\x54"];
    Kf:
    $Yu = isset($vJ[$cB]["\155\x6f\137\x73\141\x6d\154\x5f\x72\x65\x6c\x61\x79\x5f\x73\164\x61\164\145"]) ? $vJ[$cB]["\x6d\x6f\137\x73\x61\x6d\154\x5f\162\x65\154\141\x79\137\x73\164\141\164\145"] : '';
    if (!empty($Yu)) {
        goto A4;
    }
    if (!empty($lV)) {
        goto nE;
    }
    $qN = $IQ;
    goto pM;
    nE:
    $qN = $lV;
    pM:
    goto Wm;
    A4:
    $qN = $Yu;
    Wm:
    return $qN;
}
function check_if_user_allowed_to_login($user, $IQ)
{
    $LK = $user->ID;
    global $wpdb;
    if (get_user_meta($LK, "\155\x6f\x5f\163\x61\155\x6c\x5f\x75\163\x65\162\x5f\x74\x79\x70\145", true)) {
        goto d1;
    }
    if (get_site_option("\x6d\157\137\163\x61\x6d\154\137\x75\163\x72\x5f\x6c\x6d\164")) {
        goto vN;
    }
    update_user_meta($LK, "\155\157\137\x73\141\155\154\x5f\x75\163\145\x72\137\x74\x79\x70\x65", "\163\x73\157\x5f\165\x73\x65\x72");
    goto He;
    vN:
    $q3 = get_site_option("\x6d\x6f\x5f\163\x61\155\x6c\x5f\143\x75\163\x74\x6f\155\x65\x72\x5f\164\157\x6b\145\x6e");
    $kr = AESEncryption::decrypt_data(get_site_option("\x6d\157\x5f\163\x61\x6d\154\x5f\x75\163\x72\x5f\x6c\155\x74"), $q3);
    $an = "\x53\105\114\x45\103\x54\x20\103\x4f\x55\x4e\x54\50\x2a\51\40\106\x52\x4f\x4d\40" . $wpdb->prefix . "\x75\x73\x65\162\155\145\164\x61\40\x57\x48\105\x52\105\40\155\x65\x74\x61\x5f\153\145\171\75\47\155\x6f\x5f\x73\141\155\x6c\x5f\165\163\145\162\137\164\171\160\x65\x27";
    $HJ = $wpdb->get_var($an);
    if ($HJ >= $kr) {
        goto YD;
    }
    update_user_meta($LK, "\155\157\137\x73\x61\155\154\x5f\x75\163\x65\162\137\x74\x79\160\145", "\163\x73\157\137\x75\163\145\x72");
    goto sD;
    YD:
    if (get_site_option("\x75\163\x65\162\x5f\141\x6c\145\x72\x74\137\x65\x6d\141\x69\x6c\137\x73\145\156\x74")) {
        goto kV;
    }
    $hV = new Customersaml();
    $hV->mo_saml_send_user_exceeded_alert_email($kr, $this);
    kV:
    if (is_administrator_user($user)) {
        goto Aa;
    }
    wp_redirect($IQ);
    exit;
    goto qR;
    Aa:
    update_user_meta($LK, "\x6d\157\x5f\163\141\155\154\137\x75\x73\145\x72\x5f\164\x79\x70\145", "\x73\x73\x6f\x5f\165\163\x65\x72");
    qR:
    sD:
    He:
    d1:
}
function check_if_user_allowed_to_login_due_to_role_restriction($Nq)
{
    $mn = maybe_unserialize(get_site_option("\163\141\155\x6c\x5f\x61\155\x5f\162\157\154\145\137\x6d\x61\x70\x70\151\156\x67"));
    $WM = Utilities::get_active_sites();
    $uq = get_site_option("\155\157\x5f\141\160\160\154\x79\x5f\162\157\154\145\x5f\x6d\x61\x70\x70\x69\x6e\147\137\x66\157\x72\x5f\163\151\x74\145\x73");
    if ($mn) {
        goto zz;
    }
    $mn = array();
    zz:
    if (array_key_exists("\x44\105\106\x41\x55\114\124", $mn)) {
        goto UM;
    }
    $mn["\104\105\106\101\x55\x4c\124"] = array();
    UM:
    foreach ($WM as $blog_id) {
        if ($uq) {
            goto iE;
        }
        $FH = $blog_id;
        goto LH;
        iE:
        $FH = 0;
        LH:
        if (isset($mn[$FH])) {
            goto UN;
        }
        $K4 = $mn["\x44\x45\106\x41\x55\x4c\124"];
        goto x7;
        UN:
        $K4 = $mn[$FH];
        x7:
        if (empty($K4)) {
            goto AR;
        }
        $BN = isset($K4["\155\157\137\x73\141\x6d\154\x5f\x64\157\x6e\164\x5f\141\154\154\157\167\137\x75\x73\x65\162\x5f\x74\157\154\x6f\147\x69\x6e\x5f\143\x72\145\141\x74\x65\137\167\151\x74\x68\137\147\x69\166\x65\156\x5f\x67\x72\157\165\x70\x73"]) ? $K4["\x6d\157\x5f\x73\x61\x6d\x6c\x5f\x64\157\x6e\x74\137\x61\154\154\157\167\x5f\x75\163\x65\x72\x5f\164\157\154\x6f\147\x69\156\137\143\x72\x65\x61\x74\x65\137\167\x69\164\150\137\147\151\x76\145\x6e\137\147\x72\157\165\160\x73"] : '';
        if (!($BN == "\143\x68\145\143\153\145\144")) {
            goto sb;
        }
        if (empty($Nq)) {
            goto mf;
        }
        $KG = $K4["\x6d\x6f\x5f\x73\141\155\154\137\162\145\x73\x74\162\x69\143\x74\137\x75\x73\x65\162\163\x5f\x77\x69\x74\x68\137\x67\x72\x6f\165\x70\163"];
        $RB = explode("\73", $KG);
        foreach ($RB as $fL) {
            foreach ($Nq as $hA) {
                $hA = trim($hA);
                if (!(!empty($hA) && $hA == $fL)) {
                    goto Cd;
                }
                wp_die("\x59\x6f\x75\x20\x61\x72\145\x20\156\x6f\164\40\x61\165\164\x68\x6f\x72\x69\172\x65\x64\40\164\x6f\x20\x6c\x6f\147\x69\156\56\40\120\x6c\145\x61\163\x65\x20\x63\x6f\156\x74\x61\x63\164\x20\171\157\165\162\40\141\x64\x6d\x69\156\x69\x73\x74\162\x61\164\x6f\x72\x2e", "\x45\x72\x72\157\x72");
                Cd:
                sa:
            }
            Eu:
            VY:
        }
        zY:
        mf:
        sb:
        AR:
        X4:
    }
    sN:
}
function assign_roles_to_user($user, $mn, $blog_id, $Nq, $FH)
{
    $ef = false;
    if (!(!empty($Nq) && !empty($mn) && !is_administrator_user($user) && is_user_member_of_blog($user->ID, $blog_id))) {
        goto dr;
    }
    if (!empty($mn[$FH])) {
        goto Gv;
    }
    if (empty($mn["\x44\x45\x46\x41\x55\114\x54"])) {
        goto Wt;
    }
    $K4 = $mn["\x44\x45\x46\x41\x55\x4c\124"];
    Wt:
    goto p4;
    Gv:
    $K4 = $mn[$FH];
    p4:
    if (empty($K4)) {
        goto Dc;
    }
    $user->set_role(false);
    $IO = '';
    $ts = false;
    unset($K4["\144\145\x66\x61\165\154\164\x5f\162\x6f\x6c\145"]);
    unset($K4["\x64\x6f\156\164\x5f\x63\162\x65\x61\164\145\137\165\x73\x65\162"]);
    unset($K4["\144\x6f\156\164\x5f\141\154\154\x6f\x77\x5f\x75\156\x6c\x69\x73\x74\x65\x64\137\165\x73\145\x72"]);
    unset($K4["\153\x65\145\160\137\x65\x78\151\x73\x74\x69\x6e\x67\137\x75\163\x65\x72\163\x5f\x72\157\154\145"]);
    unset($K4["\155\x6f\137\x73\141\x6d\154\x5f\144\x6f\156\x74\137\141\154\x6c\x6f\x77\x5f\x75\x73\145\x72\137\164\157\x6c\x6f\147\151\156\x5f\143\x72\145\141\x74\x65\137\167\x69\164\150\x5f\x67\x69\x76\145\x6e\137\147\162\x6f\x75\x70\163"]);
    unset($K4["\x6d\x6f\137\x73\141\155\154\x5f\162\145\163\164\x72\151\x63\x74\x5f\165\x73\x65\162\163\137\x77\151\164\x68\137\x67\162\x6f\165\160\163"]);
    foreach ($K4 as $T9 => $hS) {
        $RB = explode("\x3b", $hS);
        foreach ($RB as $fL) {
            if (!(!empty($fL) && in_array($fL, $Nq))) {
                goto Jx;
            }
            $ef = true;
            $user->add_role($T9);
            Jx:
            vc:
        }
        h9:
        T3:
    }
    VZ:
    Dc:
    dr:
    $qF = get_site_option("\x6d\x6f\137\x73\141\155\154\137\x73\165\x70\x65\x72\x5f\141\x64\155\x69\156\137\x72\x6f\154\x65\137\x6d\141\x70\x70\x69\x6e\147");
    $as = array();
    if (empty($qF)) {
        goto K_;
    }
    $as = explode("\73", $qF);
    K_:
    if (!(!empty($Nq) && !empty($as))) {
        goto FS;
    }
    foreach ($as as $fL) {
        if (!in_array($fL, $Nq)) {
            goto E5;
        }
        grant_super_admin($user->ID);
        E5:
        Kz:
    }
    aJ:
    FS:
    return $ef;
}
function get_saml_roles_to_assign($mn, $blog_id, $Nq)
{
    $GT = array();
    if (!(!empty($Nq) && !empty($mn))) {
        goto d9;
    }
    if (!empty($mn[$blog_id])) {
        goto Kw;
    }
    if (empty($mn["\x44\x45\106\101\x55\114\124"])) {
        goto wX;
    }
    $K4 = $mn["\x44\105\x46\x41\x55\x4c\x54"];
    wX:
    goto s8;
    Kw:
    $K4 = $mn[$blog_id];
    s8:
    if (empty($K4)) {
        goto kq;
    }
    unset($K4["\x64\145\146\141\x75\x6c\164\137\162\x6f\154\145"]);
    unset($K4["\144\x6f\x6e\164\137\143\162\x65\x61\164\x65\137\165\163\145\162"]);
    unset($K4["\144\157\156\164\x5f\141\x6c\x6c\157\x77\137\165\x6e\x6c\151\x73\164\x65\144\x5f\165\163\145\x72"]);
    unset($K4["\153\145\145\x70\x5f\x65\x78\x69\x73\164\x69\156\147\x5f\x75\163\x65\x72\163\x5f\x72\x6f\x6c\145"]);
    unset($K4["\x6d\157\137\x73\x61\155\x6c\x5f\144\x6f\156\164\137\x61\154\x6c\x6f\167\x5f\165\x73\145\x72\137\x74\157\x6c\157\147\151\156\137\x63\162\x65\x61\x74\145\137\x77\x69\x74\150\x5f\147\x69\166\x65\156\x5f\147\162\157\165\x70\x73"]);
    unset($K4["\155\157\x5f\x73\141\x6d\x6c\x5f\162\145\163\x74\x72\x69\143\x74\137\165\163\145\162\x73\137\167\x69\x74\150\137\147\x72\157\x75\160\x73"]);
    foreach ($K4 as $T9 => $hS) {
        $RB = explode("\73", $hS);
        foreach ($RB as $fL) {
            if (!(!empty($fL) and in_array($fL, $Nq))) {
                goto w3;
            }
            array_push($GT, $T9);
            w3:
            gr:
        }
        gR:
        pU:
    }
    bP:
    kq:
    d9:
    return $GT;
}
function is_administrator_user($user)
{
    $qI = $user->roles;
    if (!is_null($qI) && in_array("\x61\x64\x6d\151\x6e\x69\x73\x74\x72\141\x74\x6f\162", $qI)) {
        goto tp;
    }
    return false;
    goto TI;
    tp:
    return true;
    TI:
}
function mo_saml_is_customer_registered()
{
    return 1;
    $X4 = get_site_option("\x6d\157\137\163\x61\155\x6c\x5f\141\144\155\x69\x6e\137\145\x6d\141\x69\x6c");
    $bD = get_site_option("\x6d\x6f\x5f\163\x61\x6d\154\137\x61\x64\155\x69\156\137\143\x75\x73\x74\157\x6d\145\162\137\x6b\x65\171");
    if (!$X4 || !$bD || !is_numeric(trim($bD))) {
        goto qS;
    }
    return 1;
    goto T2;
    qS:
    return 0;
    T2:
}
function mo_saml_is_customer_license_verified()
{
    $ON = mo_saml_get_plugin_details();
    if ($ON !== true) {
        goto uz;
    }
    return 1;
    goto Tl;
    uz:
    return 0;
    Tl:
    $q3 = get_site_option("\x6d\x6f\137\163\141\x6d\154\137\143\165\163\x74\x6f\x6d\145\162\137\164\x6f\153\145\156");
    $Pe = AESEncryption::decrypt_data(get_site_option("\x74\x5f\x73\151\164\x65\x5f\163\164\x61\x74\x75\x73"), $q3);
    $xc = get_site_option("\x73\x6d\x6c\137\x6c\153");
    $X4 = get_site_option("\x6d\157\137\x73\141\155\x6c\x5f\x61\144\x6d\x69\x6e\x5f\145\x6d\141\x69\x6c");
    $bD = get_site_option("\155\157\137\x73\141\x6d\154\x5f\141\x64\155\151\156\137\143\165\163\164\x6f\x6d\x65\162\137\153\145\171");
    $oY = AESEncryption::decrypt_data(get_site_option("\156\157\137\x73\142\163"), $q3);
    $ZM = false;
    if (!get_site_option("\x6e\x6f\137\x73\142\x73")) {
        goto jk;
    }
    $gy = Utilities::get_sites();
    $ZM = $oY < count($gy);
    jk:
    if ($Pe != "\x74\x72\165\x65" && !$xc || !$X4 || !$bD || !is_numeric(trim($bD)) || $ZM) {
        goto KT;
    }
    return 1;
    goto DI;
    KT:
    return 0;
    DI:
}
function show_status_error($Pl, $lV)
{
    if ($lV == "\164\145\x73\164\126\141\154\151\144\141\x74\x65" or $lV == "\164\145\163\x74\x4e\x65\167\x43\145\162\164\151\146\x69\x63\141\x74\145") {
        goto GZ;
    }
    wp_die("\x57\145\40\143\157\165\154\144\x20\156\x6f\164\x20\163\151\147\x6e\40\171\x6f\165\x20\151\x6e\56\40\120\x6c\145\141\163\145\40\143\157\x6e\164\141\143\164\x20\x79\157\165\162\x20\x41\x64\155\x69\156\151\x73\x74\162\141\164\157\162\56", "\105\x72\162\157\162\72\40\x49\156\x76\141\154\151\144\x20\123\101\115\114\x20\x52\x65\x73\160\x6f\156\163\x65\x20\123\164\x61\x74\x75\x73");
    goto qN;
    GZ:
    echo "\x3c\x64\x69\166\40\x73\164\x79\154\x65\x3d\42\x66\157\156\164\55\146\x61\155\x69\154\x79\x3a\103\141\154\151\142\162\151\73\160\x61\144\144\x69\156\x67\x3a\60\40\63\x25\x3b\42\76";
    echo "\74\144\151\x76\x20\x73\x74\x79\154\145\75\42\143\157\154\x6f\x72\72\40\x23\x61\x39\64\x34\64\x32\73\142\x61\143\x6b\147\162\x6f\x75\156\144\55\x63\157\154\x6f\162\x3a\x20\43\x66\62\144\145\x64\x65\73\x70\141\x64\x64\151\x6e\x67\x3a\40\x31\65\160\170\73\x6d\x61\x72\x67\x69\x6e\x2d\x62\x6f\x74\x74\157\155\72\x20\62\60\160\x78\73\x74\x65\170\x74\x2d\141\154\151\x67\156\x3a\x63\x65\156\164\145\x72\x3b\142\x6f\162\x64\145\162\72\61\160\x78\40\x73\157\154\x69\x64\x20\43\105\x36\x42\63\102\62\x3b\x66\157\x6e\x74\x2d\x73\151\x7a\145\x3a\x31\70\160\164\x3b\x22\76\x20\x45\122\122\117\122\74\57\x64\x69\x76\x3e\xd\xa\40\x20\40\x20\x20\x20\x20\40\74\144\151\166\40\x73\x74\171\x6c\145\x3d\x22\x63\x6f\154\x6f\x72\72\x20\x23\x61\71\x34\x34\64\62\x3b\x66\157\x6e\x74\x2d\x73\x69\x7a\145\72\x31\x34\160\x74\73\40\155\141\162\x67\151\156\x2d\142\157\x74\164\157\x6d\72\x32\60\x70\170\x3b\42\x3e\74\160\x3e\74\x73\x74\x72\157\156\x67\76\x45\x72\x72\x6f\162\72\40\x3c\x2f\x73\x74\x72\157\156\x67\76\x20\x49\156\x76\141\154\x69\144\x20\x53\x41\115\x4c\x20\x52\145\x73\160\x6f\x6e\163\x65\x20\x53\164\x61\x74\165\x73\56\x3c\57\160\x3e\15\xa\40\x20\40\40\40\40\40\40\40\40\x20\x20\74\x70\x3e\x3c\x73\164\x72\x6f\x6e\147\x3e\x43\141\x75\x73\x65\163\74\57\x73\x74\162\x6f\x6e\x67\76\72\x20\111\x64\x65\x6e\164\151\x74\171\x20\x50\162\x6f\x76\x69\x64\145\x72\x20\150\141\163\x20\x73\145\156\164\40\47" . esc_html($Pl) . "\47\x20\163\x74\x61\x74\x75\163\40\143\x6f\144\x65\x20\151\156\40\123\x41\115\114\x20\122\x65\x73\x70\157\x6e\163\145\56\40\74\x2f\160\x3e\15\12\40\x20\x20\40\x20\40\x20\40\x20\40\40\40\74\x70\x3e\74\x73\164\162\157\x6e\147\x3e\x52\x65\x61\x73\x6f\156\74\x2f\163\x74\x72\157\156\x67\76\72\40" . get_status_message(esc_html($Pl)) . "\74\x2f\x70\x3e\x3c\142\x72\x3e";
    if (empty($jN)) {
        goto xN;
    }
    echo "\x3c\x70\x3e\74\163\x74\162\x6f\x6e\x67\x3e\123\x74\141\x74\165\163\x20\x4d\145\x73\163\x61\147\x65\x20\151\156\40\164\x68\145\x20\123\x41\115\x4c\x20\x52\x65\163\160\157\156\163\x65\x3a\74\57\163\164\x72\157\156\x67\76\x20\74\142\x72\57\76" . esc_html($jN) . "\74\57\x70\76\x3c\142\162\x3e";
    xN:
    echo "\15\12\40\40\40\40\x20\40\40\x20\x3c\x2f\x64\151\x76\x3e\xd\xa\xd\12\x20\x20\40\40\x20\40\40\x20\74\144\x69\166\40\x73\164\171\x6c\145\x3d\42\155\141\x72\147\x69\x6e\x3a\63\45\x3b\x64\151\x73\x70\154\x61\x79\x3a\x62\x6c\x6f\143\x6b\x3b\164\x65\170\164\x2d\x61\154\151\147\x6e\x3a\x63\145\x6e\164\145\x72\x3b\x22\76\xd\xa\x20\40\x20\40\40\x20\x20\40\x20\40\x20\40\x3c\x64\151\166\x20\163\x74\171\x6c\145\x3d\42\x6d\x61\x72\147\x69\156\x3a\x33\45\x3b\x64\151\163\x70\x6c\141\171\72\142\154\157\143\x6b\73\x74\x65\x78\164\55\141\154\x69\147\x6e\72\x63\x65\x6e\x74\x65\162\x3b\42\x3e\x3c\151\156\160\165\164\x20\x73\x74\171\x6c\145\75\42\160\141\144\144\x69\156\147\x3a\x31\45\73\167\x69\144\x74\150\x3a\x31\60\60\160\x78\73\x62\141\143\x6b\147\162\x6f\165\x6e\x64\x3a\x20\x23\x30\60\x39\61\x43\104\40\156\x6f\x6e\x65\40\162\145\160\x65\141\164\x20\163\143\162\157\154\x6c\x20\60\45\x20\x30\x25\x3b\x63\165\x72\163\157\162\72\x20\160\157\x69\x6e\164\145\162\x3b\x66\x6f\x6e\164\55\163\151\172\145\72\61\x35\160\170\x3b\142\157\162\x64\145\x72\55\x77\x69\x64\164\x68\72\40\61\x70\x78\x3b\142\157\x72\144\145\162\x2d\x73\164\171\x6c\145\x3a\x20\163\x6f\154\151\x64\73\x62\x6f\x72\x64\145\x72\55\162\141\x64\x69\x75\x73\72\40\x33\160\170\x3b\167\150\x69\x74\x65\55\x73\x70\x61\143\x65\72\x20\x6e\x6f\167\162\141\x70\x3b\x62\x6f\170\x2d\163\151\172\151\156\147\x3a\40\142\157\162\144\x65\x72\55\142\x6f\x78\73\x62\x6f\162\x64\x65\x72\55\x63\x6f\154\157\162\72\40\x23\x30\x30\x37\x33\101\x41\73\x62\x6f\x78\x2d\x73\150\141\144\x6f\167\72\x20\x30\160\x78\40\x31\160\170\x20\60\160\170\x20\162\x67\142\x61\50\x31\62\60\54\x20\62\60\x30\54\x20\62\63\60\54\40\60\x2e\x36\51\x20\x69\x6e\163\145\x74\x3b\143\x6f\x6c\x6f\162\72\40\x23\106\106\106\73\42\164\171\x70\145\75\x22\x62\165\x74\x74\157\x6e\42\40\166\141\x6c\165\145\x3d\42\x44\157\156\x65\x22\40\x6f\156\103\154\151\143\x6b\75\42\x73\145\x6c\146\56\x63\154\157\163\145\50\51\73\42\x3e\74\x2f\x64\151\x76\x3e";
    exit;
    qN:
}
function addLink($Go, $hF)
{
    $FB = "\x3c\141\x20\150\x72\145\x66\75\42" . $hF . "\x22\x3e" . $Go . "\74\x2f\x61\76";
    return $FB;
}
function get_status_message($Pl)
{
    switch ($Pl) {
        case "\x52\x65\x71\165\145\163\164\145\x72":
            return "\124\150\x65\x20\x72\x65\161\165\145\x73\164\x20\x63\157\x75\x6c\144\x20\x6e\157\x74\x20\142\145\x20\160\x65\x72\x66\x6f\x72\x6d\145\144\x20\144\165\145\40\164\157\x20\x61\x6e\40\x65\162\x72\x6f\162\x20\x6f\156\40\164\x68\x65\x20\x70\x61\x72\164\x20\157\146\40\x74\150\x65\x20\162\145\161\x75\145\163\x74\145\162\x2e";
            goto F8;
        case "\122\145\x73\160\157\x6e\144\145\162":
            return "\x54\150\145\x20\162\x65\x71\165\x65\x73\x74\40\143\157\165\x6c\144\40\156\157\x74\x20\x62\x65\40\160\x65\x72\x66\157\x72\155\145\x64\40\x64\x75\145\40\x74\x6f\40\141\x6e\x20\145\x72\162\x6f\162\40\157\156\40\x74\150\x65\40\x70\141\162\164\40\157\x66\40\164\150\145\40\123\x41\x4d\114\40\x72\x65\163\x70\157\x6e\x64\145\x72\x20\x6f\162\40\123\x41\115\114\40\141\165\x74\150\x6f\162\151\x74\171\x2e";
            goto F8;
        case "\126\x65\162\x73\151\x6f\x6e\x4d\x69\163\155\141\x74\143\x68":
            return "\124\x68\145\40\123\x41\x4d\x4c\x20\x72\145\163\x70\x6f\x6e\x64\145\x72\40\x63\x6f\x75\x6c\x64\40\156\x6f\x74\x20\x70\162\157\143\x65\x73\x73\x20\164\x68\145\x20\x72\x65\161\x75\x65\x73\x74\40\x62\145\x63\141\x75\163\145\40\164\150\145\40\166\145\162\x73\x69\x6f\x6e\x20\157\x66\x20\x74\150\145\x20\x72\x65\161\x75\x65\x73\x74\x20\x6d\145\x73\163\141\x67\x65\40\167\141\163\x20\x69\156\143\x6f\162\162\145\143\x74\x2e";
            goto F8;
        default:
            return "\125\x6e\x6b\x6e\157\167\156";
    }
    Z1:
    F8:
}
function saml_get_current_page_url()
{
    $Dy = $_SERVER["\110\124\124\x50\x5f\x48\117\x53\x54"];
    if (!(substr($Dy, -1) == "\x2f")) {
        goto sR;
    }
    $Dy = substr($Dy, 0, -1);
    sR:
    $Uq = $_SERVER["\x52\x45\121\125\x45\123\124\x5f\125\122\x49"];
    if (!(substr($Uq, 0, 1) == "\57")) {
        goto M3;
    }
    $Uq = substr($Uq, 1);
    M3:
    $Dh = isset($_SERVER["\x48\124\124\x50\123"]) && strcasecmp($_SERVER["\110\124\124\120\x53"], "\157\x6e") == 0;
    $Gl = "\x68\164\x74\160" . ($Dh ? "\x73" : '') . "\x3a\57\57" . $Dy . "\57" . $Uq;
    return $Gl;
}
function get_network_site_url()
{
    $Ki = network_site_url();
    if (!(substr($Ki, -1) == "\x2f")) {
        goto VS;
    }
    $Ki = substr($Ki, 0, -1);
    VS:
    return $Ki;
}
function get_current_base_url()
{
    return sprintf("\45\163\x3a\57\x2f\45\163\57", isset($_SERVER["\110\124\x54\x50\123"]) && $_SERVER["\110\x54\x54\120\x53"] != "\x6f\146\x66" ? "\x68\x74\x74\160\x73" : "\150\x74\164\160", $_SERVER["\110\124\x54\x50\137\x48\x4f\123\x54"]);
}
add_action("\167\151\144\147\x65\164\163\137\x69\156\x69\164", function () {
    register_widget("\155\x6f\137\x6c\157\147\151\156\x5f\x77\151\144");
});
add_action("\151\x6e\151\164", "\155\x6f\137\154\x6f\x67\151\x6e\137\x76\141\x6c\x69\144\x61\x74\x65");
