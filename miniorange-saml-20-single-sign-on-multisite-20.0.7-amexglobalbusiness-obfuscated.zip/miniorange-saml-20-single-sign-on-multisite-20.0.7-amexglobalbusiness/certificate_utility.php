<?php


class CertificateUtility
{
    public static function generate_certificate($tO, $aU, $V7)
    {
        $ry = openssl_pkey_new();
        $P9 = openssl_csr_new($tO, $ry, $aU);
        $ox = openssl_csr_sign($P9, null, $ry, $V7, $aU, time());
        openssl_csr_export($P9, $ds);
        openssl_x509_export($ox, $Wd);
        openssl_pkey_export($ry, $Ud);
        Xs:
        if (!(($Y4 = openssl_error_string()) !== false)) {
            goto uo;
        }
        error_log("\x43\145\x72\164\151\146\151\x63\x61\164\145\x55\164\151\x6c\x69\x74\x79\x3a\x20\x45\162\x72\x6f\x72\x20\147\145\156\145\x72\x61\164\x69\156\147\x20\143\x65\x72\164\x69\x66\x69\x63\x61\164\145\56\x20" . $Y4);
        goto Xs;
        uo:
        $Al = array("\x70\x75\142\154\x69\x63\x5f\x6b\x65\171" => $Wd, "\x70\162\x69\x76\141\164\145\137\x6b\145\x79" => $Ud);
        return $Al;
    }
}
