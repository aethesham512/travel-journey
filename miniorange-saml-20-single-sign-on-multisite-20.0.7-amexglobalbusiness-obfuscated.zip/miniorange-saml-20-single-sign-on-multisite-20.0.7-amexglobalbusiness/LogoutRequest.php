<?php


include_once "\125\164\151\x6c\151\x74\x69\145\163\56\x70\150\160";
include_once "\170\155\154\x73\145\x63\x6c\151\x62\x73\x2e\x70\x68\160";
use RobRichards\XMLSecLibs\XMLSecurityKey;
use RobRichards\XMLSecLibs\XMLSecurityDSig;
use RobRichards\XMLSecLibs\XMLSecEnc;
class SAML2_LogoutRequest
{
    private $tagName;
    private $id;
    private $issuer;
    private $destination;
    private $issueInstant;
    private $certificates;
    private $validators;
    private $notOnOrAfter;
    private $encryptedNameId;
    private $nameId;
    private $sessionIndexes;
    public function __construct(DOMElement $O3 = NULL)
    {
        $this->tagName = "\114\x6f\147\x6f\x75\x74\122\x65\x71\x75\145\x73\164";
        $this->id = Utilities::generateID();
        $this->issueInstant = time();
        $this->certificates = array();
        $this->validators = array();
        if (!($O3 === NULL)) {
            goto LY;
        }
        return;
        LY:
        if ($O3->hasAttribute("\x49\104")) {
            goto Sc;
        }
        throw new Exception("\115\151\x73\163\151\156\147\x20\x49\104\40\x61\x74\x74\162\x69\142\x75\x74\x65\x20\x6f\x6e\x20\x53\101\115\x4c\40\155\x65\x73\163\x61\147\x65\x2e");
        Sc:
        $this->id = $O3->getAttribute("\111\104");
        if (!($O3->getAttribute("\126\x65\x72\x73\151\157\x6e") !== "\x32\x2e\x30")) {
            goto wT;
        }
        throw new Exception("\x55\156\163\x75\x70\160\157\x72\164\145\x64\x20\166\x65\162\163\x69\x6f\x6e\x3a\x20" . $O3->getAttribute("\126\x65\x72\x73\151\157\156"));
        wT:
        $this->issueInstant = Utilities::xsDateTimeToTimestamp($O3->getAttribute("\111\x73\163\165\145\x49\x6e\163\164\x61\156\164"));
        if (!$O3->hasAttribute("\104\145\163\x74\151\156\x61\x74\x69\x6f\156")) {
            goto Wn;
        }
        $this->destination = $O3->getAttribute("\x44\145\x73\x74\151\156\x61\164\x69\x6f\x6e");
        Wn:
        $pi = Utilities::xpQuery($O3, "\56\x2f\163\x61\155\x6c\137\x61\x73\x73\145\162\x74\x69\x6f\x6e\72\x49\x73\163\165\145\162");
        if (empty($pi)) {
            goto XO;
        }
        $this->issuer = trim($pi[0]->textContent);
        XO:
        try {
            $eQ = Utilities::validateElement($O3);
            if (!($eQ !== FALSE)) {
                goto i6;
            }
            $this->certificates = $eQ["\x43\145\162\164\x69\146\151\x63\x61\164\x65\163"];
            $this->validators[] = array("\106\x75\156\143\x74\151\157\156" => array("\x55\x74\x69\154\151\x74\151\145\163", "\166\141\x6c\x69\144\141\x74\145\x53\x69\147\156\141\164\165\162\x65"), "\x44\141\164\x61" => $eQ);
            i6:
        } catch (Exception $Y4) {
        }
        $this->sessionIndexes = array();
        if (!$O3->hasAttribute("\x4e\157\164\117\156\117\162\101\x66\x74\x65\x72")) {
            goto Qu;
        }
        $this->notOnOrAfter = Utilities::xsDateTimeToTimestamp($O3->getAttribute("\116\x6f\164\117\156\117\x72\x41\146\164\145\x72"));
        Qu:
        $jK = Utilities::xpQuery($O3, "\56\x2f\163\141\x6d\154\137\141\x73\163\145\162\x74\x69\x6f\156\72\x4e\x61\x6d\145\x49\104\40\x7c\x20\56\57\x73\141\155\154\137\x61\x73\x73\145\162\164\x69\x6f\156\x3a\x45\156\143\162\x79\x70\164\x65\144\x49\104\x2f\170\x65\x6e\143\72\x45\156\143\x72\171\160\164\145\x64\104\141\164\141");
        if (empty($jK)) {
            goto Y6;
        }
        if (count($jK) > 1) {
            goto Ai;
        }
        goto A_;
        Y6:
        throw new Exception("\x4d\x69\x73\x73\x69\x6e\x67\x20\74\x73\141\155\154\72\116\x61\x6d\145\111\x44\76\x20\x6f\162\40\x3c\x73\x61\155\154\x3a\x45\156\x63\x72\171\x70\x74\145\x64\x49\104\x3e\40\151\156\40\74\x73\141\155\x6c\160\x3a\x4c\x6f\147\157\165\164\x52\145\x71\165\x65\163\164\76\x2e");
        goto A_;
        Ai:
        throw new Exception("\x4d\157\162\145\x20\164\x68\x61\156\40\x6f\156\145\40\74\163\141\x6d\154\72\116\141\x6d\145\111\104\x3e\x20\157\162\x20\74\x73\141\155\154\72\105\156\143\162\171\x70\164\x65\x64\104\x3e\40\151\156\40\74\163\x61\155\154\160\x3a\114\157\x67\x6f\165\x74\122\x65\x71\x75\x65\x73\x74\76\56");
        A_:
        $jK = $jK[0];
        if ($jK->localName === "\x45\156\143\162\171\x70\x74\145\144\x44\141\164\x61") {
            goto N3;
        }
        $this->nameId = Utilities::parseNameId($jK);
        goto HZ;
        N3:
        $this->encryptedNameId = $jK;
        HZ:
        $lT = Utilities::xpQuery($O3, "\56\x2f\x73\x61\x6d\x6c\x5f\160\x72\x6f\x74\x6f\x63\157\x6c\x3a\x53\x65\x73\x73\151\x6f\x6e\111\156\x64\145\x78");
        foreach ($lT as $LF) {
            $this->sessionIndexes[] = trim($LF->textContent);
            t8:
        }
        a7:
    }
    public function getNotOnOrAfter()
    {
        return $this->notOnOrAfter;
    }
    public function setNotOnOrAfter($s6)
    {
        $this->notOnOrAfter = $s6;
    }
    public function isNameIdEncrypted()
    {
        if (!($this->encryptedNameId !== NULL)) {
            goto KD;
        }
        return TRUE;
        KD:
        return FALSE;
    }
    public function encryptNameId(XMLSecurityKey $q3)
    {
        $fT = new DOMDocument();
        $ii = $fT->createElement("\x72\x6f\157\x74");
        $fT->appendChild($ii);
        SAML2_Utils::addNameId($ii, $this->nameId);
        $jK = $ii->firstChild;
        SAML2_Utils::getContainer()->debugMessage($jK, "\145\156\143\x72\171\160\164");
        $w6 = new XMLSecEnc();
        $w6->setNode($jK);
        $w6->type = XMLSecEnc::Element;
        $HA = new XMLSecurityKey(XMLSecurityKey::AES128_CBC);
        $HA->generateSessionKey();
        $w6->encryptKey($q3, $HA);
        $this->encryptedNameId = $w6->encryptNode($HA);
        $this->nameId = NULL;
    }
    public function decryptNameId(XMLSecurityKey $q3, array $M6 = array())
    {
        if (!($this->encryptedNameId === NULL)) {
            goto dY;
        }
        return;
        dY:
        $jK = SAML2_Utils::decryptElement($this->encryptedNameId, $q3, $M6);
        SAML2_Utils::getContainer()->debugMessage($jK, "\x64\x65\143\x72\x79\160\x74");
        $this->nameId = SAML2_Utils::parseNameId($jK);
        $this->encryptedNameId = NULL;
    }
    public function getNameId()
    {
        if (!($this->encryptedNameId !== NULL)) {
            goto k2;
        }
        throw new Exception("\x41\164\164\145\155\160\164\145\144\x20\x74\157\40\162\145\164\162\x69\x65\166\145\40\145\x6e\143\162\x79\x70\164\x65\x64\x20\116\x61\155\145\111\104\x20\167\151\164\150\x6f\165\164\x20\144\145\x63\x72\171\160\x74\x69\x6e\147\x20\151\x74\40\146\x69\162\x73\164\56");
        k2:
        return $this->nameId;
    }
    public function setNameId($jK)
    {
        $this->nameId = $jK;
    }
    public function getSessionIndexes()
    {
        return $this->sessionIndexes;
    }
    public function setSessionIndexes(array $lT)
    {
        $this->sessionIndexes = $lT;
    }
    public function getSessionIndex()
    {
        if (!empty($this->sessionIndexes)) {
            goto U_;
        }
        return NULL;
        U_:
        return $this->sessionIndexes[0];
    }
    public function setSessionIndex($LF)
    {
        if (is_null($LF)) {
            goto Sk;
        }
        $this->sessionIndexes = array($LF);
        goto zR;
        Sk:
        $this->sessionIndexes = array();
        zR:
    }
    public function getId()
    {
        return $this->id;
    }
    public function setId($ni)
    {
        $this->id = $ni;
    }
    public function getIssueInstant()
    {
        return $this->issueInstant;
    }
    public function setIssueInstant($Pr)
    {
        $this->issueInstant = $Pr;
    }
    public function getDestination()
    {
        return $this->destination;
    }
    public function setDestination($gg)
    {
        $this->destination = $gg;
    }
    public function getIssuer()
    {
        return $this->issuer;
    }
    public function setIssuer($pi)
    {
        $this->issuer = $pi;
    }
}
