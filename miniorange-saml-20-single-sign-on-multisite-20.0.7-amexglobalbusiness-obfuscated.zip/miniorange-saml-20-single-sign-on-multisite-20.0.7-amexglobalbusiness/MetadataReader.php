<?php


include_once "\x55\x74\151\154\x69\164\x69\145\163\x2e\x70\150\x70";
class MetadataReader
{
    private $identityProviders;
    private $serviceProviders;
    public function __construct(DOMNode $O3 = NULL)
    {
        $this->identityProviders = array();
        $this->serviceProviders = array();
        $KW = Utilities::xpQuery($O3, "\x2e\57\x73\141\x6d\x6c\137\x6d\145\x74\x61\144\x61\164\141\72\x45\156\164\x69\164\151\145\x73\x44\145\163\x63\162\x69\160\164\157\x72");
        if (!empty($KW)) {
            goto Sn;
        }
        $Jy = Utilities::xpQuery($O3, "\x2e\57\x73\141\155\x6c\x5f\155\145\164\x61\x64\141\x74\x61\x3a\x45\x6e\164\151\x74\x79\104\x65\163\x63\162\151\160\164\x6f\162");
        goto O6;
        Sn:
        $Jy = Utilities::xpQuery($KW[0], "\x2e\57\163\141\155\x6c\137\155\x65\x74\141\x64\x61\164\x61\x3a\105\x6e\164\x69\164\171\x44\x65\163\x63\x72\x69\160\164\157\162");
        O6:
        foreach ($Jy as $xq) {
            $Lj = Utilities::xpQuery($xq, "\x2e\57\x73\141\x6d\154\137\155\145\164\141\144\x61\x74\141\x3a\x49\104\120\123\x53\x4f\104\x65\163\x63\x72\151\160\164\157\x72");
            if (!(isset($Lj) && !empty($Lj))) {
                goto Pi;
            }
            array_push($this->identityProviders, new IdentityProviders($xq));
            Pi:
            RT:
        }
        rY:
    }
    public function getIdentityProviders()
    {
        return $this->identityProviders;
    }
    public function getServiceProviders()
    {
        return $this->serviceProviders;
    }
}
class IdentityProviders
{
    private $idpName;
    private $entityID;
    private $loginDetails;
    private $logoutDetails;
    private $signingCertificate;
    private $encryptionCertificate;
    private $signedRequest;
    private $loginbinding;
    private $logoutbinding;
    public function __construct(DOMElement $O3 = NULL)
    {
        $this->idpName = '';
        $this->loginDetails = array();
        $this->logoutDetails = array();
        $this->signingCertificate = array();
        $this->encryptionCertificate = array();
        if (!$O3->hasAttribute("\145\156\x74\151\164\x79\111\x44")) {
            goto L0;
        }
        $this->entityID = $O3->getAttribute("\145\156\164\151\x74\x79\x49\104");
        L0:
        if (!$O3->hasAttribute("\127\x61\x6e\164\x41\x75\x74\150\x6e\122\x65\x71\165\145\x73\164\x73\123\x69\x67\x6e\x65\144")) {
            goto ex;
        }
        $this->signedRequest = $O3->getAttribute("\127\x61\x6e\x74\101\165\164\x68\x6e\x52\x65\161\165\x65\163\x74\x73\123\x69\147\x6e\145\144");
        ex:
        $Lj = Utilities::xpQuery($O3, "\x2e\57\163\x61\x6d\x6c\137\155\145\x74\x61\144\141\164\x61\x3a\111\x44\120\x53\123\x4f\104\145\x73\x63\x72\151\160\x74\157\x72");
        if (count($Lj) > 1) {
            goto a9;
        }
        if (empty($Lj)) {
            goto fq;
        }
        goto mi;
        a9:
        throw new Exception("\115\157\162\145\x20\164\150\141\156\x20\x6f\156\x65\x20\x3c\111\104\120\123\x53\x4f\x44\x65\163\x63\162\x69\160\164\157\162\76\x20\x69\156\40\x3c\105\x6e\x74\x69\x74\x79\x44\x65\x73\x63\162\x69\x70\x74\157\162\76\x2e");
        goto mi;
        fq:
        throw new Exception("\x4d\x69\163\x73\x69\x6e\x67\40\162\145\161\x75\151\x72\145\x64\40\x3c\x49\104\120\x53\123\x4f\x44\x65\163\143\x72\151\x70\164\157\x72\x3e\x20\151\156\40\74\105\x6e\x74\151\x74\x79\x44\145\163\143\x72\x69\x70\x74\x6f\162\x3e\56");
        mi:
        $T_ = $Lj[0];
        $lM = Utilities::xpQuery($O3, "\56\x2f\163\x61\155\x6c\137\155\x65\164\141\144\141\164\141\x3a\105\170\x74\x65\x6e\163\151\x6f\x6e\163");
        if (!$lM) {
            goto c_;
        }
        $this->parseInfo($T_);
        c_:
        $this->parseSSOService($T_);
        $this->parseSLOService($T_);
        $this->parsex509Certificate($T_);
    }
    private function parseInfo($O3)
    {
        $oD = Utilities::xpQuery($O3, "\56\x2f\155\x64\x75\151\72\125\x49\x49\156\146\157\57\155\x64\165\151\72\x44\151\163\x70\154\x61\x79\116\141\x6d\x65");
        foreach ($oD as $zd) {
            if (!($zd->hasAttribute("\170\x6d\154\x3a\154\x61\x6e\147") && $zd->getAttribute("\x78\x6d\x6c\72\x6c\x61\156\x67") == "\145\x6e")) {
                goto PX;
            }
            $this->idpName = $zd->textContent;
            PX:
            Pk:
        }
        fP:
    }
    private function parseSSOService($O3)
    {
        $jI = Utilities::xpQuery($O3, "\56\57\163\141\x6d\154\x5f\x6d\145\x74\141\x64\141\164\141\72\x53\151\x6e\x67\154\x65\x53\x69\147\156\x4f\x6e\x53\145\162\x76\x69\x63\145");
        $M5 = 0;
        foreach ($jI as $gC) {
            $Uh = str_replace("\165\x72\x6e\x3a\157\141\163\151\163\x3a\x6e\x61\155\145\163\x3a\164\x63\x3a\x53\101\x4d\114\x3a\62\56\x30\x3a\142\x69\156\x64\x69\x6e\x67\163\72", '', $gC->getAttribute("\102\151\156\144\x69\x6e\x67"));
            $this->loginDetails = array_merge($this->loginDetails, array($Uh => $gC->getAttribute("\x4c\157\x63\141\x74\151\x6f\x6e")));
            if (!($Uh == "\110\x54\124\120\x2d\x52\x65\144\x69\162\x65\x63\164")) {
                goto k_;
            }
            $M5 = 1;
            $this->loginbinding = "\110\164\x74\x70\122\x65\144\x69\162\145\143\x74";
            k_:
            Na:
        }
        IG:
        if ($M5) {
            goto Pf;
        }
        $this->loginbinding = "\110\164\164\160\x50\157\163\164";
        Pf:
    }
    private function parseSLOService($O3)
    {
        $M5 = 0;
        $Ny = Utilities::xpQuery($O3, "\x2e\57\163\141\155\x6c\137\155\145\x74\141\144\141\x74\141\x3a\x53\x69\x6e\x67\x6c\145\x4c\157\x67\157\165\164\x53\x65\162\x76\x69\x63\x65");
        foreach ($Ny as $m5) {
            $Uh = str_replace("\x75\162\156\x3a\x6f\141\163\151\163\x3a\x6e\x61\x6d\145\163\x3a\164\x63\x3a\123\x41\115\114\72\62\x2e\x30\72\x62\151\156\144\x69\x6e\147\163\x3a", '', $m5->getAttribute("\x42\x69\x6e\x64\x69\x6e\147"));
            $this->logoutDetails = array_merge($this->logoutDetails, array($Uh => $m5->getAttribute("\x4c\x6f\143\141\x74\151\x6f\156")));
            if (!($Uh == "\x48\x54\x54\120\x2d\122\145\x64\151\x72\x65\x63\164")) {
                goto Jq;
            }
            $M5 = 1;
            $this->logoutbinding = "\110\164\164\160\122\x65\x64\x69\162\145\143\164";
            Jq:
            ir:
        }
        Im:
        if (!empty($this->logoutbinding)) {
            goto W6;
        }
        $this->logoutbinding = "\110\164\164\160\x50\157\x73\164";
        W6:
    }
    private function parsex509Certificate($O3)
    {
        foreach (Utilities::xpQuery($O3, "\56\x2f\163\x61\x6d\x6c\137\155\x65\164\x61\144\141\x74\141\72\x4b\145\x79\104\145\163\143\x72\151\x70\x74\157\x72") as $HO) {
            if ($HO->hasAttribute("\165\x73\x65")) {
                goto MG;
            }
            $this->parseSigningCertificate($HO);
            goto k7;
            MG:
            if ($HO->getAttribute("\165\163\x65") == "\145\x6e\x63\x72\x79\x70\164\151\x6f\x6e") {
                goto Hl;
            }
            $this->parseSigningCertificate($HO);
            goto A6;
            Hl:
            $this->parseEncryptionCertificate($HO);
            A6:
            k7:
            Lf:
        }
        b7:
    }
    private function parseSigningCertificate($O3)
    {
        $M_ = Utilities::xpQuery($O3, "\56\x2f\x64\163\72\113\x65\x79\x49\156\x66\x6f\57\x64\x73\72\130\65\60\71\104\141\x74\141\57\144\x73\72\130\65\x30\71\103\145\162\164\151\x66\x69\x63\x61\164\x65");
        $AM = trim($M_[0]->textContent);
        $AM = str_replace(array("\15", "\xa", "\x9", "\40"), '', $AM);
        if (empty($M_)) {
            goto fJ;
        }
        array_push($this->signingCertificate, $AM);
        fJ:
    }
    private function parseEncryptionCertificate($O3)
    {
        $M_ = Utilities::xpQuery($O3, "\x2e\x2f\x64\x73\72\113\x65\171\111\x6e\146\157\57\x64\163\x3a\130\x35\x30\71\x44\141\x74\141\57\x64\163\x3a\x58\x35\x30\71\103\145\162\x74\x69\x66\151\143\141\x74\145");
        $AM = trim($M_[0]->textContent);
        $AM = str_replace(array("\15", "\xa", "\x9", "\40"), '', $AM);
        if (empty($M_)) {
            goto H2;
        }
        array_push($this->encryptionCertificate, $AM);
        H2:
    }
    public function getIdpName()
    {
        return $this->idpName;
    }
    public function getEntityID()
    {
        return $this->entityID;
    }
    public function getLoginURL($Uh)
    {
        return $this->loginDetails[$Uh];
    }
    public function getLogoutURL($Uh)
    {
        return $this->logoutDetails[$Uh];
    }
    public function getLoginDetails()
    {
        return $this->loginDetails;
    }
    public function getLogoutDetails()
    {
        return $this->logoutDetails;
    }
    public function getSigningCertificate()
    {
        return $this->signingCertificate;
    }
    public function getEncryptionCertificate()
    {
        return $this->encryptionCertificate[0];
    }
    public function isRequestSigned()
    {
        return $this->signedRequest;
    }
    public function getBindingLogin()
    {
        return $this->loginbinding;
    }
    public function getBindingLogout()
    {
        return $this->logoutbinding;
    }
}
class ServiceProviders
{
}
