<?php


if (defined("\127\x50\x49\x4e\x43")) {
    goto OC;
}
die;
OC:
