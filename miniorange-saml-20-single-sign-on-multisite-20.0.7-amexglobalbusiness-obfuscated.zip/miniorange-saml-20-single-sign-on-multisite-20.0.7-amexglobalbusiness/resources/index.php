<?php


if (defined("\127\x50\111\x4e\103")) {
    goto nGb;
}
die;
nGb:
