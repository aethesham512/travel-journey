<?php


if (defined("\x57\x50\x49\x4e\103")) {
    goto I5;
}
die;
I5:
