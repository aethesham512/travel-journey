<?php


abstract class BasicEnum
{
    private static $constCacheArray = NULL;
    public static function getConstants()
    {
        if (!(self::$constCacheArray == NULL)) {
            goto Jl;
        }
        self::$constCacheArray = array();
        Jl:
        $Zw = get_called_class();
        if (array_key_exists($Zw, self::$constCacheArray)) {
            goto u3;
        }
        $Xr = new ReflectionClass($Zw);
        self::$constCacheArray[$Zw] = $Xr->getConstants();
        u3:
        return self::$constCacheArray[$Zw];
    }
    public static function isValidName($zd, $d3 = false)
    {
        $cj = self::getConstants();
        if (!$d3) {
            goto KM;
        }
        return array_key_exists($zd, $cj);
        KM:
        $fu = array_map("\163\164\162\164\157\154\157\x77\145\x72", array_keys($cj));
        return in_array(strtolower($zd), $fu);
    }
    public static function isValidValue($nY, $d3 = true)
    {
        $W3 = array_values(self::getConstants());
        return in_array($nY, $W3, $d3);
    }
}
