<?php


namespace RobRichards\XMLSecLibs;

use DOMDocument;
use DOMElement;
use DOMNode;
use DOMXPath;
use Exception;
use RobRichards\XMLSecLibs\Utils\XPath as XPath;
class XMLSecurityDSig
{
    const XMLDSIGNS = "\x68\164\x74\x70\72\x2f\x2f\x77\x77\167\56\x77\63\x2e\x6f\162\147\x2f\62\60\60\60\57\60\71\x2f\x78\x6d\154\x64\x73\x69\147\x23";
    const SHA1 = "\150\164\164\x70\x3a\57\57\x77\167\167\56\167\63\56\x6f\162\x67\57\62\60\60\x30\x2f\x30\x39\x2f\x78\155\x6c\x64\163\151\x67\43\x73\150\x61\x31";
    const SHA256 = "\x68\164\x74\x70\72\57\x2f\167\x77\167\x2e\167\63\x2e\157\162\147\57\x32\60\x30\x31\57\60\x34\x2f\x78\x6d\154\x65\156\143\43\x73\x68\141\x32\x35\x36";
    const SHA384 = "\150\164\164\x70\x3a\57\57\167\x77\167\x2e\167\63\56\x6f\x72\147\57\x32\60\60\61\x2f\60\64\x2f\170\155\x6c\144\x73\151\147\x2d\155\x6f\x72\x65\43\x73\x68\141\x33\70\64";
    const SHA512 = "\x68\x74\164\160\72\x2f\x2f\167\x77\167\x2e\x77\x33\56\x6f\162\x67\57\x32\x30\60\x31\x2f\x30\x34\57\170\x6d\154\x65\x6e\x63\43\163\150\x61\65\61\62";
    const RIPEMD160 = "\150\164\164\x70\x3a\57\57\167\x77\x77\x2e\x77\x33\56\x6f\162\147\x2f\62\x30\x30\61\57\60\x34\57\x78\155\x6c\145\156\143\43\x72\151\160\145\x6d\x64\61\66\x30";
    const C14N = "\x68\x74\164\x70\x3a\x2f\57\x77\x77\x77\x2e\x77\63\56\157\162\x67\57\124\122\x2f\x32\60\60\x31\x2f\122\105\x43\x2d\x78\155\x6c\55\x63\x31\x34\156\55\62\x30\60\61\60\x33\61\65";
    const C14N_COMMENTS = "\150\x74\164\x70\72\x2f\x2f\167\x77\x77\56\x77\x33\56\157\x72\147\x2f\x54\122\x2f\62\60\x30\61\x2f\x52\105\103\x2d\x78\x6d\154\x2d\x63\61\x34\156\55\62\60\60\61\x30\63\61\65\43\127\151\x74\150\103\x6f\x6d\x6d\145\x6e\x74\x73";
    const EXC_C14N = "\150\164\x74\x70\x3a\x2f\x2f\167\167\x77\56\167\x33\x2e\x6f\162\147\57\62\60\x30\61\57\x31\60\57\170\155\x6c\x2d\145\x78\x63\55\143\61\64\x6e\x23";
    const EXC_C14N_COMMENTS = "\150\164\x74\160\x3a\x2f\x2f\167\167\x77\56\x77\x33\56\x6f\162\x67\x2f\62\x30\60\x31\57\x31\60\x2f\x78\155\154\x2d\145\x78\x63\x2d\143\61\x34\156\x23\127\x69\x74\150\103\157\x6d\x6d\x65\156\x74\163";
    const template = "\x3c\x64\163\72\x53\x69\147\156\141\164\165\162\145\x20\170\155\154\x6e\163\72\x64\x73\x3d\x22\150\164\164\160\x3a\57\x2f\x77\167\x77\x2e\x77\63\56\x6f\x72\x67\57\x32\x30\x30\x30\57\x30\71\x2f\170\x6d\154\144\x73\x69\x67\x23\42\x3e\xd\xa\40\x20\74\144\163\72\123\151\x67\x6e\145\144\111\x6e\146\x6f\76\xd\12\40\40\x20\40\74\144\x73\72\123\151\x67\156\141\x74\165\x72\x65\x4d\x65\164\x68\x6f\144\x20\x2f\x3e\15\xa\40\40\x3c\57\x64\x73\72\x53\x69\147\156\145\x64\111\156\146\157\76\15\12\x3c\57\x64\163\x3a\123\x69\147\x6e\x61\164\x75\162\145\x3e";
    const BASE_TEMPLATE = "\74\123\x69\x67\x6e\141\x74\165\x72\x65\x20\x78\155\x6c\156\x73\75\x22\150\x74\x74\x70\72\x2f\x2f\x77\167\167\x2e\x77\63\x2e\x6f\x72\x67\x2f\62\x30\60\x30\x2f\60\x39\57\170\155\154\144\x73\x69\147\43\42\76\15\xa\40\x20\74\123\x69\x67\x6e\145\144\111\x6e\146\157\x3e\15\12\x20\40\40\x20\74\123\151\x67\156\x61\x74\x75\162\x65\115\x65\x74\150\157\x64\x20\x2f\x3e\xd\xa\40\x20\x3c\x2f\123\151\x67\156\x65\x64\111\156\x66\157\76\15\12\x3c\x2f\123\151\x67\156\x61\x74\x75\x72\145\x3e";
    public $sigNode = null;
    public $idKeys = array();
    public $idNS = array();
    private $signedInfo = null;
    private $xPathCtx = null;
    private $canonicalMethod = null;
    private $prefix = '';
    private $searchpfx = "\x73\145\143\144\x73\x69\147";
    private $validatedNodes = null;
    public function __construct($V1 = "\144\x73")
    {
        $Ah = self::BASE_TEMPLATE;
        if (empty($V1)) {
            goto i9;
        }
        $this->prefix = $V1 . "\x3a";
        $un = array("\x3c\123", "\x3c\x2f\x53", "\170\155\x6c\x6e\163\x3d");
        $UP = array("\x3c{$V1}\x3a\123", "\74\x2f{$V1}\x3a\123", "\x78\x6d\154\156\163\72{$V1}\75");
        $Ah = str_replace($un, $UP, $Ah);
        i9:
        $EO = new DOMDocument();
        $EO->loadXML($Ah);
        $this->sigNode = $EO->documentElement;
    }
    private function resetXPathObj()
    {
        $this->xPathCtx = null;
    }
    private function getXPathObj()
    {
        if (!(empty($this->xPathCtx) && !empty($this->sigNode))) {
            goto JC;
        }
        $G1 = new DOMXPath($this->sigNode->ownerDocument);
        $G1->registerNamespace("\x73\x65\143\x64\x73\x69\147", self::XMLDSIGNS);
        $this->xPathCtx = $G1;
        JC:
        return $this->xPathCtx;
    }
    public static function generateGUID($V1 = "\160\x66\170")
    {
        $B0 = md5(uniqid(mt_rand(), true));
        $rR = $V1 . substr($B0, 0, 8) . "\x2d" . substr($B0, 8, 4) . "\x2d" . substr($B0, 12, 4) . "\55" . substr($B0, 16, 4) . "\x2d" . substr($B0, 20, 12);
        return $rR;
    }
    public static function generate_GUID($V1 = "\x70\146\170")
    {
        return self::generateGUID($V1);
    }
    public function locateSignature($Gi, $vU = 0)
    {
        if ($Gi instanceof DOMDocument) {
            goto KK;
        }
        $fT = $Gi->ownerDocument;
        goto J9;
        KK:
        $fT = $Gi;
        J9:
        if (!$fT) {
            goto Tw;
        }
        $G1 = new DOMXPath($fT);
        $G1->registerNamespace("\x73\145\143\144\x73\x69\x67", self::XMLDSIGNS);
        $an = "\x2e\57\x2f\163\145\x63\x64\163\x69\147\x3a\x53\151\x67\x6e\141\164\x75\162\x65";
        $ZD = $G1->query($an, $Gi);
        $this->sigNode = $ZD->item($vU);
        return $this->sigNode;
        Tw:
        return null;
    }
    public function createNewSignNode($zd, $nY = null)
    {
        $fT = $this->sigNode->ownerDocument;
        if (!is_null($nY)) {
            goto u8;
        }
        $y9 = $fT->createElementNS(self::XMLDSIGNS, $this->prefix . $zd);
        goto Hs;
        u8:
        $y9 = $fT->createElementNS(self::XMLDSIGNS, $this->prefix . $zd, $nY);
        Hs:
        return $y9;
    }
    public function setCanonicalMethod($uS)
    {
        switch ($uS) {
            case "\150\x74\x74\160\72\x2f\x2f\167\167\x77\56\167\x33\x2e\x6f\x72\x67\x2f\124\122\57\62\x30\x30\x31\57\x52\x45\103\x2d\170\155\154\x2d\143\x31\64\x6e\x2d\62\60\x30\61\x30\63\x31\65":
            case "\x68\164\x74\x70\x3a\57\57\167\x77\167\x2e\167\63\x2e\x6f\162\147\x2f\x54\x52\57\62\x30\60\x31\57\x52\105\x43\55\x78\x6d\154\55\143\x31\x34\x6e\55\x32\x30\60\61\60\63\61\65\x23\x57\151\164\x68\103\x6f\x6d\155\145\x6e\x74\x73":
            case "\x68\x74\x74\x70\72\57\x2f\167\x77\x77\56\x77\x33\x2e\x6f\162\147\57\x32\60\x30\61\57\61\x30\57\170\155\x6c\55\x65\x78\143\55\x63\x31\64\x6e\43":
            case "\150\164\x74\160\x3a\x2f\x2f\167\167\x77\x2e\167\x33\x2e\x6f\162\147\57\x32\60\x30\61\57\61\60\x2f\x78\x6d\x6c\x2d\145\x78\x63\55\143\x31\64\156\x23\x57\151\164\x68\x43\157\155\x6d\x65\156\164\163":
                $this->canonicalMethod = $uS;
                goto zk;
            default:
                throw new Exception("\111\x6e\x76\141\x6c\151\144\x20\x43\x61\156\x6f\156\x69\143\141\x6c\40\x4d\145\x74\x68\157\144");
        }
        C7:
        zk:
        if (!($G1 = $this->getXPathObj())) {
            goto FX;
        }
        $an = "\56\57" . $this->searchpfx . "\72\123\151\x67\156\x65\x64\111\x6e\146\x6f";
        $ZD = $G1->query($an, $this->sigNode);
        if (!($XX = $ZD->item(0))) {
            goto fG;
        }
        $an = "\56\57" . $this->searchpfx . "\x43\141\156\x6f\156\151\143\141\x6c\x69\x7a\141\164\151\157\156\x4d\145\164\150\x6f\x64";
        $ZD = $G1->query($an, $XX);
        if ($XB = $ZD->item(0)) {
            goto wQ;
        }
        $XB = $this->createNewSignNode("\x43\x61\x6e\157\x6e\x69\x63\141\154\x69\172\141\164\151\157\156\x4d\145\164\150\157\x64");
        $XX->insertBefore($XB, $XX->firstChild);
        wQ:
        $XB->setAttribute("\101\x6c\x67\157\x72\151\x74\x68\155", $this->canonicalMethod);
        fG:
        FX:
    }
    private function canonicalizeData($y9, $oa, $gx = null, $Hk = null)
    {
        $lR = false;
        $xI = false;
        switch ($oa) {
            case "\150\164\164\x70\72\x2f\x2f\167\x77\x77\x2e\x77\63\56\x6f\x72\147\x2f\124\122\x2f\62\60\60\61\x2f\x52\x45\x43\55\170\155\154\55\x63\61\64\x6e\55\x32\x30\60\61\x30\x33\61\x35":
                $lR = false;
                $xI = false;
                goto se;
            case "\x68\x74\164\160\72\x2f\57\x77\167\167\56\167\x33\56\x6f\162\147\57\x54\x52\x2f\62\60\x30\61\x2f\x52\105\x43\55\170\155\154\55\143\x31\x34\x6e\55\x32\60\x30\x31\x30\x33\x31\x35\43\127\151\x74\150\x43\157\x6d\x6d\x65\x6e\164\x73":
                $xI = true;
                goto se;
            case "\x68\164\164\x70\72\57\x2f\x77\167\167\x2e\x77\x33\x2e\157\162\x67\57\x32\60\x30\x31\57\x31\60\x2f\x78\155\154\x2d\145\170\x63\x2d\143\x31\64\x6e\x23":
                $lR = true;
                goto se;
            case "\150\x74\164\x70\x3a\57\x2f\167\x77\x77\56\167\x33\56\x6f\162\147\57\62\60\60\x31\57\x31\60\x2f\170\155\154\x2d\x65\x78\x63\x2d\x63\61\64\156\43\127\151\164\x68\x43\x6f\155\155\x65\156\x74\163":
                $lR = true;
                $xI = true;
                goto se;
        }
        jc:
        se:
        if (!(is_null($gx) && $y9 instanceof DOMNode && $y9->ownerDocument !== null && $y9->isSameNode($y9->ownerDocument->documentElement))) {
            goto iI;
        }
        $OA = $y9;
        EL:
        if (!($Ck = $OA->previousSibling)) {
            goto mn;
        }
        if (!($Ck->nodeType == XML_PI_NODE || $Ck->nodeType == XML_COMMENT_NODE && $xI)) {
            goto WY;
        }
        goto mn;
        WY:
        $OA = $Ck;
        goto EL;
        mn:
        if (!($Ck == null)) {
            goto Mi;
        }
        $y9 = $y9->ownerDocument;
        Mi:
        iI:
        return $y9->C14N($lR, $xI, $gx, $Hk);
    }
    public function canonicalizeSignedInfo()
    {
        $fT = $this->sigNode->ownerDocument;
        $oa = null;
        if (!$fT) {
            goto JZ;
        }
        $G1 = $this->getXPathObj();
        $an = "\x2e\57\x73\145\143\x64\x73\x69\x67\x3a\x53\151\x67\x6e\x65\x64\111\156\146\157";
        $ZD = $G1->query($an, $this->sigNode);
        if (!($IZ = $ZD->item(0))) {
            goto ay;
        }
        $an = "\x2e\57\163\145\x63\144\163\151\x67\72\x43\141\x6e\x6f\156\151\143\141\154\x69\172\x61\164\x69\157\156\115\x65\164\150\157\x64";
        $ZD = $G1->query($an, $IZ);
        if (!($XB = $ZD->item(0))) {
            goto q6;
        }
        $oa = $XB->getAttribute("\x41\154\147\x6f\162\151\164\150\x6d");
        q6:
        $this->signedInfo = $this->canonicalizeData($IZ, $oa);
        return $this->signedInfo;
        ay:
        JZ:
        return null;
    }
    public function calculateDigest($zo, $uG, $Bo = true)
    {
        switch ($zo) {
            case self::SHA1:
                $Vg = "\163\150\x61\x31";
                goto Pl;
            case self::SHA256:
                $Vg = "\163\x68\141\x32\x35\66";
                goto Pl;
            case self::SHA384:
                $Vg = "\163\x68\x61\x33\70\x34";
                goto Pl;
            case self::SHA512:
                $Vg = "\163\x68\x61\65\61\62";
                goto Pl;
            case self::RIPEMD160:
                $Vg = "\x72\151\x70\145\x6d\144\61\x36\x30";
                goto Pl;
            default:
                throw new Exception("\103\x61\x6e\x6e\x6f\x74\x20\166\x61\154\x69\144\141\x74\x65\40\x64\151\147\145\x73\x74\x3a\x20\x55\156\x73\x75\160\x70\x6f\x72\164\x65\x64\40\101\x6c\147\157\162\151\164\150\x6d\40\x3c{$zo}\76");
        }
        qc:
        Pl:
        $BC = hash($Vg, $uG, true);
        if (!$Bo) {
            goto oK;
        }
        $BC = base64_encode($BC);
        oK:
        return $BC;
    }
    public function validateDigest($fk, $uG)
    {
        $G1 = new DOMXPath($fk->ownerDocument);
        $G1->registerNamespace("\x73\x65\143\144\x73\x69\x67", self::XMLDSIGNS);
        $an = "\163\164\162\151\156\147\x28\x2e\57\x73\145\x63\144\x73\x69\x67\72\x44\151\147\145\x73\x74\x4d\145\164\x68\157\x64\x2f\100\101\x6c\147\x6f\162\151\x74\x68\x6d\x29";
        $zo = $G1->evaluate($an, $fk);
        $cX = $this->calculateDigest($zo, $uG, false);
        $an = "\x73\x74\162\x69\x6e\147\x28\x2e\x2f\x73\x65\143\144\163\x69\x67\x3a\x44\x69\147\x65\x73\164\x56\x61\x6c\x75\145\x29";
        $SI = $G1->evaluate($an, $fk);
        return $cX === base64_decode($SI);
    }
    public function processTransforms($fk, $rU, $pN = true)
    {
        $uG = $rU;
        $G1 = new DOMXPath($fk->ownerDocument);
        $G1->registerNamespace("\163\x65\143\144\x73\151\147", self::XMLDSIGNS);
        $an = "\56\x2f\163\145\x63\x64\163\151\x67\72\124\162\x61\x6e\163\x66\x6f\162\155\163\x2f\163\x65\x63\144\163\151\147\72\124\162\141\156\163\146\x6f\162\155";
        $GB = $G1->query($an, $fk);
        $KJ = "\150\x74\x74\160\x3a\57\x2f\x77\167\x77\x2e\167\63\56\x6f\x72\x67\x2f\124\122\x2f\62\x30\x30\x31\57\122\x45\x43\55\170\x6d\154\x2d\x63\61\64\156\55\62\x30\x30\61\x30\63\61\65";
        $gx = null;
        $Hk = null;
        foreach ($GB as $FG) {
            $cM = $FG->getAttribute("\101\154\x67\x6f\x72\151\164\x68\155");
            switch ($cM) {
                case "\x68\164\164\x70\x3a\x2f\57\x77\167\x77\x2e\167\x33\x2e\x6f\162\147\57\62\x30\x30\61\x2f\61\x30\57\x78\x6d\154\x2d\x65\170\143\x2d\x63\61\64\x6e\x23":
                case "\x68\x74\164\160\72\57\x2f\x77\x77\167\56\x77\x33\x2e\157\162\x67\x2f\62\x30\60\x31\57\x31\60\x2f\x78\x6d\154\55\x65\170\143\55\x63\61\64\156\43\x57\x69\164\x68\103\x6f\155\x6d\x65\156\x74\x73":
                    if (!$pN) {
                        goto L7;
                    }
                    $KJ = $cM;
                    goto nm;
                    L7:
                    $KJ = "\x68\x74\x74\x70\72\57\x2f\167\167\167\56\167\63\56\x6f\162\x67\57\62\x30\x30\x31\x2f\61\60\57\x78\x6d\154\x2d\145\x78\x63\55\x63\61\64\x6e\x23";
                    nm:
                    $y9 = $FG->firstChild;
                    qr:
                    if (!$y9) {
                        goto yP;
                    }
                    if (!($y9->localName == "\x49\x6e\x63\154\x75\163\151\166\x65\x4e\x61\x6d\145\x73\160\141\x63\145\163")) {
                        goto Zl;
                    }
                    if (!($HU = $y9->getAttribute("\x50\162\145\x66\x69\170\x4c\151\x73\x74"))) {
                        goto Hj;
                    }
                    $at = array();
                    $mt = explode("\40", $HU);
                    foreach ($mt as $HU) {
                        $uN = trim($HU);
                        if (empty($uN)) {
                            goto V0;
                        }
                        $at[] = $uN;
                        V0:
                        qQ:
                    }
                    th:
                    if (!(count($at) > 0)) {
                        goto DE;
                    }
                    $Hk = $at;
                    DE:
                    Hj:
                    goto yP;
                    Zl:
                    $y9 = $y9->nextSibling;
                    goto qr;
                    yP:
                    goto OB;
                case "\x68\164\164\160\x3a\57\57\167\167\x77\x2e\167\x33\x2e\x6f\162\147\57\124\122\57\x32\60\60\x31\57\122\x45\x43\x2d\170\x6d\154\x2d\143\61\x34\x6e\x2d\62\60\60\61\60\63\x31\65":
                case "\x68\x74\x74\160\x3a\x2f\57\x77\x77\167\x2e\167\63\56\x6f\x72\147\57\124\122\x2f\62\x30\60\x31\x2f\x52\105\x43\x2d\170\x6d\154\x2d\143\x31\x34\x6e\x2d\x32\x30\x30\x31\60\x33\61\x35\x23\x57\151\164\150\103\157\x6d\x6d\145\x6e\164\x73":
                    if (!$pN) {
                        goto OD;
                    }
                    $KJ = $cM;
                    goto Bs;
                    OD:
                    $KJ = "\x68\164\x74\x70\x3a\57\57\167\167\167\56\167\63\x2e\x6f\162\147\57\x54\122\57\x32\x30\60\x31\57\x52\x45\x43\x2d\x78\x6d\154\55\x63\61\x34\x6e\55\62\60\60\61\x30\x33\61\x35";
                    Bs:
                    goto OB;
                case "\150\164\164\x70\x3a\57\x2f\x77\167\167\56\x77\x33\x2e\157\x72\x67\57\124\x52\x2f\61\x39\x39\x39\x2f\x52\105\103\x2d\170\160\141\x74\x68\x2d\61\x39\71\71\x31\61\x31\66":
                    $y9 = $FG->firstChild;
                    Pz:
                    if (!$y9) {
                        goto Dk;
                    }
                    if (!($y9->localName == "\130\x50\x61\x74\x68")) {
                        goto Ma;
                    }
                    $gx = array();
                    $gx["\161\165\x65\x72\171"] = "\50\x2e\57\x2f\56\40\x7c\x20\56\x2f\57\x40\52\x20\x7c\x20\56\x2f\57\x6e\x61\x6d\145\163\160\141\x63\x65\x3a\x3a\52\51\133" . $y9->nodeValue . "\x5d";
                    $BU["\156\141\x6d\x65\x73\160\x61\x63\x65\x73"] = array();
                    $XM = $G1->query("\x2e\x2f\156\141\155\x65\163\x70\x61\143\145\72\x3a\52", $y9);
                    foreach ($XM as $em) {
                        if (!($em->localName != "\170\155\x6c")) {
                            goto R7;
                        }
                        $gx["\x6e\x61\155\x65\x73\x70\x61\x63\145\163"][$em->localName] = $em->nodeValue;
                        R7:
                        VB:
                    }
                    aI:
                    goto Dk;
                    Ma:
                    $y9 = $y9->nextSibling;
                    goto Pz;
                    Dk:
                    goto OB;
            }
            Ip:
            OB:
            cA:
        }
        Ht:
        if (!$uG instanceof DOMNode) {
            goto Py;
        }
        $uG = $this->canonicalizeData($rU, $KJ, $gx, $Hk);
        Py:
        return $uG;
    }
    public function processRefNode($fk)
    {
        $PU = null;
        $pN = true;
        if ($R_ = $fk->getAttribute("\x55\x52\111")) {
            goto C_;
        }
        $pN = false;
        $PU = $fk->ownerDocument;
        goto vG;
        C_:
        $Dm = parse_url($R_);
        if (!empty($Dm["\160\141\x74\x68"])) {
            goto WB;
        }
        if ($Lw = $Dm["\x66\x72\x61\x67\x6d\145\x6e\164"]) {
            goto Q_;
        }
        $PU = $fk->ownerDocument;
        goto aD;
        Q_:
        $pN = false;
        $I9 = new DOMXPath($fk->ownerDocument);
        if (!($this->idNS && is_array($this->idNS))) {
            goto Gy;
        }
        foreach ($this->idNS as $og => $xh) {
            $I9->registerNamespace($og, $xh);
            Z0:
        }
        h5:
        Gy:
        $NQ = "\x40\x49\x64\x3d\x22" . XPath::filterAttrValue($Lw, XPath::DOUBLE_QUOTE) . "\x22";
        if (!is_array($this->idKeys)) {
            goto hq;
        }
        foreach ($this->idKeys as $jH) {
            $NQ .= "\40\x6f\162\x20\100" . XPath::filterAttrName($jH) . "\x3d\42" . XPath::filterAttrValue($Lw, XPath::DOUBLE_QUOTE) . "\42";
            Dq:
        }
        OV:
        hq:
        $an = "\57\57\x2a\x5b" . $NQ . "\135";
        $PU = $I9->query($an)->item(0);
        aD:
        WB:
        vG:
        $uG = $this->processTransforms($fk, $PU, $pN);
        if ($this->validateDigest($fk, $uG)) {
            goto jd;
        }
        return false;
        jd:
        if (!$PU instanceof DOMNode) {
            goto yQ;
        }
        if (!empty($Lw)) {
            goto Qn;
        }
        $this->validatedNodes[] = $PU;
        goto Fh;
        Qn:
        $this->validatedNodes[$Lw] = $PU;
        Fh:
        yQ:
        return true;
    }
    public function getRefNodeID($fk)
    {
        if (!($R_ = $fk->getAttribute("\x55\122\111"))) {
            goto qL;
        }
        $Dm = parse_url($R_);
        if (!empty($Dm["\160\x61\x74\150"])) {
            goto yF;
        }
        if (!($Lw = $Dm["\146\x72\x61\147\155\145\x6e\164"])) {
            goto ci;
        }
        return $Lw;
        ci:
        yF:
        qL:
        return null;
    }
    public function getRefIDs()
    {
        $vD = array();
        $G1 = $this->getXPathObj();
        $an = "\x2e\x2f\x73\145\143\x64\x73\x69\147\72\123\x69\147\x6e\x65\144\x49\x6e\x66\157\x2f\163\145\143\144\x73\151\x67\x3a\x52\x65\x66\145\162\x65\156\x63\x65";
        $ZD = $G1->query($an, $this->sigNode);
        if (!($ZD->length == 0)) {
            goto gi;
        }
        throw new Exception("\x52\x65\x66\145\162\x65\156\143\x65\40\156\x6f\x64\145\163\x20\x6e\x6f\x74\x20\x66\x6f\x75\x6e\144");
        gi:
        foreach ($ZD as $fk) {
            $vD[] = $this->getRefNodeID($fk);
            OO:
        }
        o_:
        return $vD;
    }
    public function validateReference()
    {
        $nU = $this->sigNode->ownerDocument->documentElement;
        if ($nU->isSameNode($this->sigNode)) {
            goto sV;
        }
        if (!($this->sigNode->parentNode != null)) {
            goto zd;
        }
        $this->sigNode->parentNode->removeChild($this->sigNode);
        zd:
        sV:
        $G1 = $this->getXPathObj();
        $an = "\56\x2f\163\x65\x63\144\x73\151\x67\x3a\123\151\147\x6e\x65\x64\x49\x6e\146\x6f\x2f\x73\145\143\144\x73\x69\x67\72\x52\x65\146\x65\162\145\156\143\145";
        $ZD = $G1->query($an, $this->sigNode);
        if (!($ZD->length == 0)) {
            goto bs;
        }
        throw new Exception("\x52\x65\x66\145\x72\145\156\x63\x65\x20\156\x6f\144\x65\x73\x20\156\157\x74\40\x66\x6f\165\x6e\x64");
        bs:
        $this->validatedNodes = array();
        foreach ($ZD as $fk) {
            if ($this->processRefNode($fk)) {
                goto Vj;
            }
            $this->validatedNodes = null;
            throw new Exception("\x52\145\146\x65\162\x65\x6e\x63\145\40\x76\x61\154\151\x64\x61\x74\151\x6f\x6e\40\146\x61\151\154\x65\144");
            Vj:
            pA:
        }
        fb:
        return true;
    }
    private function addRefInternal($Kr, $y9, $cM, $fe = null, $Eb = null)
    {
        $V1 = null;
        $E5 = null;
        $XT = "\111\x64";
        $MU = true;
        $bW = false;
        if (!is_array($Eb)) {
            goto Oq;
        }
        $V1 = empty($Eb["\x70\x72\x65\146\151\x78"]) ? null : $Eb["\160\162\145\x66\151\170"];
        $E5 = empty($Eb["\160\162\x65\146\x69\170\137\156\163"]) ? null : $Eb["\160\162\145\146\151\170\137\156\163"];
        $XT = empty($Eb["\151\144\137\x6e\x61\x6d\x65"]) ? "\111\144" : $Eb["\x69\x64\x5f\x6e\x61\x6d\145"];
        $MU = !isset($Eb["\x6f\166\145\162\x77\162\x69\164\x65"]) ? true : (bool) $Eb["\x6f\166\x65\x72\x77\162\x69\x74\145"];
        $bW = !isset($Eb["\146\157\162\143\x65\x5f\x75\x72\151"]) ? false : (bool) $Eb["\x66\x6f\162\x63\x65\137\165\162\151"];
        Oq:
        $TY = $XT;
        if (empty($V1)) {
            goto n2;
        }
        $TY = $V1 . "\72" . $TY;
        n2:
        $fk = $this->createNewSignNode("\122\x65\146\x65\162\x65\x6e\143\x65");
        $Kr->appendChild($fk);
        if (!$y9 instanceof DOMDocument) {
            goto t0;
        }
        if ($bW) {
            goto tu;
        }
        goto Gs;
        t0:
        $R_ = null;
        if ($MU) {
            goto Ua;
        }
        $R_ = $E5 ? $y9->getAttributeNS($E5, $XT) : $y9->getAttribute($XT);
        Ua:
        if (!empty($R_)) {
            goto Qo;
        }
        $R_ = self::generateGUID();
        $y9->setAttributeNS($E5, $TY, $R_);
        Qo:
        $fk->setAttribute("\125\x52\111", "\x23" . $R_);
        goto Gs;
        tu:
        $fk->setAttribute("\125\122\111", '');
        Gs:
        $jm = $this->createNewSignNode("\124\x72\x61\x6e\163\146\x6f\x72\x6d\x73");
        $fk->appendChild($jm);
        if (is_array($fe)) {
            goto J3;
        }
        if (!empty($this->canonicalMethod)) {
            goto bI;
        }
        goto MM;
        J3:
        foreach ($fe as $FG) {
            $Si = $this->createNewSignNode("\x54\162\141\156\163\146\x6f\162\x6d");
            $jm->appendChild($Si);
            if (is_array($FG) && !empty($FG["\150\164\164\x70\72\57\57\x77\167\x77\56\167\63\x2e\157\x72\147\57\x54\x52\57\x31\71\x39\x39\57\x52\x45\x43\55\x78\160\141\x74\x68\55\x31\71\71\71\x31\x31\x31\66"]) && !empty($FG["\x68\x74\164\160\72\57\x2f\167\x77\167\x2e\167\x33\56\157\x72\x67\57\x54\x52\x2f\x31\x39\71\x39\57\x52\105\103\x2d\x78\x70\x61\x74\150\55\x31\x39\71\71\x31\61\61\66"]["\x71\x75\145\162\171"])) {
                goto rz;
            }
            $Si->setAttribute("\x41\154\147\157\x72\151\x74\x68\x6d", $FG);
            goto pF;
            rz:
            $Si->setAttribute("\101\154\x67\x6f\162\151\164\x68\155", "\x68\x74\x74\x70\x3a\57\57\167\x77\167\x2e\x77\63\x2e\157\x72\147\x2f\x54\x52\x2f\x31\x39\x39\71\x2f\x52\x45\x43\x2d\x78\x70\x61\164\150\55\x31\71\x39\71\x31\61\x31\x36");
            $ou = $this->createNewSignNode("\x58\120\x61\164\x68", $FG["\150\x74\x74\x70\x3a\57\57\x77\167\167\x2e\167\63\56\x6f\x72\147\x2f\x54\x52\57\x31\71\x39\x39\x2f\122\105\103\55\170\160\x61\x74\x68\x2d\x31\x39\71\x39\61\x31\x31\x36"]["\161\x75\x65\x72\171"]);
            $Si->appendChild($ou);
            if (empty($FG["\150\164\164\x70\72\57\57\167\167\167\x2e\167\x33\56\x6f\162\x67\57\x54\122\x2f\x31\x39\71\x39\57\x52\105\103\x2d\x78\x70\x61\x74\x68\x2d\x31\71\x39\71\x31\61\x31\x36"]["\156\141\x6d\x65\163\x70\141\143\145\163"])) {
                goto AH;
            }
            foreach ($FG["\150\x74\164\x70\72\x2f\57\x77\x77\167\56\x77\x33\x2e\157\x72\147\x2f\x54\x52\x2f\61\71\71\x39\57\122\x45\103\x2d\x78\x70\141\x74\x68\x2d\61\x39\x39\x39\x31\61\x31\66"]["\x6e\x61\x6d\x65\163\160\x61\x63\x65\x73"] as $V1 => $Qh) {
                $ou->setAttributeNS("\x68\164\x74\x70\72\57\57\167\x77\167\x2e\167\63\56\157\x72\x67\x2f\x32\x30\x30\60\57\x78\155\154\x6e\x73\57", "\170\155\154\156\163\72{$V1}", $Qh);
                eB:
            }
            Oc:
            AH:
            pF:
            kX:
        }
        ub:
        goto MM;
        bI:
        $Si = $this->createNewSignNode("\124\162\x61\156\x73\x66\x6f\162\x6d");
        $jm->appendChild($Si);
        $Si->setAttribute("\x41\x6c\x67\157\162\151\x74\x68\x6d", $this->canonicalMethod);
        MM:
        $OI = $this->processTransforms($fk, $y9);
        $cX = $this->calculateDigest($cM, $OI);
        $ur = $this->createNewSignNode("\104\x69\147\x65\163\x74\115\x65\x74\x68\157\144");
        $fk->appendChild($ur);
        $ur->setAttribute("\101\x6c\147\x6f\162\151\x74\x68\155", $cM);
        $SI = $this->createNewSignNode("\104\x69\147\x65\163\x74\x56\x61\154\165\x65", $cX);
        $fk->appendChild($SI);
    }
    public function addReference($y9, $cM, $fe = null, $Eb = null)
    {
        if (!($G1 = $this->getXPathObj())) {
            goto LW;
        }
        $an = "\x2e\x2f\163\x65\x63\x64\x73\151\x67\x3a\123\151\147\x6e\145\144\x49\x6e\146\x6f";
        $ZD = $G1->query($an, $this->sigNode);
        if (!($pK = $ZD->item(0))) {
            goto Xj;
        }
        $this->addRefInternal($pK, $y9, $cM, $fe, $Eb);
        Xj:
        LW:
    }
    public function addReferenceList($vs, $cM, $fe = null, $Eb = null)
    {
        if (!($G1 = $this->getXPathObj())) {
            goto mP;
        }
        $an = "\x2e\57\163\x65\143\x64\163\151\147\x3a\x53\x69\x67\156\x65\x64\x49\x6e\x66\157";
        $ZD = $G1->query($an, $this->sigNode);
        if (!($pK = $ZD->item(0))) {
            goto gj;
        }
        foreach ($vs as $y9) {
            $this->addRefInternal($pK, $y9, $cM, $fe, $Eb);
            V_:
        }
        YU:
        gj:
        mP:
    }
    public function addObject($uG, $x_ = null, $RA = null)
    {
        $Mq = $this->createNewSignNode("\117\x62\x6a\145\x63\x74");
        $this->sigNode->appendChild($Mq);
        if (empty($x_)) {
            goto FM;
        }
        $Mq->setAttribute("\x4d\151\x6d\145\124\x79\x70\x65", $x_);
        FM:
        if (empty($RA)) {
            goto DB;
        }
        $Mq->setAttribute("\105\156\x63\x6f\144\x69\x6e\x67", $RA);
        DB:
        if ($uG instanceof DOMElement) {
            goto CF;
        }
        $Iw = $this->sigNode->ownerDocument->createTextNode($uG);
        goto nt;
        CF:
        $Iw = $this->sigNode->ownerDocument->importNode($uG, true);
        nt:
        $Mq->appendChild($Iw);
        return $Mq;
    }
    public function locateKey($y9 = null)
    {
        if (!empty($y9)) {
            goto nN;
        }
        $y9 = $this->sigNode;
        nN:
        if ($y9 instanceof DOMNode) {
            goto Gi;
        }
        return null;
        Gi:
        if (!($fT = $y9->ownerDocument)) {
            goto t2;
        }
        $G1 = new DOMXPath($fT);
        $G1->registerNamespace("\x73\x65\143\x64\x73\x69\x67", self::XMLDSIGNS);
        $an = "\x73\164\162\151\x6e\x67\50\x2e\x2f\x73\145\x63\x64\x73\x69\x67\x3a\x53\151\147\156\x65\x64\111\156\146\157\x2f\x73\145\143\x64\163\x69\x67\x3a\x53\x69\147\x6e\x61\x74\165\162\145\115\145\x74\x68\157\144\x2f\x40\101\154\x67\x6f\162\151\x74\x68\x6d\51";
        $cM = $G1->evaluate($an, $y9);
        if (!$cM) {
            goto lc;
        }
        try {
            $Ig = new XMLSecurityKey($cM, array("\x74\x79\x70\x65" => "\160\x75\142\x6c\151\143"));
        } catch (Exception $Y4) {
            return null;
        }
        return $Ig;
        lc:
        t2:
        return null;
    }
    public function verify($Ig)
    {
        $fT = $this->sigNode->ownerDocument;
        $G1 = new DOMXPath($fT);
        $G1->registerNamespace("\x73\x65\x63\144\x73\x69\147", self::XMLDSIGNS);
        $an = "\163\164\x72\x69\x6e\x67\x28\56\x2f\x73\145\x63\x64\163\151\147\72\123\x69\x67\x6e\x61\x74\165\x72\145\126\141\x6c\165\x65\51";
        $Oe = $G1->evaluate($an, $this->sigNode);
        if (!empty($Oe)) {
            goto vA;
        }
        throw new Exception("\125\x6e\141\x62\154\x65\x20\x74\157\40\154\157\143\141\x74\145\x20\x53\x69\147\156\141\x74\165\x72\x65\x56\x61\x6c\165\x65");
        vA:
        return $Ig->verifySignature($this->signedInfo, base64_decode($Oe));
    }
    public function signData($Ig, $uG)
    {
        return $Ig->signData($uG);
    }
    public function sign($Ig, $nP = null)
    {
        if (!($nP != null)) {
            goto oV;
        }
        $this->resetXPathObj();
        $this->appendSignature($nP);
        $this->sigNode = $nP->lastChild;
        oV:
        if (!($G1 = $this->getXPathObj())) {
            goto Ff;
        }
        $an = "\56\x2f\x73\x65\x63\144\163\151\147\x3a\x53\151\x67\156\x65\144\x49\156\x66\x6f";
        $ZD = $G1->query($an, $this->sigNode);
        if (!($pK = $ZD->item(0))) {
            goto ow;
        }
        $an = "\56\x2f\x73\145\x63\x64\x73\151\147\x3a\x53\x69\x67\156\141\x74\165\162\145\115\x65\164\x68\157\x64";
        $ZD = $G1->query($an, $pK);
        $ZR = $ZD->item(0);
        $ZR->setAttribute("\101\x6c\147\x6f\162\151\164\x68\x6d", $Ig->type);
        $uG = $this->canonicalizeData($pK, $this->canonicalMethod);
        $Oe = base64_encode($this->signData($Ig, $uG));
        $ah = $this->createNewSignNode("\x53\x69\x67\x6e\141\x74\x75\162\x65\x56\141\x6c\x75\145", $Oe);
        if ($Hi = $pK->nextSibling) {
            goto eN;
        }
        $this->sigNode->appendChild($ah);
        goto wi;
        eN:
        $Hi->parentNode->insertBefore($ah, $Hi);
        wi:
        ow:
        Ff:
    }
    public function appendCert()
    {
    }
    public function appendKey($Ig, $Sg = null)
    {
        $Ig->serializeKey($Sg);
    }
    public function insertSignature($y9, $al = null)
    {
        $i1 = $y9->ownerDocument;
        $iQ = $i1->importNode($this->sigNode, true);
        if ($al == null) {
            goto GN;
        }
        return $y9->insertBefore($iQ, $al);
        goto nb;
        GN:
        return $y9->insertBefore($iQ);
        nb:
    }
    public function appendSignature($n_, $Nd = false)
    {
        $al = $Nd ? $n_->firstChild : null;
        return $this->insertSignature($n_, $al);
    }
    public static function get509XCert($E6, $f4 = true)
    {
        $I7 = self::staticGet509XCerts($E6, $f4);
        if (empty($I7)) {
            goto Vg;
        }
        return $I7[0];
        Vg:
        return '';
    }
    public static function staticGet509XCerts($I7, $f4 = true)
    {
        if ($f4) {
            goto fC;
        }
        return array($I7);
        goto kB;
        fC:
        $uG = '';
        $sG = array();
        $CH = explode("\xa", $I7);
        $VT = false;
        foreach ($CH as $Ab) {
            if (!$VT) {
                goto Rt;
            }
            if (!(strncmp($Ab, "\x2d\55\x2d\x2d\55\105\x4e\x44\40\103\105\122\x54\111\106\x49\x43\101\124\105", 20) == 0)) {
                goto Re;
            }
            $VT = false;
            $sG[] = $uG;
            $uG = '';
            goto pa;
            Re:
            $uG .= trim($Ab);
            goto VA;
            Rt:
            if (!(strncmp($Ab, "\55\55\x2d\55\x2d\102\x45\x47\111\x4e\x20\103\105\x52\124\x49\x46\x49\103\101\x54\105", 22) == 0)) {
                goto uU;
            }
            $VT = true;
            uU:
            VA:
            pa:
        }
        oo:
        return $sG;
        kB:
    }
    public static function staticAdd509Cert($XS, $E6, $f4 = true, $xY = false, $G1 = null, $Eb = null)
    {
        if (!$xY) {
            goto X2;
        }
        $E6 = file_get_contents($E6);
        X2:
        if ($XS instanceof DOMElement) {
            goto Du;
        }
        throw new Exception("\x49\x6e\x76\141\x6c\151\x64\40\160\x61\x72\145\156\x74\x20\116\x6f\x64\145\x20\x70\141\162\x61\155\145\164\x65\162");
        Du:
        $w3 = $XS->ownerDocument;
        if (!empty($G1)) {
            goto PS;
        }
        $G1 = new DOMXPath($XS->ownerDocument);
        $G1->registerNamespace("\x73\x65\143\144\163\x69\147", self::XMLDSIGNS);
        PS:
        $an = "\56\57\x73\x65\x63\144\163\151\x67\72\113\145\171\x49\156\146\x6f";
        $ZD = $G1->query($an, $XS);
        $Ac = $ZD->item(0);
        $jp = '';
        if (!$Ac) {
            goto iu;
        }
        $HU = $Ac->lookupPrefix(self::XMLDSIGNS);
        if (empty($HU)) {
            goto J8;
        }
        $jp = $HU . "\x3a";
        J8:
        goto MA;
        iu:
        $HU = $XS->lookupPrefix(self::XMLDSIGNS);
        if (empty($HU)) {
            goto EP;
        }
        $jp = $HU . "\x3a";
        EP:
        $YD = false;
        $Ac = $w3->createElementNS(self::XMLDSIGNS, $jp . "\113\145\x79\x49\156\x66\157");
        $an = "\x2e\x2f\x73\145\143\x64\x73\x69\x67\72\x4f\142\152\x65\143\164";
        $ZD = $G1->query($an, $XS);
        if (!($ok = $ZD->item(0))) {
            goto kh;
        }
        $ok->parentNode->insertBefore($Ac, $ok);
        $YD = true;
        kh:
        if ($YD) {
            goto Xf;
        }
        $XS->appendChild($Ac);
        Xf:
        MA:
        $I7 = self::staticGet509XCerts($E6, $f4);
        $Vr = $w3->createElementNS(self::XMLDSIGNS, $jp . "\x58\65\60\x39\x44\141\164\141");
        $Ac->appendChild($Vr);
        $E_ = false;
        $h0 = false;
        if (!is_array($Eb)) {
            goto ek;
        }
        if (empty($Eb["\151\x73\163\x75\145\162\123\x65\x72\151\141\154"])) {
            goto Nk;
        }
        $E_ = true;
        Nk:
        if (empty($Eb["\x73\x75\142\152\145\x63\x74\x4e\x61\x6d\145"])) {
            goto Be;
        }
        $h0 = true;
        Be:
        ek:
        foreach ($I7 as $tl) {
            if (!($E_ || $h0)) {
                goto Qi;
            }
            if (!($AM = openssl_x509_parse("\55\x2d\x2d\55\x2d\x42\x45\107\x49\116\40\x43\x45\122\x54\x49\106\111\x43\x41\x54\x45\55\55\x2d\55\55\12" . chunk_split($tl, 64, "\xa") . "\55\55\55\x2d\55\105\x4e\x44\40\x43\105\122\x54\x49\106\111\x43\x41\x54\x45\55\x2d\55\55\55\xa"))) {
                goto NB;
            }
            if (!($h0 && !empty($AM["\x73\x75\142\x6a\x65\x63\164"]))) {
                goto qm;
            }
            if (is_array($AM["\x73\x75\x62\152\x65\143\164"])) {
                goto Uf;
            }
            $LD = $AM["\151\163\163\x75\x65\162"];
            goto n9;
            Uf:
            $aS = array();
            foreach ($AM["\163\165\x62\152\145\x63\x74"] as $q3 => $nY) {
                if (is_array($nY)) {
                    goto pg;
                }
                array_unshift($aS, "{$q3}\75{$nY}");
                goto LF;
                pg:
                foreach ($nY as $OT) {
                    array_unshift($aS, "{$q3}\75{$OT}");
                    NM:
                }
                PY:
                LF:
                WU:
            }
            zH:
            $LD = implode("\x2c", $aS);
            n9:
            $f3 = $w3->createElementNS(self::XMLDSIGNS, $jp . "\130\x35\60\x39\123\x75\x62\152\145\x63\x74\x4e\141\155\x65", $LD);
            $Vr->appendChild($f3);
            qm:
            if (!($E_ && !empty($AM["\x69\x73\163\165\x65\162"]) && !empty($AM["\163\x65\x72\x69\141\x6c\x4e\165\155\x62\x65\162"]))) {
                goto Lk;
            }
            if (is_array($AM["\151\163\163\165\145\x72"])) {
                goto QF;
            }
            $Gp = $AM["\151\163\163\165\x65\162"];
            goto pI;
            QF:
            $aS = array();
            foreach ($AM["\151\x73\163\x75\145\162"] as $q3 => $nY) {
                array_unshift($aS, "{$q3}\75{$nY}");
                iN:
            }
            k4:
            $Gp = implode("\x2c", $aS);
            pI:
            $TQ = $w3->createElementNS(self::XMLDSIGNS, $jp . "\130\x35\60\71\111\163\163\x75\145\x72\123\x65\x72\x69\141\154");
            $Vr->appendChild($TQ);
            $Mg = $w3->createElementNS(self::XMLDSIGNS, $jp . "\x58\x35\x30\71\x49\163\x73\x75\145\x72\116\x61\155\145", $Gp);
            $TQ->appendChild($Mg);
            $Mg = $w3->createElementNS(self::XMLDSIGNS, $jp . "\130\65\x30\x39\123\x65\162\x69\141\154\116\165\155\x62\x65\x72", $AM["\163\145\162\x69\x61\154\x4e\x75\155\142\145\x72"]);
            $TQ->appendChild($Mg);
            Lk:
            NB:
            Qi:
            $Nx = $w3->createElementNS(self::XMLDSIGNS, $jp . "\x58\x35\x30\x39\x43\x65\162\x74\151\x66\x69\143\x61\164\145", $tl);
            $Vr->appendChild($Nx);
            lj:
        }
        S_:
    }
    public function add509Cert($E6, $f4 = true, $xY = false, $Eb = null)
    {
        if (!($G1 = $this->getXPathObj())) {
            goto tU;
        }
        self::staticAdd509Cert($this->sigNode, $E6, $f4, $xY, $G1, $Eb);
        tU:
    }
    public function appendToKeyInfo($y9)
    {
        $XS = $this->sigNode;
        $w3 = $XS->ownerDocument;
        $G1 = $this->getXPathObj();
        if (!empty($G1)) {
            goto zB;
        }
        $G1 = new DOMXPath($XS->ownerDocument);
        $G1->registerNamespace("\163\145\x63\144\163\x69\147", self::XMLDSIGNS);
        zB:
        $an = "\56\x2f\163\x65\143\144\163\x69\x67\x3a\113\145\171\111\x6e\x66\x6f";
        $ZD = $G1->query($an, $XS);
        $Ac = $ZD->item(0);
        if ($Ac) {
            goto sY;
        }
        $jp = '';
        $HU = $XS->lookupPrefix(self::XMLDSIGNS);
        if (empty($HU)) {
            goto hj;
        }
        $jp = $HU . "\x3a";
        hj:
        $YD = false;
        $Ac = $w3->createElementNS(self::XMLDSIGNS, $jp . "\113\x65\x79\x49\x6e\146\x6f");
        $an = "\x2e\x2f\163\x65\x63\144\x73\x69\147\x3a\117\x62\152\x65\x63\164";
        $ZD = $G1->query($an, $XS);
        if (!($ok = $ZD->item(0))) {
            goto zs;
        }
        $ok->parentNode->insertBefore($Ac, $ok);
        $YD = true;
        zs:
        if ($YD) {
            goto V5;
        }
        $XS->appendChild($Ac);
        V5:
        sY:
        $Ac->appendChild($y9);
        return $Ac;
    }
    public function getValidatedNodes()
    {
        return $this->validatedNodes;
    }
}
