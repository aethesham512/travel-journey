<?php


namespace RobRichards\XMLSecLibs\Utils;

class XPath
{
    const ALPHANUMERIC = "\x5c\x77\134\144";
    const NUMERIC = "\x5c\x64";
    const LETTERS = "\134\167";
    const EXTENDED_ALPHANUMERIC = "\x5c\167\134\144\x5c\163\x5c\x2d\x5f\x3a\134\56";
    const SINGLE_QUOTE = "\x27";
    const DOUBLE_QUOTE = "\42";
    const ALL_QUOTES = "\x5b\x27\x22\135";
    public static function filterAttrValue($nY, $fH = self::ALL_QUOTES)
    {
        return preg_replace("\43" . $fH . "\43", '', $nY);
    }
    public static function filterAttrName($zd, $Yv = self::EXTENDED_ALPHANUMERIC)
    {
        return preg_replace("\x23\133\x5e" . $Yv . "\135\x23", '', $zd);
    }
}
