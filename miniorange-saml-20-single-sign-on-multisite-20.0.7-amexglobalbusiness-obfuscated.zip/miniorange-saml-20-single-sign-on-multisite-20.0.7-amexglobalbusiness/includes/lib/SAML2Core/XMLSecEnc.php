<?php


namespace RobRichards\XMLSecLibs;

use DOMDocument;
use DOMNode;
use DOMXPath;
use Exception;
use RobRichards\XMLSecLibs\Utils\XPath as XPath;
class XMLSecEnc
{
    const template = "\x3c\x78\145\x6e\143\x3a\x45\156\x63\x72\171\x70\164\x65\x64\x44\141\164\x61\x20\170\x6d\x6c\x6e\163\x3a\x78\x65\x6e\x63\75\47\x68\164\164\x70\x3a\57\57\x77\167\x77\56\x77\63\x2e\157\x72\147\x2f\62\60\x30\61\x2f\x30\x34\x2f\x78\155\154\x65\156\x63\x23\x27\76\15\12\x20\40\x20\x3c\170\x65\156\143\x3a\103\151\x70\x68\x65\x72\x44\x61\164\x61\x3e\15\12\x20\x20\40\x20\40\40\x3c\170\145\x6e\x63\x3a\103\151\160\150\145\162\126\x61\154\x75\145\76\x3c\x2f\170\145\x6e\x63\x3a\x43\151\x70\x68\x65\x72\x56\x61\x6c\x75\145\x3e\15\xa\x20\x20\40\74\57\170\145\156\143\x3a\x43\x69\x70\150\145\x72\104\x61\164\141\x3e\xd\12\74\x2f\x78\x65\156\143\72\105\156\x63\x72\171\x70\164\145\144\x44\x61\164\x61\76";
    const Element = "\150\x74\x74\x70\72\x2f\57\167\167\167\x2e\x77\x33\56\x6f\x72\147\57\62\60\x30\x31\57\x30\x34\57\x78\155\x6c\145\x6e\x63\43\105\x6c\x65\155\145\156\164";
    const Content = "\150\x74\164\x70\72\x2f\x2f\x77\167\167\56\x77\x33\x2e\x6f\162\x67\57\62\60\x30\61\57\x30\64\x2f\170\155\x6c\x65\156\143\43\103\157\x6e\x74\x65\156\x74";
    const URI = 3;
    const XMLENCNS = "\x68\164\x74\x70\72\x2f\57\x77\x77\167\56\x77\x33\x2e\157\x72\x67\57\62\60\60\61\57\x30\64\x2f\x78\155\x6c\145\x6e\x63\43";
    private $encdoc = null;
    private $rawNode = null;
    public $type = null;
    public $encKey = null;
    private $references = array();
    public function __construct()
    {
        $this->_resetTemplate();
    }
    private function _resetTemplate()
    {
        $this->encdoc = new DOMDocument();
        $this->encdoc->loadXML(self::template);
    }
    public function addReference($zd, $y9, $iS)
    {
        if ($y9 instanceof DOMNode) {
            goto Qj;
        }
        throw new Exception("\x24\156\x6f\x64\145\x20\x69\x73\40\156\157\164\x20\157\x66\x20\164\171\x70\145\40\104\117\115\116\x6f\144\145");
        Qj:
        $SK = $this->encdoc;
        $this->_resetTemplate();
        $rn = $this->encdoc;
        $this->encdoc = $SK;
        $Ms = XMLSecurityDSig::generateGUID();
        $OA = $rn->documentElement;
        $OA->setAttribute("\x49\144", $Ms);
        $this->references[$zd] = array("\x6e\157\x64\x65" => $y9, "\x74\171\160\x65" => $iS, "\x65\x6e\x63\156\x6f\144\x65" => $rn, "\162\145\x66\165\x72\x69" => $Ms);
    }
    public function setNode($y9)
    {
        $this->rawNode = $y9;
    }
    public function encryptNode($Ig, $UP = true)
    {
        $uG = '';
        if (!empty($this->rawNode)) {
            goto L9;
        }
        throw new Exception("\116\x6f\x64\145\x20\x74\x6f\x20\x65\156\143\x72\171\x70\x74\x20\x68\141\x73\40\x6e\157\164\40\x62\x65\145\x6e\40\163\145\164");
        L9:
        if ($Ig instanceof XMLSecurityKey) {
            goto JG;
        }
        throw new Exception("\x49\156\166\x61\154\x69\x64\x20\x4b\145\x79");
        JG:
        $fT = $this->rawNode->ownerDocument;
        $I9 = new DOMXPath($this->encdoc);
        $L7 = $I9->query("\x2f\x78\145\x6e\x63\x3a\x45\x6e\143\x72\x79\160\x74\x65\x64\x44\x61\x74\x61\x2f\x78\x65\x6e\143\x3a\103\x69\x70\x68\145\162\x44\141\164\x61\57\x78\145\156\143\72\x43\x69\x70\x68\145\x72\x56\x61\154\x75\x65");
        $LY = $L7->item(0);
        if (!($LY == null)) {
            goto AX;
        }
        throw new Exception("\x45\x72\162\x6f\162\40\x6c\x6f\143\141\x74\151\156\147\40\x43\151\160\150\x65\x72\126\x61\154\165\145\40\145\154\x65\x6d\x65\x6e\164\x20\167\151\x74\x68\x69\156\x20\164\145\x6d\x70\154\x61\164\145");
        AX:
        switch ($this->type) {
            case self::Element:
                $uG = $fT->saveXML($this->rawNode);
                $this->encdoc->documentElement->setAttribute("\x54\x79\160\145", self::Element);
                goto q1;
            case self::Content:
                $ZX = $this->rawNode->childNodes;
                foreach ($ZX as $np) {
                    $uG .= $fT->saveXML($np);
                    mI:
                }
                ou:
                $this->encdoc->documentElement->setAttribute("\124\171\x70\145", self::Content);
                goto q1;
            default:
                throw new Exception("\x54\171\160\145\x20\x69\163\40\143\165\162\x72\145\x6e\x74\154\171\40\x6e\157\164\40\x73\x75\x70\x70\x6f\162\164\x65\x64");
        }
        iG:
        q1:
        $nz = $this->encdoc->documentElement->appendChild($this->encdoc->createElementNS(self::XMLENCNS, "\x78\x65\156\143\72\x45\156\143\x72\x79\160\x74\151\x6f\156\x4d\145\164\x68\x6f\x64"));
        $nz->setAttribute("\x41\154\x67\157\x72\x69\164\x68\x6d", $Ig->getAlgorithm());
        $LY->parentNode->parentNode->insertBefore($nz, $LY->parentNode->parentNode->firstChild);
        $DJ = base64_encode($Ig->encryptData($uG));
        $nY = $this->encdoc->createTextNode($DJ);
        $LY->appendChild($nY);
        if ($UP) {
            goto gf;
        }
        return $this->encdoc->documentElement;
        goto bz;
        gf:
        switch ($this->type) {
            case self::Element:
                if (!($this->rawNode->nodeType == XML_DOCUMENT_NODE)) {
                    goto z3;
                }
                return $this->encdoc;
                z3:
                $f7 = $this->rawNode->ownerDocument->importNode($this->encdoc->documentElement, true);
                $this->rawNode->parentNode->replaceChild($f7, $this->rawNode);
                return $f7;
            case self::Content:
                $f7 = $this->rawNode->ownerDocument->importNode($this->encdoc->documentElement, true);
                uk:
                if (!$this->rawNode->firstChild) {
                    goto sX;
                }
                $this->rawNode->removeChild($this->rawNode->firstChild);
                goto uk;
                sX:
                $this->rawNode->appendChild($f7);
                return $f7;
        }
        UX:
        zL:
        bz:
    }
    public function encryptReferences($Ig)
    {
        $zN = $this->rawNode;
        $Lr = $this->type;
        foreach ($this->references as $zd => $x1) {
            $this->encdoc = $x1["\145\156\143\156\157\x64\145"];
            $this->rawNode = $x1["\156\x6f\144\x65"];
            $this->type = $x1["\164\x79\160\x65"];
            try {
                $ee = $this->encryptNode($Ig);
                $this->references[$zd]["\x65\156\x63\156\157\144\145"] = $ee;
            } catch (Exception $Y4) {
                $this->rawNode = $zN;
                $this->type = $Lr;
                throw $Y4;
            }
            pd:
        }
        Zj:
        $this->rawNode = $zN;
        $this->type = $Lr;
    }
    public function getCipherValue()
    {
        if (!empty($this->rawNode)) {
            goto e5;
        }
        throw new Exception("\116\x6f\x64\x65\x20\x74\x6f\40\144\x65\x63\162\171\160\164\40\150\141\x73\x20\156\157\164\40\x62\x65\x65\x6e\x20\x73\x65\x74");
        e5:
        $fT = $this->rawNode->ownerDocument;
        $I9 = new DOMXPath($fT);
        $I9->registerNamespace("\170\x6d\x6c\x65\156\143\x72", self::XMLENCNS);
        $an = "\56\x2f\x78\155\x6c\145\x6e\x63\162\x3a\103\151\x70\x68\145\162\104\x61\164\x61\57\x78\155\x6c\x65\156\143\x72\72\103\151\160\150\145\x72\126\x61\x6c\x75\145";
        $ZD = $I9->query($an, $this->rawNode);
        $y9 = $ZD->item(0);
        if ($y9) {
            goto dg;
        }
        return null;
        dg:
        return base64_decode($y9->nodeValue);
    }
    public function decryptNode($Ig, $UP = true)
    {
        if ($Ig instanceof XMLSecurityKey) {
            goto l7;
        }
        throw new Exception("\111\156\x76\141\154\151\144\x20\x4b\145\171");
        l7:
        $ZZ = $this->getCipherValue();
        if ($ZZ) {
            goto Uu;
        }
        throw new Exception("\103\x61\x6e\156\157\x74\x20\x6c\x6f\x63\141\x74\x65\40\x65\x6e\143\162\171\x70\164\145\144\40\x64\x61\x74\141");
        goto dL;
        Uu:
        $uv = $Ig->decryptData($ZZ);
        if ($UP) {
            goto Gd;
        }
        return $uv;
        goto F9;
        Gd:
        switch ($this->type) {
            case self::Element:
                $x8 = new DOMDocument();
                $x8->loadXML($uv);
                if (!($this->rawNode->nodeType == XML_DOCUMENT_NODE)) {
                    goto KN;
                }
                return $x8;
                KN:
                $f7 = $this->rawNode->ownerDocument->importNode($x8->documentElement, true);
                $this->rawNode->parentNode->replaceChild($f7, $this->rawNode);
                return $f7;
            case self::Content:
                if ($this->rawNode->nodeType == XML_DOCUMENT_NODE) {
                    goto XK;
                }
                $fT = $this->rawNode->ownerDocument;
                goto wZ;
                XK:
                $fT = $this->rawNode;
                wZ:
                $kd = $fT->createDocumentFragment();
                $kd->appendXML($uv);
                $Sg = $this->rawNode->parentNode;
                $Sg->replaceChild($kd, $this->rawNode);
                return $Sg;
            default:
                return $uv;
        }
        np:
        Xl:
        F9:
        dL:
    }
    public function encryptKey($R5, $ri, $mN = true)
    {
        if (!(!$R5 instanceof XMLSecurityKey || !$ri instanceof XMLSecurityKey)) {
            goto m1;
        }
        throw new Exception("\111\x6e\166\141\154\151\x64\40\113\x65\171");
        m1:
        $MT = base64_encode($R5->encryptData($ri->key));
        $ii = $this->encdoc->documentElement;
        $uI = $this->encdoc->createElementNS(self::XMLENCNS, "\x78\145\x6e\x63\x3a\105\156\143\162\x79\160\x74\x65\x64\113\x65\x79");
        if ($mN) {
            goto ia;
        }
        $this->encKey = $uI;
        goto FG;
        ia:
        $Ac = $ii->insertBefore($this->encdoc->createElementNS("\x68\x74\164\160\x3a\57\x2f\167\x77\x77\56\x77\63\x2e\x6f\162\x67\57\62\x30\x30\60\57\60\x39\x2f\170\x6d\154\x64\163\x69\x67\x23", "\x64\x73\151\x67\x3a\x4b\x65\171\x49\156\146\157"), $ii->firstChild);
        $Ac->appendChild($uI);
        FG:
        $nz = $uI->appendChild($this->encdoc->createElementNS(self::XMLENCNS, "\x78\145\x6e\143\x3a\105\x6e\x63\162\171\160\164\x69\x6f\x6e\115\145\x74\150\x6f\144"));
        $nz->setAttribute("\101\x6c\x67\157\162\151\x74\x68\155", $R5->getAlgorith());
        if (empty($R5->name)) {
            goto tc;
        }
        $Ac = $uI->appendChild($this->encdoc->createElementNS("\x68\x74\164\x70\x3a\57\57\167\x77\x77\56\x77\63\56\x6f\x72\147\57\x32\x30\60\x30\x2f\60\x39\57\x78\x6d\154\x64\x73\151\x67\x23", "\144\x73\x69\x67\x3a\x4b\145\171\x49\156\x66\157"));
        $Ac->appendChild($this->encdoc->createElementNS("\150\x74\x74\160\72\57\57\x77\167\167\56\167\x33\56\x6f\x72\147\57\62\x30\60\x30\57\x30\x39\57\170\155\x6c\144\x73\x69\x67\43", "\144\x73\x69\x67\x3a\113\x65\171\116\141\155\145", $R5->name));
        tc:
        $mD = $uI->appendChild($this->encdoc->createElementNS(self::XMLENCNS, "\170\x65\156\x63\x3a\103\x69\160\x68\x65\162\x44\x61\x74\141"));
        $mD->appendChild($this->encdoc->createElementNS(self::XMLENCNS, "\x78\x65\156\143\72\x43\x69\160\x68\145\x72\126\x61\154\165\x65", $MT));
        if (!(is_array($this->references) && count($this->references) > 0)) {
            goto It;
        }
        $xV = $uI->appendChild($this->encdoc->createElementNS(self::XMLENCNS, "\170\x65\x6e\x63\x3a\x52\x65\x66\145\x72\x65\156\x63\x65\x4c\151\x73\x74"));
        foreach ($this->references as $zd => $x1) {
            $Ms = $x1["\x72\x65\146\165\162\x69"];
            $eI = $xV->appendChild($this->encdoc->createElementNS(self::XMLENCNS, "\170\x65\x6e\143\72\104\141\164\x61\122\145\146\145\x72\x65\156\x63\145"));
            $eI->setAttribute("\x55\122\111", "\x23" . $Ms);
            Hr:
        }
        in:
        It:
        return;
    }
    public function decryptKey($uI)
    {
        if ($uI->isEncrypted) {
            goto aq;
        }
        throw new Exception("\113\145\x79\x20\x69\x73\x20\156\x6f\164\40\105\x6e\x63\162\x79\160\164\145\144");
        aq:
        if (!empty($uI->key)) {
            goto UQ;
        }
        throw new Exception("\113\x65\171\40\151\163\40\155\151\x73\x73\151\x6e\147\40\x64\x61\164\x61\x20\x74\x6f\x20\160\145\x72\146\157\162\x6d\x20\164\150\x65\x20\x64\145\x63\162\171\x70\164\151\x6f\156");
        UQ:
        return $this->decryptNode($uI, false);
    }
    public function locateEncryptedData($OA)
    {
        if ($OA instanceof DOMDocument) {
            goto SA;
        }
        $fT = $OA->ownerDocument;
        goto jh;
        SA:
        $fT = $OA;
        jh:
        if (!$fT) {
            goto Ec;
        }
        $G1 = new DOMXPath($fT);
        $an = "\x2f\57\x2a\x5b\154\x6f\x63\x61\154\55\x6e\141\x6d\x65\x28\51\75\x27\105\x6e\x63\162\x79\x70\164\145\144\x44\141\x74\x61\47\40\141\156\x64\x20\x6e\x61\x6d\x65\x73\160\x61\x63\145\55\165\162\151\50\51\75\47" . self::XMLENCNS . "\47\135";
        $ZD = $G1->query($an);
        return $ZD->item(0);
        Ec:
        return null;
    }
    public function locateKey($y9 = null)
    {
        if (!empty($y9)) {
            goto I2;
        }
        $y9 = $this->rawNode;
        I2:
        if ($y9 instanceof DOMNode) {
            goto iY;
        }
        return null;
        iY:
        if (!($fT = $y9->ownerDocument)) {
            goto x2;
        }
        $G1 = new DOMXPath($fT);
        $G1->registerNamespace("\x78\155\154\x73\145\143\145\156\x63", self::XMLENCNS);
        $an = "\x2e\57\x2f\170\155\154\x73\x65\x63\145\156\143\x3a\105\156\143\x72\171\160\x74\151\157\x6e\115\145\164\150\x6f\144";
        $ZD = $G1->query($an, $y9);
        if (!($jb = $ZD->item(0))) {
            goto FZ;
        }
        $hy = $jb->getAttribute("\101\154\x67\x6f\162\151\164\x68\155");
        try {
            $Ig = new XMLSecurityKey($hy, array("\x74\x79\160\x65" => "\160\x72\x69\x76\x61\164\145"));
        } catch (Exception $Y4) {
            return null;
        }
        return $Ig;
        FZ:
        x2:
        return null;
    }
    public static function staticLocateKeyInfo($DV = null, $y9 = null)
    {
        if (!(empty($y9) || !$y9 instanceof DOMNode)) {
            goto Wk;
        }
        return null;
        Wk:
        $fT = $y9->ownerDocument;
        if ($fT) {
            goto Cu;
        }
        return null;
        Cu:
        $G1 = new DOMXPath($fT);
        $G1->registerNamespace("\170\x6d\154\163\145\143\145\x6e\x63", self::XMLENCNS);
        $G1->registerNamespace("\x78\x6d\154\x73\x65\143\x64\163\151\x67", XMLSecurityDSig::XMLDSIGNS);
        $an = "\x2e\57\170\x6d\x6c\x73\145\143\x64\163\151\x67\x3a\x4b\x65\x79\111\x6e\x66\157";
        $ZD = $G1->query($an, $y9);
        $jb = $ZD->item(0);
        if ($jb) {
            goto AN;
        }
        return $DV;
        AN:
        foreach ($jb->childNodes as $np) {
            switch ($np->localName) {
                case "\113\x65\171\x4e\141\155\x65":
                    if (empty($DV)) {
                        goto Mt;
                    }
                    $DV->name = $np->nodeValue;
                    Mt:
                    goto ts;
                case "\113\145\171\126\141\154\165\x65":
                    foreach ($np->childNodes as $vl) {
                        switch ($vl->localName) {
                            case "\x44\x53\101\x4b\145\171\126\x61\x6c\165\145":
                                throw new Exception("\x44\x53\101\x4b\145\x79\x56\x61\154\165\x65\x20\143\165\x72\162\145\156\164\154\x79\40\156\x6f\164\x20\163\165\x70\x70\x6f\x72\x74\x65\144");
                            case "\x52\123\101\x4b\x65\171\126\x61\x6c\x75\145":
                                $Y3 = null;
                                $IG = null;
                                if (!($Ag = $vl->getElementsByTagName("\115\x6f\144\x75\154\x75\163")->item(0))) {
                                    goto bc;
                                }
                                $Y3 = base64_decode($Ag->nodeValue);
                                bc:
                                if (!($uQ = $vl->getElementsByTagName("\105\x78\160\x6f\x6e\145\x6e\x74")->item(0))) {
                                    goto ib;
                                }
                                $IG = base64_decode($uQ->nodeValue);
                                ib:
                                if (!(empty($Y3) || empty($IG))) {
                                    goto h4;
                                }
                                throw new Exception("\115\x69\163\x73\151\156\147\40\x4d\157\x64\x75\x6c\x75\x73\40\157\162\40\105\x78\160\x6f\x6e\145\x6e\164");
                                h4:
                                $lq = XMLSecurityKey::convertRSA($Y3, $IG);
                                $DV->loadKey($lq);
                                goto XR;
                        }
                        T5:
                        XR:
                        s_:
                    }
                    qD:
                    goto ts;
                case "\x52\x65\164\x72\x69\x65\x76\141\154\115\x65\x74\x68\157\144":
                    $iS = $np->getAttribute("\x54\171\160\x65");
                    if (!($iS !== "\150\164\164\x70\72\57\x2f\x77\x77\x77\56\167\63\x2e\x6f\162\x67\x2f\x32\60\60\61\x2f\60\64\57\x78\x6d\x6c\145\156\143\x23\105\156\143\x72\x79\x70\x74\145\x64\113\145\171")) {
                        goto jz;
                    }
                    goto ts;
                    jz:
                    $R_ = $np->getAttribute("\x55\122\x49");
                    if (!($R_[0] !== "\x23")) {
                        goto Mw;
                    }
                    goto ts;
                    Mw:
                    $ni = substr($R_, 1);
                    $an = "\57\x2f\x78\x6d\x6c\163\145\x63\145\x6e\x63\x3a\105\x6e\x63\x72\x79\x70\x74\x65\x64\x4b\145\x79\133\100\111\144\x3d\x22" . XPath::filterAttrValue($ni, XPath::DOUBLE_QUOTE) . "\42\x5d";
                    $Xe = $G1->query($an)->item(0);
                    if ($Xe) {
                        goto he;
                    }
                    throw new Exception("\125\x6e\x61\x62\154\x65\x20\x74\157\x20\154\x6f\143\x61\164\145\x20\105\156\x63\162\171\x70\164\145\144\x4b\x65\x79\40\167\x69\164\x68\x20\x40\111\x64\x3d\47{$ni}\x27\x2e");
                    he:
                    return XMLSecurityKey::fromEncryptedKeyElement($Xe);
                case "\x45\x6e\x63\x72\171\160\x74\x65\144\113\145\171":
                    return XMLSecurityKey::fromEncryptedKeyElement($np);
                case "\x58\65\60\x39\104\141\164\x61":
                    if (!($o5 = $np->getElementsByTagName("\x58\65\x30\x39\103\x65\162\x74\x69\x66\151\x63\x61\164\x65"))) {
                        goto Rn;
                    }
                    if (!($o5->length > 0)) {
                        goto Fp;
                    }
                    $Kz = $o5->item(0)->textContent;
                    $Kz = str_replace(array("\15", "\xa", "\40"), '', $Kz);
                    $Kz = "\x2d\x2d\x2d\x2d\x2d\102\105\107\x49\116\x20\103\x45\x52\124\x49\106\111\103\x41\124\105\55\55\x2d\x2d\55\12" . chunk_split($Kz, 64, "\xa") . "\55\55\55\x2d\55\105\x4e\104\40\103\x45\x52\124\x49\106\x49\x43\101\124\105\55\x2d\x2d\55\x2d\xa";
                    $DV->loadKey($Kz, false, true);
                    Fp:
                    Rn:
                    goto ts;
            }
            P4:
            ts:
            Yx:
        }
        eu:
        return $DV;
    }
    public function locateKeyInfo($DV = null, $y9 = null)
    {
        if (!empty($y9)) {
            goto SW;
        }
        $y9 = $this->rawNode;
        SW:
        return self::staticLocateKeyInfo($DV, $y9);
    }
}
