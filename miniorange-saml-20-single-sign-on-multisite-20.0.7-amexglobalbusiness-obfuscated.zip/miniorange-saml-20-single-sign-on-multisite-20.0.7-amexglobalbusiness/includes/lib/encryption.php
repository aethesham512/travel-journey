<?php


class AESEncryption
{
    public static function encrypt_data($uG, $q3)
    {
        $q3 = openssl_digest($q3, "\x73\x68\141\62\65\66");
        $uS = "\141\145\x73\x2d\x31\x32\70\x2d\x65\x63\142";
        $Lf = openssl_encrypt($uG, $uS, $q3, OPENSSL_RAW_DATA || OPENSSL_ZERO_PADDING);
        return base64_encode($Lf);
    }
    public static function decrypt_data($uG, $q3)
    {
        $Hp = base64_decode($uG);
        $q3 = openssl_digest($q3, "\x73\150\141\x32\x35\66");
        $uS = "\101\x45\123\x2d\x31\x32\70\x2d\x45\103\x42";
        $hq = openssl_cipher_iv_length($uS);
        $xe = substr($Hp, 0, $hq);
        $uG = substr($Hp, $hq);
        $ec = openssl_decrypt($uG, $uS, $q3, OPENSSL_RAW_DATA || OPENSSL_ZERO_PADDING, $xe);
        return $ec;
    }
}
