<?php


if (defined("\x57\x50\111\x4e\x43")) {
    goto yU;
}
die;
yU:
