<?php


if (defined("\x57\120\111\x4e\x43")) {
    goto T4;
}
die;
T4:
