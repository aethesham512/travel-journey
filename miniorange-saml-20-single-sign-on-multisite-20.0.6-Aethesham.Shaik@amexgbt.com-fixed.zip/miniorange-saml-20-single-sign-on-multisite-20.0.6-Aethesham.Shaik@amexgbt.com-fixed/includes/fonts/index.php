<?php


if (defined("\x57\120\x49\116\103")) {
    goto DT;
}
die;
DT:
