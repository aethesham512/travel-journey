<?php


namespace RobRichards\XMLSecLibs;

use DOMDocument;
use DOMNode;
use DOMXPath;
use Exception;
use RobRichards\XMLSecLibs\Utils\XPath as XPath;
class XMLSecEnc
{
    const template = "\x3c\x78\x65\156\x63\x3a\105\156\143\162\x79\x70\164\x65\x64\x44\141\164\x61\x20\170\x6d\x6c\156\x73\72\x78\x65\156\143\75\47\x68\x74\164\x70\72\x2f\57\x77\x77\167\x2e\167\63\x2e\157\x72\147\57\62\60\x30\x31\x2f\x30\64\x2f\x78\155\x6c\145\x6e\143\43\47\x3e\xd\xa\40\40\40\x3c\x78\x65\156\x63\x3a\103\x69\x70\150\x65\162\104\141\x74\141\x3e\15\xa\40\x20\x20\x20\x20\40\x3c\170\x65\156\143\x3a\x43\x69\x70\150\145\x72\x56\x61\x6c\165\145\76\x3c\x2f\x78\145\156\143\x3a\103\x69\160\x68\145\x72\x56\x61\154\x75\145\x3e\15\12\x20\40\x20\74\57\170\x65\x6e\x63\72\103\151\160\150\x65\x72\x44\141\x74\141\76\xd\xa\x3c\x2f\170\x65\156\x63\x3a\105\156\143\x72\171\x70\164\145\144\104\x61\x74\141\x3e";
    const Element = "\150\164\x74\x70\x3a\57\57\167\167\x77\x2e\167\x33\56\157\162\147\57\62\60\60\x31\57\x30\64\x2f\x78\155\154\x65\x6e\x63\x23\x45\154\x65\x6d\145\x6e\x74";
    const Content = "\150\x74\x74\160\72\x2f\57\x77\167\x77\x2e\x77\63\56\x6f\162\x67\57\62\x30\x30\61\57\x30\64\57\170\x6d\x6c\x65\x6e\x63\x23\103\157\156\164\x65\156\164";
    const URI = 3;
    const XMLENCNS = "\150\164\164\x70\x3a\x2f\x2f\x77\167\x77\56\x77\x33\56\x6f\162\147\57\62\x30\60\61\57\60\x34\57\170\155\154\145\156\x63\x23";
    private $encdoc = null;
    private $rawNode = null;
    public $type = null;
    public $encKey = null;
    private $references = array();
    public function __construct()
    {
        $this->_resetTemplate();
    }
    private function _resetTemplate()
    {
        $this->encdoc = new DOMDocument();
        $this->encdoc->loadXML(self::template);
    }
    public function addReference($Ym, $tB, $az)
    {
        if ($tB instanceof DOMNode) {
            goto eE;
        }
        throw new Exception("\44\x6e\x6f\x64\145\40\x69\163\40\156\157\x74\40\157\x66\40\x74\x79\x70\145\x20\104\x4f\x4d\116\x6f\144\145");
        eE:
        $X0 = $this->encdoc;
        $this->_resetTemplate();
        $qP = $this->encdoc;
        $this->encdoc = $X0;
        $w5 = XMLSecurityDSig::generateGUID();
        $ff = $qP->documentElement;
        $ff->setAttribute("\x49\x64", $w5);
        $this->references[$Ym] = array("\x6e\157\x64\145" => $tB, "\x74\x79\160\145" => $az, "\x65\x6e\143\156\157\144\145" => $qP, "\x72\x65\146\x75\x72\151" => $w5);
    }
    public function setNode($tB)
    {
        $this->rawNode = $tB;
    }
    public function encryptNode($QH, $cy = true)
    {
        $Xu = '';
        if (!empty($this->rawNode)) {
            goto Er;
        }
        throw new Exception("\116\x6f\x64\145\x20\x74\x6f\40\x65\156\x63\x72\171\160\164\x20\150\x61\x73\x20\x6e\x6f\164\x20\142\145\145\x6e\40\x73\145\164");
        Er:
        if ($QH instanceof XMLSecurityKey) {
            goto xx;
        }
        throw new Exception("\111\x6e\166\141\x6c\151\x64\x20\113\x65\171");
        xx:
        $Jp = $this->rawNode->ownerDocument;
        $OA = new DOMXPath($this->encdoc);
        $ZX = $OA->query("\x2f\170\x65\156\143\72\x45\x6e\x63\x72\x79\160\x74\x65\x64\x44\x61\x74\x61\57\170\145\156\143\72\x43\x69\160\x68\145\x72\104\141\x74\141\57\x78\x65\x6e\143\72\x43\151\x70\x68\x65\x72\126\x61\154\165\145");
        $Oq = $ZX->item(0);
        if (!($Oq == null)) {
            goto MS;
        }
        throw new Exception("\x45\x72\x72\x6f\x72\x20\154\157\x63\141\164\x69\x6e\147\x20\x43\151\x70\150\145\162\x56\x61\x6c\x75\x65\x20\145\154\x65\155\x65\x6e\164\40\x77\151\x74\150\151\x6e\x20\x74\x65\x6d\160\154\x61\x74\145");
        MS:
        switch ($this->type) {
            case self::Element:
                $Xu = $Jp->saveXML($this->rawNode);
                $this->encdoc->documentElement->setAttribute("\124\x79\x70\x65", self::Element);
                goto s3;
            case self::Content:
                $aL = $this->rawNode->childNodes;
                foreach ($aL as $Th) {
                    $Xu .= $Jp->saveXML($Th);
                    GQ:
                }
                jK:
                $this->encdoc->documentElement->setAttribute("\124\171\x70\145", self::Content);
                goto s3;
            default:
                throw new Exception("\x54\x79\x70\x65\x20\151\x73\x20\143\165\162\x72\145\156\164\x6c\x79\40\x6e\157\164\40\163\165\160\x70\x6f\x72\164\x65\x64");
        }
        pT:
        s3:
        $q0 = $this->encdoc->documentElement->appendChild($this->encdoc->createElementNS(self::XMLENCNS, "\170\x65\156\143\72\x45\156\x63\162\171\x70\x74\x69\x6f\x6e\115\x65\x74\x68\x6f\144"));
        $q0->setAttribute("\x41\154\147\157\162\x69\164\150\x6d", $QH->getAlgorithm());
        $Oq->parentNode->parentNode->insertBefore($q0, $Oq->parentNode->parentNode->firstChild);
        $Vg = base64_encode($QH->encryptData($Xu));
        $jR = $this->encdoc->createTextNode($Vg);
        $Oq->appendChild($jR);
        if ($cy) {
            goto bU;
        }
        return $this->encdoc->documentElement;
        goto Xs;
        bU:
        switch ($this->type) {
            case self::Element:
                if (!($this->rawNode->nodeType == XML_DOCUMENT_NODE)) {
                    goto dH;
                }
                return $this->encdoc;
                dH:
                $wX = $this->rawNode->ownerDocument->importNode($this->encdoc->documentElement, true);
                $this->rawNode->parentNode->replaceChild($wX, $this->rawNode);
                return $wX;
            case self::Content:
                $wX = $this->rawNode->ownerDocument->importNode($this->encdoc->documentElement, true);
                c4:
                if (!$this->rawNode->firstChild) {
                    goto Fu;
                }
                $this->rawNode->removeChild($this->rawNode->firstChild);
                goto c4;
                Fu:
                $this->rawNode->appendChild($wX);
                return $wX;
        }
        yy:
        g0:
        Xs:
    }
    public function encryptReferences($QH)
    {
        $v2 = $this->rawNode;
        $Oa = $this->type;
        foreach ($this->references as $Ym => $Xi) {
            $this->encdoc = $Xi["\145\x6e\x63\156\x6f\144\145"];
            $this->rawNode = $Xi["\156\x6f\144\x65"];
            $this->type = $Xi["\164\x79\x70\145"];
            try {
                $kf = $this->encryptNode($QH);
                $this->references[$Ym]["\x65\156\143\x6e\x6f\x64\x65"] = $kf;
            } catch (Exception $i0) {
                $this->rawNode = $v2;
                $this->type = $Oa;
                throw $i0;
            }
            oB:
        }
        nB:
        $this->rawNode = $v2;
        $this->type = $Oa;
    }
    public function getCipherValue()
    {
        if (!empty($this->rawNode)) {
            goto Qr;
        }
        throw new Exception("\x4e\x6f\144\x65\40\164\x6f\x20\144\x65\143\162\x79\x70\164\40\x68\x61\x73\40\156\157\x74\40\x62\x65\145\x6e\x20\163\x65\x74");
        Qr:
        $Jp = $this->rawNode->ownerDocument;
        $OA = new DOMXPath($Jp);
        $OA->registerNamespace("\x78\x6d\154\x65\x6e\143\162", self::XMLENCNS);
        $MN = "\56\57\x78\155\154\x65\x6e\x63\162\x3a\103\151\x70\x68\145\x72\x44\x61\x74\x61\x2f\x78\x6d\x6c\x65\x6e\143\162\72\103\151\x70\150\145\162\126\x61\x6c\165\x65";
        $sA = $OA->query($MN, $this->rawNode);
        $tB = $sA->item(0);
        if ($tB) {
            goto Ib;
        }
        return null;
        Ib:
        return base64_decode($tB->nodeValue);
    }
    public function decryptNode($QH, $cy = true)
    {
        if ($QH instanceof XMLSecurityKey) {
            goto W4;
        }
        throw new Exception("\111\156\x76\141\154\x69\x64\40\113\x65\171");
        W4:
        $Db = $this->getCipherValue();
        if ($Db) {
            goto ZF;
        }
        throw new Exception("\x43\141\156\x6e\x6f\x74\x20\154\157\143\141\x74\x65\x20\145\156\x63\162\x79\160\x74\x65\x64\40\144\x61\x74\x61");
        goto iG;
        ZF:
        $Ui = $QH->decryptData($Db);
        if ($cy) {
            goto VQ;
        }
        return $Ui;
        goto HL;
        VQ:
        switch ($this->type) {
            case self::Element:
                $xb = new DOMDocument();
                $xb->loadXML($Ui);
                if (!($this->rawNode->nodeType == XML_DOCUMENT_NODE)) {
                    goto RQ;
                }
                return $xb;
                RQ:
                $wX = $this->rawNode->ownerDocument->importNode($xb->documentElement, true);
                $this->rawNode->parentNode->replaceChild($wX, $this->rawNode);
                return $wX;
            case self::Content:
                if ($this->rawNode->nodeType == XML_DOCUMENT_NODE) {
                    goto mB;
                }
                $Jp = $this->rawNode->ownerDocument;
                goto mX;
                mB:
                $Jp = $this->rawNode;
                mX:
                $lg = $Jp->createDocumentFragment();
                $lg->appendXML($Ui);
                $Hf = $this->rawNode->parentNode;
                $Hf->replaceChild($lg, $this->rawNode);
                return $Hf;
            default:
                return $Ui;
        }
        qB:
        no:
        HL:
        iG:
    }
    public function encryptKey($WS, $py, $OK = true)
    {
        if (!(!$WS instanceof XMLSecurityKey || !$py instanceof XMLSecurityKey)) {
            goto xJ;
        }
        throw new Exception("\x49\156\166\141\x6c\151\x64\40\x4b\145\171");
        xJ:
        $FS = base64_encode($WS->encryptData($py->key));
        $YU = $this->encdoc->documentElement;
        $a8 = $this->encdoc->createElementNS(self::XMLENCNS, "\170\x65\156\143\x3a\x45\x6e\143\162\x79\x70\x74\x65\x64\x4b\x65\x79");
        if ($OK) {
            goto gZ;
        }
        $this->encKey = $a8;
        goto x_;
        gZ:
        $fe = $YU->insertBefore($this->encdoc->createElementNS("\150\x74\164\160\x3a\x2f\57\x77\167\x77\56\167\x33\x2e\x6f\162\x67\57\62\60\x30\60\x2f\x30\x39\x2f\x78\155\154\144\x73\x69\147\43", "\144\163\x69\x67\x3a\113\x65\171\111\156\x66\157"), $YU->firstChild);
        $fe->appendChild($a8);
        x_:
        $q0 = $a8->appendChild($this->encdoc->createElementNS(self::XMLENCNS, "\x78\x65\x6e\143\x3a\x45\156\x63\x72\x79\160\x74\151\x6f\156\x4d\x65\164\150\157\144"));
        $q0->setAttribute("\101\x6c\x67\157\x72\x69\164\150\x6d", $WS->getAlgorith());
        if (empty($WS->name)) {
            goto R6;
        }
        $fe = $a8->appendChild($this->encdoc->createElementNS("\x68\164\x74\x70\72\x2f\57\167\x77\x77\x2e\x77\63\x2e\157\162\x67\x2f\62\x30\x30\x30\x2f\x30\x39\57\x78\x6d\x6c\x64\x73\x69\147\43", "\x64\163\x69\x67\x3a\x4b\x65\171\x49\156\146\x6f"));
        $fe->appendChild($this->encdoc->createElementNS("\x68\x74\x74\x70\x3a\x2f\x2f\167\167\x77\56\x77\x33\x2e\157\x72\147\57\62\60\x30\60\57\60\x39\57\170\155\154\144\x73\151\x67\43", "\144\163\x69\147\72\113\x65\x79\x4e\141\x6d\145", $WS->name));
        R6:
        $LX = $a8->appendChild($this->encdoc->createElementNS(self::XMLENCNS, "\x78\x65\x6e\x63\72\x43\151\x70\150\x65\162\104\x61\164\x61"));
        $LX->appendChild($this->encdoc->createElementNS(self::XMLENCNS, "\x78\145\156\143\x3a\x43\151\160\150\x65\x72\x56\141\x6c\x75\x65", $FS));
        if (!(is_array($this->references) && count($this->references) > 0)) {
            goto il;
        }
        $Gg = $a8->appendChild($this->encdoc->createElementNS(self::XMLENCNS, "\x78\x65\156\143\72\x52\145\x66\145\x72\145\x6e\143\145\114\151\x73\x74"));
        foreach ($this->references as $Ym => $Xi) {
            $w5 = $Xi["\162\145\x66\165\x72\151"];
            $Zb = $Gg->appendChild($this->encdoc->createElementNS(self::XMLENCNS, "\170\x65\x6e\143\x3a\104\141\x74\141\x52\145\x66\x65\x72\145\x6e\x63\x65"));
            $Zb->setAttribute("\x55\122\x49", "\x23" . $w5);
            yb:
        }
        Xb:
        il:
        return;
    }
    public function decryptKey($a8)
    {
        if ($a8->isEncrypted) {
            goto Ug;
        }
        throw new Exception("\x4b\x65\171\40\x69\x73\x20\x6e\x6f\x74\x20\105\x6e\x63\162\171\x70\164\145\x64");
        Ug:
        if (!empty($a8->key)) {
            goto ot;
        }
        throw new Exception("\x4b\145\171\40\x69\x73\x20\x6d\x69\163\x73\x69\156\x67\40\144\141\164\x61\40\164\x6f\40\160\x65\162\146\x6f\162\155\x20\164\150\145\x20\144\145\143\162\171\160\164\x69\x6f\156");
        ot:
        return $this->decryptNode($a8, false);
    }
    public function locateEncryptedData($ff)
    {
        if ($ff instanceof DOMDocument) {
            goto On;
        }
        $Jp = $ff->ownerDocument;
        goto Jv;
        On:
        $Jp = $ff;
        Jv:
        if (!$Jp) {
            goto at;
        }
        $B6 = new DOMXPath($Jp);
        $MN = "\x2f\x2f\52\x5b\x6c\x6f\143\141\154\55\x6e\x61\x6d\145\x28\51\75\47\105\x6e\143\x72\x79\160\x74\145\x64\x44\x61\164\x61\47\40\x61\x6e\x64\40\156\141\155\x65\x73\x70\141\x63\145\55\165\162\x69\x28\x29\x3d\47" . self::XMLENCNS . "\47\135";
        $sA = $B6->query($MN);
        return $sA->item(0);
        at:
        return null;
    }
    public function locateKey($tB = null)
    {
        if (!empty($tB)) {
            goto XG;
        }
        $tB = $this->rawNode;
        XG:
        if ($tB instanceof DOMNode) {
            goto Wr;
        }
        return null;
        Wr:
        if (!($Jp = $tB->ownerDocument)) {
            goto sA;
        }
        $B6 = new DOMXPath($Jp);
        $B6->registerNamespace("\170\155\x6c\x73\145\x63\x65\156\143", self::XMLENCNS);
        $MN = "\56\x2f\57\x78\155\154\163\x65\143\145\x6e\143\72\x45\x6e\x63\162\x79\160\164\151\x6f\156\115\x65\164\150\x6f\x64";
        $sA = $B6->query($MN, $tB);
        if (!($vR = $sA->item(0))) {
            goto FK;
        }
        $zN = $vR->getAttribute("\x41\154\147\157\x72\x69\x74\x68\x6d");
        try {
            $QH = new XMLSecurityKey($zN, array("\164\x79\x70\145" => "\x70\162\x69\x76\141\x74\145"));
        } catch (Exception $i0) {
            return null;
        }
        return $QH;
        FK:
        sA:
        return null;
    }
    public static function staticLocateKeyInfo($g8 = null, $tB = null)
    {
        if (!(empty($tB) || !$tB instanceof DOMNode)) {
            goto M5;
        }
        return null;
        M5:
        $Jp = $tB->ownerDocument;
        if ($Jp) {
            goto yH;
        }
        return null;
        yH:
        $B6 = new DOMXPath($Jp);
        $B6->registerNamespace("\x78\x6d\154\163\145\143\x65\x6e\x63", self::XMLENCNS);
        $B6->registerNamespace("\x78\155\154\163\x65\x63\x64\x73\x69\x67", XMLSecurityDSig::XMLDSIGNS);
        $MN = "\56\x2f\x78\155\x6c\163\x65\143\144\163\x69\x67\x3a\113\145\171\x49\x6e\146\157";
        $sA = $B6->query($MN, $tB);
        $vR = $sA->item(0);
        if ($vR) {
            goto ij;
        }
        return $g8;
        ij:
        foreach ($vR->childNodes as $Th) {
            switch ($Th->localName) {
                case "\113\x65\x79\x4e\x61\155\145":
                    if (empty($g8)) {
                        goto Jq;
                    }
                    $g8->name = $Th->nodeValue;
                    Jq:
                    goto AV;
                case "\113\x65\171\126\x61\x6c\x75\145":
                    foreach ($Th->childNodes as $Ti) {
                        switch ($Ti->localName) {
                            case "\104\123\101\x4b\145\x79\126\141\x6c\x75\x65":
                                throw new Exception("\104\123\x41\x4b\145\171\x56\141\x6c\165\x65\x20\143\x75\x72\162\145\156\164\x6c\x79\x20\x6e\157\164\40\163\165\x70\x70\x6f\x72\164\145\x64");
                            case "\x52\123\101\x4b\145\171\126\x61\x6c\165\145":
                                $YC = null;
                                $tW = null;
                                if (!($SN = $Ti->getElementsByTagName("\115\x6f\x64\x75\154\165\163")->item(0))) {
                                    goto WF;
                                }
                                $YC = base64_decode($SN->nodeValue);
                                WF:
                                if (!($r1 = $Ti->getElementsByTagName("\105\x78\x70\x6f\x6e\145\156\164")->item(0))) {
                                    goto YB;
                                }
                                $tW = base64_decode($r1->nodeValue);
                                YB:
                                if (!(empty($YC) || empty($tW))) {
                                    goto K9;
                                }
                                throw new Exception("\x4d\151\x73\163\x69\156\147\x20\115\157\144\165\154\165\163\40\x6f\x72\40\x45\170\x70\x6f\x6e\x65\156\164");
                                K9:
                                $QD = XMLSecurityKey::convertRSA($YC, $tW);
                                $g8->loadKey($QD);
                                goto N1;
                        }
                        ae:
                        N1:
                        VC:
                    }
                    bi:
                    goto AV;
                case "\x52\145\x74\162\x69\x65\166\141\154\115\x65\164\x68\157\144":
                    $az = $Th->getAttribute("\x54\x79\160\x65");
                    if (!($az !== "\150\x74\164\x70\72\x2f\57\x77\167\x77\56\167\63\x2e\157\x72\x67\57\62\x30\60\61\x2f\60\64\x2f\x78\155\x6c\x65\156\x63\x23\x45\156\143\162\171\160\x74\145\x64\113\145\x79")) {
                        goto af;
                    }
                    goto AV;
                    af:
                    $gZ = $Th->getAttribute("\x55\122\x49");
                    if (!($gZ[0] !== "\43")) {
                        goto eC;
                    }
                    goto AV;
                    eC:
                    $Iv = substr($gZ, 1);
                    $MN = "\57\57\x78\155\x6c\163\145\x63\145\x6e\143\x3a\105\156\x63\162\x79\160\x74\x65\x64\x4b\145\171\x5b\x40\x49\144\x3d\42" . XPath::filterAttrValue($Iv, XPath::DOUBLE_QUOTE) . "\42\x5d";
                    $nI = $B6->query($MN)->item(0);
                    if ($nI) {
                        goto tv;
                    }
                    throw new Exception("\125\156\x61\x62\x6c\145\x20\x74\157\40\154\157\x63\x61\164\145\x20\105\x6e\x63\162\x79\x70\x74\x65\x64\x4b\145\x79\x20\167\151\x74\x68\40\100\111\144\x3d\x27{$Iv}\47\56");
                    tv:
                    return XMLSecurityKey::fromEncryptedKeyElement($nI);
                case "\105\x6e\143\162\171\x70\164\x65\x64\x4b\x65\x79":
                    return XMLSecurityKey::fromEncryptedKeyElement($Th);
                case "\x58\65\x30\71\104\141\x74\141":
                    if (!($Ox = $Th->getElementsByTagName("\130\65\60\x39\x43\x65\x72\164\151\x66\151\x63\x61\164\x65"))) {
                        goto TE;
                    }
                    if (!($Ox->length > 0)) {
                        goto k_;
                    }
                    $UF = $Ox->item(0)->textContent;
                    $UF = str_replace(array("\15", "\xa", "\40"), '', $UF);
                    $UF = "\x2d\55\55\x2d\55\x42\x45\x47\111\x4e\x20\103\105\x52\x54\111\x46\111\103\x41\x54\105\x2d\55\x2d\x2d\x2d\12" . chunk_split($UF, 64, "\xa") . "\55\55\x2d\55\x2d\105\x4e\x44\40\103\x45\122\124\111\x46\x49\x43\x41\124\105\x2d\x2d\55\x2d\55\xa";
                    $g8->loadKey($UF, false, true);
                    k_:
                    TE:
                    goto AV;
            }
            p0:
            AV:
            BO:
        }
        Cx:
        return $g8;
    }
    public function locateKeyInfo($g8 = null, $tB = null)
    {
        if (!empty($tB)) {
            goto pM;
        }
        $tB = $this->rawNode;
        pM:
        return self::staticLocateKeyInfo($g8, $tB);
    }
}
