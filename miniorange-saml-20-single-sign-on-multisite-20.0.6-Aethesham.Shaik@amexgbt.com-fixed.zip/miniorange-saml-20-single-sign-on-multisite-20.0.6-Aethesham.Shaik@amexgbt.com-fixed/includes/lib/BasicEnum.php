<?php


abstract class BasicEnum
{
    private static $constCacheArray = NULL;
    public static function getConstants()
    {
        if (!(self::$constCacheArray == NULL)) {
            goto pr;
        }
        self::$constCacheArray = array();
        pr:
        $fT = get_called_class();
        if (array_key_exists($fT, self::$constCacheArray)) {
            goto Ab;
        }
        $AX = new ReflectionClass($fT);
        self::$constCacheArray[$fT] = $AX->getConstants();
        Ab:
        return self::$constCacheArray[$fT];
    }
    public static function isValidName($Ym, $mu = false)
    {
        $he = self::getConstants();
        if (!$mu) {
            goto Iv;
        }
        return array_key_exists($Ym, $he);
        Iv:
        $EE = array_map("\163\x74\162\164\157\154\157\167\145\162", array_keys($he));
        return in_array(strtolower($Ym), $EE);
    }
    public static function isValidValue($jR, $mu = true)
    {
        $js = array_values(self::getConstants());
        return in_array($jR, $js, $mu);
    }
}
