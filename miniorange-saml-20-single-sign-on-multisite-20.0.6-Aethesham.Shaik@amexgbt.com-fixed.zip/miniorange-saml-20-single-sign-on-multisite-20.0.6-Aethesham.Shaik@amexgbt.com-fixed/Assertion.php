<?php


include_once "\125\x74\151\x6c\151\x74\151\x65\163\56\x70\150\x70";
include_once "\170\x6d\154\163\x65\143\x6c\151\x62\x73\56\x70\150\160";
use RobRichards\XMLSecLibs\XMLSecurityKey;
use RobRichards\XMLSecLibs\XMLSecurityDSig;
use RobRichards\XMLSecLibs\XMLSecEnc;
class SAML2_Assertion
{
    private $id;
    private $issueInstant;
    private $issuer;
    private $nameId;
    private $encryptedNameId;
    private $encryptedAttribute;
    private $encryptionKey;
    private $notBefore;
    private $notOnOrAfter;
    private $validAudiences;
    private $sessionNotOnOrAfter;
    private $sessionIndex;
    private $authnInstant;
    private $authnContextClassRef;
    private $authnContextDecl;
    private $authnContextDeclRef;
    private $AuthenticatingAuthority;
    private $attributes;
    private $nameFormat;
    private $signatureKey;
    private $certificates;
    private $signatureData;
    private $requiredEncAttributes;
    private $SubjectConfirmation;
    private $privateKeyUrl;
    protected $wasSignedAtConstruction = FALSE;
    public function __construct(DOMElement $tn = NULL, $rm)
    {
        $this->id = Utilities::generateId();
        $this->issueInstant = Utilities::generateTimestamp();
        $this->issuer = '';
        $this->authnInstant = Utilities::generateTimestamp();
        $this->attributes = array();
        $this->nameFormat = "\x75\x72\x6e\72\x6f\x61\163\x69\x73\x3a\x6e\141\155\145\x73\72\x74\143\72\123\x41\x4d\114\72\x31\x2e\61\72\156\141\x6d\x65\151\144\x2d\x66\x6f\162\x6d\141\164\x3a\165\x6e\163\x70\x65\x63\x69\146\x69\145\x64";
        $this->certificates = array();
        $this->AuthenticatingAuthority = array();
        $this->SubjectConfirmation = array();
        if (!($tn === NULL)) {
            goto ib;
        }
        return;
        ib:
        if (!($tn->localName === "\105\x6e\143\162\x79\160\164\x65\144\101\x73\163\145\162\164\x69\x6f\x6e")) {
            goto vT;
        }
        $Xu = Utilities::xpQuery($tn, "\56\57\x78\145\x6e\x63\72\x45\x6e\x63\x72\x79\x70\x74\x65\144\104\141\x74\x61");
        $DQ = Utilities::xpQuery($tn, "\56\57\170\x65\156\143\72\x45\x6e\143\162\171\160\164\145\144\x44\141\x74\141\x2f\x64\x73\72\x4b\x65\x79\x49\x6e\146\x6f\57\170\145\x6e\x63\x3a\x45\x6e\143\x72\171\160\164\x65\144\x4b\145\x79");
        $Z7 = '';
        if (empty($DQ)) {
            goto QJ;
        }
        $Z7 = $DQ[0]->firstChild->getAttribute("\x41\154\147\157\x72\151\164\x68\x6d");
        goto xD;
        QJ:
        $DQ = Utilities::xpQuery($tn, "\56\x2f\x78\145\156\143\x3a\x45\x6e\x63\x72\x79\x70\164\145\144\x4b\x65\171\x2f\170\145\156\x63\x3a\x45\156\143\162\x79\160\164\151\x6f\156\x4d\x65\x74\150\157\144");
        $Z7 = $DQ[0]->getAttribute("\101\154\147\x6f\x72\151\x74\150\x6d");
        xD:
        $up = Utilities::getEncryptionAlgorithm($Z7);
        if (count($Xu) === 0) {
            goto UM;
        }
        if (count($Xu) > 1) {
            goto tt;
        }
        goto Ec;
        UM:
        throw new Exception("\115\x69\163\x73\x69\156\147\40\x65\156\x63\x72\x79\x70\164\x65\144\x20\x64\141\164\x61\x20\151\156\x20\x3c\x73\x61\155\154\72\x45\156\143\162\171\160\x74\145\144\101\x73\163\x65\x72\164\x69\157\156\x3e\56");
        goto Ec;
        tt:
        throw new Exception("\x4d\157\162\145\40\164\x68\141\156\40\157\156\x65\40\145\x6e\143\162\x79\160\x74\x65\144\x20\144\x61\164\141\x20\145\154\x65\x6d\x65\156\x74\40\151\156\x20\74\x73\141\x6d\154\72\x45\x6e\x63\x72\171\x70\164\145\x64\x41\163\163\145\x72\164\x69\x6f\x6e\x3e\x2e");
        Ec:
        $u_ = new XMLSecurityKey($up, array("\x74\x79\160\145" => "\160\162\151\166\141\164\145"));
        $ks = get_site_option("\155\x6f\137\163\141\155\154\x5f\143\x75\162\162\x65\156\164\137\x63\x65\x72\x74\137\x70\x72\151\x76\x61\x74\145\137\153\145\171");
        $u_->loadKey($rm, FALSE);
        $xO = array();
        $tn = Utilities::decryptElement($Xu[0], $u_, $xO);
        vT:
        if ($tn->hasAttribute("\111\104")) {
            goto IC;
        }
        throw new Exception("\115\151\x73\163\151\156\x67\x20\x49\x44\40\141\x74\164\x72\x69\x62\x75\164\145\40\x6f\x6e\40\x53\101\x4d\x4c\40\x61\163\x73\x65\162\x74\x69\x6f\156\x2e");
        IC:
        $this->id = $tn->getAttribute("\x49\104");
        if (!($tn->getAttribute("\126\145\162\x73\151\157\156") !== "\62\x2e\60")) {
            goto Ma;
        }
        throw new Exception("\x55\x6e\x73\x75\160\x70\157\x72\164\x65\144\x20\166\145\162\x73\x69\157\x6e\72\x20" . $tn->getAttribute("\126\145\162\x73\151\157\x6e"));
        Ma:
        $this->issueInstant = Utilities::xsDateTimeToTimestamp($tn->getAttribute("\x49\x73\x73\165\145\111\156\x73\164\x61\x6e\164"));
        $NY = Utilities::xpQuery($tn, "\56\57\x73\141\155\154\137\141\x73\163\x65\x72\x74\x69\x6f\x6e\72\111\x73\163\x75\145\162");
        if (!empty($NY)) {
            goto H1;
        }
        throw new Exception("\115\151\163\x73\151\156\147\x20\74\x73\141\x6d\x6c\72\111\x73\x73\x75\145\x72\76\40\151\x6e\x20\x61\x73\163\145\x72\x74\x69\x6f\x6e\x2e");
        H1:
        $this->issuer = trim($NY[0]->textContent);
        $this->parseConditions($tn);
        $this->parseAuthnStatement($tn);
        $this->parseAttributes($tn);
        $this->parseEncryptedAttributes($tn);
        $this->parseSignature($tn);
        $this->parseSubject($tn);
    }
    private function parseSubject(DOMElement $tn)
    {
        $xe = Utilities::xpQuery($tn, "\x2e\57\163\x61\x6d\x6c\x5f\x61\x73\x73\x65\162\x74\151\x6f\156\x3a\123\x75\142\152\x65\143\x74");
        if (empty($xe)) {
            goto nE;
        }
        if (count($xe) > 1) {
            goto iH;
        }
        goto QX;
        nE:
        return;
        goto QX;
        iH:
        throw new Exception("\115\x6f\x72\145\x20\164\150\x61\x6e\40\x6f\x6e\145\x20\74\x73\141\x6d\x6c\x3a\123\x75\x62\x6a\145\143\x74\x3e\x20\x69\156\40\74\163\141\x6d\154\x3a\x41\x73\163\145\x72\x74\x69\x6f\156\76\56");
        QX:
        $xe = $xe[0];
        $PB = Utilities::xpQuery($xe, "\x2e\57\163\x61\x6d\154\137\141\x73\x73\x65\162\164\151\157\156\x3a\116\x61\155\x65\x49\x44\40\x7c\40\56\x2f\x73\141\155\154\137\x61\163\163\x65\162\164\x69\x6f\156\x3a\105\156\143\x72\171\x70\x74\x65\144\x49\104\x2f\x78\145\156\x63\x3a\x45\156\143\x72\171\x70\x74\145\144\104\x61\164\x61");
        if (empty($PB)) {
            goto cJ;
        }
        if (count($PB) > 1) {
            goto JK;
        }
        goto yX;
        cJ:
        if ($_POST["\122\x65\154\x61\x79\x53\x74\141\164\x65"] == "\164\x65\163\x74\x56\141\x6c\x69\144\141\x74\145" or $_POST["\122\145\x6c\141\x79\123\x74\x61\164\145"] == "\x74\145\x73\164\x4e\x65\167\x43\145\x72\164\151\146\151\143\x61\164\145") {
            goto bd;
        }
        wp_die("\x57\145\x20\x63\157\165\x6c\144\x20\156\157\x74\x20\x73\151\147\156\40\x79\157\x75\40\151\x6e\x2e\x20\x50\x6c\x65\141\x73\x65\40\143\x6f\x6e\x74\141\x63\164\40\x79\157\x75\x72\40\141\x64\x6d\151\x6e\x69\x73\x74\x72\141\x74\x6f\x72");
        goto u4;
        bd:
        echo "\x3c\144\x69\x76\x20\163\164\171\x6c\145\75\42\x66\x6f\156\164\55\146\141\x6d\151\154\171\72\103\141\x6c\x69\142\162\x69\x3b\160\141\144\x64\151\156\147\72\60\x20\x33\x25\73\42\76";
        echo "\x3c\144\x69\166\40\163\x74\x79\154\x65\75\x22\x63\157\154\x6f\162\x3a\40\43\x61\x39\x34\x34\x34\x32\73\x62\141\x63\x6b\x67\x72\157\x75\156\x64\x2d\x63\x6f\154\157\x72\72\x20\x23\x66\x32\x64\145\x64\x65\x3b\x70\141\x64\x64\151\x6e\x67\x3a\x20\x31\x35\x70\170\73\155\x61\162\147\x69\x6e\55\x62\x6f\164\164\x6f\x6d\72\40\x32\60\160\170\x3b\164\145\x78\x74\55\x61\x6c\151\147\x6e\x3a\143\x65\156\164\x65\x72\73\x62\157\162\x64\145\x72\x3a\x31\160\x78\40\x73\x6f\x6c\x69\144\40\43\105\66\102\63\x42\62\x3b\x66\157\156\164\x2d\x73\151\x7a\145\x3a\x31\70\x70\164\73\42\x3e\x20\105\x52\x52\117\x52\x3c\57\x64\x69\166\x3e\xd\xa\x20\x20\x20\x20\x20\40\x20\40\x20\x20\x20\x3c\x64\151\x76\40\163\x74\x79\154\x65\75\42\x63\x6f\154\157\x72\x3a\x20\x23\141\x39\64\64\64\62\73\146\157\156\164\55\x73\x69\x7a\145\x3a\x31\64\x70\164\73\x20\x6d\141\162\147\151\156\55\142\x6f\x74\x74\157\155\72\x32\x30\x70\x78\x3b\42\76\74\160\x3e\74\163\164\x72\157\156\147\76\105\x72\x72\x6f\162\72\x20\74\x2f\x73\164\x72\x6f\x6e\147\76\x4d\151\x73\163\x69\x6e\147\40\x20\x4e\x61\155\x65\111\x44\40\x6f\x72\40\x45\156\x63\x72\171\160\164\x65\x64\x49\104\40\151\x6e\x20\x53\101\115\x4c\x20\x52\x65\163\x70\x6f\x6e\x73\x65\x3c\x2f\x70\76\15\xa\x20\x20\x20\x20\40\40\x20\40\40\x20\x20\x20\40\x20\40\40\x3c\x70\76\x50\x6c\x65\x61\163\145\x20\143\x6f\x6e\164\x61\143\164\40\x79\157\165\x72\x20\141\144\x6d\x69\x6e\151\x73\164\162\x61\164\157\x72\40\x61\x6e\x64\x20\162\x65\160\x6f\162\164\x20\x74\x68\x65\x20\146\x6f\154\x6c\x6f\x77\151\x6e\147\40\145\162\162\157\x72\72\x3c\x2f\x70\76\xd\12\40\x20\x20\x20\x20\x20\x20\40\x20\40\40\40\40\x20\x20\40\x3c\x70\x3e\x3c\x73\164\162\157\x6e\147\x3e\120\157\163\x73\151\x62\154\x65\x20\x43\141\x75\163\x65\x3a\74\57\163\164\x72\157\156\147\76\40\x4e\141\x6d\145\111\104\40\156\157\x74\40\x66\x6f\x75\156\144\x20\x69\x6e\40\123\101\115\114\x20\122\145\163\160\157\156\x73\x65\x20\163\165\x62\152\145\143\x74\x3c\x2f\x70\x3e\xd\12\x20\40\40\x20\x20\x20\x20\x20\x20\x20\x20\40\40\x20\40\40\x3c\x2f\x64\151\166\76\xd\xa\x20\40\x20\40\40\40\40\40\40\x20\40\40\x20\40\x20\40\74\x64\x69\166\40\163\164\x79\154\145\75\42\155\x61\162\x67\x69\156\x3a\x33\x25\x3b\x64\151\163\x70\x6c\x61\171\x3a\x62\x6c\x6f\x63\x6b\73\x74\145\x78\x74\x2d\141\154\x69\x67\156\72\143\145\156\164\145\162\x3b\x22\76\xd\12\x20\40\40\40\x20\40\x20\x20\x20\x20\x20\40\40\40\x20\40\x3c\x64\151\166\40\163\164\x79\x6c\x65\75\42\155\x61\162\x67\x69\x6e\72\x33\45\x3b\x64\151\x73\x70\154\141\x79\x3a\x62\x6c\x6f\x63\x6b\x3b\x74\145\x78\164\55\141\154\x69\147\156\x3a\x63\145\x6e\164\x65\162\73\42\76\74\151\156\160\x75\x74\40\163\164\171\x6c\145\75\x22\x70\141\x64\x64\151\x6e\147\x3a\x31\x25\x3b\167\151\144\x74\150\x3a\x31\60\60\160\x78\73\x62\141\x63\x6b\x67\162\x6f\x75\156\x64\72\40\x23\x30\x30\x39\x31\x43\104\40\x6e\x6f\x6e\145\x20\x72\145\x70\x65\x61\164\x20\x73\x63\162\157\154\x6c\x20\60\45\40\x30\x25\x3b\143\x75\162\x73\x6f\162\72\x20\160\x6f\x69\156\164\145\x72\x3b\146\x6f\x6e\164\55\163\151\172\x65\x3a\61\x35\160\x78\73\142\x6f\162\x64\145\162\x2d\167\x69\x64\x74\x68\x3a\40\x31\160\170\73\142\157\162\144\145\x72\55\x73\x74\171\154\x65\72\x20\163\157\154\151\144\x3b\x62\157\162\x64\145\x72\x2d\162\141\144\x69\x75\x73\72\40\63\x70\x78\x3b\x77\x68\151\x74\145\55\x73\160\141\143\145\72\40\x6e\157\x77\x72\x61\x70\73\142\x6f\x78\55\163\x69\172\151\156\x67\72\x20\x62\x6f\162\144\145\162\55\x62\157\170\73\142\x6f\x72\x64\x65\x72\55\x63\157\x6c\157\162\x3a\40\43\x30\x30\x37\x33\x41\101\x3b\x62\157\170\55\x73\150\141\144\x6f\x77\72\x20\x30\160\x78\40\61\x70\x78\40\x30\x70\x78\40\162\x67\142\141\50\x31\x32\x30\x2c\40\x32\x30\x30\54\40\x32\x33\x30\x2c\40\60\56\x36\51\x20\151\156\163\145\x74\73\x63\x6f\154\157\x72\x3a\40\43\x46\106\x46\73\x22\164\x79\x70\145\x3d\x22\142\165\164\164\x6f\156\42\x20\166\x61\154\165\145\x3d\x22\104\x6f\x6e\x65\42\x20\157\x6e\103\154\x69\x63\153\x3d\42\x73\145\x6c\x66\56\x63\154\157\x73\x65\50\51\73\x22\76\74\57\x64\x69\166\x3e";
        exit;
        u4:
        goto yX;
        JK:
        throw new Exception("\115\157\162\145\x20\x74\150\x61\156\x20\157\x6e\x65\x20\x3c\x73\x61\155\154\72\x4e\x61\155\x65\x49\x44\x3e\x20\157\x72\40\74\x73\x61\155\x6c\x3a\x45\x6e\143\x72\171\x70\x74\145\x64\x44\x3e\x20\x69\x6e\x20\x3c\x73\x61\155\x6c\x3a\123\165\x62\x6a\x65\x63\164\x3e\x2e");
        yX:
        $PB = $PB[0];
        if ($PB->localName === "\x45\156\x63\162\x79\x70\164\145\144\104\x61\x74\x61") {
            goto f6;
        }
        $this->nameId = Utilities::parseNameId($PB);
        goto Hn;
        f6:
        $this->encryptedNameId = $PB;
        Hn:
    }
    private function parseConditions(DOMElement $tn)
    {
        $OH = Utilities::xpQuery($tn, "\x2e\57\163\141\155\154\x5f\141\x73\163\x65\162\x74\151\x6f\x6e\x3a\x43\x6f\x6e\x64\x69\x74\151\157\x6e\x73");
        if (empty($OH)) {
            goto vR;
        }
        if (count($OH) > 1) {
            goto fC;
        }
        goto PG;
        vR:
        return;
        goto PG;
        fC:
        throw new Exception("\115\157\x72\x65\40\164\x68\x61\156\40\157\156\145\40\74\163\x61\155\x6c\72\103\157\x6e\144\151\164\151\157\156\x73\x3e\40\x69\156\x20\x3c\163\x61\x6d\154\x3a\101\x73\x73\x65\162\164\x69\x6f\156\76\56");
        PG:
        $OH = $OH[0];
        if (!$OH->hasAttribute("\x4e\157\164\x42\145\x66\x6f\162\x65")) {
            goto CA;
        }
        $mv = Utilities::xsDateTimeToTimestamp($OH->getAttribute("\x4e\157\164\102\x65\146\x6f\x72\145"));
        if (!($this->notBefore === NULL || $this->notBefore < $mv)) {
            goto RT;
        }
        $this->notBefore = $mv;
        RT:
        CA:
        if (!$OH->hasAttribute("\116\x6f\x74\117\156\117\162\101\x66\x74\145\162")) {
            goto Cj;
        }
        $KC = Utilities::xsDateTimeToTimestamp($OH->getAttribute("\x4e\x6f\164\117\x6e\117\162\101\146\164\x65\162"));
        if (!($this->notOnOrAfter === NULL || $this->notOnOrAfter > $KC)) {
            goto d0;
        }
        $this->notOnOrAfter = $KC;
        d0:
        Cj:
        $tB = $OH->firstChild;
        in:
        if (!($tB !== NULL)) {
            goto c5;
        }
        if (!$tB instanceof DOMText) {
            goto Vx;
        }
        goto qZ;
        Vx:
        if (!($tB->namespaceURI !== "\x75\162\x6e\x3a\157\141\163\x69\163\72\156\x61\x6d\145\163\x3a\x74\143\72\x53\x41\x4d\x4c\72\62\x2e\60\72\x61\x73\163\x65\x72\x74\x69\x6f\156")) {
            goto hE;
        }
        throw new Exception("\x55\x6e\153\156\157\167\x6e\40\x6e\x61\155\145\163\160\141\143\x65\x20\x6f\146\x20\x63\157\156\144\x69\x74\x69\157\x6e\x3a\x20" . var_export($tB->namespaceURI, TRUE));
        hE:
        switch ($tB->localName) {
            case "\x41\165\x64\151\x65\x6e\x63\x65\122\x65\x73\164\162\151\x63\164\x69\157\156":
                $ST = Utilities::extractStrings($tB, "\x75\x72\156\72\x6f\141\163\151\163\72\x6e\x61\155\145\x73\x3a\x74\143\72\123\101\115\114\72\x32\56\60\x3a\141\163\163\x65\162\164\x69\157\156", "\101\165\x64\x69\145\x6e\143\145");
                if ($this->validAudiences === NULL) {
                    goto d7;
                }
                $this->validAudiences = array_intersect($this->validAudiences, $ST);
                goto YZ;
                d7:
                $this->validAudiences = $ST;
                YZ:
                goto lg;
            case "\x4f\156\x65\x54\151\155\145\x55\x73\x65":
                goto lg;
            case "\120\162\157\x78\171\122\x65\x73\164\x72\151\x63\x74\x69\x6f\156":
                goto lg;
            default:
                throw new Exception("\x55\156\153\156\x6f\167\156\40\143\x6f\x6e\x64\151\x74\151\157\156\72\40" . var_export($tB->localName, TRUE));
        }
        ZE:
        lg:
        qZ:
        $tB = $tB->nextSibling;
        goto in;
        c5:
    }
    private function parseAuthnStatement(DOMElement $tn)
    {
        $qN = Utilities::xpQuery($tn, "\x2e\57\x73\x61\155\154\137\x61\163\x73\x65\162\164\x69\x6f\156\x3a\101\x75\x74\x68\156\x53\x74\x61\x74\x65\x6d\145\x6e\164");
        if (empty($qN)) {
            goto Mt;
        }
        if (count($qN) > 1) {
            goto Q0;
        }
        goto Bp;
        Mt:
        $this->authnInstant = NULL;
        return;
        goto Bp;
        Q0:
        throw new Exception("\x4d\x6f\162\x65\40\x74\150\x61\164\40\157\156\x65\40\74\x73\141\155\154\72\x41\165\x74\x68\156\123\x74\x61\164\145\x6d\145\156\164\76\40\151\156\40\x3c\163\141\155\154\72\101\163\x73\x65\162\x74\x69\157\x6e\x3e\40\x6e\x6f\x74\40\x73\165\x70\x70\x6f\x72\x74\x65\x64\x2e");
        Bp:
        $u3 = $qN[0];
        if ($u3->hasAttribute("\x41\x75\164\x68\x6e\111\x6e\163\164\141\156\164")) {
            goto v3;
        }
        throw new Exception("\x4d\151\x73\x73\151\156\x67\x20\162\145\x71\165\151\x72\145\144\x20\x41\165\x74\x68\x6e\111\156\163\164\x61\x6e\164\40\x61\164\x74\162\x69\x62\165\164\145\40\x6f\156\40\x3c\x73\x61\x6d\154\72\101\x75\x74\x68\x6e\123\x74\x61\164\145\x6d\145\156\x74\x3e\x2e");
        v3:
        $this->authnInstant = Utilities::xsDateTimeToTimestamp($u3->getAttribute("\101\165\x74\x68\156\111\x6e\x73\164\x61\156\x74"));
        if (!$u3->hasAttribute("\x53\x65\163\163\151\x6f\156\116\x6f\x74\x4f\156\x4f\162\101\146\x74\145\x72")) {
            goto Bi;
        }
        $this->sessionNotOnOrAfter = Utilities::xsDateTimeToTimestamp($u3->getAttribute("\x53\145\x73\x73\x69\157\156\x4e\x6f\x74\117\x6e\x4f\162\x41\146\164\145\x72"));
        Bi:
        if (!$u3->hasAttribute("\123\145\x73\x73\151\157\156\111\x6e\x64\x65\x78")) {
            goto Lr;
        }
        $this->sessionIndex = $u3->getAttribute("\123\x65\x73\163\x69\157\x6e\111\156\x64\145\x78");
        Lr:
        $this->parseAuthnContext($u3);
    }
    private function parseAuthnContext(DOMElement $dH)
    {
        $nR = Utilities::xpQuery($dH, "\56\57\163\x61\x6d\x6c\x5f\141\163\163\x65\x72\x74\151\x6f\156\x3a\101\165\x74\x68\x6e\x43\x6f\156\x74\x65\x78\x74");
        if (count($nR) > 1) {
            goto KB;
        }
        if (empty($nR)) {
            goto Ay;
        }
        goto a4;
        KB:
        throw new Exception("\115\157\x72\x65\40\164\x68\141\156\40\157\x6e\x65\40\x3c\163\141\x6d\154\72\101\165\x74\150\x6e\103\157\156\x74\x65\170\164\76\x20\x69\x6e\40\x3c\163\x61\155\x6c\x3a\101\165\x74\150\x6e\123\164\x61\x74\145\155\x65\156\164\x3e\x2e");
        goto a4;
        Ay:
        throw new Exception("\x4d\151\163\163\x69\156\x67\40\162\x65\x71\x75\x69\162\145\x64\40\74\x73\x61\155\x6c\x3a\x41\x75\164\150\156\x43\157\156\x74\x65\x78\164\76\40\x69\x6e\40\x3c\x73\141\155\x6c\x3a\x41\165\164\150\156\x53\x74\141\164\x65\155\145\156\164\76\56");
        a4:
        $xS = $nR[0];
        $RB = Utilities::xpQuery($xS, "\x2e\x2f\163\141\155\x6c\x5f\x61\163\x73\x65\162\x74\x69\157\156\x3a\101\165\164\150\x6e\x43\x6f\x6e\164\x65\170\x74\104\x65\x63\154\122\x65\146");
        if (count($RB) > 1) {
            goto Ih;
        }
        if (count($RB) === 1) {
            goto LS;
        }
        goto A_;
        Ih:
        throw new Exception("\115\157\x72\145\40\164\150\141\x6e\40\157\156\145\x20\74\x73\x61\x6d\x6c\72\x41\x75\x74\x68\x6e\103\157\x6e\164\x65\170\x74\104\145\143\x6c\x52\145\146\x3e\x20\x66\157\x75\x6e\144\x3f");
        goto A_;
        LS:
        $this->setAuthnContextDeclRef(trim($RB[0]->textContent));
        A_:
        $zO = Utilities::xpQuery($xS, "\56\57\163\x61\155\x6c\137\141\x73\163\x65\162\164\x69\157\156\72\101\x75\164\150\156\103\157\156\x74\x65\x78\x74\x44\x65\x63\154");
        if (count($zO) > 1) {
            goto nf;
        }
        if (count($zO) === 1) {
            goto It;
        }
        goto LB;
        nf:
        throw new Exception("\x4d\157\162\x65\40\164\150\x61\156\40\x6f\156\x65\40\74\x73\141\155\x6c\x3a\101\x75\x74\150\x6e\x43\x6f\156\164\x65\170\164\104\145\143\x6c\x3e\x20\x66\x6f\165\x6e\x64\77");
        goto LB;
        It:
        $this->setAuthnContextDecl(new SAML2_XML_Chunk($zO[0]));
        LB:
        $Vb = Utilities::xpQuery($xS, "\x2e\57\163\141\155\x6c\x5f\141\163\163\x65\162\x74\151\x6f\156\72\101\165\x74\150\156\103\157\156\164\145\170\164\103\154\141\x73\163\x52\145\x66");
        if (count($Vb) > 1) {
            goto Rp;
        }
        if (count($Vb) === 1) {
            goto Lf;
        }
        goto XH;
        Rp:
        throw new Exception("\x4d\x6f\162\145\x20\164\x68\141\156\x20\x6f\x6e\x65\x20\74\163\x61\x6d\154\x3a\101\165\x74\150\156\103\x6f\x6e\164\x65\x78\x74\x43\154\141\163\163\x52\145\x66\76\x20\151\x6e\40\74\x73\141\x6d\x6c\x3a\x41\165\x74\150\x6e\x43\157\x6e\x74\x65\x78\164\x3e\x2e");
        goto XH;
        Lf:
        $this->setAuthnContextClassRef(trim($Vb[0]->textContent));
        XH:
        if (!(empty($this->authnContextClassRef) && empty($this->authnContextDecl) && empty($this->authnContextDeclRef))) {
            goto Qs;
        }
        throw new Exception("\x4d\151\163\x73\151\156\x67\x20\145\151\x74\x68\145\162\x20\x3c\163\141\155\154\x3a\101\165\x74\x68\156\x43\157\x6e\164\145\170\164\x43\x6c\141\x73\163\x52\x65\x66\76\x20\x6f\162\40\74\x73\x61\155\154\72\101\165\164\x68\x6e\x43\157\156\164\x65\x78\164\104\145\x63\x6c\122\x65\x66\x3e\40\157\x72\40\74\x73\x61\155\154\x3a\101\x75\x74\150\156\x43\x6f\156\x74\x65\170\164\104\x65\x63\154\76");
        Qs:
        $this->AuthenticatingAuthority = Utilities::extractStrings($xS, "\165\x72\156\x3a\x6f\141\x73\x69\163\72\156\x61\155\x65\x73\72\x74\143\x3a\123\101\115\x4c\72\x32\56\60\72\x61\163\x73\145\x72\164\x69\157\x6e", "\101\x75\164\x68\145\156\x74\x69\x63\x61\x74\x69\x6e\x67\101\x75\x74\x68\x6f\x72\151\164\x79");
    }
    private function parseAttributes(DOMElement $tn)
    {
        $vw = TRUE;
        $nZ = Utilities::xpQuery($tn, "\56\x2f\163\x61\155\154\x5f\x61\x73\163\145\x72\x74\151\x6f\156\72\101\164\x74\x72\151\142\x75\164\x65\x53\x74\x61\164\x65\x6d\145\156\x74\x2f\163\x61\155\x6c\x5f\x61\x73\163\145\162\x74\x69\x6f\156\x3a\101\x74\164\x72\x69\142\x75\164\145");
        foreach ($nZ as $n1) {
            if ($n1->hasAttribute("\116\141\155\x65")) {
                goto u0;
            }
            throw new Exception("\x4d\151\x73\163\x69\156\147\40\156\141\x6d\x65\x20\x6f\156\x20\x3c\163\141\155\x6c\72\x41\164\x74\162\151\x62\165\x74\145\x3e\x20\x65\x6c\x65\x6d\x65\x6e\164\x2e");
            u0:
            $Ym = $n1->getAttribute("\x4e\x61\155\x65");
            if ($n1->hasAttribute("\116\x61\155\x65\x46\x6f\162\x6d\141\164")) {
                goto rk;
            }
            $ZD = "\165\162\x6e\x3a\x6f\x61\x73\x69\163\x3a\156\141\155\x65\x73\72\x74\x63\x3a\x53\x41\115\114\x3a\x31\56\x31\x3a\156\x61\155\x65\x69\x64\55\146\x6f\162\155\x61\x74\x3a\165\156\163\x70\x65\143\x69\146\151\x65\x64";
            goto Ww;
            rk:
            $ZD = $n1->getAttribute("\116\141\x6d\x65\106\x6f\162\x6d\141\x74");
            Ww:
            if ($vw) {
                goto gb;
            }
            if (!($this->nameFormat !== $ZD)) {
                goto hF;
            }
            $this->nameFormat = "\x75\162\156\72\157\141\x73\151\163\72\156\x61\155\145\163\x3a\164\x63\x3a\123\101\x4d\x4c\x3a\x31\56\x31\x3a\x6e\x61\x6d\145\151\x64\55\146\157\162\155\x61\164\72\x75\x6e\163\x70\145\143\x69\146\x69\145\x64";
            hF:
            goto G1;
            gb:
            $this->nameFormat = $ZD;
            $vw = FALSE;
            G1:
            if (array_key_exists($Ym, $this->attributes)) {
                goto r9;
            }
            $this->attributes[$Ym] = array();
            r9:
            $js = Utilities::xpQuery($n1, "\56\x2f\x73\141\155\x6c\x5f\x61\x73\163\x65\x72\x74\x69\x6f\x6e\72\x41\x74\164\162\151\142\165\164\145\126\x61\154\165\x65");
            foreach ($js as $jR) {
                $this->attributes[$Ym][] = trim($jR->textContent);
                gx:
            }
            IY:
            E4:
        }
        t7:
    }
    private function parseEncryptedAttributes(DOMElement $tn)
    {
        $this->encryptedAttribute = Utilities::xpQuery($tn, "\x2e\x2f\x73\x61\x6d\154\137\x61\x73\x73\145\162\x74\151\157\156\x3a\x41\164\x74\x72\x69\x62\x75\164\x65\123\164\x61\x74\145\x6d\145\156\x74\x2f\x73\x61\155\154\137\x61\x73\x73\x65\x72\164\151\x6f\156\72\105\x6e\143\x72\x79\x70\x74\x65\144\101\x74\164\x72\x69\142\165\x74\x65");
    }
    private function parseSignature(DOMElement $tn)
    {
        $ad = Utilities::validateElement($tn);
        if (!($ad !== FALSE)) {
            goto EH;
        }
        $this->wasSignedAtConstruction = TRUE;
        $this->certificates = $ad["\x43\x65\x72\x74\151\x66\x69\x63\141\164\145\x73"];
        $this->signatureData = $ad;
        EH:
    }
    public function validate(XMLSecurityKey $u_)
    {
        if (!($this->signatureData === NULL)) {
            goto AP;
        }
        return FALSE;
        AP:
        Utilities::validateSignature($this->signatureData, $u_);
        return TRUE;
    }
    public function getId()
    {
        return $this->id;
    }
    public function setId($Iv)
    {
        $this->id = $Iv;
    }
    public function getIssueInstant()
    {
        return $this->issueInstant;
    }
    public function setIssueInstant($hR)
    {
        $this->issueInstant = $hR;
    }
    public function getIssuer()
    {
        return $this->issuer;
    }
    public function setIssuer($NY)
    {
        $this->issuer = $NY;
    }
    public function getNameId()
    {
        if (!($this->encryptedNameId !== NULL)) {
            goto xh;
        }
        throw new Exception("\101\x74\x74\x65\x6d\x70\164\145\144\x20\164\157\x20\x72\145\x74\162\x69\x65\x76\x65\40\145\156\143\x72\x79\x70\x74\x65\x64\x20\x4e\x61\155\145\x49\x44\x20\167\x69\x74\150\x6f\x75\164\40\x64\x65\143\x72\171\x70\164\x69\x6e\x67\x20\151\x74\40\x66\x69\x72\x73\x74\x2e");
        xh:
        return $this->nameId;
    }
    public function setNameId($PB)
    {
        $this->nameId = $PB;
    }
    public function isNameIdEncrypted()
    {
        if (!($this->encryptedNameId !== NULL)) {
            goto fq;
        }
        return TRUE;
        fq:
        return FALSE;
    }
    public function encryptNameId(XMLSecurityKey $u_)
    {
        $Jp = new DOMDocument();
        $YU = $Jp->createElement("\x72\157\157\x74");
        $Jp->appendChild($YU);
        Utilities::addNameId($YU, $this->nameId);
        $PB = $YU->firstChild;
        Utilities::getContainer()->debugMessage($PB, "\145\156\143\x72\171\x70\x74");
        $iS = new XMLSecEnc();
        $iS->setNode($PB);
        $iS->type = XMLSecEnc::Element;
        $zR = new XMLSecurityKey(XMLSecurityKey::AES128_CBC);
        $zR->generateSessionKey();
        $iS->encryptKey($u_, $zR);
        $this->encryptedNameId = $iS->encryptNode($zR);
        $this->nameId = NULL;
    }
    public function decryptNameId(XMLSecurityKey $u_, array $xO = array())
    {
        if (!($this->encryptedNameId === NULL)) {
            goto mT;
        }
        return;
        mT:
        $PB = Utilities::decryptElement($this->encryptedNameId, $u_, $xO);
        Utilities::getContainer()->debugMessage($PB, "\x64\x65\x63\162\x79\160\x74");
        $this->nameId = Utilities::parseNameId($PB);
        $this->encryptedNameId = NULL;
    }
    public function decryptAttributes(XMLSecurityKey $u_, array $xO = array())
    {
        if (!($this->encryptedAttribute === NULL)) {
            goto RB;
        }
        return;
        RB:
        $vw = TRUE;
        $nZ = $this->encryptedAttribute;
        foreach ($nZ as $wY) {
            $n1 = Utilities::decryptElement($wY->getElementsByTagName("\105\156\143\162\x79\x70\164\x65\x64\104\141\164\141")->item(0), $u_, $xO);
            if ($n1->hasAttribute("\116\141\155\145")) {
                goto RZ;
            }
            throw new Exception("\x4d\151\x73\x73\151\x6e\x67\x20\x6e\141\x6d\x65\x20\x6f\x6e\x20\x3c\x73\x61\x6d\154\x3a\101\164\x74\x72\151\x62\x75\164\145\x3e\40\145\x6c\x65\155\x65\x6e\164\x2e");
            RZ:
            $Ym = $n1->getAttribute("\x4e\141\155\x65");
            if ($n1->hasAttribute("\116\x61\155\145\106\157\x72\155\141\164")) {
                goto IT;
            }
            $ZD = "\165\162\156\72\157\141\163\x69\x73\72\156\141\155\x65\163\72\x74\143\72\123\101\115\x4c\x3a\x32\56\x30\72\141\164\x74\162\156\141\155\x65\55\x66\x6f\162\155\x61\164\x3a\x75\x6e\x73\x70\x65\x63\151\146\x69\x65\144";
            goto S6;
            IT:
            $ZD = $n1->getAttribute("\x4e\141\x6d\x65\x46\x6f\162\155\x61\x74");
            S6:
            if ($vw) {
                goto mY;
            }
            if (!($this->nameFormat !== $ZD)) {
                goto Kc;
            }
            $this->nameFormat = "\165\162\156\72\157\x61\163\x69\x73\72\156\x61\x6d\145\163\72\164\143\72\x53\x41\115\x4c\x3a\62\56\60\x3a\141\x74\x74\162\156\x61\x6d\145\x2d\146\x6f\162\155\141\164\72\165\156\x73\x70\145\143\151\146\x69\x65\144";
            Kc:
            goto hM;
            mY:
            $this->nameFormat = $ZD;
            $vw = FALSE;
            hM:
            if (array_key_exists($Ym, $this->attributes)) {
                goto iu;
            }
            $this->attributes[$Ym] = array();
            iu:
            $js = Utilities::xpQuery($n1, "\x2e\x2f\x73\x61\155\154\x5f\141\163\x73\x65\162\164\x69\157\156\72\101\164\164\162\x69\142\x75\x74\x65\x56\x61\x6c\x75\145");
            foreach ($js as $jR) {
                $this->attributes[$Ym][] = trim($jR->textContent);
                oY:
            }
            Tb:
            YO:
        }
        jJ:
    }
    public function getNotBefore()
    {
        return $this->notBefore;
    }
    public function setNotBefore($mv)
    {
        $this->notBefore = $mv;
    }
    public function getNotOnOrAfter()
    {
        return $this->notOnOrAfter;
    }
    public function setNotOnOrAfter($KC)
    {
        $this->notOnOrAfter = $KC;
    }
    public function setEncryptedAttributes($Zn)
    {
        $this->requiredEncAttributes = $Zn;
    }
    public function getValidAudiences()
    {
        return $this->validAudiences;
    }
    public function setValidAudiences(array $fI = NULL)
    {
        $this->validAudiences = $fI;
    }
    public function getAuthnInstant()
    {
        return $this->authnInstant;
    }
    public function setAuthnInstant($S9)
    {
        $this->authnInstant = $S9;
    }
    public function getSessionNotOnOrAfter()
    {
        return $this->sessionNotOnOrAfter;
    }
    public function setSessionNotOnOrAfter($T2)
    {
        $this->sessionNotOnOrAfter = $T2;
    }
    public function getSessionIndex()
    {
        return $this->sessionIndex;
    }
    public function setSessionIndex($VZ)
    {
        $this->sessionIndex = $VZ;
    }
    public function getAuthnContext()
    {
        if (empty($this->authnContextClassRef)) {
            goto SE;
        }
        return $this->authnContextClassRef;
        SE:
        if (empty($this->authnContextDeclRef)) {
            goto An;
        }
        return $this->authnContextDeclRef;
        An:
        return NULL;
    }
    public function setAuthnContext($pE)
    {
        $this->setAuthnContextClassRef($pE);
    }
    public function getAuthnContextClassRef()
    {
        return $this->authnContextClassRef;
    }
    public function setAuthnContextClassRef($gR)
    {
        $this->authnContextClassRef = $gR;
    }
    public function setAuthnContextDecl(SAML2_XML_Chunk $Kn)
    {
        if (empty($this->authnContextDeclRef)) {
            goto tL;
        }
        throw new Exception("\101\x75\164\150\156\x43\x6f\x6e\x74\145\170\x74\104\x65\143\154\122\145\x66\x20\151\163\40\x61\x6c\x72\x65\x61\144\171\40\x72\x65\x67\151\163\x74\x65\x72\145\144\41\40\115\141\x79\x20\x6f\156\x6c\x79\x20\150\141\166\145\x20\x65\x69\x74\150\x65\162\x20\141\x20\x44\x65\143\154\x20\157\162\x20\x61\40\104\x65\x63\154\122\145\146\x2c\40\x6e\x6f\164\x20\x62\157\164\150\x21");
        tL:
        $this->authnContextDecl = $Kn;
    }
    public function getAuthnContextDecl()
    {
        return $this->authnContextDecl;
    }
    public function setAuthnContextDeclRef($E2)
    {
        if (empty($this->authnContextDecl)) {
            goto Hz;
        }
        throw new Exception("\101\165\164\x68\156\x43\157\x6e\x74\145\170\x74\x44\x65\143\154\40\151\163\x20\x61\154\x72\x65\141\x64\x79\40\162\145\x67\x69\x73\x74\145\x72\145\x64\41\40\x4d\x61\x79\x20\x6f\x6e\x6c\x79\40\150\x61\x76\145\x20\145\151\x74\150\145\x72\40\141\x20\x44\145\143\x6c\40\157\162\x20\x61\40\104\145\x63\154\x52\x65\x66\x2c\40\156\157\164\40\142\x6f\164\150\41");
        Hz:
        $this->authnContextDeclRef = $E2;
    }
    public function getAuthnContextDeclRef()
    {
        return $this->authnContextDeclRef;
    }
    public function getAuthenticatingAuthority()
    {
        return $this->AuthenticatingAuthority;
    }
    public function setAuthenticatingAuthority($FM)
    {
        $this->AuthenticatingAuthority = $FM;
    }
    public function getAttributes()
    {
        return $this->attributes;
    }
    public function setAttributes(array $nZ)
    {
        $this->attributes = $nZ;
    }
    public function getAttributeNameFormat()
    {
        return $this->nameFormat;
    }
    public function setAttributeNameFormat($ZD)
    {
        $this->nameFormat = $ZD;
    }
    public function getSubjectConfirmation()
    {
        return $this->SubjectConfirmation;
    }
    public function setSubjectConfirmation(array $lq)
    {
        $this->SubjectConfirmation = $lq;
    }
    public function getSignatureKey()
    {
        return $this->signatureKey;
    }
    public function setSignatureKey(XMLsecurityKey $cH = NULL)
    {
        $this->signatureKey = $cH;
    }
    public function getEncryptionKey()
    {
        return $this->encryptionKey;
    }
    public function setEncryptionKey(XMLSecurityKey $TY = NULL)
    {
        $this->encryptionKey = $TY;
    }
    public function setCertificates(array $FD)
    {
        $this->certificates = $FD;
    }
    public function getCertificates()
    {
        return $this->certificates;
    }
    public function getSignatureData()
    {
        return $this->signatureData;
    }
    public function getWasSignedAtConstruction()
    {
        return $this->wasSignedAtConstruction;
    }
    public function toXML(DOMNode $Il = NULL)
    {
        if ($Il === NULL) {
            goto hh;
        }
        $CS = $Il->ownerDocument;
        goto f5;
        hh:
        $CS = new DOMDocument();
        $Il = $CS;
        f5:
        $YU = $CS->createElementNS("\x75\x72\156\72\x6f\x61\163\151\x73\72\156\x61\155\145\163\x3a\x74\x63\72\123\101\115\114\72\62\x2e\x30\x3a\x61\x73\163\145\x72\164\151\x6f\156", "\163\141\x6d\x6c\x3a" . "\101\x73\163\x65\162\x74\151\157\x6e");
        $Il->appendChild($YU);
        $YU->setAttributeNS("\165\162\156\72\157\x61\163\151\163\x3a\156\141\155\145\x73\72\164\143\72\x53\x41\x4d\114\x3a\62\x2e\x30\x3a\160\x72\157\x74\x6f\x63\x6f\x6c", "\x73\x61\155\x6c\x70\x3a\x74\155\x70", "\164\155\x70");
        $YU->removeAttributeNS("\165\x72\156\x3a\x6f\141\163\x69\163\x3a\156\141\155\x65\163\x3a\164\x63\72\x53\101\115\114\x3a\x32\56\60\x3a\x70\x72\x6f\164\157\x63\157\x6c", "\x74\155\160");
        $YU->setAttributeNS("\150\164\x74\160\72\x2f\57\167\x77\167\x2e\167\63\x2e\x6f\x72\x67\57\62\60\60\x31\57\130\115\114\x53\x63\150\x65\155\141\55\x69\x6e\163\164\x61\156\143\x65", "\170\x73\151\72\164\x6d\160", "\x74\x6d\160");
        $YU->removeAttributeNS("\x68\164\x74\160\x3a\57\57\x77\x77\x77\56\167\63\56\x6f\162\147\x2f\x32\x30\x30\61\x2f\130\x4d\114\123\x63\150\x65\x6d\x61\x2d\151\156\163\164\x61\x6e\x63\145", "\x74\x6d\160");
        $YU->setAttributeNS("\x68\164\164\x70\72\57\57\167\167\x77\56\x77\63\56\157\162\147\57\x32\60\x30\61\x2f\x58\115\x4c\x53\x63\x68\145\x6d\141", "\170\163\72\x74\x6d\x70", "\164\x6d\160");
        $YU->removeAttributeNS("\150\x74\164\x70\72\x2f\x2f\x77\x77\167\56\x77\x33\x2e\157\162\147\57\x32\60\x30\61\x2f\x58\115\x4c\123\x63\x68\x65\x6d\141", "\x74\155\160");
        $YU->setAttribute("\111\104", $this->id);
        $YU->setAttribute("\126\x65\x72\163\x69\157\x6e", "\x32\56\60");
        $YU->setAttribute("\x49\163\163\x75\145\x49\156\163\164\x61\x6e\x74", gmdate("\x59\55\155\x2d\144\x5c\x54\x48\x3a\x69\72\x73\134\x5a", $this->issueInstant));
        $NY = Utilities::addString($YU, "\165\162\x6e\72\x6f\x61\163\151\x73\x3a\156\141\x6d\145\x73\72\164\143\x3a\123\101\x4d\x4c\x3a\62\x2e\60\72\x61\x73\163\x65\x72\164\x69\157\156", "\163\141\x6d\x6c\x3a\x49\x73\163\x75\x65\x72", $this->issuer);
        $this->addSubject($YU);
        $this->addConditions($YU);
        $this->addAuthnStatement($YU);
        if ($this->requiredEncAttributes == FALSE) {
            goto k8;
        }
        $this->addEncryptedAttributeStatement($YU);
        goto Zf;
        k8:
        $this->addAttributeStatement($YU);
        Zf:
        if (!($this->signatureKey !== NULL)) {
            goto g2;
        }
        Utilities::insertSignature($this->signatureKey, $this->certificates, $YU, $NY->nextSibling);
        g2:
        return $YU;
    }
    private function addSubject(DOMElement $YU)
    {
        if (!($this->nameId === NULL && $this->encryptedNameId === NULL)) {
            goto Qk;
        }
        return;
        Qk:
        $xe = $YU->ownerDocument->createElementNS("\165\x72\156\x3a\157\141\x73\x69\x73\x3a\x6e\141\155\x65\x73\72\x74\x63\x3a\x53\x41\x4d\114\x3a\x32\x2e\x30\72\x61\163\x73\x65\162\164\x69\157\156", "\x73\141\155\x6c\x3a\123\165\142\152\x65\143\x74");
        $YU->appendChild($xe);
        if ($this->encryptedNameId === NULL) {
            goto Tt;
        }
        $nx = $xe->ownerDocument->createElementNS("\165\x72\x6e\72\157\x61\163\x69\x73\x3a\156\141\x6d\x65\x73\x3a\164\143\x3a\x53\x41\x4d\x4c\x3a\x32\56\x30\x3a\x61\x73\x73\x65\x72\164\x69\157\156", "\x73\141\x6d\x6c\x3a" . "\x45\x6e\x63\162\x79\x70\164\145\144\x49\104");
        $xe->appendChild($nx);
        $nx->appendChild($xe->ownerDocument->importNode($this->encryptedNameId, TRUE));
        goto sf;
        Tt:
        Utilities::addNameId($xe, $this->nameId);
        sf:
        foreach ($this->SubjectConfirmation as $qY) {
            $qY->toXML($xe);
            O6:
        }
        cg:
    }
    private function addConditions(DOMElement $YU)
    {
        $CS = $YU->ownerDocument;
        $OH = $CS->createElementNS("\x75\x72\x6e\x3a\157\x61\163\151\163\72\156\x61\155\145\163\x3a\164\143\72\x53\x41\115\114\72\x32\56\x30\x3a\x61\x73\163\x65\162\x74\x69\x6f\156", "\163\x61\155\154\x3a\x43\x6f\156\144\x69\164\151\x6f\156\x73");
        $YU->appendChild($OH);
        if (!($this->notBefore !== NULL)) {
            goto Zn;
        }
        $OH->setAttribute("\x4e\157\164\102\x65\146\157\162\x65", gmdate("\x59\x2d\155\x2d\144\x5c\x54\110\x3a\x69\x3a\163\134\x5a", $this->notBefore));
        Zn:
        if (!($this->notOnOrAfter !== NULL)) {
            goto Gp;
        }
        $OH->setAttribute("\x4e\157\164\x4f\156\117\x72\101\x66\x74\145\x72", gmdate("\131\55\x6d\x2d\x64\134\x54\x48\x3a\151\72\163\x5c\132", $this->notOnOrAfter));
        Gp:
        if (!($this->validAudiences !== NULL)) {
            goto Dt;
        }
        $iU = $CS->createElementNS("\165\x72\x6e\72\157\141\x73\x69\163\72\x6e\141\x6d\x65\163\72\164\x63\72\123\x41\115\x4c\x3a\x32\56\x30\72\141\163\x73\x65\162\164\x69\x6f\156", "\163\x61\155\x6c\x3a\x41\165\x64\151\145\156\143\x65\122\x65\x73\164\x72\x69\143\x74\151\x6f\156");
        $OH->appendChild($iU);
        Utilities::addStrings($iU, "\x75\162\156\x3a\x6f\141\163\x69\163\x3a\156\141\x6d\x65\163\x3a\164\x63\x3a\x53\101\x4d\x4c\x3a\62\x2e\60\72\141\163\163\145\x72\164\151\x6f\x6e", "\x73\x61\x6d\x6c\72\101\x75\144\151\145\156\x63\145", FALSE, $this->validAudiences);
        Dt:
    }
    private function addAuthnStatement(DOMElement $YU)
    {
        if (!($this->authnInstant === NULL || $this->authnContextClassRef === NULL && $this->authnContextDecl === NULL && $this->authnContextDeclRef === NULL)) {
            goto pO;
        }
        return;
        pO:
        $CS = $YU->ownerDocument;
        $dH = $CS->createElementNS("\165\162\156\x3a\x6f\x61\163\x69\x73\x3a\x6e\x61\155\x65\x73\x3a\164\x63\72\123\x41\x4d\x4c\72\x32\56\x30\72\141\163\x73\x65\162\x74\x69\157\156", "\x73\x61\155\154\72\x41\165\164\x68\156\123\x74\141\164\145\155\x65\x6e\x74");
        $YU->appendChild($dH);
        $dH->setAttribute("\101\165\x74\150\x6e\x49\x6e\x73\x74\141\156\x74", gmdate("\131\55\155\55\x64\134\x54\110\72\151\x3a\x73\x5c\132", $this->authnInstant));
        if (!($this->sessionNotOnOrAfter !== NULL)) {
            goto ni;
        }
        $dH->setAttribute("\123\145\x73\x73\151\157\x6e\x4e\x6f\164\117\x6e\x4f\x72\x41\x66\x74\x65\162", gmdate("\131\55\155\x2d\x64\x5c\x54\110\72\151\72\x73\x5c\x5a", $this->sessionNotOnOrAfter));
        ni:
        if (!($this->sessionIndex !== NULL)) {
            goto ZR;
        }
        $dH->setAttribute("\123\x65\163\163\151\157\x6e\111\x6e\144\145\x78", $this->sessionIndex);
        ZR:
        $xS = $CS->createElementNS("\165\x72\156\x3a\x6f\141\163\151\163\72\x6e\x61\x6d\145\163\72\164\143\x3a\123\x41\115\x4c\72\62\x2e\x30\72\x61\x73\163\145\x72\164\x69\x6f\x6e", "\x73\141\x6d\x6c\x3a\x41\x75\164\x68\156\103\157\156\164\145\170\x74");
        $dH->appendChild($xS);
        if (empty($this->authnContextClassRef)) {
            goto IJ;
        }
        Utilities::addString($xS, "\165\162\x6e\72\157\x61\163\151\x73\72\x6e\141\x6d\145\x73\x3a\164\x63\x3a\123\x41\x4d\114\72\62\x2e\60\x3a\141\163\163\x65\162\164\151\x6f\x6e", "\x73\x61\x6d\x6c\x3a\101\x75\x74\x68\156\103\157\156\164\x65\x78\164\x43\x6c\141\163\x73\122\145\146", $this->authnContextClassRef);
        IJ:
        if (empty($this->authnContextDecl)) {
            goto wV;
        }
        $this->authnContextDecl->toXML($xS);
        wV:
        if (empty($this->authnContextDeclRef)) {
            goto lv;
        }
        Utilities::addString($xS, "\165\162\156\72\x6f\141\x73\151\x73\72\156\141\x6d\x65\x73\72\164\143\x3a\x53\101\x4d\x4c\72\x32\56\x30\x3a\x61\163\x73\145\162\164\x69\x6f\x6e", "\x73\141\x6d\x6c\72\101\165\x74\150\156\103\157\x6e\164\x65\x78\x74\x44\x65\143\x6c\122\x65\x66", $this->authnContextDeclRef);
        lv:
        Utilities::addStrings($xS, "\165\162\156\72\157\x61\x73\x69\x73\72\156\141\155\145\x73\72\164\143\72\123\101\x4d\114\72\x32\56\60\72\141\x73\x73\145\x72\164\151\157\156", "\x73\141\x6d\154\x3a\101\165\164\x68\x65\x6e\164\x69\143\x61\164\x69\x6e\x67\x41\165\x74\150\x6f\x72\151\x74\x79", FALSE, $this->AuthenticatingAuthority);
    }
    private function addAttributeStatement(DOMElement $YU)
    {
        if (!empty($this->attributes)) {
            goto UZ;
        }
        return;
        UZ:
        $CS = $YU->ownerDocument;
        $cT = $CS->createElementNS("\x75\162\156\72\157\x61\163\x69\163\x3a\x6e\141\155\145\x73\x3a\x74\143\x3a\x53\x41\x4d\x4c\72\x32\56\60\x3a\x61\163\x73\x65\162\x74\x69\157\156", "\163\141\155\x6c\x3a\101\x74\164\162\x69\142\165\164\145\x53\164\x61\164\145\155\x65\x6e\x74");
        $YU->appendChild($cT);
        foreach ($this->attributes as $Ym => $js) {
            $n1 = $CS->createElementNS("\x75\x72\156\x3a\157\141\163\x69\x73\x3a\x6e\x61\x6d\145\163\x3a\x74\x63\72\123\101\115\x4c\72\x32\56\60\x3a\x61\x73\163\145\x72\x74\151\x6f\x6e", "\x73\x61\x6d\154\72\x41\x74\x74\162\151\142\x75\x74\x65");
            $cT->appendChild($n1);
            $n1->setAttribute("\x4e\141\155\145", $Ym);
            if (!($this->nameFormat !== "\x75\x72\x6e\72\157\141\163\151\163\x3a\156\x61\155\145\x73\x3a\x74\x63\x3a\x53\101\115\x4c\72\62\x2e\60\72\x61\x74\164\x72\156\x61\x6d\145\55\146\x6f\162\155\x61\164\72\x75\x6e\x73\x70\x65\143\151\146\x69\x65\x64")) {
                goto yI;
            }
            $n1->setAttribute("\x4e\x61\x6d\x65\106\157\162\155\141\164", $this->nameFormat);
            yI:
            foreach ($js as $jR) {
                if (is_string($jR)) {
                    goto zQ;
                }
                if (is_int($jR)) {
                    goto RX;
                }
                $az = NULL;
                goto Ru;
                zQ:
                $az = "\x78\163\x3a\x73\x74\x72\x69\156\147";
                goto Ru;
                RX:
                $az = "\170\163\x3a\x69\x6e\164\145\x67\x65\x72";
                Ru:
                $l0 = $CS->createElementNS("\x75\x72\x6e\72\157\141\163\151\163\x3a\156\x61\x6d\x65\x73\72\164\143\72\x53\101\115\114\72\x32\56\x30\72\x61\163\163\x65\162\164\151\x6f\156", "\x73\141\155\x6c\x3a\x41\164\164\162\x69\x62\165\x74\x65\126\x61\x6c\165\145");
                $n1->appendChild($l0);
                if (!($az !== NULL)) {
                    goto om;
                }
                $l0->setAttributeNS("\150\164\x74\x70\72\x2f\57\x77\167\x77\x2e\167\63\x2e\157\162\x67\57\x32\60\60\61\x2f\130\115\114\x53\x63\x68\x65\155\141\x2d\151\156\x73\164\141\156\x63\145", "\x78\x73\x69\x3a\164\x79\x70\145", $az);
                om:
                if (!is_null($jR)) {
                    goto PE;
                }
                $l0->setAttributeNS("\x68\x74\164\160\x3a\57\x2f\x77\x77\167\x2e\167\x33\56\x6f\x72\x67\57\62\x30\x30\61\57\x58\x4d\x4c\123\x63\x68\x65\x6d\141\55\x69\x6e\163\164\x61\156\143\145", "\170\x73\151\72\156\x69\154", "\x74\162\165\x65");
                PE:
                if ($jR instanceof DOMNodeList) {
                    goto nS;
                }
                $l0->appendChild($CS->createTextNode($jR));
                goto HW;
                nS:
                $Wh = 0;
                p7:
                if (!($Wh < $jR->length)) {
                    goto xR;
                }
                $tB = $CS->importNode($jR->item($Wh), TRUE);
                $l0->appendChild($tB);
                NI:
                $Wh++;
                goto p7;
                xR:
                HW:
                O4:
            }
            XB:
            Pc:
        }
        sr:
    }
    private function addEncryptedAttributeStatement(DOMElement $YU)
    {
        if (!($this->requiredEncAttributes == FALSE)) {
            goto R7;
        }
        return;
        R7:
        $CS = $YU->ownerDocument;
        $cT = $CS->createElementNS("\x75\162\156\x3a\157\141\x73\x69\x73\x3a\x6e\x61\x6d\145\x73\x3a\x74\143\x3a\123\101\x4d\x4c\72\x32\x2e\x30\x3a\x61\x73\x73\145\162\x74\151\157\156", "\x73\141\x6d\x6c\72\x41\x74\164\x72\x69\142\165\164\145\x53\x74\x61\164\x65\155\x65\156\164");
        $YU->appendChild($cT);
        foreach ($this->attributes as $Ym => $js) {
            $x4 = new DOMDocument();
            $n1 = $x4->createElementNS("\x75\x72\x6e\72\x6f\x61\x73\x69\163\72\x6e\x61\x6d\145\x73\x3a\164\143\x3a\123\101\115\x4c\72\x32\56\60\72\141\x73\163\x65\x72\x74\x69\157\156", "\x73\141\155\154\x3a\101\x74\164\162\x69\x62\165\x74\x65");
            $n1->setAttribute("\116\x61\155\145", $Ym);
            $x4->appendChild($n1);
            if (!($this->nameFormat !== "\165\162\156\x3a\x6f\x61\x73\x69\163\72\156\x61\155\x65\163\72\x74\143\x3a\x53\101\x4d\114\72\62\56\60\x3a\141\x74\x74\162\x6e\141\155\145\55\x66\157\162\155\141\x74\72\165\156\x73\x70\145\143\x69\x66\151\145\x64")) {
                goto QV;
            }
            $n1->setAttribute("\x4e\x61\155\x65\x46\x6f\x72\x6d\x61\x74", $this->nameFormat);
            QV:
            foreach ($js as $jR) {
                if (is_string($jR)) {
                    goto rx;
                }
                if (is_int($jR)) {
                    goto jZ;
                }
                $az = NULL;
                goto KP;
                rx:
                $az = "\x78\x73\x3a\x73\x74\x72\151\156\x67";
                goto KP;
                jZ:
                $az = "\x78\x73\x3a\x69\156\x74\145\147\x65\162";
                KP:
                $l0 = $x4->createElementNS("\x75\x72\156\x3a\157\141\163\x69\163\x3a\x6e\x61\x6d\x65\163\x3a\x74\143\72\123\x41\x4d\x4c\x3a\x32\56\60\x3a\141\163\x73\145\x72\x74\x69\157\156", "\x73\x61\155\x6c\72\x41\164\x74\162\151\142\165\164\145\126\x61\154\x75\x65");
                $n1->appendChild($l0);
                if (!($az !== NULL)) {
                    goto xW;
                }
                $l0->setAttributeNS("\x68\x74\164\160\72\57\57\167\167\x77\56\167\x33\56\x6f\x72\147\x2f\x32\x30\x30\x31\x2f\x58\x4d\x4c\123\x63\x68\x65\x6d\x61\x2d\x69\x6e\163\164\141\x6e\143\x65", "\170\x73\151\72\x74\171\x70\x65", $az);
                xW:
                if ($jR instanceof DOMNodeList) {
                    goto Yv;
                }
                $l0->appendChild($x4->createTextNode($jR));
                goto ED;
                Yv:
                $Wh = 0;
                EQ:
                if (!($Wh < $jR->length)) {
                    goto H9;
                }
                $tB = $x4->importNode($jR->item($Wh), TRUE);
                $l0->appendChild($tB);
                J0:
                $Wh++;
                goto EQ;
                H9:
                ED:
                Jg:
            }
            CW:
            $eF = new XMLSecEnc();
            $eF->setNode($x4->documentElement);
            $eF->type = "\x68\164\164\x70\72\57\x2f\167\x77\x77\56\x77\63\56\x6f\x72\147\x2f\x32\60\x30\61\57\x30\64\x2f\x78\x6d\154\145\156\143\x23\105\154\145\x6d\x65\156\x74";
            $zR = new XMLSecurityKey(XMLSecurityKey::AES256_CBC);
            $zR->generateSessionKey();
            $eF->encryptKey($this->encryptionKey, $zR);
            $lH = $eF->encryptNode($zR);
            $iN = $CS->createElementNS("\165\162\156\x3a\157\141\x73\151\163\x3a\x6e\141\155\145\163\x3a\x74\143\72\123\101\115\114\72\62\x2e\60\72\x61\163\163\145\x72\164\x69\157\156", "\x73\x61\x6d\154\72\105\x6e\x63\x72\x79\160\x74\145\x64\101\x74\164\162\x69\142\165\164\x65");
            $cT->appendChild($iN);
            $AK = $CS->importNode($lH, TRUE);
            $iN->appendChild($AK);
            ES:
        }
        kG:
    }
    public function getPrivateKeyUrl()
    {
        return $this->privateKeyUrl;
    }
    public function setPrivateKeyUrl($rm)
    {
        $this->privateKeyUrl = $rm;
    }
}
