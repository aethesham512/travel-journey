<?php


if (defined("\127\120\x49\116\103")) {
    goto i7H;
}
die;
i7H:
