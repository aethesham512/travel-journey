<?php


include_once "\125\x74\x69\154\x69\164\x69\145\x73\x2e\160\x68\x70";
include_once "\x78\155\154\163\145\143\154\151\x62\163\56\x70\150\160";
use RobRichards\XMLSecLibs\XMLSecurityKey;
use RobRichards\XMLSecLibs\XMLSecurityDSig;
use RobRichards\XMLSecLibs\XMLSecEnc;
class SAML2_LogoutRequest
{
    private $tagName;
    private $id;
    private $issuer;
    private $destination;
    private $issueInstant;
    private $certificates;
    private $validators;
    private $notOnOrAfter;
    private $encryptedNameId;
    private $nameId;
    private $sessionIndexes;
    public function __construct(DOMElement $tn = NULL)
    {
        $this->tagName = "\114\x6f\x67\x6f\165\164\122\x65\161\x75\x65\163\x74";
        $this->id = Utilities::generateID();
        $this->issueInstant = time();
        $this->certificates = array();
        $this->validators = array();
        if (!($tn === NULL)) {
            goto NP;
        }
        return;
        NP:
        if ($tn->hasAttribute("\x49\104")) {
            goto wx;
        }
        throw new Exception("\x4d\151\x73\163\x69\x6e\x67\x20\111\104\x20\141\164\x74\x72\x69\142\165\x74\145\40\x6f\156\x20\x53\101\x4d\x4c\40\155\145\163\163\x61\x67\145\x2e");
        wx:
        $this->id = $tn->getAttribute("\x49\x44");
        if (!($tn->getAttribute("\126\145\162\x73\151\x6f\156") !== "\x32\56\x30")) {
            goto ve;
        }
        throw new Exception("\x55\x6e\163\165\x70\x70\157\162\164\x65\x64\x20\166\145\x72\x73\151\157\156\72\40" . $tn->getAttribute("\x56\x65\x72\x73\151\157\x6e"));
        ve:
        $this->issueInstant = Utilities::xsDateTimeToTimestamp($tn->getAttribute("\x49\x73\x73\x75\x65\111\156\x73\x74\x61\156\x74"));
        if (!$tn->hasAttribute("\104\x65\x73\164\151\156\141\x74\x69\157\x6e")) {
            goto dp;
        }
        $this->destination = $tn->getAttribute("\104\145\163\x74\x69\x6e\x61\164\151\x6f\x6e");
        dp:
        $NY = Utilities::xpQuery($tn, "\x2e\57\x73\x61\155\x6c\x5f\141\163\x73\x65\162\164\151\157\156\72\x49\x73\x73\165\145\162");
        if (empty($NY)) {
            goto Id;
        }
        $this->issuer = trim($NY[0]->textContent);
        Id:
        try {
            $ad = Utilities::validateElement($tn);
            if (!($ad !== FALSE)) {
                goto Ii;
            }
            $this->certificates = $ad["\x43\x65\162\x74\x69\x66\x69\x63\141\x74\x65\x73"];
            $this->validators[] = array("\106\165\x6e\x63\164\x69\157\x6e" => array("\x55\164\151\154\x69\x74\x69\x65\163", "\166\141\154\151\144\x61\164\145\x53\x69\x67\156\x61\164\165\162\x65"), "\x44\141\x74\141" => $ad);
            Ii:
        } catch (Exception $i0) {
        }
        $this->sessionIndexes = array();
        if (!$tn->hasAttribute("\x4e\157\164\117\156\117\x72\101\x66\x74\x65\162")) {
            goto LN;
        }
        $this->notOnOrAfter = Utilities::xsDateTimeToTimestamp($tn->getAttribute("\x4e\x6f\x74\117\156\x4f\162\101\x66\x74\x65\x72"));
        LN:
        $PB = Utilities::xpQuery($tn, "\56\57\x73\141\x6d\x6c\x5f\x61\163\163\145\x72\x74\x69\x6f\x6e\x3a\x4e\x61\155\145\x49\x44\x20\174\x20\x2e\57\163\x61\x6d\154\137\141\163\x73\145\162\164\x69\157\x6e\x3a\105\156\x63\162\x79\160\x74\145\x64\x49\x44\57\x78\x65\x6e\x63\72\105\156\143\x72\171\160\x74\145\144\x44\141\x74\141");
        if (empty($PB)) {
            goto Wk;
        }
        if (count($PB) > 1) {
            goto qj;
        }
        goto ym;
        Wk:
        throw new Exception("\x4d\x69\x73\x73\x69\x6e\x67\40\x3c\x73\x61\x6d\154\x3a\116\141\155\145\111\104\x3e\x20\x6f\x72\x20\74\163\141\x6d\x6c\72\105\156\143\x72\171\x70\x74\x65\x64\111\x44\x3e\x20\x69\156\x20\74\163\141\155\154\160\72\x4c\x6f\x67\x6f\x75\164\122\145\x71\x75\145\163\x74\x3e\56");
        goto ym;
        qj:
        throw new Exception("\115\x6f\162\145\40\164\x68\141\x6e\40\157\156\145\x20\74\x73\141\155\x6c\x3a\116\141\155\x65\111\104\76\x20\157\x72\x20\74\x73\141\155\154\72\x45\x6e\x63\x72\171\160\x74\145\x64\104\76\x20\151\156\40\74\x73\141\x6d\x6c\160\72\114\x6f\x67\157\165\x74\122\145\161\165\145\163\x74\x3e\56");
        ym:
        $PB = $PB[0];
        if ($PB->localName === "\x45\156\x63\162\171\160\x74\145\144\x44\141\x74\141") {
            goto Qo;
        }
        $this->nameId = Utilities::parseNameId($PB);
        goto zF;
        Qo:
        $this->encryptedNameId = $PB;
        zF:
        $EM = Utilities::xpQuery($tn, "\56\x2f\163\x61\x6d\x6c\137\160\162\157\x74\157\x63\157\154\72\123\x65\x73\163\151\157\156\111\156\x64\145\x78");
        foreach ($EM as $VZ) {
            $this->sessionIndexes[] = trim($VZ->textContent);
            DV:
        }
        GV:
    }
    public function getNotOnOrAfter()
    {
        return $this->notOnOrAfter;
    }
    public function setNotOnOrAfter($KC)
    {
        $this->notOnOrAfter = $KC;
    }
    public function isNameIdEncrypted()
    {
        if (!($this->encryptedNameId !== NULL)) {
            goto TQ;
        }
        return TRUE;
        TQ:
        return FALSE;
    }
    public function encryptNameId(XMLSecurityKey $u_)
    {
        $Jp = new DOMDocument();
        $YU = $Jp->createElement("\162\x6f\x6f\x74");
        $Jp->appendChild($YU);
        SAML2_Utils::addNameId($YU, $this->nameId);
        $PB = $YU->firstChild;
        SAML2_Utils::getContainer()->debugMessage($PB, "\x65\x6e\143\162\x79\160\x74");
        $iS = new XMLSecEnc();
        $iS->setNode($PB);
        $iS->type = XMLSecEnc::Element;
        $zR = new XMLSecurityKey(XMLSecurityKey::AES128_CBC);
        $zR->generateSessionKey();
        $iS->encryptKey($u_, $zR);
        $this->encryptedNameId = $iS->encryptNode($zR);
        $this->nameId = NULL;
    }
    public function decryptNameId(XMLSecurityKey $u_, array $xO = array())
    {
        if (!($this->encryptedNameId === NULL)) {
            goto AK;
        }
        return;
        AK:
        $PB = SAML2_Utils::decryptElement($this->encryptedNameId, $u_, $xO);
        SAML2_Utils::getContainer()->debugMessage($PB, "\144\x65\143\162\171\x70\164");
        $this->nameId = SAML2_Utils::parseNameId($PB);
        $this->encryptedNameId = NULL;
    }
    public function getNameId()
    {
        if (!($this->encryptedNameId !== NULL)) {
            goto sE;
        }
        throw new Exception("\101\x74\x74\145\155\x70\164\145\144\40\x74\x6f\40\x72\145\x74\x72\151\145\166\x65\40\145\x6e\x63\162\171\160\164\145\144\40\x4e\141\x6d\x65\111\104\40\167\151\164\x68\x6f\165\x74\x20\144\x65\x63\162\x79\160\164\151\156\x67\40\x69\x74\40\146\x69\162\163\x74\x2e");
        sE:
        return $this->nameId;
    }
    public function setNameId($PB)
    {
        $this->nameId = $PB;
    }
    public function getSessionIndexes()
    {
        return $this->sessionIndexes;
    }
    public function setSessionIndexes(array $EM)
    {
        $this->sessionIndexes = $EM;
    }
    public function getSessionIndex()
    {
        if (!empty($this->sessionIndexes)) {
            goto lp;
        }
        return NULL;
        lp:
        return $this->sessionIndexes[0];
    }
    public function setSessionIndex($VZ)
    {
        if (is_null($VZ)) {
            goto mH;
        }
        $this->sessionIndexes = array($VZ);
        goto rA;
        mH:
        $this->sessionIndexes = array();
        rA:
    }
    public function getId()
    {
        return $this->id;
    }
    public function setId($Iv)
    {
        $this->id = $Iv;
    }
    public function getIssueInstant()
    {
        return $this->issueInstant;
    }
    public function setIssueInstant($hR)
    {
        $this->issueInstant = $hR;
    }
    public function getDestination()
    {
        return $this->destination;
    }
    public function setDestination($CX)
    {
        $this->destination = $CX;
    }
    public function getIssuer()
    {
        return $this->issuer;
    }
    public function setIssuer($NY)
    {
        $this->issuer = $NY;
    }
}
