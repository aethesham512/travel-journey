<?php

define( 'REDIRECTION_VERSION', '5.3.9' );
define( 'REDIRECTION_BUILD', 'd9e6fbf82d86a7f9b256e669c214cb3a' );
define( 'REDIRECTION_MIN_WP', '5.4' );
