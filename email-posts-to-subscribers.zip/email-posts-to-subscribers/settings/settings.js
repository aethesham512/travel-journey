function _elp_cancel(option) {
	window.location = "admin.php?page=elp-settings&tab=" + option;
}

function _elp_help() {
	window.open("http://www.gopiplus.com/work/2014/03/28/wordpress-plugin-email-posts-to-subscribers/");
}