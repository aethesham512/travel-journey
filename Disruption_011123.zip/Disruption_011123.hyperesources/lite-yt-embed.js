/*
 Hype Data Decorator 1.2.8
copyright (c) 2019-2021 Max Ziebell, (https://maxziebell.de). MIT-license
*/
!1==="HypeDataDecorator"in window&&(window.HypeDataDecorator=function(){function B(a){for(var b in h)-1!=b.indexOf(a.id+"__")&&(h[b].disconnect(),h[b]=void 0,delete h[b])}function w(a,b){B(a);q.forEach(function(c){c.activateHandler(c,a,b)})}function C(a,b,c){var e=b.id+"__"+a.attributeName,r=b;h[e]||(a.observerFunction=function(l){l.forEach(function(d){if(d.attributeName==a.attributeName){var f=d.target.getAttribute(a.attributeName),g=[].slice.call(d.target.querySelectorAll(a.selector));d.target.matches(a.selector)&&
g.unshift(d.target);for(var m=0;m<g.length;m++){var t=c?c.getSymbolInstanceById(g[m].id):null,p=x(a.callback?a.callback:k.setContent);u||(r=document.getElementById(c.currentSceneId()));for(var n,v=0;v<p.length;v++)n=p[v](c,g[m],n||{value:f,mutation:d,symbolInstance:t,hypeDocumentElm:b,sceneElm:r})}}d.attributeName==a.attributeName+"-initial"&&(g=d.target.getAttribute(a.attributeName+"-initial"),f=d.target.getAttribute(a.attributeName),u?d.target.setAttribute(a.attributeName,g):null!=f?d.target.setAttribute(a.attributeName,
f):!d.target.hasAttribute(a.attributeName)&&g&&d.target.setAttribute(a.attributeName,g))})},a.observer=new MutationObserver(a.observerFunction),h[e]=a.observer,a.startObserver=function(l){this.observer.observe(l,{attributes:!0,attributeOldValue:!0,subtree:!0,attributeFilter:[this.attributeName,this.attributeName+"-initial"]})},a.startObserver(b))}function D(a,b,c){var e=b.id+"__"+a.selector,r=a.attributeFilter?a.attributeFilter[0]:"style",l=b;h[e]||(a.observerFunction=function(d){d.forEach(function(f){if(f.target.matches(a.selector)){var g=
f.target.getAttribute(r),m=c?c.getSymbolInstanceById(f.target):null,t=x(a.callback);u||(l=document.getElementById(c.currentSceneId()));for(var p,n=0;n<t.length;n++)p=t[n](c,f.target,p||{value:g,mutation:f,symbolInstance:m,hypeDocumentElm:b,sceneElm:l})}})},a.observer=new MutationObserver(a.observerFunction),h[e]=a.observer,a.observer.observe(b,{attributes:!0,attributeOldValue:!0,subtree:!0,attributeFilter:a.attributeFilter?a.attributeFilter:["style"]}))}function x(a){var b=[];switch(typeof a){case "function":b=
[a];break;case "string":b=a.split("|").map(function(c){return c.trim()}).filter(function(c){return c&&k[c]}).map(function(c){return k[c]});break;case "object":Array.isArray(a)&&(b=a.filter(function(c){return"function"==typeof c||k[c]}).map(function(c){return"function"==typeof c?c:k[c]}))}return b}function y(a,b){a&&!a.querySelector(".HYPE_element_container, .HYPE_element")&&(a.innerHTML=b)}function z(a,b,c,e){(new RegExp(/^[a-z0-9-_]+$/i)).test(a)&&b&&c&&(e=e?e:{},q.push(Object.assign(e,{attributeName:a,
selector:b,callback:c,activateHandler:C})))}var q=[],h={},k={setContent:function(a,b,c){y(b,c.value)}},u=-1!=window.location.href.indexOf("/Hype/Scratch/HypeScratch.");if(u){var E=function(){var a=Math.round((new Date).getTime()/10);A!=a&&(A=a,q.forEach(function(b){b.attributeName&&document.querySelectorAll("["+b.attributeName+"]").forEach(function(c){c.setAttribute(b.attributeName,c.getAttribute(b.attributeName))})}))},A=0;window.addEventListener("DOMContentLoaded",function(a){a=document.documentElement||
document.body;w(a);(new MutationObserver(function(){E()})).observe(a,{attributes:!0,subtree:!0,attributeFilter:["class"]})})}!1==="HYPE_eventListeners"in window&&(window.HYPE_eventListeners=[]);window.HYPE_eventListeners.push({type:"HypeDocumentLoad",callback:function(a,b,c){b=a.getElementById(a.documentId());w(b,a)}});return{version:"1.2.8",mapDataAttribute:function(a,b,c){z("data-"+a,"."+a,b||k[a]||k.setContent,c)},mapAttributeToSelector:z,observeBySelector:function(a,b,c){a&&b&&(c=c?c:{},q.push(Object.assign(c,
{selector:a,callback:b,activateHandler:D})))},registerElementDecorator:function(a,b){k[a]=b},setContent:y,getRunningObserver:function(){return h}}}());


HypeDataDecorator.observeBySelector('[data-yt-videoid],[data-yt-poster]', function(hypeDocument, element, event){
	var videoId = element.getAttribute('data-yt-videoid');
	if(!videoId) return;
	var poster = element.getAttribute('data-yt-poster');
	var posterAttr = poster? ` poster="${poster}"`: '';
	var appendPlayer = function(){
		element.innerHTML = `
			<lite-youtube videoid="${videoId}"${posterAttr}>
				<button type="button" class="lty-playbtn">
					<span class="lyt-visually-hidden">Play Video</span>
				</button>
			</lite-youtube>
		`;
	};
	if (hypeDocument) {
		appendPlayer();
	} else {
		setTimeout(appendPlayer,1);
	}
	
}, {attributeFilter: ['data-yt-videoid', 'data-yt-poster']});

/* 
https://github.com/paulirish/lite-youtube-embed
By Paul Irish, Modified by Max Ziebell
*/
var style = document.createElement('style');
style.innerHTML = `
lite-youtube {
	background-color: #000;
	position: relative;
	display: block;
	contain: content;
	background-position: center center;
	background-size: cover;
	cursor: pointer;
	max-width: 1000px;
}

/* gradient */
lite-youtube::before {
	content: '';
	display: block;
	position: absolute;
	top: 0;
	
	background-position: top;
	background-repeat: repeat-x;
	height: 60px;
	padding-bottom: 50px;
	width: 100%;
	transition: all 0.2s cubic-bezier(0, 0, 0.2, 1);
}

/* responsive iframe with a 16:9 aspect ratio
	thanks https://css-tricks.com/responsive-iframes/
*/
lite-youtube::after {
	content: "";
	display: block;
	padding-bottom: calc(100% / (16 / 9));
}
lite-youtube > iframe {
	width: 100%;
	height: 100%;
	position: absolute;
	top: 0;
	left: 0;
	border: 0;
}

/* play button */
lite-youtube > .lty-playbtn {
	width: 68px;
	height: 48px;
	position: absolute;
	transform: translate3d(-50%, -50%, 0);
	top: 50%;
	left: 50%;
	z-index: 1;
	background-color: transparent;
	/* YT's actual play button svg */
	background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" version="1.1" viewBox="0 0 68 48"><path fill="%23f00" fill-opacity="0.0" d="M66.52,7.74c-0.78-2.93-2.49-5.41-5.42-6.19C55.79,.13,34,0,34,0S12.21,.13,6.9,1.55 C3.97,2.33,2.27,4.81,1.48,7.74C0.06,13.05,0,24,0,24s0.06,10.95,1.48,16.26c0.78,2.93,2.49,5.41,5.42,6.19 C12.21,47.87,34,48,34,48s21.79-0.13,27.1-1.55c2.93-0.78,4.64-3.26,5.42-6.19C67.94,34.95,68,24,68,24S67.94,13.05,66.52,7.74z"></path><path d="M 45,24 27,14 27,34" fill="%23fff"></path></svg>');
	filter: grayscale(0%);
	transition: filter .1s cubic-bezier(0, 0, 0.2, 1);
	border: none;
}

lite-youtube:hover > .lty-playbtn,
lite-youtube .lty-playbtn:focus {
	filter: none;
}

/* Post-click styles */
lite-youtube.lyt-activated {
	cursor: unset;
}
lite-youtube.lyt-activated::before,
lite-youtube.lyt-activated > .lty-playbtn {
	opacity: 0;
	pointer-events: none;
}

.lyt-visually-hidden {
	clip: rect(0 0 0 0);
	clip-path: inset(50%);
	height: 1px;
	overflow: hidden;
	position: absolute;
	white-space: nowrap;
	width: 1px;
}
`;
document.head.appendChild(style);

class LiteYTEmbed extends HTMLElement {
   	/**
	 * Connect and prepare
	 */
	connectedCallback() {
		this._isHypeIDE = window.location.href.indexOf("/Hype/Scratch/HypeScratch.") != -1;
		this.prepareDisplay();
	}

	prepareDisplay() {
		this.videoId = this.getAttribute('videoid');
		let playBtnEl = this.querySelector('.lty-playbtn');
		this.playLabel = (playBtnEl && playBtnEl.textContent.trim()) || this.getAttribute('playlabel') || 'Play';
		this.posterUrl = this.getAttribute('poster') || `https://i.ytimg.com/vi/${this.videoId}/hqdefault.jpg`;
		
		LiteYTEmbed.addPrefetch('preload', this.posterUrl, 'image');
		this.style.backgroundImage = `url("${this.posterUrl}")`;

		if (!playBtnEl) {
			playBtnEl = document.createElement('button');
			playBtnEl.type = 'button';
			playBtnEl.classList.add('lty-playbtn');
			this.append(playBtnEl);
		}

		if (!playBtnEl.textContent) {
			const playBtnLabelEl = document.createElement('span');
			playBtnLabelEl.className = 'lyt-visually-hidden';
			playBtnLabelEl.textContent = this.playLabel;
			playBtnEl.append(playBtnLabelEl);
		}
		
		if (!this._isHypeIDE) {
			this.addEventListener('pointerover', LiteYTEmbed.warmConnections, {once: true});
			this.addEventListener('click', e => this.addIframe());    
		}
	}

	/**
	 * Add a <link rel={preload | preconnect} ...> to the head
	 */
	static addPrefetch(kind, url, as) {
		const linkEl = document.createElement('link');
		linkEl.rel = kind;
		linkEl.href = url;
		if (as) {
			linkEl.as = as;
		}
		document.head.append(linkEl);
	}

	/**
	 * Begin pre-connecting to warm up the iframe load
	 */
	static warmConnections() {
		if (LiteYTEmbed.preconnected) return;

		// The iframe document and most of its subresources come right off youtube.com
		// LiteYTEmbed.addPrefetch('preconnect', 'https://www.youtube-nocookie.com');
		LiteYTEmbed.addPrefetch('preconnect', 'https://www.youtube.com');
		// The botguard script is fetched off from google.com
		LiteYTEmbed.addPrefetch('preconnect', 'https://www.google.com');

		// Not certain if these ad related domains are in the critical path. Could verify with domain-specific throttling.
		LiteYTEmbed.addPrefetch('preconnect', 'https://googleads.g.doubleclick.net');
		LiteYTEmbed.addPrefetch('preconnect', 'https://static.doubleclick.net');

		LiteYTEmbed.preconnected = true;
	}

	addIframe() {
		const params = new URLSearchParams(this.getAttribute('params') || []);
		params.append('autoplay', '1');
		const iframeEl = document.createElement('iframe');
		iframeEl.width = '100%';
		iframeEl.height = '100%';
		iframeEl.title = this.playLabel;
		iframeEl.allow = 'accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture';
		iframeEl.allowFullscreen = true;
		//iframeEl.src = `https://www.youtube-nocookie.com/embed/${encodeURIComponent(this.videoId)}?${params.toString()}`;
		iframeEl.src = `https://www.youtube.com/embed/${encodeURIComponent(this.videoId)}?${params.toString()}`;
		this.append(iframeEl);
		this.classList.add('lyt-activated');
		this.querySelector('iframe').focus();
	}
}

customElements.define('lite-youtube', LiteYTEmbed);
