module.exports = function gutenBuildPaths() {
    return {
        'captainform' : {
            'pluginDir' : 'captainform',
            'mainFile': 'captainform/captainform.php'
        },
        'formbuilder123' : { 
            'pluginDir' : '123contactform-for-wordpress',
            'mainFile' : '123contactform-for-wordpress/123contactform-wp-plugin.php'
        }
    }
};