var TSC = TSC || {};

TSC.embedded_config_xml = '<x:xmpmeta tsc:version="2.0.1" xmlns:x="adobe:ns:meta/" xmlns:tsc="http://www.techsmith.com/xmp/tsc/">\
   <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" xmlns:xmp="http://ns.adobe.com/xap/1.0/" xmlns:xmpDM="http://ns.adobe.com/xmp/1.0/DynamicMedia/" xmlns:xmpG="http://ns.adobe.com/xap/1.0/g/" xmlns:xmpMM="http://ns.adobe.com/xap/1.0/mm/" xmlns:tscDM="http://www.techsmith.com/xmp/tscDM/" xmlns:tscIQ="http://www.techsmith.com/xmp/tscIQ/" xmlns:tscHS="http://www.techsmith.com/xmp/tscHS/" xmlns:stDim="http://ns.adobe.com/xap/1.0/sType/Dimensions#" xmlns:stFnt="http://ns.adobe.com/xap/1.0/sType/Font#" xmlns:exif="http://ns.adobe.com/exif/1.0" xmlns:dc="http://purl.org/dc/elements/1.1/">\
      <rdf:Description dc:date="2022-10-25 12:54:53 " dc:source="Camtasia,21.0.16,enu" dc:title="Camtasia Hotspot and Quiz" tscDM:firstFrame="Camtasia_Hotspot_and_Quiz_First_Frame.png" tscDM:originId="AB57D52A-0518-4065-A727-0D76A161BF69" tscDM:project="Camtasia Hotspot and Quiz">\
         <xmpDM:duration xmpDM:scale="1/1000" xmpDM:value="7000"/>\
         <xmpDM:videoFrameSize stDim:unit="pixel" stDim:h="1080" stDim:w="1920"/>\
         <tsc:langName>\
            <rdf:Bag>\
               <rdf:li xml:lang="en-US">English</rdf:li></rdf:Bag>\
         </tsc:langName>\
         <xmpDM:Tracks>\
            <rdf:Bag>\
               <rdf:li>\
                  <rdf:Description xmpDM:trackType="Hotspot" xmpDM:frameRate="f1000" xmpDM:trackName="Hotspots">\
                     <xmpDM:markers>\
                        <rdf:Seq>\
                           <rdf:li><rdf:Description xmpDM:label="1" xmpDM:startTime="0" xmpDM:duration="7000" tscDM:boundingPoly="0,0;1920,0;1920,1080;0,1080;" tscDM:rotate="0.000000" tscHS:pause="1"/></rdf:li><rdf:li><rdf:Description xmpDM:label="2" xmpDM:startTime="2000" xmpDM:duration="1730" tscDM:boundingPoly="1248,41;1592,41;1592,414;1248,414;" tscDM:rotate="0.000000" tscHS:pause="1" tscHS:jumpTime="4467"/></rdf:li><rdf:li><rdf:Description xmpDM:label="3" xmpDM:startTime="5070" xmpDM:duration="1730" tscDM:boundingPoly="1248,41;1592,41;1592,414;1248,414;" tscDM:rotate="0.000000" tscHS:pause="1" xmpDM:location="https://www.techsmith.com" tscHS:newWindow="1"/></rdf:li><rdf:li><rdf:Description xmpDM:label="4" xmpDM:startTime="0" xmpDM:duration="1200" tscDM:boundingPoly="272,308;616,308;616,680;272,680;" tscDM:rotate="0.000000" tscHS:pause="1" xmpDM:location="https://www.techsmith.com" tscHS:newWindow="1"/></rdf:li></rdf:Seq>\
                     </xmpDM:markers>\
                  </rdf:Description>\
               </rdf:li>\
               <rdf:li>\
                  <rdf:Description xmpDM:trackType="TableOfContents" xmpDM:frameRate="f1000" xmpDM:trackName="Table of Contents">\
                     <xmpDM:markers>\
                        <rdf:Seq>\
                           <rdf:li><rdf:Description xmpDM:name="Introduction" xmpDM:startTime="0" tscDM:image="Camtasia_Hotspot_and_Quiz_Thumbnails.png" tscDM:imageindex="0" tscDM:imageoffset="0" tscDM:imagerect="0, 0, 75, 42"/></rdf:li><rdf:li><rdf:Description xmpDM:name="Marker 1" xmpDM:startTime="4467" tscDM:image="Camtasia_Hotspot_and_Quiz_Thumbnails.png" tscDM:imageindex="1" tscDM:imageoffset="0" tscDM:imagerect="75, 0, 75, 42"/></rdf:li></rdf:Seq>\
                     </xmpDM:markers>\
                  </rdf:Description>\
               </rdf:li>\
               <rdf:li>\
                  <rdf:Description xmpDM:trackType="Quiz" xmpDM:frameRate="f1000" xmpDM:trackName="Quiz" tscIQ:quizGuid="DBB1293F-070B-41A6-A292-51D31664B1F0" tscIQ:authoredEmail="AYQ9qNvM/FESdmiSoGArlBeBdyuMVZ/hnDUqxML92cs/1QcxDxok+oX/oM6dWTiM2pYmoGgYa0Ow\
dFYKEnObLga4cmHC/gMnlT/F6+wpu93+rKMD4dO2Sr2nzivCV7gm/ro+AlqYjVVe/J+yc9ZNxal7\
s762dizULAs1aktD28mv2HzkMNqzzBomWbADiSjhBZj9z8XpvE9k03srD/7V30iysm58OXWbnrDb\
pFSfzv9KZSkwWUtdjOnTAZYSJtCLNj0HQzDZFHYSSY7eSOdgjwUpuSbGta14xgteuqGwXW0LHQrM\
RdD3geY1tEoBJLSQUOp+IjYNwJtbZs4hpH3xmw==" tscIQ:requireUserId="1" tscIQ:locale="en-US" tscIQ:reportMethod="API" tscIQ:allowSkipQuiz="1" tscIQ:clientId="E7885279-24D1-4E90-AF2A-EF9A7A4E075B" tscIQ:hideReplay="0" tscIQ:quizHash="1a36c3b52f49e7da4e345cd7f447549b">\
                     <xmpDM:markers>\
                        <rdf:Seq>\
                           <rdf:li><rdf:Description xmpDM:startTime="5767" tscIQ:feedback="1" tscIQ:questionSetName="Quiz 4"><tscIQ:questions><rdf:Seq><rdf:li><rdf:Description tscIQ:type="MC" tscIQ:id="0"><tscIQ:question>Default Question Text</tscIQ:question><tscIQ:correctAnswer>1</tscIQ:correctAnswer><tscIQ:answerArray><rdf:Seq><rdf:li><rdf:Description tscIQ:orderId="0"><tscIQ:answer>True</tscIQ:answer></rdf:Description></rdf:li><rdf:li><rdf:Description tscIQ:orderId="1"><tscIQ:answer>False</tscIQ:answer></rdf:Description></rdf:li></rdf:Seq></tscIQ:answerArray></rdf:Description></rdf:li></rdf:Seq></tscIQ:questions></rdf:Description></rdf:li></rdf:Seq>\
                     </xmpDM:markers>\
                     <tscIQ:QuizParams><rdf:Bag><rdf:li xmpDM:name="txtPrev" xmpDM:value="Previous"/><rdf:li xmpDM:name="txtNext" xmpDM:value="Next"/><rdf:li xmpDM:name="txtAnswerQuestion" xmpDM:value="Take Quiz Now"/><rdf:li xmpDM:name="txtSubmit" xmpDM:value="Submit Answers"/><rdf:li xmpDM:name="txtReview" xmpDM:value="Replay Last Section"/><rdf:li xmpDM:name="txtReviewAnswer" xmpDM:value="View Answers"/><rdf:li xmpDM:name="txtContinue" xmpDM:value="Continue"/></rdf:Bag></tscIQ:QuizParams></rdf:Description>\
               </rdf:li>\
            </rdf:Bag>\
         </xmpDM:Tracks>\
         <tscDM:controller>\
            <rdf:Description xmpDM:name="tscplayer">\
               <tscDM:parameters>\
                  <rdf:Bag>\
                     <rdf:li xmpDM:name="autohide" xmpDM:value="true"/><rdf:li xmpDM:name="autoplay" xmpDM:value="false"/><rdf:li xmpDM:name="loop" xmpDM:value="false"/><rdf:li xmpDM:name="searchable" xmpDM:value="true"/><rdf:li xmpDM:name="captionsenabled" xmpDM:value="false"/><rdf:li xmpDM:name="sidebarenabled" xmpDM:value="false"/><rdf:li xmpDM:name="unicodeenabled" xmpDM:value="false"/><rdf:li xmpDM:name="backgroundcolor" xmpDM:value="000000"/><rdf:li xmpDM:name="sidebarlocation" xmpDM:value="left"/><rdf:li xmpDM:name="endaction" xmpDM:value="stop"/><rdf:li xmpDM:name="endactionparam" xmpDM:value="true"/><rdf:li xmpDM:name="locale" xmpDM:value="en-US"/></rdf:Bag>\
               </tscDM:parameters>\
               <tscDM:controllerText>\
                  <rdf:Bag>\
                  </rdf:Bag>\
               </tscDM:controllerText>\
            </rdf:Description>\
         </tscDM:controller>\
         <tscDM:contentList>\
            <rdf:Description>\
               <tscDM:files>\
                  <rdf:Seq>\
                     <rdf:li xmpDM:name="0" xmpDM:value="Camtasia Hotspot and Quiz.mp4"/><rdf:li xmpDM:name="1" xmpDM:value="Camtasia_Hotspot_and_Quiz_First_Frame.png"/><rdf:li xmpDM:name="2" xmpDM:value="Camtasia_Hotspot_and_Quiz_Thumbnails.png"/></rdf:Seq>\
               </tscDM:files>\
            </rdf:Description>\
         </tscDM:contentList>\
      </rdf:Description>\
   </rdf:RDF>\
</x:xmpmeta>';
