<?php


include "\x41\163\163\x65\x72\164\x69\x6f\156\56\160\150\160";
class SAML2_Response
{
    private $assertions;
    private $destination;
    private $certificates;
    private $signatureData;
    public function __construct(DOMElement $Th = NULL, $vG)
    {
        $this->assertions = array();
        $this->certificates = array();
        if (!($Th === NULL)) {
            goto YkQ;
        }
        return;
        YkQ:
        $BL = Utilities::validateElement($Th);
        if (!($BL !== FALSE)) {
            goto UO9;
        }
        $this->certificates = $BL["\103\x65\162\164\x69\x66\x69\x63\141\164\x65\x73"];
        $this->signatureData = $BL;
        UO9:
        if (!$Th->hasAttribute("\x44\x65\163\164\x69\x6e\141\x74\151\x6f\156")) {
            goto Ybn;
        }
        $this->destination = $Th->getAttribute("\104\145\x73\x74\151\156\x61\164\x69\157\156");
        Ybn:
        $Vf = $Th->firstChild;
        pTv:
        if (!($Vf !== NULL)) {
            goto e2k;
        }
        if (!($Vf->namespaceURI !== "\165\x72\156\x3a\x6f\x61\x73\151\163\x3a\156\x61\155\145\163\72\x74\143\x3a\x53\x41\x4d\x4c\x3a\x32\x2e\x30\x3a\x61\163\x73\x65\x72\x74\151\157\156")) {
            goto gDH;
        }
        goto PHN;
        gDH:
        if (!($Vf->localName === "\x41\163\163\145\162\x74\x69\x6f\x6e" || $Vf->localName === "\105\156\x63\162\x79\x70\164\145\x64\101\x73\163\x65\162\x74\151\157\x6e")) {
            goto mD5;
        }
        $this->assertions[] = new SAML2_Assertion($Vf, $vG);
        mD5:
        PHN:
        $Vf = $Vf->nextSibling;
        goto pTv;
        e2k:
    }
    public function getAssertions()
    {
        return $this->assertions;
    }
    public function setAssertions(array $q5)
    {
        $this->assertions = $q5;
    }
    public function getDestination()
    {
        return $this->destination;
    }
    public function getCertificates()
    {
        return $this->certificates;
    }
    public function getSignatureData()
    {
        return $this->signatureData;
    }
}
