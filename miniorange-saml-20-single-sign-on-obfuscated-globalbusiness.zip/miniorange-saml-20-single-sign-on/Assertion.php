<?php


include_once "\125\164\151\x6c\151\164\x69\145\163\56\x70\150\160";
include_once "\170\x6d\154\x73\x65\143\x6c\x69\142\x73\x2e\x70\x68\x70";
use RobRichards\XMLSecLibs\XMLSecurityKey;
use RobRichards\XMLSecLibs\XMLSecurityDSig;
use RobRichards\XMLSecLibs\XMLSecEnc;
class SAML2_Assertion
{
    private $id;
    private $issueInstant;
    private $issuer;
    private $nameId;
    private $encryptedNameId;
    private $encryptedAttribute;
    private $encryptionKey;
    private $notBefore;
    private $notOnOrAfter;
    private $validAudiences;
    private $sessionNotOnOrAfter;
    private $sessionIndex;
    private $authnInstant;
    private $authnContextClassRef;
    private $authnContextDecl;
    private $authnContextDeclRef;
    private $AuthenticatingAuthority;
    private $attributes;
    private $nameFormat;
    private $signatureKey;
    private $certificates;
    private $signatureData;
    private $requiredEncAttributes;
    private $SubjectConfirmation;
    private $privateKeyUrl;
    protected $wasSignedAtConstruction = FALSE;
    public function __construct(DOMElement $Th = NULL, $vG)
    {
        $this->id = Utilities::generateId();
        $this->issueInstant = Utilities::generateTimestamp();
        $this->issuer = '';
        $this->authnInstant = Utilities::generateTimestamp();
        $this->attributes = array();
        $this->nameFormat = "\165\162\156\x3a\x6f\x61\x73\x69\163\x3a\x6e\x61\x6d\x65\163\x3a\x74\x63\x3a\x53\x41\115\x4c\x3a\x31\56\61\72\156\141\155\x65\x69\144\x2d\x66\157\162\x6d\141\164\72\165\x6e\x73\x70\145\x63\151\146\151\145\x64";
        $this->certificates = array();
        $this->AuthenticatingAuthority = array();
        $this->SubjectConfirmation = array();
        if (!($Th === NULL)) {
            goto W0;
        }
        return;
        W0:
        if (!($Th->localName === "\105\156\x63\162\x79\160\164\x65\144\x41\163\163\145\x72\164\151\x6f\x6e")) {
            goto r4;
        }
        $UF = Utilities::xpQuery($Th, "\56\x2f\x78\x65\x6e\143\72\105\x6e\x63\x72\171\x70\x74\145\x64\104\x61\x74\x61");
        $CN = Utilities::xpQuery($Th, "\56\x2f\170\x65\156\143\72\x45\x6e\x63\x72\171\x70\x74\x65\144\x44\141\x74\x61\x2f\144\x73\72\113\145\171\111\156\x66\x6f\57\170\145\156\x63\72\105\156\143\x72\x79\160\164\145\144\113\145\171");
        $j0 = '';
        if (empty($CN)) {
            goto jg;
        }
        $j0 = $CN[0]->firstChild->getAttribute("\x41\x6c\147\157\x72\x69\164\x68\x6d");
        goto De;
        jg:
        $CN = Utilities::xpQuery($Th, "\56\x2f\170\x65\156\x63\x3a\105\156\x63\162\x79\x70\x74\145\144\113\x65\x79\57\x78\x65\x6e\143\x3a\105\x6e\143\x72\171\x70\x74\x69\157\x6e\115\145\164\150\157\144");
        $j0 = $CN[0]->getAttribute("\x41\154\x67\x6f\162\x69\164\x68\x6d");
        De:
        $LS = Utilities::getEncryptionAlgorithm($j0);
        if (count($UF) === 0) {
            goto tH;
        }
        if (count($UF) > 1) {
            goto z2;
        }
        goto wq;
        tH:
        throw new Exception("\x4d\x69\163\x73\151\156\x67\40\145\156\x63\162\171\160\x74\x65\144\x20\x64\141\164\x61\x20\151\x6e\x20\74\x73\x61\155\154\72\105\x6e\143\162\x79\x70\x74\x65\144\101\163\163\145\x72\x74\x69\157\156\76\56");
        goto wq;
        z2:
        throw new Exception("\115\x6f\162\x65\x20\164\x68\x61\x6e\x20\157\156\145\40\145\156\x63\x72\x79\160\164\145\x64\40\144\141\164\141\x20\x65\154\145\x6d\x65\x6e\164\x20\x69\156\x20\74\x73\141\155\154\x3a\x45\x6e\x63\162\x79\x70\x74\145\144\101\163\163\x65\162\164\x69\157\156\76\x2e");
        wq:
        $a5 = new XMLSecurityKey($LS, array("\x74\x79\160\145" => "\x70\x72\x69\x76\x61\164\145"));
        $GR = get_site_option("\x6d\x6f\x5f\x73\x61\155\154\137\143\x75\x72\x72\x65\x6e\x74\137\143\x65\162\164\137\160\x72\151\166\x61\164\x65\x5f\x6b\145\171");
        $a5->loadKey($vG, FALSE);
        $Zo = array();
        $Th = Utilities::decryptElement($UF[0], $a5, $Zo);
        r4:
        if ($Th->hasAttribute("\111\104")) {
            goto rf;
        }
        throw new Exception("\115\x69\163\x73\x69\x6e\147\x20\111\104\x20\141\x74\x74\162\x69\142\x75\x74\x65\40\157\x6e\x20\x53\101\x4d\114\40\x61\x73\x73\x65\x72\x74\x69\x6f\x6e\56");
        rf:
        $this->id = $Th->getAttribute("\x49\x44");
        if (!($Th->getAttribute("\126\x65\x72\x73\151\x6f\x6e") !== "\62\56\60")) {
            goto Ha;
        }
        throw new Exception("\x55\x6e\x73\x75\160\160\157\x72\x74\145\144\40\x76\145\x72\x73\x69\x6f\x6e\72\x20" . $Th->getAttribute("\126\x65\x72\x73\151\x6f\156"));
        Ha:
        $this->issueInstant = Utilities::xsDateTimeToTimestamp($Th->getAttribute("\111\163\x73\165\x65\x49\156\163\164\x61\x6e\x74"));
        $B9 = Utilities::xpQuery($Th, "\x2e\x2f\163\141\155\x6c\x5f\x61\163\x73\145\162\164\x69\x6f\156\72\111\163\163\165\x65\x72");
        if (!empty($B9)) {
            goto O8;
        }
        throw new Exception("\x4d\151\163\163\x69\x6e\147\40\74\x73\141\x6d\154\72\x49\x73\163\x75\x65\162\76\x20\x69\x6e\x20\x61\163\163\145\162\164\x69\157\156\56");
        O8:
        $this->issuer = trim($B9[0]->textContent);
        $this->parseConditions($Th);
        $this->parseAuthnStatement($Th);
        $this->parseAttributes($Th);
        $this->parseEncryptedAttributes($Th);
        $this->parseSignature($Th);
        $this->parseSubject($Th);
    }
    private function parseSubject(DOMElement $Th)
    {
        $mk = Utilities::xpQuery($Th, "\x2e\x2f\163\141\155\x6c\137\x61\163\163\x65\162\x74\151\157\156\x3a\x53\x75\x62\x6a\145\x63\x74");
        if (empty($mk)) {
            goto lE;
        }
        if (count($mk) > 1) {
            goto IQ;
        }
        goto yl;
        lE:
        return;
        goto yl;
        IQ:
        throw new Exception("\115\157\x72\145\40\x74\150\x61\x6e\x20\x6f\x6e\x65\x20\74\163\141\155\154\72\x53\x75\142\x6a\x65\143\x74\76\x20\x69\x6e\x20\x3c\163\141\155\154\72\101\x73\x73\x65\162\x74\x69\x6f\x6e\76\56");
        yl:
        $mk = $mk[0];
        $q6 = Utilities::xpQuery($mk, "\x2e\x2f\x73\x61\155\x6c\x5f\141\x73\x73\x65\x72\164\x69\157\x6e\72\x4e\141\155\x65\x49\x44\x20\174\x20\x2e\x2f\x73\x61\x6d\x6c\x5f\x61\x73\163\x65\x72\164\x69\157\x6e\72\x45\156\x63\x72\171\160\x74\x65\144\x49\104\57\170\145\156\143\72\x45\x6e\143\x72\x79\160\164\145\144\x44\x61\164\x61");
        if (empty($q6)) {
            goto g1;
        }
        if (count($q6) > 1) {
            goto eo;
        }
        goto FV;
        g1:
        if ($_POST["\122\x65\154\141\171\123\x74\141\x74\x65"] == "\164\145\x73\x74\x56\141\x6c\x69\144\141\164\x65" or $_POST["\x52\x65\x6c\141\171\123\x74\141\x74\x65"] == "\x74\145\163\x74\116\145\167\x43\x65\162\164\151\146\151\x63\141\x74\145") {
            goto x6;
        }
        wp_die("\127\x65\x20\x63\157\165\x6c\x64\40\x6e\x6f\x74\x20\x73\151\x67\156\40\171\157\165\x20\x69\156\x2e\x20\x50\x6c\x65\x61\x73\145\x20\x63\x6f\x6e\164\141\143\164\40\x79\157\x75\162\x20\141\x64\x6d\151\156\151\163\164\162\x61\x74\157\162");
        goto Rp;
        x6:
        echo "\x3c\144\x69\166\x20\163\164\x79\x6c\x65\75\42\146\157\x6e\x74\x2d\146\141\155\x69\154\x79\72\x43\141\154\151\x62\162\151\73\160\x61\144\144\x69\156\x67\72\60\40\x33\x25\73\42\x3e";
        echo "\74\144\x69\166\40\163\164\x79\x6c\145\75\x22\x63\157\154\x6f\x72\72\40\43\x61\71\64\64\x34\62\x3b\142\x61\143\x6b\147\x72\157\165\x6e\x64\x2d\x63\x6f\x6c\x6f\162\72\x20\43\146\62\x64\145\x64\145\73\x70\141\144\144\151\x6e\x67\x3a\x20\x31\x35\160\170\73\155\x61\x72\x67\x69\x6e\55\x62\157\164\x74\157\155\x3a\x20\x32\x30\160\x78\73\x74\x65\x78\x74\x2d\x61\154\x69\147\x6e\x3a\143\x65\x6e\164\145\x72\x3b\142\x6f\162\144\145\162\72\61\160\170\40\x73\x6f\x6c\151\x64\40\43\105\66\102\x33\102\62\x3b\x66\x6f\x6e\x74\x2d\163\151\172\x65\72\61\x38\160\x74\x3b\42\76\x20\x45\x52\x52\117\x52\x3c\x2f\144\x69\166\x3e\15\12\40\40\x20\x20\x20\40\x20\40\x20\40\40\74\144\151\x76\x20\163\164\x79\154\x65\x3d\x22\x63\x6f\154\x6f\x72\72\x20\43\141\x39\64\x34\x34\62\x3b\146\x6f\156\164\55\x73\x69\x7a\145\x3a\61\x34\160\164\x3b\40\x6d\141\x72\147\x69\x6e\x2d\142\x6f\x74\x74\157\x6d\x3a\x32\x30\x70\x78\x3b\x22\76\x3c\160\x3e\74\x73\164\x72\x6f\156\147\x3e\105\162\162\x6f\162\72\x20\x3c\57\x73\x74\162\x6f\x6e\147\x3e\x4d\x69\x73\x73\x69\156\147\x20\x20\116\x61\x6d\145\x49\x44\40\x6f\x72\x20\x45\x6e\x63\x72\x79\x70\x74\x65\144\x49\104\40\151\x6e\40\x53\101\115\114\x20\x52\145\163\160\x6f\x6e\x73\x65\x3c\x2f\x70\x3e\15\12\40\40\x20\x20\x20\x20\x20\x20\x20\40\40\40\x20\x20\x20\40\74\x70\x3e\x50\x6c\145\x61\163\145\40\143\x6f\x6e\x74\x61\x63\164\40\x79\157\x75\162\x20\141\144\155\151\156\151\163\x74\x72\141\164\157\162\40\x61\x6e\144\x20\x72\x65\x70\x6f\x72\x74\x20\164\x68\x65\40\x66\x6f\154\x6c\157\167\151\156\x67\40\x65\162\x72\157\162\72\74\x2f\160\x3e\xd\xa\40\x20\x20\x20\40\x20\x20\x20\40\x20\x20\40\40\x20\40\x20\74\160\x3e\74\x73\x74\x72\157\x6e\147\x3e\x50\x6f\x73\163\151\142\154\145\40\x43\x61\165\x73\145\72\74\x2f\163\x74\162\157\156\147\76\40\116\x61\155\145\x49\x44\x20\x6e\157\x74\x20\146\x6f\x75\156\x64\40\x69\156\x20\x53\101\115\114\x20\122\x65\163\x70\x6f\156\x73\145\x20\163\165\x62\152\x65\x63\x74\74\57\160\76\15\xa\40\x20\40\x20\x20\40\x20\40\x20\x20\40\x20\x20\40\40\40\74\x2f\144\x69\166\76\xd\12\40\x20\40\40\x20\40\40\40\40\x20\x20\40\40\40\40\40\74\144\151\x76\40\x73\x74\x79\154\x65\x3d\42\x6d\x61\162\147\x69\x6e\x3a\63\x25\73\x64\x69\x73\x70\x6c\x61\x79\x3a\x62\x6c\157\x63\153\73\164\x65\170\164\55\x61\x6c\x69\x67\156\x3a\143\145\x6e\x74\x65\x72\x3b\x22\x3e\xd\xa\x20\40\40\40\40\x20\40\40\x20\40\x20\40\x20\x20\x20\x20\x3c\x64\x69\x76\40\163\x74\x79\154\145\x3d\x22\155\x61\162\147\x69\156\x3a\63\x25\73\144\151\163\160\154\x61\x79\x3a\142\154\x6f\x63\153\73\164\x65\x78\164\x2d\x61\154\151\147\x6e\72\x63\x65\x6e\164\x65\x72\x3b\x22\76\74\x69\156\160\165\x74\40\x73\x74\x79\x6c\x65\75\x22\x70\x61\x64\144\x69\x6e\147\72\61\x25\73\167\x69\x64\164\150\72\x31\60\x30\160\x78\73\142\x61\143\x6b\x67\x72\x6f\165\156\144\x3a\40\x23\x30\60\71\x31\x43\x44\40\x6e\157\156\x65\x20\162\145\x70\x65\x61\x74\x20\x73\143\x72\x6f\154\154\x20\60\x25\40\x30\x25\73\x63\165\x72\163\157\162\x3a\x20\160\157\x69\x6e\164\x65\x72\73\x66\x6f\156\164\55\x73\x69\x7a\145\x3a\61\x35\160\x78\73\x62\157\162\144\145\x72\55\167\151\x64\x74\x68\72\x20\61\x70\170\x3b\x62\157\162\x64\x65\162\55\163\164\x79\x6c\145\x3a\x20\163\157\x6c\151\x64\x3b\x62\157\162\x64\145\x72\55\x72\141\144\151\165\163\72\40\x33\x70\170\73\x77\x68\x69\x74\145\55\x73\160\x61\143\x65\x3a\x20\x6e\157\x77\x72\141\x70\x3b\142\157\170\x2d\x73\x69\x7a\x69\156\147\72\x20\x62\157\162\144\x65\x72\x2d\142\x6f\170\x3b\x62\x6f\162\x64\145\162\x2d\143\x6f\x6c\x6f\x72\x3a\40\43\60\60\67\x33\101\x41\73\x62\x6f\170\x2d\163\150\x61\144\x6f\167\72\x20\x30\x70\x78\x20\x31\160\170\x20\x30\x70\x78\40\x72\147\x62\x61\50\61\62\60\x2c\40\x32\x30\x30\x2c\40\62\63\x30\54\x20\60\x2e\x36\51\x20\x69\156\163\145\164\x3b\x63\x6f\x6c\x6f\162\x3a\x20\43\x46\x46\106\73\42\x74\x79\160\145\75\x22\142\x75\x74\164\x6f\x6e\42\40\x76\x61\154\165\145\75\42\104\x6f\156\x65\x22\x20\157\156\103\x6c\151\x63\153\x3d\x22\x73\145\154\x66\x2e\x63\154\157\163\145\50\51\73\42\76\x3c\x2f\x64\151\x76\x3e";
        exit;
        Rp:
        goto FV;
        eo:
        throw new Exception("\x4d\157\x72\145\x20\164\x68\141\x6e\40\x6f\x6e\145\x20\x3c\163\x61\x6d\154\x3a\116\x61\x6d\x65\111\104\x3e\x20\157\162\x20\74\163\141\155\x6c\72\x45\156\x63\x72\x79\160\164\145\x64\x44\76\x20\x69\156\40\x3c\x73\x61\x6d\154\72\x53\165\142\152\145\143\164\x3e\x2e");
        FV:
        $q6 = $q6[0];
        if ($q6->localName === "\105\156\x63\x72\x79\x70\164\145\144\104\x61\164\141") {
            goto m9;
        }
        $this->nameId = Utilities::parseNameId($q6);
        goto fe;
        m9:
        $this->encryptedNameId = $q6;
        fe:
    }
    private function parseConditions(DOMElement $Th)
    {
        $gK = Utilities::xpQuery($Th, "\56\57\163\x61\155\x6c\x5f\141\x73\x73\x65\162\164\151\157\156\72\x43\x6f\156\144\151\x74\x69\x6f\156\x73");
        if (empty($gK)) {
            goto e_;
        }
        if (count($gK) > 1) {
            goto UL;
        }
        goto Tf;
        e_:
        return;
        goto Tf;
        UL:
        throw new Exception("\x4d\x6f\162\x65\x20\x74\150\141\x6e\40\x6f\x6e\x65\x20\74\x73\141\x6d\x6c\x3a\103\x6f\x6e\144\x69\164\151\x6f\x6e\163\x3e\40\151\x6e\x20\74\163\x61\x6d\154\x3a\x41\163\163\x65\162\x74\151\x6f\x6e\76\56");
        Tf:
        $gK = $gK[0];
        if (!$gK->hasAttribute("\116\157\x74\x42\145\x66\x6f\162\x65")) {
            goto vp;
        }
        $wQ = Utilities::xsDateTimeToTimestamp($gK->getAttribute("\116\x6f\x74\x42\x65\146\x6f\162\x65"));
        if (!($this->notBefore === NULL || $this->notBefore < $wQ)) {
            goto xs;
        }
        $this->notBefore = $wQ;
        xs:
        vp:
        if (!$gK->hasAttribute("\116\157\x74\x4f\156\x4f\162\101\x66\x74\x65\162")) {
            goto St;
        }
        $V2 = Utilities::xsDateTimeToTimestamp($gK->getAttribute("\116\157\x74\117\156\117\x72\x41\146\x74\x65\x72"));
        if (!($this->notOnOrAfter === NULL || $this->notOnOrAfter > $V2)) {
            goto zA;
        }
        $this->notOnOrAfter = $V2;
        zA:
        St:
        $Vf = $gK->firstChild;
        qi:
        if (!($Vf !== NULL)) {
            goto aq;
        }
        if (!$Vf instanceof DOMText) {
            goto bZ;
        }
        goto TK;
        bZ:
        if (!($Vf->namespaceURI !== "\165\x72\156\72\x6f\141\163\x69\x73\72\x6e\x61\x6d\145\163\72\164\143\72\x53\x41\115\x4c\x3a\x32\x2e\60\72\x61\163\163\145\x72\164\x69\157\x6e")) {
            goto QN;
        }
        throw new Exception("\x55\156\153\x6e\157\x77\156\40\x6e\x61\x6d\x65\x73\160\141\x63\145\x20\157\146\40\x63\157\x6e\144\151\164\x69\x6f\156\x3a\40" . var_export($Vf->namespaceURI, TRUE));
        QN:
        switch ($Vf->localName) {
            case "\101\165\x64\x69\x65\156\143\x65\122\145\x73\164\162\151\x63\164\151\157\x6e":
                $Y_ = Utilities::extractStrings($Vf, "\x75\162\x6e\72\x6f\141\x73\x69\x73\x3a\156\x61\x6d\145\163\72\x74\x63\72\123\101\x4d\x4c\x3a\x32\x2e\x30\72\141\x73\163\145\162\x74\x69\x6f\156", "\x41\165\x64\151\145\156\x63\145");
                if ($this->validAudiences === NULL) {
                    goto hy;
                }
                $this->validAudiences = array_intersect($this->validAudiences, $Y_);
                goto vi;
                hy:
                $this->validAudiences = $Y_;
                vi:
                goto Ps;
            case "\x4f\156\x65\124\x69\155\145\x55\x73\x65":
                goto Ps;
            case "\120\x72\x6f\170\171\122\145\163\164\x72\151\143\x74\151\157\156":
                goto Ps;
            default:
                throw new Exception("\125\x6e\x6b\156\x6f\167\156\x20\x63\157\156\144\x69\164\151\x6f\x6e\x3a\x20" . var_export($Vf->localName, TRUE));
        }
        Pb:
        Ps:
        TK:
        $Vf = $Vf->nextSibling;
        goto qi;
        aq:
    }
    private function parseAuthnStatement(DOMElement $Th)
    {
        $b5 = Utilities::xpQuery($Th, "\x2e\57\163\141\155\x6c\137\x61\x73\163\145\x72\164\x69\157\x6e\x3a\101\x75\164\x68\x6e\x53\x74\x61\x74\145\x6d\x65\x6e\164");
        if (empty($b5)) {
            goto uO;
        }
        if (count($b5) > 1) {
            goto a4;
        }
        goto Xx;
        uO:
        $this->authnInstant = NULL;
        return;
        goto Xx;
        a4:
        throw new Exception("\x4d\157\x72\145\40\164\x68\141\x74\40\157\x6e\145\40\74\x73\x61\x6d\154\72\x41\x75\x74\x68\156\x53\164\141\x74\145\x6d\x65\156\x74\x3e\x20\x69\x6e\40\74\163\141\155\x6c\72\x41\x73\x73\145\162\x74\151\157\x6e\x3e\x20\x6e\157\164\40\163\x75\160\x70\157\162\164\x65\144\56");
        Xx:
        $uD = $b5[0];
        if ($uD->hasAttribute("\x41\x75\x74\x68\156\x49\156\x73\x74\141\156\164")) {
            goto dn;
        }
        throw new Exception("\x4d\151\163\x73\151\x6e\147\40\162\145\x71\165\151\x72\145\144\40\x41\165\x74\x68\156\111\156\x73\164\x61\x6e\x74\x20\141\x74\x74\x72\151\142\x75\164\x65\x20\x6f\156\x20\x3c\x73\141\155\154\x3a\x41\165\x74\x68\156\x53\164\x61\x74\x65\x6d\x65\x6e\x74\76\x2e");
        dn:
        $this->authnInstant = Utilities::xsDateTimeToTimestamp($uD->getAttribute("\101\x75\164\150\x6e\111\156\163\164\141\x6e\164"));
        if (!$uD->hasAttribute("\123\x65\163\163\151\x6f\156\116\157\164\x4f\x6e\117\162\x41\146\x74\x65\162")) {
            goto au;
        }
        $this->sessionNotOnOrAfter = Utilities::xsDateTimeToTimestamp($uD->getAttribute("\x53\145\x73\x73\x69\x6f\156\x4e\x6f\x74\x4f\156\x4f\x72\x41\146\164\145\162"));
        au:
        if (!$uD->hasAttribute("\x53\x65\163\163\x69\157\x6e\111\156\144\x65\x78")) {
            goto C2;
        }
        $this->sessionIndex = $uD->getAttribute("\123\x65\163\x73\x69\x6f\x6e\x49\156\144\145\x78");
        C2:
        $this->parseAuthnContext($uD);
    }
    private function parseAuthnContext(DOMElement $VT)
    {
        $cI = Utilities::xpQuery($VT, "\x2e\57\x73\141\x6d\x6c\137\x61\x73\x73\x65\x72\164\151\x6f\156\x3a\x41\x75\x74\x68\156\x43\x6f\x6e\x74\x65\170\x74");
        if (count($cI) > 1) {
            goto vo;
        }
        if (empty($cI)) {
            goto UU;
        }
        goto XN;
        vo:
        throw new Exception("\x4d\x6f\x72\145\40\164\150\x61\156\40\157\x6e\x65\40\74\x73\x61\x6d\x6c\x3a\101\x75\x74\150\156\x43\157\156\164\x65\170\x74\x3e\40\x69\x6e\40\74\163\x61\x6d\x6c\72\101\165\x74\150\156\123\x74\141\164\145\x6d\x65\156\164\76\56");
        goto XN;
        UU:
        throw new Exception("\x4d\151\x73\163\151\x6e\x67\x20\162\145\x71\165\x69\x72\145\x64\x20\x3c\163\x61\155\154\72\x41\165\x74\150\x6e\103\157\x6e\164\x65\170\164\76\x20\x69\x6e\40\74\163\x61\x6d\x6c\72\101\x75\164\150\x6e\x53\x74\141\x74\x65\x6d\x65\156\164\76\x2e");
        XN:
        $fz = $cI[0];
        $m1 = Utilities::xpQuery($fz, "\x2e\x2f\x73\141\x6d\154\137\x61\163\163\145\x72\164\x69\x6f\x6e\x3a\101\165\x74\150\x6e\103\157\156\x74\145\170\164\104\x65\x63\154\122\x65\146");
        if (count($m1) > 1) {
            goto Sb;
        }
        if (count($m1) === 1) {
            goto Rx;
        }
        goto sn;
        Sb:
        throw new Exception("\115\157\x72\x65\x20\164\x68\141\x6e\40\157\156\145\40\74\x73\141\x6d\x6c\x3a\101\x75\164\x68\156\103\x6f\156\x74\x65\x78\x74\104\145\x63\154\122\x65\146\x3e\x20\x66\x6f\x75\156\144\x3f");
        goto sn;
        Rx:
        $this->setAuthnContextDeclRef(trim($m1[0]->textContent));
        sn:
        $Ca = Utilities::xpQuery($fz, "\x2e\57\163\x61\x6d\x6c\x5f\x61\163\163\x65\x72\x74\x69\157\x6e\72\x41\165\164\x68\x6e\103\157\156\164\x65\x78\164\104\x65\143\154");
        if (count($Ca) > 1) {
            goto w8;
        }
        if (count($Ca) === 1) {
            goto ib;
        }
        goto nm;
        w8:
        throw new Exception("\x4d\157\162\x65\x20\164\150\x61\x6e\x20\x6f\x6e\x65\x20\x3c\163\141\155\154\x3a\101\165\164\x68\156\x43\157\x6e\164\x65\170\x74\x44\x65\x63\154\x3e\x20\x66\157\x75\x6e\144\x3f");
        goto nm;
        ib:
        $this->setAuthnContextDecl(new SAML2_XML_Chunk($Ca[0]));
        nm:
        $Bn = Utilities::xpQuery($fz, "\56\x2f\163\141\x6d\x6c\x5f\x61\163\163\x65\162\164\151\157\156\x3a\101\165\164\150\x6e\x43\157\x6e\x74\x65\170\x74\x43\154\x61\x73\x73\x52\145\146");
        if (count($Bn) > 1) {
            goto ZP;
        }
        if (count($Bn) === 1) {
            goto i9;
        }
        goto sp;
        ZP:
        throw new Exception("\x4d\x6f\x72\x65\x20\x74\150\x61\156\x20\157\x6e\x65\40\74\163\141\155\x6c\x3a\x41\165\164\150\156\103\157\156\x74\145\170\164\x43\x6c\x61\163\163\122\x65\146\x3e\40\151\x6e\40\x3c\x73\141\155\154\x3a\x41\x75\x74\150\x6e\103\x6f\x6e\164\145\x78\164\x3e\x2e");
        goto sp;
        i9:
        $this->setAuthnContextClassRef(trim($Bn[0]->textContent));
        sp:
        if (!(empty($this->authnContextClassRef) && empty($this->authnContextDecl) && empty($this->authnContextDeclRef))) {
            goto uo;
        }
        throw new Exception("\x4d\x69\163\163\x69\x6e\147\x20\145\151\164\x68\145\x72\x20\x3c\x73\141\x6d\x6c\72\101\165\164\x68\x6e\103\157\x6e\164\145\x78\164\103\154\x61\x73\x73\122\x65\146\76\x20\x6f\x72\x20\x3c\x73\x61\155\x6c\72\101\x75\164\x68\156\x43\157\x6e\x74\x65\x78\x74\104\x65\143\x6c\x52\x65\x66\76\40\157\162\x20\74\x73\141\155\154\x3a\x41\x75\164\x68\x6e\x43\157\156\x74\x65\x78\x74\x44\145\x63\154\x3e");
        uo:
        $this->AuthenticatingAuthority = Utilities::extractStrings($fz, "\x75\x72\x6e\x3a\157\141\163\151\163\72\156\x61\x6d\x65\x73\x3a\164\143\72\123\x41\x4d\x4c\72\x32\x2e\60\x3a\141\x73\163\145\x72\x74\151\x6f\156", "\x41\165\164\150\x65\x6e\164\x69\x63\141\x74\x69\156\147\101\x75\x74\x68\157\162\151\164\x79");
    }
    private function parseAttributes(DOMElement $Th)
    {
        $qH = TRUE;
        $ao = Utilities::xpQuery($Th, "\56\57\x73\141\155\x6c\137\141\x73\163\x65\x72\164\151\157\x6e\72\x41\164\x74\162\x69\x62\x75\x74\x65\x53\x74\141\164\145\155\x65\x6e\x74\57\x73\x61\155\x6c\137\141\x73\163\145\162\164\151\157\156\72\x41\x74\x74\162\x69\142\x75\x74\x65");
        foreach ($ao as $rV) {
            if ($rV->hasAttribute("\x4e\141\155\x65")) {
                goto f4;
            }
            throw new Exception("\x4d\x69\x73\x73\x69\x6e\x67\40\x6e\x61\155\145\40\157\156\40\x3c\163\141\x6d\x6c\x3a\101\x74\164\162\151\142\x75\164\x65\76\40\145\154\x65\x6d\x65\x6e\x74\x2e");
            f4:
            $Wu = $rV->getAttribute("\x4e\141\x6d\145");
            if ($rV->hasAttribute("\x4e\141\155\x65\x46\x6f\162\x6d\x61\x74")) {
                goto rG;
            }
            $vx = "\x75\x72\156\x3a\x6f\141\163\x69\x73\x3a\x6e\x61\155\145\163\72\164\143\x3a\123\101\115\x4c\x3a\x31\x2e\x31\72\x6e\x61\x6d\145\x69\144\x2d\x66\157\x72\155\141\164\x3a\165\x6e\x73\x70\x65\x63\x69\x66\151\145\x64";
            goto uU;
            rG:
            $vx = $rV->getAttribute("\116\141\155\x65\x46\157\162\x6d\141\164");
            uU:
            if ($qH) {
                goto nw;
            }
            if (!($this->nameFormat !== $vx)) {
                goto Qn;
            }
            $this->nameFormat = "\165\x72\x6e\x3a\157\x61\163\151\163\72\156\141\x6d\145\x73\72\x74\143\x3a\123\101\x4d\114\72\x31\56\61\x3a\x6e\141\155\x65\x69\x64\x2d\146\x6f\162\x6d\x61\164\x3a\165\156\163\x70\145\143\151\146\151\x65\144";
            Qn:
            goto qD;
            nw:
            $this->nameFormat = $vx;
            $qH = FALSE;
            qD:
            if (array_key_exists($Wu, $this->attributes)) {
                goto OO;
            }
            $this->attributes[$Wu] = array();
            OO:
            $rj = Utilities::xpQuery($rV, "\x2e\57\x73\x61\155\x6c\x5f\x61\x73\163\145\162\x74\x69\157\x6e\72\101\164\164\x72\x69\x62\165\x74\x65\x56\141\154\165\145");
            foreach ($rj as $n5) {
                $this->attributes[$Wu][] = trim($n5->textContent);
                rh:
            }
            W8:
            vJ:
        }
        Ct:
    }
    private function parseEncryptedAttributes(DOMElement $Th)
    {
        $this->encryptedAttribute = Utilities::xpQuery($Th, "\x2e\x2f\x73\141\155\154\137\141\163\x73\x65\162\164\151\x6f\x6e\x3a\101\x74\x74\162\x69\142\165\x74\145\123\x74\141\164\145\155\x65\156\x74\57\163\141\155\154\x5f\x61\163\163\x65\x72\x74\x69\x6f\x6e\x3a\x45\x6e\143\x72\171\x70\x74\145\144\x41\x74\x74\x72\151\x62\x75\x74\145");
    }
    private function parseSignature(DOMElement $Th)
    {
        $BL = Utilities::validateElement($Th);
        if (!($BL !== FALSE)) {
            goto vK;
        }
        $this->wasSignedAtConstruction = TRUE;
        $this->certificates = $BL["\103\x65\x72\x74\151\146\151\143\x61\164\145\163"];
        $this->signatureData = $BL;
        vK:
    }
    public function validate(XMLSecurityKey $a5)
    {
        if (!($this->signatureData === NULL)) {
            goto PX;
        }
        return FALSE;
        PX:
        Utilities::validateSignature($this->signatureData, $a5);
        return TRUE;
    }
    public function getId()
    {
        return $this->id;
    }
    public function setId($oH)
    {
        $this->id = $oH;
    }
    public function getIssueInstant()
    {
        return $this->issueInstant;
    }
    public function setIssueInstant($ii)
    {
        $this->issueInstant = $ii;
    }
    public function getIssuer()
    {
        return $this->issuer;
    }
    public function setIssuer($B9)
    {
        $this->issuer = $B9;
    }
    public function getNameId()
    {
        if (!($this->encryptedNameId !== NULL)) {
            goto FT;
        }
        throw new Exception("\x41\x74\x74\x65\x6d\x70\164\145\x64\x20\x74\x6f\40\x72\x65\164\162\151\145\x76\x65\40\145\156\143\x72\x79\x70\x74\x65\144\x20\x4e\x61\x6d\x65\x49\104\x20\x77\x69\164\x68\x6f\x75\x74\40\144\x65\143\x72\x79\x70\x74\x69\156\x67\x20\151\x74\x20\x66\x69\x72\x73\x74\56");
        FT:
        return $this->nameId;
    }
    public function setNameId($q6)
    {
        $this->nameId = $q6;
    }
    public function isNameIdEncrypted()
    {
        if (!($this->encryptedNameId !== NULL)) {
            goto Sd;
        }
        return TRUE;
        Sd:
        return FALSE;
    }
    public function encryptNameId(XMLSecurityKey $a5)
    {
        $Pj = new DOMDocument();
        $ym = $Pj->createElement("\162\x6f\157\x74");
        $Pj->appendChild($ym);
        Utilities::addNameId($ym, $this->nameId);
        $q6 = $ym->firstChild;
        Utilities::getContainer()->debugMessage($q6, "\x65\x6e\143\162\171\x70\x74");
        $cy = new XMLSecEnc();
        $cy->setNode($q6);
        $cy->type = XMLSecEnc::Element;
        $Is = new XMLSecurityKey(XMLSecurityKey::AES128_CBC);
        $Is->generateSessionKey();
        $cy->encryptKey($a5, $Is);
        $this->encryptedNameId = $cy->encryptNode($Is);
        $this->nameId = NULL;
    }
    public function decryptNameId(XMLSecurityKey $a5, array $Zo = array())
    {
        if (!($this->encryptedNameId === NULL)) {
            goto GB;
        }
        return;
        GB:
        $q6 = Utilities::decryptElement($this->encryptedNameId, $a5, $Zo);
        Utilities::getContainer()->debugMessage($q6, "\144\x65\143\162\171\x70\164");
        $this->nameId = Utilities::parseNameId($q6);
        $this->encryptedNameId = NULL;
    }
    public function decryptAttributes(XMLSecurityKey $a5, array $Zo = array())
    {
        if (!($this->encryptedAttribute === NULL)) {
            goto aI;
        }
        return;
        aI:
        $qH = TRUE;
        $ao = $this->encryptedAttribute;
        foreach ($ao as $f3) {
            $rV = Utilities::decryptElement($f3->getElementsByTagName("\x45\156\x63\162\171\160\x74\x65\144\x44\141\x74\x61")->item(0), $a5, $Zo);
            if ($rV->hasAttribute("\116\141\x6d\x65")) {
                goto yG;
            }
            throw new Exception("\115\151\x73\x73\151\156\x67\x20\156\141\x6d\145\40\x6f\x6e\40\74\163\141\155\x6c\x3a\101\x74\x74\162\x69\142\165\x74\145\76\x20\x65\154\145\x6d\145\156\164\56");
            yG:
            $Wu = $rV->getAttribute("\116\x61\155\145");
            if ($rV->hasAttribute("\116\x61\x6d\x65\x46\157\x72\155\141\164")) {
                goto Zs;
            }
            $vx = "\165\162\156\72\157\x61\163\x69\163\72\x6e\x61\x6d\x65\x73\x3a\x74\x63\72\123\101\115\114\x3a\x32\x2e\x30\x3a\x61\x74\x74\x72\x6e\141\x6d\x65\x2d\x66\x6f\x72\155\x61\164\x3a\x75\156\163\160\145\x63\x69\x66\151\145\144";
            goto Op;
            Zs:
            $vx = $rV->getAttribute("\116\141\155\x65\106\157\162\x6d\x61\164");
            Op:
            if ($qH) {
                goto yB;
            }
            if (!($this->nameFormat !== $vx)) {
                goto Up;
            }
            $this->nameFormat = "\165\162\x6e\72\x6f\x61\x73\x69\163\x3a\x6e\x61\x6d\x65\163\x3a\x74\x63\72\x53\x41\x4d\x4c\72\x32\56\60\x3a\x61\x74\x74\162\x6e\x61\x6d\145\55\x66\157\162\155\x61\164\72\165\156\163\x70\x65\x63\151\x66\151\145\144";
            Up:
            goto Mh;
            yB:
            $this->nameFormat = $vx;
            $qH = FALSE;
            Mh:
            if (array_key_exists($Wu, $this->attributes)) {
                goto Pf;
            }
            $this->attributes[$Wu] = array();
            Pf:
            $rj = Utilities::xpQuery($rV, "\56\x2f\163\x61\155\154\x5f\141\163\163\x65\x72\164\151\x6f\x6e\x3a\x41\x74\x74\x72\x69\x62\165\164\x65\126\141\154\165\145");
            foreach ($rj as $n5) {
                $this->attributes[$Wu][] = trim($n5->textContent);
                w3:
            }
            Co:
            rz:
        }
        Sz:
    }
    public function getNotBefore()
    {
        return $this->notBefore;
    }
    public function setNotBefore($wQ)
    {
        $this->notBefore = $wQ;
    }
    public function getNotOnOrAfter()
    {
        return $this->notOnOrAfter;
    }
    public function setNotOnOrAfter($V2)
    {
        $this->notOnOrAfter = $V2;
    }
    public function setEncryptedAttributes($U9)
    {
        $this->requiredEncAttributes = $U9;
    }
    public function getValidAudiences()
    {
        return $this->validAudiences;
    }
    public function setValidAudiences(array $R3 = NULL)
    {
        $this->validAudiences = $R3;
    }
    public function getAuthnInstant()
    {
        return $this->authnInstant;
    }
    public function setAuthnInstant($KS)
    {
        $this->authnInstant = $KS;
    }
    public function getSessionNotOnOrAfter()
    {
        return $this->sessionNotOnOrAfter;
    }
    public function setSessionNotOnOrAfter($Zd)
    {
        $this->sessionNotOnOrAfter = $Zd;
    }
    public function getSessionIndex()
    {
        return $this->sessionIndex;
    }
    public function setSessionIndex($sL)
    {
        $this->sessionIndex = $sL;
    }
    public function getAuthnContext()
    {
        if (empty($this->authnContextClassRef)) {
            goto S5;
        }
        return $this->authnContextClassRef;
        S5:
        if (empty($this->authnContextDeclRef)) {
            goto ow;
        }
        return $this->authnContextDeclRef;
        ow:
        return NULL;
    }
    public function setAuthnContext($Df)
    {
        $this->setAuthnContextClassRef($Df);
    }
    public function getAuthnContextClassRef()
    {
        return $this->authnContextClassRef;
    }
    public function setAuthnContextClassRef($Uu)
    {
        $this->authnContextClassRef = $Uu;
    }
    public function setAuthnContextDecl(SAML2_XML_Chunk $LI)
    {
        if (empty($this->authnContextDeclRef)) {
            goto Gw;
        }
        throw new Exception("\101\165\x74\x68\x6e\103\x6f\x6e\x74\145\x78\164\104\x65\143\x6c\x52\x65\146\x20\151\x73\40\x61\x6c\162\x65\x61\x64\x79\40\x72\145\x67\x69\163\x74\x65\x72\x65\144\41\x20\115\141\171\40\157\x6e\x6c\171\x20\x68\141\x76\145\40\x65\x69\x74\x68\145\162\x20\x61\40\104\145\143\154\x20\157\162\x20\x61\40\x44\x65\x63\154\122\145\146\54\40\156\x6f\164\x20\142\157\x74\x68\41");
        Gw:
        $this->authnContextDecl = $LI;
    }
    public function getAuthnContextDecl()
    {
        return $this->authnContextDecl;
    }
    public function setAuthnContextDeclRef($qm)
    {
        if (empty($this->authnContextDecl)) {
            goto pG;
        }
        throw new Exception("\x41\165\x74\150\x6e\x43\x6f\156\164\145\170\x74\104\145\x63\x6c\40\x69\x73\x20\141\154\x72\x65\x61\144\x79\x20\162\145\x67\x69\163\x74\145\x72\145\144\41\40\115\141\x79\x20\x6f\156\154\x79\x20\x68\141\166\x65\x20\145\151\164\150\x65\162\40\x61\x20\x44\145\143\154\40\157\162\40\x61\x20\x44\145\143\154\x52\x65\146\54\40\x6e\157\x74\x20\142\157\x74\150\x21");
        pG:
        $this->authnContextDeclRef = $qm;
    }
    public function getAuthnContextDeclRef()
    {
        return $this->authnContextDeclRef;
    }
    public function getAuthenticatingAuthority()
    {
        return $this->AuthenticatingAuthority;
    }
    public function setAuthenticatingAuthority($zv)
    {
        $this->AuthenticatingAuthority = $zv;
    }
    public function getAttributes()
    {
        return $this->attributes;
    }
    public function setAttributes(array $ao)
    {
        $this->attributes = $ao;
    }
    public function getAttributeNameFormat()
    {
        return $this->nameFormat;
    }
    public function setAttributeNameFormat($vx)
    {
        $this->nameFormat = $vx;
    }
    public function getSubjectConfirmation()
    {
        return $this->SubjectConfirmation;
    }
    public function setSubjectConfirmation(array $YD)
    {
        $this->SubjectConfirmation = $YD;
    }
    public function getSignatureKey()
    {
        return $this->signatureKey;
    }
    public function setSignatureKey(XMLsecurityKey $Mk = NULL)
    {
        $this->signatureKey = $Mk;
    }
    public function getEncryptionKey()
    {
        return $this->encryptionKey;
    }
    public function setEncryptionKey(XMLSecurityKey $XS = NULL)
    {
        $this->encryptionKey = $XS;
    }
    public function setCertificates(array $x4)
    {
        $this->certificates = $x4;
    }
    public function getCertificates()
    {
        return $this->certificates;
    }
    public function getSignatureData()
    {
        return $this->signatureData;
    }
    public function getWasSignedAtConstruction()
    {
        return $this->wasSignedAtConstruction;
    }
    public function toXML(DOMNode $W0 = NULL)
    {
        if ($W0 === NULL) {
            goto Kp;
        }
        $vy = $W0->ownerDocument;
        goto AV;
        Kp:
        $vy = new DOMDocument();
        $W0 = $vy;
        AV:
        $ym = $vy->createElementNS("\165\x72\x6e\72\157\141\x73\x69\163\x3a\156\141\x6d\145\163\x3a\164\x63\72\123\x41\115\x4c\72\62\x2e\x30\72\x61\163\x73\x65\162\x74\151\157\156", "\x73\x61\x6d\x6c\72" . "\101\163\163\145\x72\x74\x69\157\x6e");
        $W0->appendChild($ym);
        $ym->setAttributeNS("\x75\162\156\x3a\x6f\x61\163\151\x73\x3a\x6e\141\x6d\x65\x73\72\x74\x63\x3a\123\101\115\x4c\x3a\x32\56\60\x3a\160\162\157\x74\157\x63\x6f\154", "\163\141\155\x6c\x70\x3a\164\x6d\160", "\x74\x6d\x70");
        $ym->removeAttributeNS("\165\x72\x6e\x3a\157\141\163\x69\x73\72\x6e\x61\x6d\145\x73\x3a\x74\x63\x3a\123\101\x4d\114\72\x32\56\x30\x3a\160\162\x6f\x74\157\x63\157\x6c", "\x74\x6d\x70");
        $ym->setAttributeNS("\150\164\164\x70\x3a\x2f\x2f\167\x77\x77\x2e\167\x33\56\157\162\x67\x2f\x32\60\60\61\x2f\130\115\x4c\123\x63\150\x65\155\x61\55\x69\x6e\163\164\141\156\143\145", "\x78\x73\x69\x3a\x74\x6d\x70", "\x74\155\160");
        $ym->removeAttributeNS("\x68\164\164\x70\x3a\x2f\57\167\167\167\x2e\167\x33\56\157\x72\x67\x2f\62\60\x30\61\x2f\x58\x4d\x4c\x53\x63\150\145\x6d\x61\x2d\x69\156\x73\x74\x61\x6e\x63\145", "\164\155\x70");
        $ym->setAttributeNS("\x68\164\164\160\x3a\57\x2f\x77\167\x77\56\167\63\56\157\x72\147\x2f\x32\x30\60\x31\x2f\x58\115\x4c\x53\143\150\x65\x6d\141", "\170\x73\72\x74\155\x70", "\164\x6d\160");
        $ym->removeAttributeNS("\150\x74\164\x70\72\57\x2f\167\x77\x77\56\x77\63\x2e\157\162\147\57\x32\60\60\x31\x2f\x58\x4d\x4c\x53\143\x68\x65\x6d\x61", "\164\155\160");
        $ym->setAttribute("\111\x44", $this->id);
        $ym->setAttribute("\x56\145\162\x73\151\x6f\x6e", "\62\x2e\60");
        $ym->setAttribute("\x49\x73\163\165\x65\x49\156\163\x74\141\x6e\164", gmdate("\x59\55\x6d\55\x64\134\124\x48\x3a\x69\72\x73\134\x5a", $this->issueInstant));
        $B9 = Utilities::addString($ym, "\165\162\x6e\x3a\157\141\x73\151\163\72\156\141\155\145\x73\72\x74\x63\x3a\x53\101\115\114\x3a\62\x2e\60\72\x61\163\163\145\x72\164\x69\157\x6e", "\x73\141\155\154\72\111\163\163\x75\145\x72", $this->issuer);
        $this->addSubject($ym);
        $this->addConditions($ym);
        $this->addAuthnStatement($ym);
        if ($this->requiredEncAttributes == FALSE) {
            goto oH;
        }
        $this->addEncryptedAttributeStatement($ym);
        goto YN;
        oH:
        $this->addAttributeStatement($ym);
        YN:
        if (!($this->signatureKey !== NULL)) {
            goto G9;
        }
        Utilities::insertSignature($this->signatureKey, $this->certificates, $ym, $B9->nextSibling);
        G9:
        return $ym;
    }
    private function addSubject(DOMElement $ym)
    {
        if (!($this->nameId === NULL && $this->encryptedNameId === NULL)) {
            goto zW;
        }
        return;
        zW:
        $mk = $ym->ownerDocument->createElementNS("\x75\x72\x6e\x3a\157\141\163\151\163\72\x6e\x61\x6d\145\x73\x3a\164\x63\72\x53\x41\x4d\x4c\72\62\56\60\x3a\141\163\163\145\162\x74\x69\157\156", "\x73\x61\155\x6c\x3a\123\x75\142\x6a\145\x63\x74");
        $ym->appendChild($mk);
        if ($this->encryptedNameId === NULL) {
            goto uk;
        }
        $B5 = $mk->ownerDocument->createElementNS("\x75\x72\x6e\x3a\157\141\163\151\163\x3a\156\141\x6d\145\163\72\x74\143\72\123\101\x4d\114\x3a\62\56\x30\72\141\x73\x73\x65\x72\164\151\157\x6e", "\x73\141\x6d\x6c\x3a" . "\105\156\143\162\x79\x70\164\x65\x64\x49\104");
        $mk->appendChild($B5);
        $B5->appendChild($mk->ownerDocument->importNode($this->encryptedNameId, TRUE));
        goto XO;
        uk:
        Utilities::addNameId($mk, $this->nameId);
        XO:
        foreach ($this->SubjectConfirmation as $gA) {
            $gA->toXML($mk);
            Yv:
        }
        qA:
    }
    private function addConditions(DOMElement $ym)
    {
        $vy = $ym->ownerDocument;
        $gK = $vy->createElementNS("\x75\x72\156\x3a\157\141\x73\x69\163\x3a\x6e\x61\155\x65\x73\72\x74\143\x3a\x53\x41\115\114\x3a\62\56\60\72\x61\x73\163\x65\162\x74\151\x6f\x6e", "\163\x61\155\x6c\x3a\103\157\x6e\x64\x69\x74\151\157\x6e\x73");
        $ym->appendChild($gK);
        if (!($this->notBefore !== NULL)) {
            goto ze;
        }
        $gK->setAttribute("\116\x6f\x74\x42\145\x66\x6f\x72\145", gmdate("\x59\55\155\x2d\x64\x5c\x54\110\72\x69\x3a\x73\x5c\x5a", $this->notBefore));
        ze:
        if (!($this->notOnOrAfter !== NULL)) {
            goto Vy;
        }
        $gK->setAttribute("\116\x6f\x74\x4f\x6e\117\162\x41\x66\x74\x65\162", gmdate("\x59\x2d\155\55\144\134\x54\110\72\x69\72\x73\x5c\132", $this->notOnOrAfter));
        Vy:
        if (!($this->validAudiences !== NULL)) {
            goto yc;
        }
        $nE = $vy->createElementNS("\165\x72\x6e\72\157\141\163\151\x73\72\x6e\141\155\145\x73\72\164\143\72\123\101\x4d\114\x3a\x32\x2e\60\72\x61\x73\x73\x65\162\x74\x69\x6f\x6e", "\163\x61\155\x6c\72\101\x75\144\151\145\x6e\143\145\x52\x65\x73\164\x72\151\143\164\151\157\156");
        $gK->appendChild($nE);
        Utilities::addStrings($nE, "\165\x72\x6e\72\x6f\141\163\151\x73\72\x6e\x61\155\145\x73\x3a\x74\x63\x3a\123\x41\115\x4c\x3a\x32\x2e\60\72\141\x73\163\145\x72\164\151\x6f\x6e", "\163\141\155\x6c\72\x41\x75\144\151\145\156\x63\145", FALSE, $this->validAudiences);
        yc:
    }
    private function addAuthnStatement(DOMElement $ym)
    {
        if (!($this->authnInstant === NULL || $this->authnContextClassRef === NULL && $this->authnContextDecl === NULL && $this->authnContextDeclRef === NULL)) {
            goto ss;
        }
        return;
        ss:
        $vy = $ym->ownerDocument;
        $VT = $vy->createElementNS("\x75\162\x6e\72\x6f\141\163\x69\x73\x3a\156\141\155\x65\x73\72\x74\143\x3a\x53\101\x4d\114\72\x32\56\60\x3a\141\x73\163\145\162\x74\151\x6f\156", "\163\141\x6d\x6c\72\101\x75\x74\x68\x6e\x53\164\x61\x74\145\155\x65\x6e\x74");
        $ym->appendChild($VT);
        $VT->setAttribute("\x41\x75\164\150\x6e\111\x6e\163\164\141\156\164", gmdate("\x59\55\x6d\x2d\x64\x5c\124\110\x3a\x69\72\x73\134\132", $this->authnInstant));
        if (!($this->sessionNotOnOrAfter !== NULL)) {
            goto Zf;
        }
        $VT->setAttribute("\123\145\x73\163\x69\157\156\x4e\x6f\164\x4f\156\x4f\162\x41\146\164\x65\162", gmdate("\131\55\155\x2d\144\x5c\124\x48\72\151\72\x73\x5c\132", $this->sessionNotOnOrAfter));
        Zf:
        if (!($this->sessionIndex !== NULL)) {
            goto nI;
        }
        $VT->setAttribute("\x53\x65\x73\163\x69\157\156\x49\156\x64\145\170", $this->sessionIndex);
        nI:
        $fz = $vy->createElementNS("\165\x72\x6e\x3a\x6f\141\x73\x69\x73\x3a\x6e\141\155\x65\x73\72\164\x63\72\x53\x41\115\x4c\72\62\56\60\x3a\141\x73\163\x65\162\x74\151\157\156", "\x73\141\155\154\x3a\x41\x75\164\x68\156\x43\157\156\x74\x65\170\x74");
        $VT->appendChild($fz);
        if (empty($this->authnContextClassRef)) {
            goto SC;
        }
        Utilities::addString($fz, "\x75\x72\156\x3a\157\x61\163\151\x73\72\156\x61\155\145\x73\72\x74\x63\x3a\123\101\115\114\72\x32\x2e\x30\72\141\163\x73\145\x72\164\x69\157\156", "\x73\141\155\154\72\x41\165\164\x68\156\103\x6f\156\164\x65\x78\x74\x43\154\141\163\x73\x52\x65\x66", $this->authnContextClassRef);
        SC:
        if (empty($this->authnContextDecl)) {
            goto qa;
        }
        $this->authnContextDecl->toXML($fz);
        qa:
        if (empty($this->authnContextDeclRef)) {
            goto Cc;
        }
        Utilities::addString($fz, "\x75\162\156\72\157\x61\163\151\x73\72\x6e\141\155\x65\x73\x3a\164\143\x3a\123\101\x4d\114\72\x32\56\x30\72\x61\163\x73\145\162\164\151\157\156", "\x73\141\155\x6c\x3a\x41\x75\164\x68\x6e\103\x6f\156\164\x65\170\x74\104\x65\x63\154\x52\x65\146", $this->authnContextDeclRef);
        Cc:
        Utilities::addStrings($fz, "\x75\162\156\72\x6f\x61\163\151\x73\72\x6e\141\x6d\x65\163\x3a\x74\x63\x3a\x53\x41\x4d\x4c\x3a\62\x2e\x30\x3a\x61\163\x73\x65\162\164\x69\157\156", "\163\141\155\154\72\x41\165\x74\x68\x65\x6e\x74\x69\x63\141\164\151\156\x67\101\165\x74\x68\x6f\162\151\x74\171", FALSE, $this->AuthenticatingAuthority);
    }
    private function addAttributeStatement(DOMElement $ym)
    {
        if (!empty($this->attributes)) {
            goto IJ;
        }
        return;
        IJ:
        $vy = $ym->ownerDocument;
        $Zf = $vy->createElementNS("\x75\162\156\72\x6f\141\x73\x69\x73\72\156\x61\155\145\x73\x3a\164\x63\72\123\101\x4d\x4c\x3a\x32\56\x30\x3a\141\x73\x73\145\162\x74\x69\x6f\x6e", "\x73\x61\x6d\x6c\72\101\x74\x74\162\151\142\165\x74\x65\x53\x74\141\164\145\155\x65\156\164");
        $ym->appendChild($Zf);
        foreach ($this->attributes as $Wu => $rj) {
            $rV = $vy->createElementNS("\165\162\156\x3a\157\x61\163\x69\163\72\156\141\x6d\145\x73\72\x74\143\72\x53\x41\x4d\x4c\x3a\x32\56\60\72\141\x73\x73\145\x72\164\x69\x6f\x6e", "\x73\141\x6d\154\72\x41\x74\164\162\x69\x62\x75\x74\145");
            $Zf->appendChild($rV);
            $rV->setAttribute("\x4e\x61\x6d\x65", $Wu);
            if (!($this->nameFormat !== "\165\162\156\72\x6f\x61\163\151\x73\72\x6e\x61\x6d\145\163\x3a\164\x63\x3a\123\101\x4d\114\x3a\62\x2e\x30\x3a\x61\164\x74\162\x6e\x61\x6d\x65\55\x66\x6f\162\x6d\x61\164\72\165\156\163\160\x65\x63\151\146\151\145\x64")) {
                goto Za;
            }
            $rV->setAttribute("\x4e\141\155\145\x46\157\x72\x6d\x61\164", $this->nameFormat);
            Za:
            foreach ($rj as $n5) {
                if (is_string($n5)) {
                    goto Sq;
                }
                if (is_int($n5)) {
                    goto eg;
                }
                $AG = NULL;
                goto IW;
                Sq:
                $AG = "\170\163\x3a\x73\x74\162\x69\156\147";
                goto IW;
                eg:
                $AG = "\x78\163\72\151\156\164\145\147\x65\x72";
                IW:
                $SD = $vy->createElementNS("\x75\x72\156\x3a\157\141\163\151\163\72\156\x61\155\145\x73\x3a\164\x63\72\123\x41\x4d\114\72\x32\x2e\x30\72\141\163\x73\145\162\x74\x69\x6f\156", "\x73\141\x6d\x6c\x3a\x41\x74\x74\x72\x69\142\x75\x74\145\126\x61\154\x75\x65");
                $rV->appendChild($SD);
                if (!($AG !== NULL)) {
                    goto Gq;
                }
                $SD->setAttributeNS("\150\x74\x74\160\72\x2f\x2f\167\167\x77\x2e\167\x33\x2e\x6f\x72\x67\57\62\60\x30\61\57\x58\x4d\114\x53\143\150\145\155\141\x2d\151\156\x73\164\141\156\x63\x65", "\x78\x73\x69\72\164\171\x70\x65", $AG);
                Gq:
                if (!is_null($n5)) {
                    goto Sn;
                }
                $SD->setAttributeNS("\150\164\164\x70\72\x2f\57\167\167\x77\x2e\167\x33\56\x6f\162\147\57\x32\60\60\61\x2f\130\115\114\x53\x63\150\145\x6d\141\x2d\x69\x6e\163\164\141\x6e\x63\x65", "\170\x73\151\x3a\x6e\x69\x6c", "\x74\x72\165\145");
                Sn:
                if ($n5 instanceof DOMNodeList) {
                    goto W1;
                }
                $SD->appendChild($vy->createTextNode($n5));
                goto Ni;
                W1:
                $Cz = 0;
                gh:
                if (!($Cz < $n5->length)) {
                    goto LI;
                }
                $Vf = $vy->importNode($n5->item($Cz), TRUE);
                $SD->appendChild($Vf);
                UC:
                $Cz++;
                goto gh;
                LI:
                Ni:
                mA:
            }
            W4:
            ks:
        }
        F9:
    }
    private function addEncryptedAttributeStatement(DOMElement $ym)
    {
        if (!($this->requiredEncAttributes == FALSE)) {
            goto kl;
        }
        return;
        kl:
        $vy = $ym->ownerDocument;
        $Zf = $vy->createElementNS("\165\162\x6e\x3a\157\x61\x73\x69\163\72\156\x61\x6d\145\163\x3a\164\x63\72\x53\101\x4d\114\x3a\62\56\x30\x3a\x61\x73\x73\145\x72\x74\151\157\x6e", "\163\x61\x6d\x6c\x3a\101\164\164\x72\151\x62\165\164\145\123\x74\141\x74\x65\155\145\156\164");
        $ym->appendChild($Zf);
        foreach ($this->attributes as $Wu => $rj) {
            $n1 = new DOMDocument();
            $rV = $n1->createElementNS("\x75\x72\156\x3a\x6f\141\163\x69\x73\72\156\x61\x6d\145\163\x3a\164\x63\x3a\123\101\115\x4c\72\x32\56\60\72\x61\x73\x73\x65\x72\x74\x69\x6f\x6e", "\x73\x61\x6d\154\72\101\x74\x74\162\151\x62\165\x74\145");
            $rV->setAttribute("\116\141\x6d\145", $Wu);
            $n1->appendChild($rV);
            if (!($this->nameFormat !== "\x75\x72\x6e\x3a\x6f\x61\163\x69\163\x3a\x6e\141\x6d\145\x73\72\164\143\72\x53\x41\x4d\x4c\72\62\x2e\60\72\141\x74\164\162\x6e\x61\155\x65\x2d\x66\157\x72\155\141\164\x3a\x75\156\x73\x70\x65\143\x69\x66\x69\145\144")) {
                goto TN;
            }
            $rV->setAttribute("\x4e\141\x6d\x65\106\157\162\155\x61\x74", $this->nameFormat);
            TN:
            foreach ($rj as $n5) {
                if (is_string($n5)) {
                    goto my;
                }
                if (is_int($n5)) {
                    goto f_;
                }
                $AG = NULL;
                goto s8;
                my:
                $AG = "\170\163\x3a\163\164\162\x69\x6e\x67";
                goto s8;
                f_:
                $AG = "\170\163\72\151\x6e\164\x65\147\145\162";
                s8:
                $SD = $n1->createElementNS("\x75\x72\156\x3a\x6f\141\x73\x69\x73\x3a\156\141\x6d\145\163\x3a\164\x63\x3a\123\x41\115\x4c\72\x32\56\x30\72\x61\x73\x73\x65\x72\x74\x69\157\156", "\x73\x61\x6d\154\72\101\164\164\162\x69\142\x75\164\x65\126\141\x6c\165\x65");
                $rV->appendChild($SD);
                if (!($AG !== NULL)) {
                    goto rJ;
                }
                $SD->setAttributeNS("\x68\x74\x74\x70\72\57\x2f\x77\167\x77\56\x77\63\56\x6f\162\x67\57\62\x30\x30\x31\57\x58\x4d\114\x53\143\150\145\155\x61\x2d\151\156\x73\x74\141\x6e\143\x65", "\170\x73\151\x3a\x74\x79\x70\x65", $AG);
                rJ:
                if ($n5 instanceof DOMNodeList) {
                    goto x0;
                }
                $SD->appendChild($n1->createTextNode($n5));
                goto J7;
                x0:
                $Cz = 0;
                cU:
                if (!($Cz < $n5->length)) {
                    goto n5;
                }
                $Vf = $n1->importNode($n5->item($Cz), TRUE);
                $SD->appendChild($Vf);
                RO:
                $Cz++;
                goto cU;
                n5:
                J7:
                LH:
            }
            jp:
            $xR = new XMLSecEnc();
            $xR->setNode($n1->documentElement);
            $xR->type = "\150\x74\164\x70\72\x2f\x2f\167\167\x77\x2e\167\63\56\157\x72\x67\x2f\x32\60\60\61\57\60\64\57\x78\155\x6c\145\x6e\x63\43\105\x6c\x65\x6d\x65\156\x74";
            $Is = new XMLSecurityKey(XMLSecurityKey::AES256_CBC);
            $Is->generateSessionKey();
            $xR->encryptKey($this->encryptionKey, $Is);
            $F3 = $xR->encryptNode($Is);
            $vp = $vy->createElementNS("\165\x72\x6e\72\x6f\141\163\x69\163\72\x6e\141\155\145\163\72\x74\x63\72\x53\101\x4d\114\72\x32\x2e\x30\72\x61\163\x73\x65\162\164\x69\x6f\156", "\x73\141\155\154\72\x45\156\x63\x72\171\160\164\145\144\x41\x74\x74\x72\151\142\165\164\x65");
            $Zf->appendChild($vp);
            $AB = $vy->importNode($F3, TRUE);
            $vp->appendChild($AB);
            cQ:
        }
        Rj:
    }
    public function getPrivateKeyUrl()
    {
        return $this->privateKeyUrl;
    }
    public function setPrivateKeyUrl($vG)
    {
        $this->privateKeyUrl = $vG;
    }
}
