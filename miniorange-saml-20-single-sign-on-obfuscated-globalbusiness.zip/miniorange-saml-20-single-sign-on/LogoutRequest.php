<?php


include_once "\x55\x74\x69\x6c\151\x74\x69\x65\163\56\x70\x68\160";
include_once "\x78\x6d\154\163\145\143\154\x69\x62\x73\x2e\x70\x68\x70";
use RobRichards\XMLSecLibs\XMLSecurityKey;
use RobRichards\XMLSecLibs\XMLSecurityDSig;
use RobRichards\XMLSecLibs\XMLSecEnc;
class SAML2_LogoutRequest
{
    private $tagName;
    private $id;
    private $issuer;
    private $destination;
    private $issueInstant;
    private $certificates;
    private $validators;
    private $notOnOrAfter;
    private $encryptedNameId;
    private $nameId;
    private $sessionIndexes;
    public function __construct(DOMElement $Th = NULL)
    {
        $this->tagName = "\x4c\x6f\147\x6f\x75\164\122\145\161\165\145\163\164";
        $this->id = Utilities::generateID();
        $this->issueInstant = time();
        $this->certificates = array();
        $this->validators = array();
        if (!($Th === NULL)) {
            goto UV;
        }
        return;
        UV:
        if ($Th->hasAttribute("\111\x44")) {
            goto Cl;
        }
        throw new Exception("\x4d\151\163\163\x69\x6e\x67\x20\111\104\x20\x61\164\x74\x72\151\142\x75\x74\x65\40\157\156\x20\123\x41\115\114\x20\x6d\145\163\x73\141\147\x65\56");
        Cl:
        $this->id = $Th->getAttribute("\111\104");
        if (!($Th->getAttribute("\x56\145\x72\163\151\157\x6e") !== "\62\56\60")) {
            goto oM;
        }
        throw new Exception("\125\156\x73\x75\160\x70\157\x72\164\145\144\40\166\x65\162\163\x69\157\x6e\x3a\40" . $Th->getAttribute("\126\145\x72\163\x69\x6f\156"));
        oM:
        $this->issueInstant = Utilities::xsDateTimeToTimestamp($Th->getAttribute("\x49\163\x73\165\x65\x49\156\x73\x74\x61\156\x74"));
        if (!$Th->hasAttribute("\x44\145\163\x74\x69\156\141\164\x69\x6f\156")) {
            goto uW;
        }
        $this->destination = $Th->getAttribute("\x44\145\163\x74\x69\x6e\141\164\151\x6f\156");
        uW:
        $B9 = Utilities::xpQuery($Th, "\56\57\x73\x61\155\x6c\137\141\163\163\x65\x72\x74\x69\x6f\156\x3a\111\163\x73\x75\x65\x72");
        if (empty($B9)) {
            goto nv;
        }
        $this->issuer = trim($B9[0]->textContent);
        nv:
        try {
            $BL = Utilities::validateElement($Th);
            if (!($BL !== FALSE)) {
                goto DY;
            }
            $this->certificates = $BL["\x43\x65\162\164\151\146\x69\143\141\164\x65\163"];
            $this->validators[] = array("\106\x75\x6e\143\164\151\x6f\156" => array("\x55\164\151\154\x69\x74\x69\x65\x73", "\x76\141\x6c\x69\x64\x61\x74\145\x53\x69\147\156\x61\x74\165\x72\145"), "\104\141\164\141" => $BL);
            DY:
        } catch (Exception $jB) {
        }
        $this->sessionIndexes = array();
        if (!$Th->hasAttribute("\x4e\x6f\164\117\x6e\x4f\162\101\x66\x74\x65\x72")) {
            goto DV;
        }
        $this->notOnOrAfter = Utilities::xsDateTimeToTimestamp($Th->getAttribute("\116\157\x74\x4f\156\x4f\x72\101\x66\x74\145\x72"));
        DV:
        $q6 = Utilities::xpQuery($Th, "\56\57\163\x61\155\x6c\x5f\x61\x73\163\145\162\164\151\157\156\x3a\116\x61\x6d\x65\x49\x44\x20\x7c\40\x2e\57\163\x61\155\154\137\x61\163\x73\x65\162\164\x69\x6f\x6e\x3a\105\x6e\x63\162\171\x70\x74\145\144\x49\104\x2f\x78\x65\x6e\x63\x3a\105\156\143\x72\171\x70\x74\145\x64\x44\141\x74\141");
        if (empty($q6)) {
            goto qI;
        }
        if (count($q6) > 1) {
            goto yn;
        }
        goto uN;
        qI:
        throw new Exception("\115\x69\x73\x73\x69\x6e\147\x20\x3c\163\141\155\154\x3a\x4e\x61\155\x65\111\x44\x3e\x20\x6f\x72\x20\x3c\163\141\155\154\72\x45\x6e\x63\162\171\160\x74\145\144\111\104\76\x20\151\156\40\x3c\163\141\155\x6c\x70\x3a\x4c\x6f\147\x6f\165\x74\x52\145\161\165\x65\x73\x74\76\56");
        goto uN;
        yn:
        throw new Exception("\x4d\157\162\145\x20\x74\x68\x61\x6e\x20\157\156\x65\x20\x3c\x73\141\155\x6c\72\x4e\141\155\x65\x49\x44\x3e\40\x6f\x72\40\x3c\x73\x61\155\x6c\72\105\x6e\143\x72\171\160\x74\145\x64\104\x3e\40\x69\x6e\x20\x3c\x73\141\155\154\160\x3a\x4c\x6f\147\x6f\x75\x74\x52\145\161\165\145\x73\x74\x3e\x2e");
        uN:
        $q6 = $q6[0];
        if ($q6->localName === "\x45\156\143\x72\x79\160\164\x65\144\x44\141\x74\141") {
            goto iH;
        }
        $this->nameId = Utilities::parseNameId($q6);
        goto i5;
        iH:
        $this->encryptedNameId = $q6;
        i5:
        $s6 = Utilities::xpQuery($Th, "\x2e\57\x73\x61\155\x6c\137\x70\162\x6f\x74\157\143\157\x6c\x3a\123\x65\x73\x73\151\x6f\x6e\x49\156\x64\145\x78");
        foreach ($s6 as $sL) {
            $this->sessionIndexes[] = trim($sL->textContent);
            Xq:
        }
        Q1:
    }
    public function getNotOnOrAfter()
    {
        return $this->notOnOrAfter;
    }
    public function setNotOnOrAfter($V2)
    {
        $this->notOnOrAfter = $V2;
    }
    public function isNameIdEncrypted()
    {
        if (!($this->encryptedNameId !== NULL)) {
            goto x2;
        }
        return TRUE;
        x2:
        return FALSE;
    }
    public function encryptNameId(XMLSecurityKey $a5)
    {
        $Pj = new DOMDocument();
        $ym = $Pj->createElement("\162\157\157\x74");
        $Pj->appendChild($ym);
        SAML2_Utils::addNameId($ym, $this->nameId);
        $q6 = $ym->firstChild;
        SAML2_Utils::getContainer()->debugMessage($q6, "\x65\x6e\x63\x72\x79\x70\x74");
        $cy = new XMLSecEnc();
        $cy->setNode($q6);
        $cy->type = XMLSecEnc::Element;
        $Is = new XMLSecurityKey(XMLSecurityKey::AES128_CBC);
        $Is->generateSessionKey();
        $cy->encryptKey($a5, $Is);
        $this->encryptedNameId = $cy->encryptNode($Is);
        $this->nameId = NULL;
    }
    public function decryptNameId(XMLSecurityKey $a5, array $Zo = array())
    {
        if (!($this->encryptedNameId === NULL)) {
            goto td;
        }
        return;
        td:
        $q6 = SAML2_Utils::decryptElement($this->encryptedNameId, $a5, $Zo);
        SAML2_Utils::getContainer()->debugMessage($q6, "\x64\145\143\162\x79\160\164");
        $this->nameId = SAML2_Utils::parseNameId($q6);
        $this->encryptedNameId = NULL;
    }
    public function getNameId()
    {
        if (!($this->encryptedNameId !== NULL)) {
            goto wO;
        }
        throw new Exception("\101\164\x74\145\x6d\x70\164\x65\x64\40\x74\157\x20\x72\145\164\x72\151\145\x76\x65\40\145\x6e\143\x72\x79\x70\164\145\144\x20\x4e\141\x6d\x65\x49\104\x20\x77\151\164\x68\157\165\164\40\x64\145\143\x72\x79\160\164\x69\156\147\40\151\x74\x20\146\x69\162\163\164\56");
        wO:
        return $this->nameId;
    }
    public function setNameId($q6)
    {
        $this->nameId = $q6;
    }
    public function getSessionIndexes()
    {
        return $this->sessionIndexes;
    }
    public function setSessionIndexes(array $s6)
    {
        $this->sessionIndexes = $s6;
    }
    public function getSessionIndex()
    {
        if (!empty($this->sessionIndexes)) {
            goto BY;
        }
        return NULL;
        BY:
        return $this->sessionIndexes[0];
    }
    public function setSessionIndex($sL)
    {
        if (is_null($sL)) {
            goto Vj;
        }
        $this->sessionIndexes = array($sL);
        goto uK;
        Vj:
        $this->sessionIndexes = array();
        uK:
    }
    public function getId()
    {
        return $this->id;
    }
    public function setId($oH)
    {
        $this->id = $oH;
    }
    public function getIssueInstant()
    {
        return $this->issueInstant;
    }
    public function setIssueInstant($ii)
    {
        $this->issueInstant = $ii;
    }
    public function getDestination()
    {
        return $this->destination;
    }
    public function setDestination($Dl)
    {
        $this->destination = $Dl;
    }
    public function getIssuer()
    {
        return $this->issuer;
    }
    public function setIssuer($B9)
    {
        $this->issuer = $B9;
    }
}
