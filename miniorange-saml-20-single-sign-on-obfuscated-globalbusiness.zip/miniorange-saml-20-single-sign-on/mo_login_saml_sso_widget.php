<?php


include_once dirname(__FILE__) . "\57\125\164\x69\x6c\x69\164\151\145\x73\56\160\150\160";
include_once dirname(__FILE__) . "\x2f\x52\145\163\160\157\156\163\x65\56\x70\150\x70";
include_once dirname(__FILE__) . "\57\114\157\147\157\x75\x74\x52\145\x71\x75\x65\163\164\56\x70\150\x70";
require_once dirname(__FILE__) . "\x2f\x69\x6e\x63\154\165\x64\145\163\x2f\x6c\x69\x62\x2f\145\156\x63\162\x79\160\164\151\157\156\x2e\160\150\x70";
include_once "\x78\155\x6c\163\x65\x63\154\151\142\x73\56\x70\150\x70";
use RobRichards\XMLSecLibs\XMLSecurityKey;
use RobRichards\XMLSecLibs\XMLSecurityDSig;
use RobRichards\XMLSecLibs\XMLSecEnc;
class mo_login_wid extends WP_Widget
{
    public function __construct()
    {
        $zr = get_site_option("\x73\141\155\154\137\151\x64\x65\x6e\164\151\164\x79\x5f\x6e\141\x6d\145");
        parent::__construct("\123\x61\155\154\x5f\114\157\147\x69\156\x5f\x57\x69\x64\x67\145\x74", "\114\x6f\147\151\x6e\x20\x77\151\164\150\40" . $zr, array("\144\145\163\x63\x72\151\x70\164\151\157\156" => __("\x54\x68\151\x73\40\x69\x73\40\141\x20\155\x69\x6e\151\x4f\162\141\x6e\147\145\x20\x53\x41\115\114\x20\x6c\157\147\151\x6e\x20\167\x69\144\x67\145\164\56", "\155\x6f\163\x61\155\154")));
    }
    public function widget($LQ, $sA)
    {
        extract($LQ);
        $cj = apply_filters("\167\151\144\x67\145\x74\x5f\x74\x69\164\x6c\x65", $sA["\x77\151\x64\x5f\164\151\164\x6c\x65"]);
        echo $LQ["\x62\145\146\157\x72\x65\x5f\x77\x69\x64\x67\x65\x74"];
        if (empty($cj)) {
            goto DqU;
        }
        echo $LQ["\142\x65\146\157\162\x65\x5f\164\151\164\x6c\145"] . $cj . $LQ["\x61\146\x74\145\162\x5f\x74\151\164\x6c\145"];
        DqU:
        $this->loginForm();
        echo $LQ["\x61\146\x74\x65\162\x5f\x77\x69\144\147\145\164"];
    }
    public function update($t6, $AK)
    {
        $sA = array();
        $sA["\167\x69\x64\137\164\x69\x74\x6c\x65"] = strip_tags($t6["\x77\x69\144\137\164\151\164\154\x65"]);
        return $sA;
    }
    public function form($sA)
    {
        $cj = '';
        if (!array_key_exists("\x77\x69\x64\137\164\151\x74\154\145", $sA)) {
            goto ymD;
        }
        $cj = $sA["\167\151\x64\137\164\x69\x74\154\x65"];
        ymD:
        echo "\15\12\11\x9\x3c\160\x3e\74\154\x61\x62\x65\154\x20\146\157\162\x3d\42" . $this->get_field_id("\167\151\144\x5f\164\151\164\x6c\x65") . "\40\x22\76" . _e("\124\x69\164\x6c\x65\72") . "\x20\74\x2f\154\141\142\x65\154\76\xd\12\11\11\x9\x3c\x69\156\x70\x75\164\40\143\x6c\141\163\x73\75\42\167\x69\144\145\x66\x61\x74\42\x20\x69\144\x3d\x22" . $this->get_field_id("\x77\151\x64\x5f\164\x69\x74\154\x65") . "\x22\x20\156\x61\155\145\75\42" . $this->get_field_name("\x77\151\144\x5f\164\151\x74\154\145") . "\x22\x20\164\x79\160\x65\75\42\x74\x65\x78\x74\42\x20\166\x61\154\165\x65\75\x22" . $cj . "\42\40\x2f\76\15\xa\11\11\74\x2f\160\76";
    }
    public function loginForm()
    {
        global $post;
        $yn = get_site_option("\163\x61\x6d\154\x5f\163\x73\x6f\x5f\x73\x65\164\x74\151\156\147\x73");
        $FX = get_current_blog_id();
        $pB = Utilities::get_active_sites();
        if (in_array($FX, $pB)) {
            goto ULE;
        }
        return;
        ULE:
        if (!(empty($yn[$FX]) && !empty($yn["\x44\105\106\101\125\x4c\x54"]))) {
            goto VUR;
        }
        $yn[$FX] = $yn["\x44\x45\106\x41\125\114\124"];
        VUR:
        if (!is_user_logged_in()) {
            goto cbP;
        }
        $current_user = wp_get_current_user();
        $g4 = "\x48\x65\x6c\x6c\157\54";
        if (empty($yn[$FX]["\x6d\x6f\137\163\x61\155\154\x5f\x63\x75\163\x74\157\155\x5f\147\x72\x65\145\164\151\156\147\137\x74\x65\170\x74"])) {
            goto Vev;
        }
        $g4 = $yn[$FX]["\x6d\157\137\x73\x61\155\154\137\x63\x75\163\164\x6f\155\x5f\x67\162\145\145\x74\151\156\x67\x5f\x74\x65\170\164"];
        Vev:
        $sO = '';
        if (empty($yn[$FX]["\x6d\157\x5f\163\141\155\x6c\x5f\147\x72\145\145\164\151\156\x67\137\x6e\x61\155\145"])) {
            goto sZm;
        }
        switch ($yn[$FX]["\155\x6f\x5f\163\141\x6d\154\x5f\x67\162\x65\x65\x74\x69\156\147\137\x6e\x61\155\x65"]) {
            case "\125\x53\x45\x52\116\x41\x4d\x45":
                $sO = $current_user->user_login;
                goto rcx;
            case "\105\x4d\x41\x49\x4c":
                $sO = $current_user->user_email;
                goto rcx;
            case "\106\116\x41\x4d\x45":
                $sO = $current_user->user_firstname;
                goto rcx;
            case "\x4c\x4e\101\115\105":
                $sO = $current_user->user_lastname;
                goto rcx;
            case "\106\x4e\x41\x4d\105\x5f\x4c\x4e\x41\115\105":
                $sO = $current_user->user_firstname . "\x20" . $current_user->user_lastname;
                goto rcx;
            case "\114\x4e\x41\115\105\x5f\106\116\x41\x4d\105":
                $sO = $current_user->user_lastname . "\40" . $current_user->user_firstname;
                goto rcx;
            default:
                $sO = $current_user->user_login;
        }
        qT4:
        rcx:
        sZm:
        if (!empty(trim($sO))) {
            goto kmi;
        }
        $sO = $current_user->user_login;
        kmi:
        $oZ = $g4 . "\x20" . $sO;
        $EM = "\x4c\x6f\147\x6f\x75\164";
        if (empty($yn[$FX]["\x6d\x6f\137\x73\x61\155\154\x5f\143\165\x73\164\157\155\137\x6c\x6f\147\157\165\164\x5f\x74\x65\170\164"])) {
            goto c5o;
        }
        $EM = $yn[$FX]["\x6d\157\137\x73\141\x6d\x6c\137\x63\165\x73\164\x6f\155\x5f\x6c\x6f\147\x6f\165\164\137\164\x65\170\164"];
        c5o:
        echo $oZ . "\x20\x7c\40\x3c\x61\40\x68\162\x65\x66\x3d\x22" . wp_logout_url(home_url()) . "\42\40\164\x69\x74\x6c\x65\75\x22\x6c\x6f\147\x6f\165\x74\x22\x20\76" . $EM . "\x3c\57\x61\x3e\x3c\x2f\154\151\76";
        goto ubn;
        cbP:
        echo "\xd\12\11\11\x9\74\x73\143\x72\151\x70\164\76\15\12\x9\x9\11\x9\x66\x75\156\x63\164\151\157\156\40\x73\x75\x62\x6d\x69\164\123\141\x6d\x6c\x46\x6f\x72\x6d\50\x29\x7b\x20\x64\x6f\x63\165\x6d\145\156\164\56\147\x65\x74\105\154\x65\155\x65\156\x74\x42\171\x49\144\50\x22\x6c\157\x67\151\x6e\x22\51\56\163\x75\142\x6d\x69\x74\x28\51\73\40\175\xd\xa\11\x9\11\74\x2f\163\143\x72\151\x70\x74\76\15\xa\11\11\x9\74\146\x6f\162\155\40\156\141\x6d\145\75\42\x6c\157\147\151\156\42\x20\x69\144\75\x22\x6c\x6f\147\x69\156\x22\x20\155\145\164\150\x6f\144\x3d\x22\x70\157\x73\x74\x22\40\x61\143\x74\x69\157\x6e\x3d\42\42\x3e\15\xa\11\11\x9\11\x3c\x69\156\160\165\x74\40\164\x79\160\145\x3d\42\x68\x69\x64\144\145\156\42\x20\x6e\141\x6d\x65\75\x22\x6f\160\164\151\x6f\156\42\40\x76\141\154\165\145\x3d\42\163\x61\x6d\154\137\x75\163\145\x72\x5f\x6c\157\147\151\156\x22\40\x2f\76\xd\12\15\12\x9\x9\11\11\x3c\146\157\156\x74\x20\x73\151\172\145\75\42\x2b\61\x22\40\x73\x74\171\154\145\75\x22\x76\145\162\164\151\x63\x61\154\55\x61\x6c\151\x67\x6e\72\x74\x6f\160\73\x22\x3e\x20\74\57\x66\157\156\x74\x3e";
        $ZE = get_site_option("\163\x61\x6d\154\x5f\151\144\145\156\164\x69\164\x79\x5f\156\141\155\x65");
        $Jt = get_site_option("\x73\x61\155\154\137\170\x35\x30\71\x5f\143\x65\162\x74\151\x66\x69\x63\141\164\145");
        if (!empty($ZE) && !empty($Jt)) {
            goto dDv;
        }
        echo "\120\x6c\145\141\x73\145\x20\143\157\156\146\x69\x67\165\162\145\40\164\x68\x65\40\x6d\x69\x6e\151\x4f\x72\x61\x6e\x67\145\40\123\x41\x4d\x4c\x20\120\154\x75\147\151\156\40\x66\151\162\163\x74\56";
        goto FQU;
        dDv:
        $Yb = "\114\x6f\x67\151\x6e\40\167\x69\164\x68\40\x23\x23\111\104\120\x23\x23";
        if (empty($yn[$FX]["\x6d\157\137\x73\141\x6d\x6c\x5f\143\165\163\164\157\x6d\137\154\157\x67\x69\x6e\x5f\x74\145\170\x74"])) {
            goto kkv;
        }
        $Yb = $yn[$FX]["\155\157\137\163\141\155\154\x5f\143\165\x73\164\x6f\155\x5f\154\x6f\x67\x69\x6e\x5f\164\145\x78\x74"];
        kkv:
        $Yb = str_replace("\x23\43\111\x44\x50\x23\43", $ZE, $Yb);
        $XP = false;
        if (!(isset($yn[$FX]["\155\x6f\137\163\x61\x6d\154\137\x75\163\145\137\x62\x75\x74\x74\157\x6e\137\141\x73\x5f\167\151\144\x67\145\x74"]) && $yn[$FX]["\x6d\x6f\137\163\x61\155\x6c\x5f\165\x73\145\137\142\x75\164\x74\x6f\156\x5f\141\163\137\x77\x69\x64\147\x65\x74"] == "\x74\x72\x75\x65")) {
            goto Iae;
        }
        $XP = true;
        Iae:
        if (!$XP) {
            goto zO_;
        }
        $Ql = isset($yn[$FX]["\x6d\x6f\137\163\141\155\154\137\x62\x75\164\x74\x6f\156\137\x77\x69\144\164\150"]) ? $yn[$FX]["\155\x6f\x5f\x73\141\x6d\154\x5f\142\165\164\164\157\x6e\137\x77\x69\x64\164\150"] : "\x31\x30\x30";
        $DB = isset($yn[$FX]["\155\x6f\x5f\x73\141\155\x6c\137\x62\165\x74\x74\x6f\156\x5f\150\145\151\x67\150\x74"]) ? $yn[$FX]["\x6d\x6f\137\163\141\x6d\154\x5f\x62\x75\164\164\x6f\156\x5f\x68\145\151\x67\x68\x74"] : "\65\x30";
        $el = isset($yn[$FX]["\155\x6f\137\163\x61\x6d\x6c\x5f\142\x75\164\x74\157\x6e\137\163\151\172\145"]) ? $yn[$FX]["\155\x6f\137\163\x61\155\x6c\x5f\142\x75\164\x74\157\x6e\x5f\163\x69\172\x65"] : "\65\60";
        $eo = isset($yn[$FX]["\155\157\x5f\x73\141\x6d\x6c\137\142\165\164\x74\x6f\156\137\x63\x75\162\166\145"]) ? $yn[$FX]["\155\x6f\x5f\x73\x61\155\154\x5f\142\x75\x74\x74\x6f\156\137\x63\x75\x72\x76\x65"] : "\x35";
        $gH = isset($yn[$FX]["\x6d\157\x5f\163\x61\155\154\137\142\165\164\x74\x6f\156\137\143\157\x6c\157\x72"]) ? $yn[$FX]["\x6d\x6f\x5f\x73\141\155\x6c\x5f\x62\165\x74\x74\x6f\156\x5f\143\157\154\157\x72"] : "\60\x30\70\x35\x62\141";
        $tV = isset($yn[$FX]["\x6d\157\137\x73\141\155\154\x5f\142\x75\x74\x74\x6f\x6e\x5f\164\x68\x65\x6d\x65"]) ? $yn[$FX]["\155\157\137\163\x61\155\x6c\x5f\142\165\x74\164\x6f\156\137\x74\x68\x65\155\145"] : "\154\157\156\147\x62\165\x74\x74\x6f\156";
        $hQ = isset($yn[$FX]["\155\157\137\163\x61\x6d\x6c\137\142\165\164\x74\x6f\156\x5f\x74\145\170\164"]) ? $yn[$FX]["\x6d\157\137\x73\x61\155\x6c\137\142\x75\164\x74\x6f\x6e\x5f\x74\145\x78\x74"] : (get_site_option("\163\141\x6d\154\x5f\x69\144\145\x6e\x74\x69\164\171\x5f\x6e\141\x6d\145") ? get_site_option("\163\x61\x6d\154\137\x69\144\x65\x6e\x74\x69\x74\x79\x5f\x6e\141\155\x65") : "\x4c\x6f\147\151\x6e");
        $g5 = isset($yn[$FX]["\155\157\137\163\141\155\154\137\146\x6f\x6e\164\137\x63\157\154\157\x72"]) ? $yn[$FX]["\155\157\137\163\141\155\154\137\x66\x6f\x6e\x74\x5f\143\157\154\x6f\x72"] : "\146\146\x66\146\x66\146";
        $vq = isset($yn[$FX]["\x6d\157\137\x73\141\155\x6c\137\146\x6f\156\x74\137\163\x69\172\x65"]) ? $yn[$FX]["\x6d\157\x5f\163\141\x6d\x6c\137\146\x6f\x6e\x74\137\x73\151\172\x65"] : "\62\60";
        $SE = isset($yn[$FX]["\163\x73\x6f\137\142\x75\x74\x74\157\x6e\137\154\x6f\147\151\156\137\146\157\x72\155\137\160\157\x73\151\x74\x69\x6f\156"]) ? $yn[$FX]["\x73\163\157\x5f\x62\x75\164\x74\x6f\156\137\x6c\157\x67\151\156\137\146\157\x72\x6d\137\x70\x6f\x73\151\x74\x69\157\x6e"] : "\141\142\x6f\166\x65";
        $Yb = "\74\151\x6e\x70\165\x74\40\x74\171\x70\x65\75\x22\142\165\164\x74\157\x6e\x22\x20\x6e\x61\155\145\75\x22\155\x6f\137\163\x61\155\x6c\137\167\160\x5f\x73\163\x6f\x5f\142\x75\164\x74\157\156\x22\x20\x76\141\x6c\165\x65\75\42" . $hQ . "\x22\x20\x73\x74\171\154\145\75\x22";
        $T1 = '';
        if ($tV == "\x6c\x6f\x6e\x67\142\x75\164\164\157\x6e") {
            goto rIu;
        }
        if ($tV == "\x63\151\162\143\154\145") {
            goto SYw;
        }
        if ($tV == "\x6f\166\141\154") {
            goto stz;
        }
        if ($tV == "\x73\161\165\x61\x72\x65") {
            goto Vkz;
        }
        goto Re3;
        SYw:
        $T1 = $T1 . "\167\x69\x64\164\x68\72" . $el . "\160\170\73";
        $T1 = $T1 . "\x68\145\151\x67\x68\x74\x3a" . $el . "\x70\x78\x3b";
        $T1 = $T1 . "\x62\x6f\162\144\145\x72\x2d\162\x61\x64\x69\165\x73\72\71\x39\71\x70\x78\x3b";
        goto Re3;
        stz:
        $T1 = $T1 . "\x77\x69\144\x74\150\72" . $el . "\x70\170\73";
        $T1 = $T1 . "\150\145\x69\x67\x68\x74\72" . $el . "\160\x78\x3b";
        $T1 = $T1 . "\x62\157\162\144\x65\162\x2d\162\141\x64\151\165\x73\x3a\65\160\x78\x3b";
        goto Re3;
        Vkz:
        $T1 = $T1 . "\x77\151\x64\164\x68\72" . $el . "\160\170\x3b";
        $T1 = $T1 . "\150\145\x69\147\150\x74\x3a" . $el . "\x70\170\x3b";
        $T1 = $T1 . "\142\157\x72\x64\x65\x72\55\x72\x61\x64\151\x75\x73\x3a\60\160\170\x3b";
        Re3:
        goto lZv;
        rIu:
        $T1 = $T1 . "\x77\x69\x64\164\150\72" . $Ql . "\160\170\73";
        $T1 = $T1 . "\x68\145\x69\147\150\x74\x3a" . $DB . "\160\170\73";
        $T1 = $T1 . "\142\x6f\162\x64\x65\x72\x2d\162\141\144\151\x75\x73\72" . $eo . "\160\170\73";
        lZv:
        $T1 = $T1 . "\142\x61\143\x6b\147\x72\x6f\165\x6e\x64\x2d\x63\157\154\x6f\x72\72\x23" . $gH . "\x3b";
        $T1 = $T1 . "\142\x6f\162\144\x65\162\x2d\143\x6f\154\x6f\162\72\x74\162\x61\x6e\x73\x70\x61\x72\145\156\164\73";
        $T1 = $T1 . "\143\x6f\x6c\157\x72\72\43" . $g5 . "\73";
        $T1 = $T1 . "\x66\x6f\x6e\x74\55\163\151\x7a\145\72" . $vq . "\160\170\73";
        $T1 = $T1 . "\x70\x61\x64\x64\x69\x6e\147\x3a\x30\x70\x78\73";
        $Yb = $Yb . $T1 . "\x22\x2f\x3e";
        zO_:
        echo "\40\x3c\141\40\150\162\145\146\75\x22\x23\42\x20\157\x6e\x43\154\151\x63\153\75\42\163\165\142\155\151\x74\x53\141\155\154\x46\x6f\162\x6d\x28\x29\42\x3e";
        echo $Yb;
        echo "\x3c\57\141\76\74\x2f\x66\x6f\162\x6d\x3e\40";
        FQU:
        if ($this->mo_saml_check_empty_or_null_val(get_site_option("\x6d\157\137\x73\x61\x6d\154\x5f\162\x65\x64\x69\x72\145\x63\x74\137\x65\162\x72\x6f\162\137\143\x6f\144\145"))) {
            goto pB4;
        }
        echo "\74\144\151\166\76\x3c\x2f\x64\x69\166\76\x3c\144\151\166\40\164\151\164\154\x65\x3d\42\x4c\157\x67\151\156\40\x45\x72\x72\x6f\162\x22\x3e\x3c\146\x6f\156\x74\x20\143\157\x6c\x6f\162\x3d\x22\162\145\x64\42\x3e\x57\145\40\x63\157\165\x6c\144\x20\x6e\157\x74\40\163\x69\147\156\40\171\x6f\165\40\x69\156\56\40\120\154\x65\141\163\x65\x20\143\157\156\x74\141\143\x74\x20\171\157\x75\x72\x20\x41\144\155\x69\x6e\151\x73\x74\x72\x61\x74\x6f\x72\x2e\x3c\57\x66\157\156\164\x3e\x3c\57\x64\x69\166\76";
        delete_site_option("\155\157\x5f\163\x61\155\x6c\x5f\162\x65\144\x69\162\x65\x63\164\137\145\162\162\x6f\x72\137\x63\157\x64\145");
        delete_site_option("\155\x6f\x5f\x73\x61\155\154\137\x72\145\144\151\x72\x65\x63\x74\x5f\x65\x72\x72\157\162\137\x72\145\x61\163\x6f\x6e");
        pB4:
        echo "\74\141\40\150\162\145\146\x3d\42\150\x74\164\x70\x3a\57\57\155\151\156\x69\x6f\162\x61\x6e\x67\x65\x2e\x63\x6f\x6d\x2f\x77\x6f\x72\144\x70\x72\145\163\x73\55\154\144\141\160\55\x6c\157\147\x69\156\x22\x20\x73\x74\171\x6c\145\75\x22\144\x69\x73\x70\154\x61\x79\x3a\156\x6f\x6e\x65\x22\76\114\157\147\x69\x6e\x20\164\x6f\40\x57\x6f\x72\x64\120\x72\145\163\x73\x20\165\163\151\x6e\147\x20\x4c\104\101\120\x3c\57\141\76\15\12\11\11\11\x9\x3c\x61\40\x68\162\x65\x66\x3d\x22\x68\164\x74\160\x3a\x2f\57\x6d\x69\156\151\x6f\162\x61\156\147\x65\x2e\143\x6f\x6d\x2f\x63\154\157\x75\144\55\151\x64\145\x6e\164\x69\x74\171\x2d\142\x72\157\153\145\x72\55\163\x65\162\x76\x69\x63\x65\x22\x20\x73\x74\171\x6c\145\x3d\x22\144\151\163\x70\154\141\x79\72\156\x6f\x6e\x65\x22\76\x43\154\157\165\144\x20\111\144\145\156\x74\151\164\171\40\142\x72\157\153\145\162\40\163\x65\162\x76\x69\x63\145\x3c\x2f\x61\x3e\xd\xa\11\11\11\11\74\x61\x20\150\162\x65\146\x3d\x22\150\x74\164\x70\x3a\57\x2f\155\151\x6e\151\157\162\x61\156\147\145\x2e\x63\x6f\155\57\x73\x74\x72\157\x6e\147\x5f\141\x75\x74\150\42\x20\163\x74\171\x6c\x65\75\42\144\151\x73\160\x6c\141\x79\x3a\x6e\x6f\x6e\x65\73\42\76\x3c\57\141\76\xd\xa\11\11\11\11\74\x61\x20\x68\x72\x65\x66\75\x22\150\164\x74\160\x3a\x2f\x2f\x6d\x69\156\x69\x6f\x72\141\x6e\x67\x65\x2e\143\157\x6d\57\x73\151\156\x67\154\145\x2d\163\x69\147\x6e\55\x6f\x6e\x2d\163\x73\x6f\42\x20\163\164\x79\154\145\x3d\x22\144\151\163\160\x6c\x61\x79\72\x6e\157\156\x65\x3b\x22\76\x3c\57\x61\x3e\15\12\11\11\11\11\74\141\40\150\x72\145\x66\75\42\150\164\164\160\72\57\57\155\x69\x6e\151\x6f\x72\x61\x6e\x67\x65\x2e\143\x6f\x6d\57\x66\x72\141\165\144\x22\x20\x73\164\171\154\x65\75\x22\x64\x69\163\160\154\141\x79\x3a\x6e\157\x6e\x65\73\x22\76\x3c\57\x61\76\15\xa\15\12\11\11\11\x3c\x2f\x75\154\76\15\xa\x9\x9\x3c\57\x66\157\x72\x6d\76";
        ubn:
    }
    public function mo_saml_check_empty_or_null_val($n5)
    {
        if (!(!isset($n5) || empty($n5))) {
            goto nsw;
        }
        return true;
        nsw:
        return false;
    }
    function mo_saml_logout($AR)
    {
        $user = get_user_by("\151\x64", $AR);
        $im = get_site_option("\163\x61\155\x6c\137\x6c\157\147\157\165\x74\x5f\165\162\154");
        $JS = get_site_option("\163\141\155\x6c\137\x6c\x6f\147\x6f\165\x74\x5f\x62\x69\156\x64\x69\x6e\147\x5f\164\171\x70\x65");
        $current_user = $user;
        $D0 = get_user_meta($current_user->ID, "\x6d\157\x5f\x73\x61\155\154\x5f\x69\144\160\137\154\x6f\147\x69\156");
        $D0 = isset($D0[0]) ? $D0[0] : '';
        $YU = wp_get_referer();
        if (!empty($YU)) {
            goto jSW;
        }
        $YU = !empty(get_site_option("\155\157\x5f\x73\x61\155\154\137\163\160\137\142\141\x73\145\137\165\162\154")) ? get_site_option("\x6d\157\137\x73\x61\x6d\x6c\x5f\x73\160\137\x62\141\163\x65\137\x75\x72\154") : get_network_site_url();
        jSW:
        if (empty($im)) {
            goto skk;
        }
        if (!(!session_id() || session_id() == '' || !isset($_SESSION))) {
            goto f9C;
        }
        session_start();
        f9C:
        if (isset($_SESSION["\x6d\157\x5f\163\x61\155\154\137\154\x6f\x67\157\x75\164\137\x72\145\x71\x75\x65\163\164"])) {
            goto lUk;
        }
        if ($D0 == "\164\x72\165\145") {
            goto AcL;
        }
        goto y1j;
        lUk:
        self::createLogoutResponseAndRedirect($im, $JS);
        exit;
        goto y1j;
        AcL:
        delete_user_meta($current_user->ID, "\x6d\x6f\137\x73\141\x6d\x6c\x5f\x69\x64\160\137\x6c\x6f\x67\x69\x6e");
        $q6 = get_user_meta($current_user->ID, "\155\x6f\x5f\x73\141\155\154\x5f\156\x61\155\145\x5f\151\x64");
        $sL = get_user_meta($current_user->ID, "\155\157\x5f\x73\141\155\154\x5f\x73\145\x73\x73\x69\x6f\156\137\x69\x6e\x64\145\x78");
        mo_saml_create_logout_request($q6, $sL, $im, $JS, $YU);
        y1j:
        skk:
        wp_redirect($YU);
        exit;
    }
    function createLogoutResponseAndRedirect($im, $JS)
    {
        $E6 = get_site_option("\155\x6f\x5f\x73\x61\155\154\137\163\160\137\x62\x61\x73\x65\x5f\x75\162\154");
        if (!empty($E6)) {
            goto dy9;
        }
        $E6 = get_network_site_url();
        dy9:
        $Ah = $_SESSION["\155\x6f\137\x73\141\x6d\x6c\x5f\x6c\157\x67\x6f\165\164\137\x72\145\161\165\145\163\164"];
        $QB = $_SESSION["\155\157\137\x73\141\155\154\x5f\154\157\147\157\165\164\x5f\x72\145\x6c\x61\x79\x5f\163\164\x61\x74\145"];
        unset($_SESSION["\x6d\x6f\x5f\163\x61\x6d\154\137\154\x6f\147\157\x75\164\x5f\162\145\x71\165\145\x73\x74"]);
        unset($_SESSION["\x6d\x6f\137\x73\141\155\154\137\154\157\147\157\165\x74\137\x72\x65\x6c\141\171\137\x73\164\141\x74\x65"]);
        $vy = new DOMDocument();
        $vy->loadXML($Ah);
        $Ah = $vy->firstChild;
        if (!($Ah->localName == "\114\157\x67\157\x75\x74\x52\x65\x71\165\145\163\164")) {
            goto krM;
        }
        $JD = new SAML2_LogoutRequest($Ah);
        $Tc = get_site_option("\x6d\157\137\163\x61\x6d\154\137\163\x70\x5f\145\x6e\164\x69\x74\x79\137\151\144");
        if (!empty($Tc)) {
            goto xPM;
        }
        $Tc = $E6 . "\x2f\167\x70\55\143\157\156\x74\145\156\164\57\x70\154\x75\x67\x69\x6e\163\x2f\155\x69\x6e\x69\157\162\141\x6e\147\145\55\x73\x61\x6d\154\55\x32\x30\x2d\x73\151\x6e\147\154\x65\x2d\163\x69\x67\156\x2d\x6f\x6e\x2f";
        xPM:
        $Dl = $im;
        $ts = Utilities::createLogoutResponse($JD->getId(), $Tc, $Dl, $JS);
        if (empty($JS) || $JS == "\110\164\x74\160\x52\x65\144\151\162\145\143\164") {
            goto nEL;
        }
        if (!(get_site_option("\163\141\155\x6c\x5f\162\x65\161\x75\x65\163\x74\x5f\x73\151\x67\156\145\144") == "\165\x6e\143\x68\145\x63\153\x65\x64")) {
            goto GIk;
        }
        $Ln = base64_encode($ts);
        Utilities::postSAMLResponse($im, $Ln, $QB);
        exit;
        GIk:
        $MC = '';
        $q_ = '';
        $Ln = Utilities::signXML($ts, "\123\x74\x61\164\165\x73");
        Utilities::postSAMLResponse($im, $Ln, $QB);
        goto FUD;
        nEL:
        $nN = $im;
        if (strpos($im, "\x3f") !== false) {
            goto Zo8;
        }
        $nN .= "\x3f";
        goto Lgy;
        Zo8:
        $nN .= "\x26";
        Lgy:
        if (!(get_site_option("\163\141\155\154\x5f\x72\x65\161\165\x65\x73\164\x5f\163\x69\147\x6e\145\144") == "\165\x6e\x63\150\x65\143\153\145\x64")) {
            goto A96;
        }
        $nN .= "\123\x41\115\114\x52\x65\163\x70\x6f\x6e\x73\x65\x3d" . $ts . "\46\122\x65\154\141\x79\123\x74\141\164\145\75" . urlencode($QB);
        header("\114\x6f\x63\x61\164\x69\x6f\156\72\x20" . $nN);
        exit;
        A96:
        $nN .= "\123\101\115\114\122\x65\163\160\157\x6e\x73\145\75" . $ts . "\46\122\145\x6c\x61\171\x53\x74\x61\x74\145\75" . urlencode($QB);
        header("\114\x6f\143\141\x74\x69\x6f\x6e\72\40" . $nN);
        exit;
        FUD:
        krM:
    }
}
function mo_saml_create_logout_request($q6, $sL, $im, $JS, $YU)
{
    $E6 = get_site_option("\155\x6f\137\163\x61\155\154\x5f\163\160\x5f\x62\x61\x73\x65\137\x75\x72\154");
    if (!empty($E6)) {
        goto axb;
    }
    $E6 = get_network_site_url();
    axb:
    $Tc = get_site_option("\155\157\137\163\141\155\x6c\x5f\x73\x70\x5f\145\156\164\151\x74\x79\137\151\x64");
    if (!empty($Tc)) {
        goto AP5;
    }
    $Tc = $E6 . "\x2f\167\x70\55\143\x6f\156\164\x65\156\x74\57\x70\154\165\x67\x69\x6e\163\57\x6d\x69\x6e\151\x6f\x72\x61\156\147\145\x2d\x73\141\x6d\154\x2d\62\x30\x2d\163\151\156\x67\x6c\145\x2d\163\151\147\x6e\55\157\x6e\x2f";
    AP5:
    $Dl = $im;
    $iO = $YU;
    if (!empty($iO)) {
        goto WBr;
    }
    $iO = saml_get_current_page_url();
    if (!strpos($iO, "\x3f")) {
        goto v9F;
    }
    $iO = get_network_site_url();
    v9F:
    WBr:
    $iO = mo_saml_relaystate_url($iO);
    $ve = Utilities::createLogoutRequest($q6, $Tc, $Dl, $sL, $JS);
    if (empty($JS) || $JS == "\x48\x74\x74\160\x52\x65\x64\151\162\145\143\164") {
        goto Lfs;
    }
    if (!(get_site_option("\163\x61\x6d\x6c\137\162\x65\161\165\x65\163\x74\x5f\163\x69\147\x6e\x65\x64") == "\x75\x6e\x63\x68\145\x63\153\x65\x64")) {
        goto rOp;
    }
    $Ln = base64_encode($ve);
    Utilities::postSAMLRequest($im, $Ln, $iO);
    exit;
    rOp:
    $MC = '';
    $q_ = '';
    $Ln = Utilities::signXML($ve, "\x4e\141\155\x65\111\x44\120\x6f\x6c\151\x63\171");
    Utilities::postSAMLRequest($im, $Ln, $iO);
    goto g9c;
    Lfs:
    $nN = $im;
    if (strpos($im, "\x3f") !== false) {
        goto EIQ;
    }
    $nN .= "\77";
    goto WCP;
    EIQ:
    $nN .= "\x26";
    WCP:
    if (!(get_site_option("\x73\x61\155\154\x5f\x72\145\x71\165\x65\163\x74\x5f\163\151\x67\x6e\145\x64") == "\165\x6e\x63\x68\145\x63\x6b\145\x64")) {
        goto nVK;
    }
    $nN .= "\x53\101\x4d\x4c\x52\x65\x71\165\x65\163\164\75" . $ve . "\46\122\x65\154\141\171\x53\x74\141\x74\x65\75" . urlencode($iO);
    header("\x4c\x6f\143\x61\x74\x69\157\x6e\72\40" . $nN);
    exit;
    nVK:
    $ve = "\123\x41\115\x4c\x52\145\161\165\145\x73\164\x3d" . $ve . "\46\122\145\x6c\x61\x79\123\164\141\x74\x65\75" . urlencode($iO) . "\x26\123\151\147\101\x6c\147\75" . urlencode(XMLSecurityKey::RSA_SHA256);
    $Du = array("\164\x79\160\x65" => "\x70\x72\x69\x76\141\164\145");
    $a5 = new XMLSecurityKey(XMLSecurityKey::RSA_SHA256, $Du);
    $F_ = get_site_option("\155\x6f\137\x73\141\155\154\137\143\x75\x72\162\x65\156\x74\137\x63\x65\162\x74\x5f\x70\162\x69\x76\x61\164\x65\137\153\x65\x79");
    $a5->loadKey($F_, FALSE);
    $tP = new XMLSecurityDSig();
    $Xe = $a5->signData($ve);
    $Xe = base64_encode($Xe);
    $nN .= $ve . "\x26\123\x69\147\156\141\164\x75\x72\145\x3d" . urlencode($Xe);
    header("\114\x6f\x63\x61\x74\151\x6f\156\x3a" . $nN);
    exit;
    g9c:
}
function mo_login_validate()
{
    if (!(isset($_REQUEST["\x6f\x70\x74\x69\x6f\156"]) && $_REQUEST["\x6f\160\164\151\x6f\x6e"] == "\155\157\163\141\x6d\x6c\x5f\155\x65\164\x61\144\x61\x74\x61")) {
        goto a0Z;
    }
    miniorange_generate_metadata();
    a0Z:
    if (!mo_saml_is_customer_license_verified()) {
        goto Z9E;
    }
    if (!(isset($_REQUEST["\157\x70\x74\151\x6f\x6e"]) && $_REQUEST["\x6f\x70\x74\151\x6f\156"] == "\163\x61\x6d\154\x5f\165\163\145\x72\137\154\x6f\x67\x69\156" || isset($_REQUEST["\157\160\x74\x69\157\156"]) && $_REQUEST["\x6f\160\164\x69\157\156"] == "\164\145\x73\x74\103\x6f\x6e\146\x69\x67" || isset($_REQUEST["\x6f\160\x74\x69\157\x6e"]) && $_REQUEST["\157\160\x74\151\x6f\156"] == "\147\145\164\x73\x61\155\x6c\x72\x65\161\x75\x65\163\x74" || isset($_REQUEST["\157\x70\x74\x69\x6f\156"]) && $_REQUEST["\157\x70\164\151\157\156"] == "\147\145\164\x73\x61\155\x6c\162\x65\163\160\x6f\x6e\x73\145")) {
        goto S0B;
    }
    if (mo_saml_is_sp_configured()) {
        goto Vh4;
    }
    if (!is_user_logged_in()) {
        goto r3C;
    }
    if (!isset($_REQUEST["\162\145\144\151\162\145\x63\164\137\x74\157"])) {
        goto mXx;
    }
    $Nk = htmlspecialchars($_REQUEST["\162\145\x64\151\x72\x65\x63\164\x5f\x74\x6f"]);
    wp_safe_redirect($Nk);
    exit;
    mXx:
    r3C:
    goto dj6;
    Vh4:
    if (!(is_user_logged_in() and $_REQUEST["\157\160\x74\151\x6f\156"] == "\163\x61\155\154\137\165\x73\x65\162\x5f\154\157\x67\151\156")) {
        goto DxH;
    }
    if (!isset($_REQUEST["\162\x65\x64\x69\162\145\143\164\137\x74\157"])) {
        goto AR7;
    }
    $Nk = htmlspecialchars($_REQUEST["\162\145\x64\151\x72\145\x63\164\x5f\x74\157"]);
    wp_safe_redirect($Nk);
    exit;
    AR7:
    return;
    DxH:
    $E6 = get_site_option("\x6d\157\137\163\141\x6d\154\137\163\x70\137\x62\141\x73\145\x5f\x75\162\154");
    if (!empty($E6)) {
        goto mlt;
    }
    $E6 = get_network_site_url();
    mlt:
    $yn = get_site_option("\163\141\x6d\154\x5f\x73\x73\x6f\x5f\163\x65\164\x74\151\x6e\x67\163");
    $FX = get_current_blog_id();
    $pB = Utilities::get_active_sites();
    if (in_array($FX, $pB)) {
        goto ABF;
    }
    return;
    ABF:
    if (!(empty($yn[$FX]) && !empty($yn["\x44\x45\106\101\125\x4c\x54"]))) {
        goto Kyu;
    }
    $yn[$FX] = $yn["\x44\105\x46\x41\125\x4c\124"];
    Kyu:
    if ($_REQUEST["\157\160\164\x69\x6f\156"] == "\x74\145\x73\164\103\x6f\x6e\146\x69\x67" and array_key_exists("\156\x65\x77\143\145\x72\x74", $_REQUEST)) {
        goto RRg;
    }
    if ($_REQUEST["\x6f\x70\164\151\x6f\156"] == "\x74\145\x73\164\x43\157\x6e\x66\x69\147") {
        goto XmD;
    }
    if ($_REQUEST["\x6f\160\164\x69\x6f\x6e"] == "\x67\x65\164\x73\x61\x6d\154\x72\145\x71\x75\x65\163\164") {
        goto XUy;
    }
    if ($_REQUEST["\x6f\160\164\151\x6f\156"] == "\x67\x65\164\x73\141\x6d\x6c\162\145\x73\160\157\156\x73\145") {
        goto GgC;
    }
    if (!empty($yn[$FX]["\155\x6f\137\163\x61\155\154\x5f\x72\x65\x6c\x61\x79\137\163\164\x61\x74\145"])) {
        goto tTo;
    }
    if (isset($_REQUEST["\x72\145\x64\151\x72\145\x63\x74\x5f\164\157"])) {
        goto e9_;
    }
    $iO = saml_get_current_page_url();
    goto PVK;
    e9_:
    $iO = $_REQUEST["\x72\x65\x64\x69\x72\x65\143\164\x5f\164\157"];
    PVK:
    goto cPF;
    tTo:
    $iO = $yn[$FX]["\x6d\157\137\x73\141\x6d\x6c\137\162\145\x6c\x61\171\137\163\x74\x61\164\145"];
    cPF:
    goto jeK;
    GgC:
    $iO = "\144\x69\x73\160\154\x61\x79\x53\x41\115\114\x52\x65\163\x70\x6f\156\x73\145";
    jeK:
    goto rBh;
    XUy:
    $iO = "\144\151\x73\160\154\141\171\123\x41\x4d\114\122\x65\x71\165\x65\x73\x74";
    rBh:
    goto faS;
    XmD:
    $iO = "\x74\x65\x73\164\x56\x61\154\x69\x64\x61\164\x65";
    faS:
    goto khn;
    RRg:
    $iO = "\x74\145\163\164\116\145\x77\x43\145\162\164\x69\x66\x69\143\141\x74\x65";
    khn:
    $Ju = get_site_option("\163\141\x6d\154\x5f\x6c\157\x67\x69\156\137\165\162\x6c");
    $ke = !empty(get_site_option("\163\141\x6d\154\x5f\154\157\x67\x69\156\x5f\x62\x69\156\x64\151\156\x67\137\164\171\160\145")) ? get_site_option("\163\x61\155\154\137\x6c\x6f\147\x69\156\137\x62\x69\156\144\x69\156\x67\x5f\x74\171\x70\145") : "\110\x74\164\160\x50\x6f\163\164";
    $yn = get_site_option("\x73\x61\x6d\154\137\163\163\157\137\x73\145\x74\164\x69\156\x67\163");
    $FX = get_current_blog_id();
    $pB = Utilities::get_active_sites();
    if (in_array($FX, $pB)) {
        goto q8_;
    }
    return;
    q8_:
    if (!(empty($yn[$FX]) && !empty($yn["\x44\105\106\101\125\x4c\x54"]))) {
        goto uYu;
    }
    $yn[$FX] = $yn["\x44\x45\x46\x41\x55\114\124"];
    uYu:
    $VU = isset($yn[$FX]["\x6d\157\x5f\x73\x61\x6d\154\137\x66\x6f\162\143\x65\x5f\x61\x75\164\x68\x65\156\x74\x69\143\x61\164\151\x6f\156"]) ? $yn[$FX]["\x6d\157\x5f\x73\141\x6d\154\137\x66\x6f\162\x63\x65\137\141\165\x74\150\145\x6e\x74\x69\143\x61\x74\151\157\x6e"] : '';
    $XW = $E6 . "\x2f";
    $Tc = get_site_option("\155\x6f\137\x73\141\155\154\137\x73\x70\137\145\156\x74\x69\x74\x79\137\x69\x64");
    $ju = get_site_option("\x73\141\x6d\154\x5f\x6e\141\155\145\x69\x64\x5f\x66\157\x72\155\x61\164");
    if (!empty($ju)) {
        goto QBw;
    }
    $ju = "\61\x2e\61\72\156\x61\x6d\x65\151\144\x2d\146\157\x72\155\x61\x74\72\165\156\x73\160\145\x63\x69\x66\x69\x65\x64";
    QBw:
    if (!empty($Tc)) {
        goto rJY;
    }
    $Tc = $E6 . "\57\167\160\x2d\x63\x6f\156\x74\x65\x6e\164\57\x70\154\x75\x67\x69\x6e\x73\57\155\151\x6e\151\x6f\x72\141\x6e\147\x65\55\163\141\x6d\154\x2d\x32\60\55\163\151\156\x67\154\x65\x2d\163\x69\147\x6e\55\157\156\x2f";
    rJY:
    $ve = Utilities::createAuthnRequest($XW, $Tc, $Ju, $VU, $ke, $ju);
    if (!($iO == "\x64\x69\163\x70\x6c\x61\171\123\101\115\114\122\x65\x71\165\x65\x73\x74")) {
        goto ZUV;
    }
    mo_saml_show_SAML_log(Utilities::createAuthnRequest($XW, $Tc, $Ju, $VU, "\110\x74\x74\160\x50\157\x73\164", $ju), $iO);
    ZUV:
    $nN = htmlspecialchars_decode($Ju);
    if (strpos($Ju, "\x3f") !== false) {
        goto mD7;
    }
    $nN .= "\x3f";
    goto GC0;
    mD7:
    $nN .= "\46";
    GC0:
    $iO = mo_saml_relaystate_url($iO);
    if ($ke == "\110\x74\164\160\x52\145\144\x69\x72\145\143\x74") {
        goto YlR;
    }
    if (!(get_site_option("\163\141\x6d\154\x5f\x72\x65\x71\x75\145\163\164\137\x73\x69\x67\x6e\x65\x64") == "\x75\x6e\143\x68\x65\x63\x6b\x65\x64")) {
        goto FJz;
    }
    $Ln = base64_encode($ve);
    Utilities::postSAMLRequest($Ju, $Ln, $iO);
    exit;
    FJz:
    $MC = '';
    $q_ = '';
    if ($_REQUEST["\157\160\164\x69\157\156"] == "\164\x65\163\x74\103\x6f\x6e\x66\x69\147" && array_key_exists("\156\145\x77\143\x65\x72\164", $_REQUEST)) {
        goto yMJ;
    }
    $Ln = Utilities::signXML($ve, "\x4e\x61\155\x65\111\104\120\157\154\151\x63\x79");
    goto k8x;
    yMJ:
    $Ln = Utilities::signXML($ve, "\116\x61\155\x65\111\104\120\157\154\x69\143\171", true);
    k8x:
    Utilities::postSAMLRequest($Ju, $Ln, $iO);
    update_site_option("\x6d\157\x5f\x73\x61\x6d\x6c\137\156\145\x77\x5f\143\x65\x72\164\137\164\x65\163\x74", true);
    goto F_0;
    YlR:
    if (!(get_site_option("\163\x61\155\x6c\137\x72\145\x71\x75\145\163\164\137\163\x69\x67\156\145\144") == "\x75\156\143\x68\x65\143\153\x65\x64")) {
        goto PTq;
    }
    $nN .= "\123\x41\115\114\122\145\161\x75\x65\x73\x74\75" . $ve . "\x26\122\x65\154\141\171\123\x74\141\x74\x65\x3d" . urlencode($iO);
    header("\x4c\157\143\x61\x74\x69\157\x6e\72\x20" . $nN);
    exit;
    PTq:
    $ve = "\123\101\x4d\114\122\145\161\x75\145\163\164\x3d" . $ve . "\x26\x52\x65\154\141\171\x53\164\141\164\145\x3d" . urlencode($iO) . "\46\123\x69\147\101\154\147\x3d" . urlencode(XMLSecurityKey::RSA_SHA256);
    $Du = array("\164\x79\x70\x65" => "\160\162\151\x76\141\164\145");
    $a5 = new XMLSecurityKey(XMLSecurityKey::RSA_SHA256, $Du);
    if ($_REQUEST["\x6f\x70\164\151\157\156"] == "\x74\145\163\164\103\x6f\156\146\151\x67" && array_key_exists("\x6e\x65\167\x63\145\162\x74", $_REQUEST)) {
        goto l8y;
    }
    $F_ = get_site_option("\155\x6f\137\x73\141\x6d\154\137\143\165\x72\162\x65\156\164\137\143\x65\x72\164\137\160\162\151\x76\x61\164\x65\x5f\153\x65\x79");
    goto Imb;
    l8y:
    $F_ = file_get_contents(plugin_dir_path(__FILE__) . "\162\145\163\x6f\165\x72\x63\145\163" . DIRECTORY_SEPARATOR . mo_options_enum_default_sp_certificate::SP_Private_Key);
    Imb:
    $a5->loadKey($F_, FALSE);
    $tP = new XMLSecurityDSig();
    $Xe = $a5->signData($ve);
    $Xe = base64_encode($Xe);
    $nN .= $ve . "\x26\x53\x69\x67\x6e\x61\164\165\x72\x65\x3d" . urlencode($Xe);
    header("\x4c\x6f\143\141\164\x69\157\156\x3a\x20" . $nN);
    exit;
    F_0:
    dj6:
    S0B:
    if (!(array_key_exists("\x53\101\x4d\114\x52\145\163\x70\x6f\156\x73\x65", $_REQUEST) && !empty($_REQUEST["\x53\101\x4d\114\x52\x65\x73\160\x6f\156\163\x65"]))) {
        goto w11;
    }
    if (array_key_exists("\x52\145\154\141\171\x53\x74\x61\x74\145", $_POST) && !empty($_POST["\122\145\154\141\171\x53\164\x61\164\x65"]) && $_POST["\x52\145\154\x61\x79\x53\x74\141\x74\145"] != "\57") {
        goto maI;
    }
    $Rj = '';
    goto Vro;
    maI:
    $Rj = $_POST["\122\x65\x6c\141\x79\123\x74\141\x74\145"];
    Vro:
    $Rj = mo_saml_parse_url($Rj);
    $E6 = get_site_option("\155\157\x5f\x73\x61\155\154\137\163\160\x5f\142\x61\163\145\137\165\162\154");
    if (!empty($E6)) {
        goto Ahl;
    }
    $E6 = get_network_site_url();
    Ahl:
    $KJ = $_REQUEST["\123\x41\x4d\x4c\122\145\x73\x70\157\156\163\145"];
    $KJ = base64_decode($KJ);
    if (!($Rj == "\144\x69\x73\160\x6c\x61\x79\123\101\115\x4c\122\x65\x73\160\157\156\x73\145")) {
        goto e8j;
    }
    mo_saml_show_SAML_log($KJ, $Rj);
    e8j:
    if (!(array_key_exists("\123\101\115\x4c\x52\145\x73\160\x6f\x6e\163\145", $_GET) && !empty($_GET["\123\x41\115\x4c\x52\145\163\x70\x6f\156\x73\x65"]))) {
        goto cEK;
    }
    $KJ = gzinflate($KJ);
    cEK:
    $vy = new DOMDocument();
    $vy->loadXML($KJ);
    $Ob = $vy->firstChild;
    $Pj = $vy->documentElement;
    $Mn = new DOMXpath($vy);
    $Mn->registerNamespace("\163\141\x6d\x6c\160", "\x75\162\156\x3a\x6f\141\x73\151\x73\72\156\141\x6d\145\x73\x3a\164\x63\72\123\101\x4d\114\72\x32\56\x30\x3a\x70\162\x6f\x74\157\143\x6f\154");
    $Mn->registerNamespace("\x73\141\155\154", "\165\x72\156\x3a\157\141\163\x69\163\x3a\156\x61\x6d\x65\x73\72\164\143\x3a\123\x41\115\114\x3a\x32\56\x30\72\141\x73\x73\145\x72\x74\151\157\156");
    if ($Ob->localName == "\114\157\147\157\165\x74\122\145\163\160\x6f\156\x73\145") {
        goto k3O;
    }
    $u_ = $Mn->query("\57\163\x61\155\154\x70\72\122\145\163\160\x6f\x6e\163\x65\x2f\x73\x61\155\154\160\x3a\123\x74\x61\164\x75\x73\57\x73\141\155\154\x70\x3a\x53\x74\141\164\x75\163\103\157\x64\x65", $Pj);
    $Dp = isset($u_) ? $u_->item(0)->getAttribute("\126\141\154\x75\x65") : '';
    $Fo = explode("\x3a", $Dp);
    if (!array_key_exists(7, $Fo)) {
        goto qD0;
    }
    $u_ = $Fo[7];
    qD0:
    $Af = $Mn->query("\57\163\141\155\x6c\x70\72\122\x65\163\160\x6f\x6e\163\145\57\x73\x61\x6d\154\x70\x3a\123\164\x61\x74\165\163\57\163\141\155\x6c\160\x3a\123\164\141\x74\x75\163\115\145\x73\163\x61\x67\145", $Pj);
    $GZ = isset($Af) ? $Af->item(0) : '';
    if (empty($GZ)) {
        goto BGv;
    }
    $GZ = $GZ->nodeValue;
    BGv:
    if (array_key_exists("\122\145\x6c\x61\x79\x53\164\x61\x74\145", $_POST) && !empty($_POST["\x52\145\154\141\x79\123\x74\141\x74\145"]) && $_POST["\x52\145\154\x61\x79\x53\x74\141\164\145"] != "\57") {
        goto Flp;
    }
    $Rj = '';
    goto VD_;
    Flp:
    $Rj = $_POST["\x52\145\154\141\171\x53\x74\141\x74\x65"];
    $Rj = mo_saml_parse_url($Rj);
    VD_:
    if (!($u_ != "\123\x75\x63\x63\145\163\163")) {
        goto Jm7;
    }
    show_status_error($u_, $Rj, $GZ);
    Jm7:
    if (!($Rj !== "\164\145\x73\x74\x56\141\154\x69\x64\141\x74\x65" && $Rj !== "\164\145\x73\164\116\145\x77\103\x65\162\164\151\146\151\143\x61\164\x65")) {
        goto lDp;
    }
    $rX = parse_url($Rj, PHP_URL_HOST);
    $aW = parse_url($E6, PHP_URL_HOST);
    $W3 = parse_url(get_current_base_url(), PHP_URL_HOST);
    if (!empty($Rj)) {
        goto vA9;
    }
    $Rj = "\x2f";
    goto Bd2;
    vA9:
    $Rj = mo_saml_parse_url($Rj);
    Bd2:
    if (!(!empty($rX) && $rX != $W3)) {
        goto PVf;
    }
    Utilities::postSAMLResponse($Rj, $_REQUEST["\123\x41\115\114\122\x65\163\x70\157\156\163\x65"], mo_saml_relaystate_url($Rj));
    PVf:
    lDp:
    $Fx = maybe_unserialize(get_site_option("\x73\x61\155\154\x5f\170\65\x30\x39\x5f\x63\x65\x72\x74\151\x66\x69\143\141\x74\145"));
    update_site_option("\155\157\137\163\141\x6d\x6c\137\162\145\163\160\x6f\x6e\x73\145", base64_encode($KJ));
    foreach ($Fx as $a5 => $n5) {
        if (@openssl_x509_read($n5)) {
            goto IpZ;
        }
        unset($Fx[$a5]);
        IpZ:
        S8P:
    }
    Ikz:
    $XW = $E6 . "\x2f";
    if ($Rj == "\164\145\163\164\x4e\x65\x77\103\145\x72\164\151\146\x69\x63\141\164\x65") {
        goto pnR;
    }
    $KJ = new SAML2_Response($Ob, get_site_option("\155\x6f\x5f\x73\x61\x6d\x6c\x5f\143\x75\x72\162\x65\x6e\164\137\x63\x65\x72\x74\137\x70\162\x69\x76\x61\x74\145\x5f\153\x65\171"));
    goto ByE;
    pnR:
    $KV = file_get_contents(plugin_dir_path(__FILE__) . "\162\145\x73\x6f\165\x72\143\145\x73" . DIRECTORY_SEPARATOR . mo_options_enum_default_sp_certificate::SP_Private_Key);
    $KJ = new SAML2_Response($Ob, $KV);
    ByE:
    $Kd = $KJ->getSignatureData();
    $Ok = current($KJ->getAssertions())->getSignatureData();
    if (!(empty($Ok) && empty($Kd))) {
        goto QMF;
    }
    if ($Rj == "\164\145\x73\164\x56\141\154\x69\x64\x61\x74\145" or $Rj == "\164\x65\x73\164\x4e\x65\x77\103\145\162\x74\x69\x66\151\143\x61\x74\145") {
        goto WTk;
    }
    wp_die("\x57\x65\40\143\x6f\x75\154\144\x20\156\x6f\x74\x20\163\x69\147\x6e\x20\171\157\x75\40\x69\x6e\x2e\x20\120\154\145\x61\163\x65\40\x63\157\x6e\x74\141\x63\x74\x20\x61\144\x6d\151\x6e\x69\x73\x74\162\x61\x74\157\162", "\x45\162\x72\157\x72\x3a\x20\x49\156\x76\141\154\151\x64\40\123\x41\x4d\x4c\x20\x52\x65\x73\x70\157\156\163\x65");
    goto RQi;
    WTk:
    $Pn = mo_options_error_constants::Error_no_certificate;
    $yy = mo_options_error_constants::Cause_no_certificate;
    echo "\x3c\144\x69\166\40\163\164\171\x6c\x65\x3d\42\x66\157\156\164\55\146\x61\x6d\151\x6c\171\72\103\141\x6c\151\142\162\151\x3b\160\x61\x64\x64\151\x6e\x67\x3a\x30\x20\x33\45\x3b\42\76\xd\12\11\x9\11\11\11\11\x3c\x64\151\166\40\x73\x74\x79\154\x65\75\42\x63\x6f\x6c\157\x72\x3a\x20\x23\x61\71\x34\x34\x34\62\x3b\142\x61\143\x6b\x67\162\157\165\156\x64\55\143\x6f\154\157\x72\72\40\43\x66\x32\144\145\x64\145\73\160\141\144\x64\151\156\147\72\40\x31\x35\160\x78\73\155\141\x72\147\x69\x6e\x2d\x62\x6f\164\164\157\x6d\72\40\62\60\160\x78\73\x74\145\x78\x74\55\x61\x6c\x69\x67\x6e\72\x63\145\x6e\x74\x65\x72\73\142\x6f\x72\x64\145\x72\72\61\x70\170\x20\163\x6f\154\151\x64\40\x23\105\x36\102\63\x42\62\73\146\157\x6e\x74\55\x73\x69\x7a\x65\72\61\70\x70\x74\73\42\x3e\40\x45\122\122\x4f\122\74\57\x64\x69\x76\x3e\xd\12\x9\11\11\x9\11\x9\74\144\x69\166\x20\x73\164\171\x6c\145\75\42\x63\157\154\157\x72\72\x20\x23\141\x39\64\x34\64\x32\x3b\x66\157\156\x74\x2d\163\x69\172\145\x3a\61\x34\160\x74\x3b\x20\x6d\x61\x72\x67\x69\x6e\55\x62\x6f\x74\x74\157\155\72\x32\60\160\170\73\x22\76\74\x70\x3e\x3c\163\164\x72\157\x6e\x67\76\105\x72\x72\157\162\x20\x20\72" . esc_html($Pn) . "\x20\74\x2f\163\164\x72\157\x6e\x67\x3e\74\57\160\x3e\xd\xa\x9\x9\11\x9\11\11\15\12\x9\11\x9\11\x9\11\74\x70\76\x3c\x73\164\162\157\156\147\x3e\x50\157\x73\163\151\142\x6c\145\40\103\x61\165\x73\145\x3a\40" . esc_html($yy) . "\x3c\x2f\163\x74\x72\157\x6e\147\76\74\x2f\x70\x3e\15\xa\x9\11\11\11\x9\11\15\xa\11\11\11\x9\x9\x9\x3c\x2f\144\151\x76\x3e\x3c\x2f\x64\151\166\x3e";
    mo_saml_download_logs($Pn, $yy);
    exit;
    RQi:
    QMF:
    $OJ = '';
    if (is_array($Fx)) {
        goto scE;
    }
    $np = XMLSecurityKey::getRawThumbprint($Fx);
    $np = mo_saml_convert_to_windows_iconv($np);
    $np = preg_replace("\x2f\134\163\x2b\x2f", '', $np);
    if (empty($Kd)) {
        goto cN3;
    }
    $OJ = Utilities::processResponse($XW, $np, $Kd, $KJ, 0, $Rj);
    cN3:
    if (empty($Ok)) {
        goto qUg;
    }
    $OJ = Utilities::processResponse($XW, $np, $Ok, $KJ, 0, $Rj);
    qUg:
    goto Q5n;
    scE:
    foreach ($Fx as $a5 => $n5) {
        $np = XMLSecurityKey::getRawThumbprint($n5);
        $np = mo_saml_convert_to_windows_iconv($np);
        $np = preg_replace("\57\x5c\163\53\57", '', $np);
        if (empty($Kd)) {
            goto oRP;
        }
        $OJ = Utilities::processResponse($XW, $np, $Kd, $KJ, $a5, $Rj);
        oRP:
        if (empty($Ok)) {
            goto hXI;
        }
        $OJ = Utilities::processResponse($XW, $np, $Ok, $KJ, $a5, $Rj);
        hXI:
        if (!$OJ) {
            goto q8C;
        }
        goto xKH;
        q8C:
        M1m:
    }
    xKH:
    Q5n:
    if (empty($Kd)) {
        goto YAC;
    }
    $g1 = $Kd["\x43\x65\x72\164\x69\146\151\143\x61\164\145\x73"][0];
    goto qvl;
    YAC:
    $g1 = $Ok["\103\x65\162\164\x69\146\x69\x63\x61\164\x65\163"][0];
    qvl:
    if ($OJ) {
        goto UMI;
    }
    if ($Rj == "\x74\x65\163\x74\x56\141\154\x69\x64\x61\164\x65" or $Rj == "\164\x65\x73\164\x4e\145\x77\x43\x65\x72\x74\x69\146\151\143\141\x74\145") {
        goto eyA;
    }
    wp_die("\x57\x65\40\x63\157\x75\154\144\x20\x6e\157\x74\40\x73\151\147\156\x20\171\x6f\x75\x20\x69\156\x2e\x20\120\x6c\x65\141\x73\145\40\143\x6f\156\164\141\x63\164\40\x79\x6f\165\x72\40\x41\x64\x6d\x69\156\x69\x73\x74\x72\x61\164\x6f\x72", "\x45\x72\x72\157\x72\40\72\x43\x65\162\164\151\146\x69\143\x61\164\x65\40\x6e\157\164\x20\x66\x6f\165\156\x64");
    goto eYG;
    eyA:
    $Pn = mo_options_error_constants::Error_wrong_certificate;
    $yy = mo_options_error_constants::Cause_wrong_certificate;
    $EW = "\x2d\x2d\x2d\55\55\x42\105\107\111\x4e\40\x43\105\x52\x54\x49\x46\x49\103\101\124\105\x2d\x2d\55\55\x2d\74\142\162\x3e" . chunk_split($g1, 64) . "\74\x62\162\x3e\55\55\x2d\55\x2d\x45\x4e\x44\x20\x43\x45\122\124\111\106\111\x43\x41\x54\x45\x2d\55\55\55\x2d";
    echo "\x3c\144\151\x76\40\163\164\171\154\x65\75\42\x66\157\x6e\x74\x2d\x66\141\155\x69\154\x79\72\103\x61\154\x69\142\x72\151\x3b\x70\x61\x64\x64\x69\x6e\147\72\60\x20\63\45\x3b\42\x3e";
    echo "\74\144\x69\166\40\163\x74\171\x6c\x65\x3d\x22\143\x6f\x6c\157\162\72\40\x23\x61\71\x34\64\x34\62\73\x62\141\x63\x6b\147\x72\157\165\x6e\144\x2d\143\157\x6c\x6f\162\72\40\43\x66\62\x64\145\x64\x65\73\160\x61\x64\x64\x69\156\147\72\40\x31\65\160\x78\x3b\155\x61\162\147\x69\156\x2d\x62\157\164\x74\x6f\x6d\x3a\40\62\x30\x70\x78\73\164\x65\170\164\x2d\141\154\151\x67\x6e\x3a\x63\x65\x6e\x74\x65\162\x3b\x62\x6f\x72\x64\145\162\72\61\x70\170\x20\x73\x6f\154\x69\x64\x20\x23\105\x36\102\x33\102\62\73\146\157\x6e\164\x2d\163\151\x7a\x65\x3a\x31\x38\160\x74\x3b\x22\76\40\x45\x52\x52\117\122\x3c\57\144\x69\166\76\xd\12\x20\40\x20\40\x20\40\40\x20\40\40\x20\x20\40\40\x20\40\40\40\40\40\x20\40\x20\40\74\144\151\166\x20\x73\x74\171\154\145\x3d\x22\x63\x6f\x6c\x6f\x72\72\40\x23\141\71\64\x34\64\62\x3b\146\157\x6e\164\55\163\151\x7a\145\72\61\64\160\x74\73\40\155\x61\x72\x67\x69\156\x2d\x62\157\164\164\x6f\155\x3a\x32\60\x70\170\73\x22\76\x3c\x70\x3e\x3c\x73\x74\x72\x6f\x6e\x67\x3e\x45\x72\162\157\162\72\40\74\x2f\163\x74\x72\157\156\x67\x3e\x55\x6e\141\142\154\145\x20\x74\x6f\x20\146\151\156\144\40\x61\x20\x63\145\162\164\151\146\151\143\x61\x74\x65\x20\155\x61\164\143\150\151\x6e\x67\40\x74\150\x65\x20\143\x6f\x6e\146\x69\x67\165\162\145\x64\x20\x66\x69\156\147\x65\x72\x70\x72\151\156\164\x2e\x3c\57\160\x3e\xd\xa\40\40\40\x20\40\x20\40\x20\40\40\x20\40\x20\x20\x20\40\40\40\40\40\40\x20\x20\40\40\40\40\40\74\160\76\x50\154\x65\141\163\145\x20\143\x6f\x6e\x74\x61\143\x74\40\x79\157\165\x72\x20\141\x64\155\x69\156\151\163\x74\162\x61\x74\157\162\40\141\x6e\144\40\x72\145\160\157\162\164\x20\x74\150\x65\x20\146\x6f\154\x6c\157\x77\x69\156\x67\40\145\162\162\x6f\162\72\x3c\x2f\160\76\15\12\x20\x20\x20\40\x20\40\x20\40\40\x20\x20\x20\40\40\x20\x20\40\x20\x20\x20\40\x20\x20\x20\40\x20\40\40\x3c\x70\76\74\163\164\162\x6f\156\x67\76\120\157\x73\163\x69\x62\x6c\x65\x20\x43\x61\165\163\145\72\40\x3c\x2f\x73\164\x72\x6f\156\147\76\x27\x58\56\x35\60\x39\x20\103\145\162\164\x69\146\x69\143\x61\x74\x65\x27\40\146\151\145\x6c\144\x20\151\x6e\x20\160\154\x75\x67\151\156\x20\x64\157\x65\x73\x20\x6e\157\164\40\155\x61\164\143\x68\40\x74\x68\x65\40\143\x65\162\164\151\x66\x69\x63\141\x74\x65\40\146\x6f\x75\x6e\144\x20\x69\156\40\x53\101\x4d\x4c\x20\122\145\x73\x70\157\x6e\163\x65\56\x3c\x2f\x70\x3e\xd\12\x20\x20\40\x20\x20\x20\40\x20\x20\x20\40\40\x20\x20\x20\x20\x20\x20\40\x20\40\40\x20\x20\x20\x20\x20\40\74\x70\76\74\163\x74\x72\x6f\x6e\x67\76\x43\145\162\164\x69\146\151\x63\x61\x74\x65\40\146\x6f\x75\156\x64\40\151\156\40\123\x41\x4d\114\x20\x52\145\163\160\157\156\x73\x65\x3a\x20\74\57\x73\x74\162\157\156\147\x3e\74\x66\157\156\164\x20\x66\141\143\145\75\42\x43\x6f\x75\162\151\x65\162\x20\x4e\x65\167\x22\76\74\x62\x72\76\x3c\142\162\x3e" . $EW . "\x3c\57\x70\76\74\57\x66\157\x6e\164\x3e\15\12\40\40\x20\x20\40\40\x20\40\x20\x20\x20\40\40\x20\40\x20\40\x20\x20\40\x20\40\x20\x20\x20\40\x20\x20\x3c\x70\76\74\163\x74\x72\157\x6e\x67\76\123\157\154\x75\164\151\x6f\x6e\72\x20\74\x2f\163\164\162\x6f\x6e\147\76\74\x2f\160\76\xd\12\x20\40\x20\40\x20\x20\x20\x20\40\40\40\40\x20\x20\40\x20\40\40\x20\x20\40\x20\40\x20\40\40\40\x20\74\x6f\x6c\x3e\xd\xa\40\x20\40\x20\x20\x20\40\x20\x20\x20\40\40\40\40\x20\x20\40\x20\40\x20\x20\40\x20\40\x20\40\40\x20\x20\x20\40\x3c\154\x69\x3e\x43\157\x70\x79\40\x70\141\x73\x74\x65\40\x74\x68\145\x20\x63\145\x72\x74\151\x66\151\143\x61\164\145\40\160\162\x6f\166\151\144\145\x64\x20\x61\x62\x6f\166\145\x20\x69\156\40\x58\x35\x30\x39\40\x43\145\162\x74\x69\x66\x69\x63\x61\x74\145\40\165\x6e\x64\145\x72\40\123\145\162\166\151\143\x65\x20\x50\x72\x6f\166\151\144\145\x72\40\x53\145\164\165\x70\40\164\x61\142\x2e\x3c\x2f\x6c\x69\x3e\15\12\x20\x20\x20\x20\x20\40\x20\40\x20\40\x20\40\40\40\x20\x20\x20\x20\40\x20\x20\40\40\40\x20\x20\40\x20\40\40\x20\74\x6c\x69\76\111\x66\x20\x69\x73\x73\165\x65\x20\x70\145\x72\x73\x69\x73\164\163\x20\x64\151\163\x61\142\154\145\40\x3c\x62\76\103\x68\x61\162\x61\x63\x74\145\x72\40\x65\156\143\x6f\x64\151\156\147\x3c\x2f\142\x3e\x20\x75\x6e\x64\x65\162\40\x53\145\x72\166\x69\143\x65\x20\x50\x72\157\166\144\145\162\x20\x53\145\164\x75\x70\x20\x74\x61\x62\x2e\x3c\x2f\154\x69\76\15\xa\40\x20\40\40\x20\40\x20\40\40\40\40\x20\x20\40\x20\x20\40\x20\x20\40\40\x20\40\x20\40\x20\x20\40\x3c\57\x6f\154\x3e\xd\xa\40\x20\x20\40\x20\x20\40\40\40\x20\40\x20\x20\x20\x20\40\40\40\x20\x20\40\40\x20\x20\x20\40\x20\40\74\x2f\x64\151\166\x3e\xd\xa\x20\40\40\x20\x20\x20\40\40\40\x20\40\40\x20\40\40\x20\40\40\x20\40\x20\40\x20\x20\74\x64\151\166\x20\x73\164\171\154\x65\x3d\x22\x6d\x61\x72\x67\151\156\x3a\x33\45\73\x64\151\x73\160\154\141\171\72\x62\154\157\143\x6b\x3b\x74\x65\170\x74\55\x61\154\151\x67\x6e\x3a\x63\x65\156\x74\145\x72\x3b\x22\76\xd\xa\40\x20\40\40\x20\40\40\40\40\40\x20\40\x20\x20\x20\40\x20\x20\40\x20\x20\40\40\x20\40\x20\40\40\40\40\x20\40\x3c\x64\151\166\40\163\x74\171\154\145\75\42\155\141\x72\147\x69\156\x3a\x33\x25\x3b\x64\151\x73\160\x6c\141\171\x3a\x62\154\157\x63\153\73\x74\145\x78\x74\x2d\x61\154\x69\x67\156\72\x63\x65\156\x74\145\x72\73\x22\76\x3c\151\156\160\x75\164\40\163\x74\171\x6c\145\x3d\x22\x70\x61\144\x64\151\156\147\x3a\61\45\73\167\x69\144\164\x68\72\61\x30\x30\x70\x78\73\x62\x61\x63\153\147\x72\157\x75\156\x64\72\x20\x23\x30\60\x39\x31\x43\x44\40\156\x6f\156\145\40\162\x65\160\x65\x61\164\40\x73\x63\162\157\x6c\x6c\x20\x30\45\40\60\45\73\x63\x75\162\x73\x6f\x72\x3a\x20\160\157\x69\156\x74\145\162\73\146\157\156\x74\x2d\163\x69\172\145\x3a\61\65\x70\170\73\142\157\162\x64\x65\162\x2d\x77\151\x64\x74\x68\72\40\x31\160\x78\73\142\x6f\162\x64\145\x72\55\163\x74\171\x6c\x65\x3a\40\163\157\x6c\x69\144\x3b\142\157\x72\x64\145\162\55\162\141\144\x69\165\163\72\40\x33\160\x78\73\167\150\151\164\145\55\x73\x70\141\x63\145\x3a\40\156\x6f\167\x72\141\x70\73\x62\157\x78\55\163\151\x7a\x69\x6e\147\x3a\40\x62\x6f\x72\x64\x65\162\x2d\x62\x6f\x78\x3b\x62\157\162\x64\145\162\55\x63\157\154\x6f\x72\x3a\x20\43\60\60\67\x33\101\101\x3b\x62\157\170\55\x73\150\141\144\x6f\x77\x3a\40\60\160\170\40\x31\160\170\40\x30\x70\170\40\162\147\142\141\50\x31\x32\x30\x2c\40\62\60\x30\x2c\40\x32\x33\60\x2c\40\60\x2e\x36\x29\x20\151\x6e\163\x65\164\73\x63\x6f\154\x6f\162\x3a\x20\43\106\x46\x46\73\x22\x74\x79\x70\145\75\x22\x62\x75\x74\164\x6f\156\x22\x20\166\x61\154\165\145\75\x22\x44\x6f\156\145\x22\40\157\x6e\x43\154\x69\143\x6b\x3d\x22\x73\x65\x6c\146\56\143\x6c\157\x73\x65\x28\x29\x3b\x22\x3e\x3c\57\144\151\x76\76";
    mo_saml_download_logs($Pn, $yy);
    exit;
    eYG:
    UMI:
    $B9 = get_site_option("\163\141\x6d\154\x5f\x69\163\163\165\x65\x72");
    $Tc = get_site_option("\x6d\157\137\x73\141\x6d\x6c\137\x73\160\x5f\x65\156\x74\151\x74\x79\x5f\x69\144");
    if (!empty($Tc)) {
        goto Olf;
    }
    $Tc = $E6 . "\x2f\167\x70\55\143\x6f\x6e\164\x65\x6e\164\x2f\160\154\x75\147\x69\156\163\x2f\155\x69\156\x69\x6f\162\141\156\x67\145\55\163\141\x6d\154\55\x32\x30\55\163\x69\156\147\154\145\55\163\151\x67\156\55\157\156\x2f";
    Olf:
    Utilities::validateIssuerAndAudience($KJ, $Tc, $B9, $Rj);
    $fI = current(current($KJ->getAssertions())->getNameId());
    $Te = current($KJ->getAssertions())->getAttributes();
    $Te["\x4e\141\155\x65\111\104"] = array("\x30" => $fI);
    $sL = current($KJ->getAssertions())->getSessionIndex();
    mo_saml_checkMapping($Te, $Rj, $sL);
    goto xyE;
    k3O:
    if (!isset($_REQUEST["\122\x65\x6c\141\171\x53\164\x61\164\145"])) {
        goto qLW;
    }
    $QB = $_REQUEST["\x52\145\x6c\141\171\123\164\x61\164\145"];
    qLW:
    if (!is_user_logged_in()) {
        goto iZ0;
    }
    wp_logout();
    iZ0:
    if (empty($QB)) {
        goto BqB;
    }
    $QB = mo_saml_parse_url($QB);
    goto J1R;
    BqB:
    $QB = $E6;
    J1R:
    header("\114\157\x63\141\x74\x69\x6f\156\72" . $QB);
    exit;
    xyE:
    w11:
    if (!(array_key_exists("\123\101\115\114\122\x65\161\x75\145\163\164", $_REQUEST) && !empty($_REQUEST["\123\x41\x4d\114\122\x65\161\x75\x65\x73\164"]))) {
        goto WUm;
    }
    $ve = $_REQUEST["\x53\x41\115\x4c\122\145\x71\x75\145\x73\164"];
    $Rj = "\x2f";
    if (!array_key_exists("\122\145\154\141\171\123\x74\x61\x74\x65", $_REQUEST)) {
        goto OdG;
    }
    $Rj = $_REQUEST["\122\x65\x6c\x61\x79\x53\164\141\164\145"];
    OdG:
    $ve = base64_decode($ve);
    if (!(array_key_exists("\x53\101\x4d\114\122\145\x71\165\x65\x73\x74", $_GET) && !empty($_GET["\123\x41\115\x4c\x52\x65\161\165\145\x73\x74"]))) {
        goto ema;
    }
    $ve = gzinflate($ve);
    ema:
    $vy = new DOMDocument();
    $vy->loadXML($ve);
    $Kr = $vy->firstChild;
    if (!($Kr->localName == "\114\x6f\x67\x6f\165\x74\x52\145\161\x75\145\x73\164")) {
        goto IIk;
    }
    $JD = new SAML2_LogoutRequest($Kr);
    if (!(!session_id() || session_id() == '' || !isset($_SESSION))) {
        goto QW7;
    }
    session_start();
    QW7:
    $_SESSION["\x6d\x6f\x5f\163\141\155\154\137\154\x6f\x67\157\x75\x74\x5f\162\x65\x71\165\145\x73\164"] = $ve;
    $_SESSION["\x6d\x6f\137\x73\141\155\x6c\x5f\154\x6f\147\x6f\x75\x74\137\x72\145\x6c\x61\x79\x5f\x73\164\141\164\x65"] = $Rj;
    wp_redirect(htmlspecialchars_decode(wp_logout_url()));
    exit;
    IIk:
    WUm:
    if (!(isset($_REQUEST["\157\160\x74\x69\x6f\156"]) and !is_array($_REQUEST["\x6f\160\164\x69\157\x6e"]) and strpos($_REQUEST["\157\x70\x74\x69\157\156"], "\x72\145\141\144\163\x61\155\x6c\154\157\147\x69\x6e") !== false)) {
        goto tQh;
    }
    require_once dirname(__FILE__) . "\x2f\x69\x6e\143\x6c\x75\x64\x65\163\x2f\x6c\151\142\57\145\x6e\143\x72\171\x70\164\x69\x6f\156\56\160\150\160";
    if (isset($_POST["\x53\124\x41\x54\x55\123"]) && $_POST["\123\x54\101\x54\x55\x53"] == "\105\x52\122\x4f\122") {
        goto Shq;
    }
    if (!(isset($_POST["\123\x54\101\x54\x55\123"]) && $_POST["\123\124\101\124\x55\123"] == "\123\125\x43\103\105\x53\x53")) {
        goto Ntq;
    }
    $Uy = '';
    if (!(isset($_REQUEST["\x72\145\x64\151\162\145\x63\x74\137\164\157"]) && !empty($_REQUEST["\x72\x65\144\151\x72\x65\143\x74\x5f\x74\x6f"]) && $_REQUEST["\162\x65\x64\x69\162\x65\143\164\137\164\157"] != "\57")) {
        goto nef;
    }
    $Uy = $_REQUEST["\x72\145\144\x69\x72\x65\x63\x74\x5f\164\157"];
    nef:
    delete_site_option("\155\157\x5f\x73\x61\155\154\137\162\145\x64\x69\162\145\x63\164\137\145\x72\162\x6f\x72\x5f\x63\x6f\x64\x65");
    delete_site_option("\x6d\x6f\137\x73\x61\155\154\x5f\162\145\144\151\x72\x65\x63\164\x5f\x65\162\x72\x6f\162\137\162\145\x61\163\157\156");
    try {
        $Em = get_site_option("\x73\141\155\x6c\x5f\141\x6d\137\145\x6d\x61\x69\x6c");
        $yZ = get_site_option("\163\141\x6d\154\137\141\x6d\x5f\x75\x73\x65\162\x6e\x61\x6d\145");
        $Of = get_site_option("\x73\x61\x6d\x6c\137\141\155\137\x66\151\x72\x73\x74\137\156\x61\155\x65");
        $sK = get_site_option("\x73\141\x6d\x6c\137\x61\155\x5f\x6c\x61\163\x74\137\156\141\155\145");
        $fC = get_site_option("\163\x61\155\154\137\141\x6d\137\147\x72\x6f\x75\160\x5f\156\x61\x6d\145");
        $W5 = get_site_option("\163\141\x6d\154\137\x61\x6d\x5f\144\145\146\x61\165\154\x74\x5f\165\163\x65\162\137\162\157\154\x65");
        $GJ = get_site_option("\163\141\x6d\x6c\137\x61\x6d\137\x64\157\156\164\x5f\x61\154\154\157\167\137\165\156\x6c\x69\x73\164\x65\x64\x5f\165\x73\145\162\137\x72\157\x6c\145");
        $Pr = get_site_option("\163\141\155\x6c\x5f\141\155\137\141\x63\143\x6f\x75\156\x74\137\x6d\141\x74\143\150\x65\x72");
        $rC = '';
        $M0 = '';
        $Of = str_replace("\56", "\137", $Of);
        $Of = str_replace("\x20", "\x5f", $Of);
        if (!(!empty($Of) && array_key_exists($Of, $_POST))) {
            goto v2l;
        }
        $Of = $_POST[$Of];
        v2l:
        $sK = str_replace("\x2e", "\137", $sK);
        $sK = str_replace("\x20", "\x5f", $sK);
        if (!(!empty($sK) && array_key_exists($sK, $_POST))) {
            goto dtk;
        }
        $sK = $_POST[$sK];
        dtk:
        $yZ = str_replace("\x2e", "\x5f", $yZ);
        $yZ = str_replace("\40", "\x5f", $yZ);
        if (!empty($yZ) && array_key_exists($yZ, $_POST)) {
            goto g3e;
        }
        $M0 = $_POST["\116\141\x6d\145\x49\104"];
        goto upx;
        g3e:
        $M0 = $_POST[$yZ];
        upx:
        $rC = str_replace("\56", "\137", $Em);
        $rC = str_replace("\40", "\x5f", $Em);
        if (!empty($Em) && array_key_exists($Em, $_POST)) {
            goto AIV;
        }
        $rC = $_POST["\x4e\141\x6d\x65\111\104"];
        goto dVL;
        AIV:
        $rC = $_POST[$Em];
        dVL:
        $fC = str_replace("\x2e", "\x5f", $fC);
        $fC = str_replace("\40", "\x5f", $fC);
        if (!(!empty($fC) && array_key_exists($fC, $_POST))) {
            goto qBv;
        }
        $fC = $_POST[$fC];
        qBv:
        if (!empty($Pr)) {
            goto pwR;
        }
        $Pr = "\x65\x6d\141\151\154";
        pwR:
        $a5 = get_site_option("\x6d\157\x5f\x73\x61\x6d\154\x5f\x63\x75\163\164\x6f\x6d\x65\162\x5f\164\x6f\x6b\x65\156");
        if (!(isset($a5) || trim($a5) != '')) {
            goto lMW;
        }
        $Cs = AESEncryption::decrypt_data($rC, $a5);
        $rC = $Cs;
        lMW:
        if (!(!empty($Of) && !empty($a5))) {
            goto GCH;
        }
        $F2 = AESEncryption::decrypt_data($Of, $a5);
        $Of = $F2;
        GCH:
        if (!(!empty($sK) && !empty($a5))) {
            goto h2Q;
        }
        $gY = AESEncryption::decrypt_data($sK, $a5);
        $sK = $gY;
        h2Q:
        if (!(!empty($M0) && !empty($a5))) {
            goto tTt;
        }
        $HW = AESEncryption::decrypt_data($M0, $a5);
        $M0 = $HW;
        tTt:
        if (!(!empty($fC) && !empty($a5))) {
            goto XV3;
        }
        $Q3 = AESEncryption::decrypt_data($fC, $a5);
        $fC = $Q3;
        XV3:
    } catch (Exception $jB) {
        echo sprintf("\x41\x6e\x20\145\162\x72\157\x72\40\157\143\x63\165\x72\162\145\x64\40\167\x68\151\154\x65\40\x70\x72\x6f\143\x65\163\x73\x69\156\x67\x20\x74\150\145\40\123\x41\115\114\40\x52\145\x73\x70\x6f\156\163\x65\56");
        exit;
    }
    $VD = array($fC);
    mo_saml_login_user($rC, $Of, $sK, $M0, $VD, $GJ, $W5, $Uy, $Pr);
    Ntq:
    goto erl;
    Shq:
    update_site_option("\x6d\157\x5f\163\x61\155\154\137\x72\145\144\x69\x72\x65\143\x74\x5f\x65\162\162\x6f\x72\x5f\143\x6f\x64\145", $_POST["\x45\x52\x52\117\122\x5f\122\x45\x41\x53\117\116"]);
    update_site_option("\155\x6f\137\163\141\x6d\154\137\x72\x65\144\x69\162\145\x63\x74\x5f\x65\162\x72\x6f\x72\x5f\162\x65\x61\x73\157\x6e", $_POST["\x45\122\x52\x4f\x52\x5f\115\105\123\123\101\107\105"]);
    erl:
    tQh:
    Z9E:
}
function mo_saml_relaystate_url($Rj)
{
    $HP = parse_url($Rj, PHP_URL_SCHEME);
    $Rj = str_replace($HP . "\72\x2f\57", '', $Rj);
    return $Rj;
}
function mo_saml_hash_relaystate($Rj)
{
    $HP = parse_url($Rj, PHP_URL_SCHEME);
    $Rj = str_replace($HP . "\72\x2f\x2f", '', $Rj);
    $Rj = base64_encode($Rj);
    $MS = cdjsurkhh($Rj);
    $Rj = $Rj . "\56" . $MS;
    return $Rj;
}
function mo_saml_get_relaystate($Rj)
{
    if (!filter_var($Rj, FILTER_VALIDATE_URL)) {
        goto oHO;
    }
    return $Rj;
    oHO:
    $F8 = strpos($Rj, "\56");
    if ($F8) {
        goto VPR;
    }
    wp_die("\x41\156\40\x65\x72\x72\157\x72\x20\x6f\143\x63\x75\x72\145\x64\56\x20\120\154\x65\x61\163\145\x20\x63\157\156\164\x61\143\164\40\x79\157\x75\162\x20\x61\x64\x6d\151\156\x69\x73\164\x72\x61\164\x6f\x72\56", "\105\162\162\x6f\162\x20\x3a\40\116\x6f\164\x20\141\x20\164\162\165\x73\x74\x65\x64\40\x73\x6f\x75\162\x63\x65\x20\x6f\x66\40\x74\x68\145\x20\123\101\x4d\x4c\40\x72\x65\163\x70\x6f\156\x73\x65");
    exit;
    VPR:
    $QB = substr($Rj, 0, $F8);
    $WS = substr($Rj, $F8 + 1);
    $XK = cdjsurkhh($QB);
    if (!($WS !== $XK)) {
        goto E5n;
    }
    wp_die("\101\156\x20\x65\x72\162\157\x72\40\x6f\143\143\x75\x72\145\144\56\40\x50\x6c\145\x61\163\x65\x20\143\x6f\x6e\164\x61\x63\164\40\171\x6f\x75\162\40\141\x64\155\x69\x6e\x69\x73\164\x72\x61\164\x6f\x72\56", "\105\162\x72\157\162\40\x3a\x20\x4e\x6f\164\40\x61\40\164\x72\x75\163\x74\x65\144\x20\x73\157\165\162\x63\145\x20\157\146\40\164\150\145\40\123\101\115\114\40\162\145\x73\x70\x6f\x6e\163\x65");
    exit;
    E5n:
    $QB = base64_decode($QB);
    return $QB;
}
function cdjsurkhh($YN)
{
    $MS = hash("\163\x68\141\65\61\62", $YN);
    $EU = substr($MS, 7, 14);
    return $EU;
}
function mo_saml_parse_url($Rj)
{
    if (!($Rj != "\164\x65\163\164\126\x61\x6c\x69\x64\x61\x74\145" && $Rj != "\164\145\163\164\116\145\167\x43\x65\162\164\151\146\x69\143\x61\164\x65")) {
        goto guf;
    }
    $E6 = get_site_option("\x6d\157\x5f\x73\x61\155\x6c\137\163\160\x5f\x62\x61\163\145\137\165\x72\154");
    if (!empty($E6)) {
        goto zu0;
    }
    $E6 = get_network_site_url();
    zu0:
    $HP = parse_url($E6, PHP_URL_SCHEME);
    if (filter_var($Rj, FILTER_VALIDATE_URL)) {
        goto DEC;
    }
    $Rj = $HP . "\x3a\x2f\x2f" . $Rj;
    DEC:
    guf:
    return $Rj;
}
function mo_saml_is_subsite($Rj)
{
    $aV = parse_url($Rj, PHP_URL_HOST);
    $j_ = parse_url($Rj, PHP_URL_PATH);
    if (is_subdomain_install()) {
        goto mFL;
    }
    $ov = strpos($j_, "\x2f", 1) != false ? strpos($j_, "\57", 1) : strlen($j_) - 1;
    $j_ = substr($j_, 0, $ov + 1);
    $blog_id = get_blog_id_from_url($aV, $j_);
    goto yRs;
    mFL:
    $blog_id = get_blog_id_from_url($aV);
    yRs:
    if ($blog_id !== 0) {
        goto BRr;
    }
    return false;
    goto qGo;
    BRr:
    return true;
    qGo:
}
function mo_saml_show_SAML_log($Kr, $AG)
{
    header("\x43\157\156\x74\x65\156\x74\x2d\x54\x79\x70\145\x3a\x20\x74\x65\170\x74\57\150\x74\x6d\x6c");
    $Pj = new DOMDocument();
    $Pj->preserveWhiteSpace = false;
    $Pj->formatOutput = true;
    $Pj->loadXML($Kr);
    if ($AG == "\144\151\163\160\x6c\x61\x79\x53\x41\115\114\x52\x65\x71\x75\x65\x73\164") {
        goto KgG;
    }
    $Xz = "\123\101\115\x4c\x20\x52\145\163\x70\x6f\156\x73\x65";
    goto K_f;
    KgG:
    $Xz = "\123\x41\x4d\114\x20\x52\145\161\165\145\163\x74";
    K_f:
    $vw = $Pj->saveXML();
    $SY = htmlentities($vw);
    $SY = rtrim($SY);
    $Th = simplexml_load_string($vw);
    $ba = json_encode($Th);
    $nw = json_decode($ba);
    $GR = plugins_url("\x69\156\x63\154\165\144\145\x73\57\143\x73\x73\57\x73\164\x79\x6c\x65\137\163\x65\164\x74\x69\x6e\x67\163\x2e\143\163\163\77\x76\145\162\x3d\x34\x2e\x38\x2e\64\60", __FILE__);
    echo "\x3c\x6c\151\156\153\x20\162\x65\154\x3d\47\x73\164\x79\x6c\145\163\x68\x65\145\164\47\40\151\144\x3d\x27\x6d\x6f\137\163\x61\155\154\x5f\141\x64\x6d\151\x6e\x5f\x73\x65\164\164\x69\156\147\x73\137\x73\164\171\154\x65\55\x63\x73\x73\47\40\40\x68\x72\x65\x66\x3d\x27" . $GR . "\x27\40\164\x79\160\x65\x3d\47\x74\145\x78\x74\x2f\x63\163\163\x27\40\x6d\145\x64\151\x61\x3d\x27\141\x6c\154\47\40\57\76\xd\xa\xd\12\x3c\144\151\x76\40\143\x6c\x61\x73\x73\75\42\155\157\x2d\x64\x69\163\x70\154\141\x79\55\x6c\x6f\x67\x73\42\x20\76\x3c\160\40\x74\x79\160\x65\x3d\x22\164\145\x78\x74\x22\x20\40\40\x69\x64\75\x22\123\101\x4d\x4c\137\164\x79\x70\x65\x22\x3e" . $Xz . "\x3c\57\x70\76\74\x2f\144\151\166\x3e\xd\12\xd\xa\x3c\144\x69\x76\40\164\171\x70\x65\75\42\164\145\x78\x74\42\40\x69\x64\75\42\123\x41\115\114\137\x64\x69\x73\160\154\141\171\42\40\x63\x6c\x61\163\x73\75\x22\155\157\x2d\144\x69\163\x70\154\x61\171\x2d\x62\x6c\x6f\143\153\x22\x3e\74\x70\x72\145\x20\x63\154\x61\x73\x73\75\47\x62\162\165\x73\150\72\40\x78\155\x6c\x3b\x27\x3e" . $SY . "\74\57\160\162\145\76\74\57\x64\x69\x76\76\15\xa\74\142\162\x3e\15\12\74\x64\x69\x76\x9\x20\x73\164\171\x6c\145\x3d\42\x6d\141\162\x67\x69\x6e\x3a\63\45\x3b\144\x69\163\160\x6c\x61\x79\72\x62\x6c\157\143\x6b\73\x74\x65\x78\x74\55\141\154\x69\x67\156\x3a\x63\x65\156\x74\x65\162\x3b\x22\76\15\12\xd\xa\x3c\144\x69\x76\x20\x73\x74\171\154\x65\x3d\x22\155\141\162\147\151\x6e\x3a\63\45\x3b\144\151\x73\x70\154\x61\171\x3a\x62\154\157\143\x6b\x3b\164\145\170\x74\x2d\x61\154\151\x67\x6e\x3a\x63\145\156\164\x65\162\x3b\42\x20\x3e\15\12\xd\12\x3c\x2f\x64\x69\x76\76\15\xa\74\x62\165\164\x74\157\156\40\x69\x64\75\42\143\157\160\171\42\40\x6f\x6e\x63\x6c\151\x63\153\75\x22\x63\157\160\x79\104\151\166\124\x6f\x43\154\x69\160\142\157\141\x72\x64\50\x29\x22\x20\40\x73\164\171\x6c\x65\75\42\160\x61\x64\x64\x69\156\147\x3a\61\x25\73\x77\x69\x64\164\150\72\x31\x30\x30\x70\170\x3b\142\x61\x63\x6b\x67\162\x6f\x75\156\x64\72\x20\43\x30\x30\x39\x31\x43\x44\x20\x6e\x6f\156\145\40\x72\x65\160\x65\141\x74\40\x73\143\162\x6f\x6c\154\40\x30\45\x20\x30\x25\x3b\x63\165\x72\163\157\x72\x3a\x20\160\x6f\151\156\x74\145\x72\x3b\146\157\x6e\x74\x2d\x73\x69\172\145\x3a\x31\x35\x70\x78\73\x62\x6f\x72\x64\145\x72\x2d\167\151\144\164\x68\x3a\x20\61\x70\170\73\142\x6f\162\x64\x65\x72\x2d\163\164\171\x6c\x65\x3a\40\163\157\154\x69\144\x3b\142\x6f\x72\144\x65\x72\x2d\x72\x61\144\x69\x75\163\72\x20\63\x70\170\x3b\167\x68\151\x74\145\55\163\x70\x61\143\x65\x3a\40\x6e\x6f\167\162\x61\160\x3b\x62\157\170\55\x73\x69\x7a\x69\156\147\72\40\142\x6f\162\x64\145\x72\55\142\157\x78\x3b\142\x6f\x72\144\145\x72\x2d\x63\157\x6c\x6f\x72\72\40\x23\60\x30\67\63\101\101\x3b\x62\157\x78\55\x73\x68\141\144\157\167\72\x20\x30\160\x78\40\61\x70\x78\x20\x30\160\x78\x20\162\147\142\x61\50\61\x32\60\x2c\x20\x32\60\60\x2c\x20\62\63\x30\x2c\40\x30\x2e\x36\x29\x20\x69\156\x73\145\x74\x3b\143\157\154\157\x72\x3a\x20\43\x46\106\x46\x3b\x22\x20\x3e\103\157\160\x79\x3c\57\x62\165\x74\164\x6f\156\x3e\xd\12\46\x6e\x62\x73\160\73\xd\xa\74\x69\x6e\160\165\x74\40\x69\144\75\x22\x64\167\156\x2d\x62\164\156\42\40\163\x74\x79\x6c\145\x3d\x22\x70\x61\144\144\151\x6e\147\72\61\x25\x3b\167\151\144\x74\150\x3a\61\60\60\x70\170\x3b\x62\141\143\153\147\162\x6f\165\156\x64\x3a\40\43\x30\x30\71\x31\103\x44\x20\156\x6f\x6e\x65\x20\162\x65\160\x65\x61\164\x20\x73\x63\162\157\x6c\154\x20\x30\x25\x20\x30\x25\x3b\x63\165\162\x73\157\162\72\x20\x70\x6f\151\156\164\145\x72\x3b\x66\x6f\x6e\164\x2d\x73\151\172\x65\72\x31\x35\160\170\73\142\157\x72\144\145\162\55\x77\151\144\164\x68\72\40\x31\x70\170\x3b\x62\157\x72\144\145\162\x2d\x73\164\x79\x6c\x65\x3a\x20\163\x6f\154\x69\144\x3b\142\157\162\x64\x65\x72\x2d\x72\x61\144\x69\x75\x73\x3a\40\x33\x70\170\x3b\167\x68\151\x74\145\55\163\160\141\x63\x65\x3a\40\x6e\157\x77\162\141\x70\73\x62\x6f\170\55\x73\x69\x7a\151\156\147\72\40\142\x6f\162\144\145\x72\55\142\x6f\x78\73\142\x6f\x72\144\145\162\x2d\143\x6f\x6c\x6f\x72\72\x20\x23\x30\60\67\x33\x41\101\x3b\142\157\170\x2d\x73\x68\141\144\157\167\72\40\x30\x70\170\x20\61\160\170\x20\x30\160\170\40\162\x67\x62\x61\x28\x31\x32\x30\x2c\x20\x32\x30\60\54\x20\x32\x33\x30\x2c\40\x30\x2e\66\51\40\x69\x6e\x73\145\164\73\143\157\x6c\x6f\x72\72\x20\x23\x46\106\x46\x3b\42\164\171\160\145\75\42\x62\165\x74\164\x6f\156\42\x20\166\x61\154\165\145\75\42\104\x6f\167\x6e\154\157\x61\x64\x22\40\15\xa\x22\x3e\xd\xa\74\57\144\151\166\x3e\15\xa\74\57\144\151\166\x3e\15\12\15\12\15\12";
    ob_end_flush();
    echo "\15\12\74\x73\x63\162\151\160\x74\76\xd\xa\15\xa\x66\x75\x6e\143\x74\x69\157\156\40\143\157\160\171\x44\x69\x76\124\x6f\x43\154\x69\x70\142\x6f\141\162\144\50\x29\40\173\15\12\166\x61\162\x20\x61\165\170\x20\75\x20\x64\x6f\143\165\155\145\156\x74\56\x63\162\145\141\164\x65\x45\x6c\x65\155\145\156\164\x28\42\x69\x6e\160\165\164\x22\x29\x3b\xd\xa\141\165\x78\x2e\x73\x65\164\x41\164\x74\162\x69\x62\x75\x74\x65\x28\x22\x76\141\154\x75\x65\x22\54\40\x64\157\x63\165\155\x65\x6e\x74\x2e\147\145\x74\105\154\145\155\x65\156\164\102\171\111\144\50\x22\123\x41\x4d\x4c\137\x64\x69\x73\x70\154\141\171\42\x29\56\164\145\170\164\x43\157\156\x74\145\x6e\x74\51\x3b\xd\12\144\157\143\x75\155\x65\156\164\56\142\157\144\x79\x2e\x61\160\x70\145\156\x64\103\x68\151\x6c\x64\x28\x61\165\170\x29\x3b\15\xa\141\165\170\x2e\x73\x65\x6c\145\x63\x74\x28\x29\73\15\xa\x64\157\143\165\155\x65\x6e\164\56\145\x78\x65\143\103\157\155\x6d\x61\156\144\x28\x22\x63\157\x70\171\x22\x29\x3b\15\xa\144\157\143\165\155\x65\x6e\164\x2e\x62\x6f\x64\171\56\x72\145\155\157\x76\145\103\x68\151\x6c\x64\50\141\165\x78\x29\x3b\xd\xa\144\157\x63\x75\155\145\x6e\164\56\x67\x65\x74\105\x6c\x65\155\x65\156\164\102\x79\x49\144\50\47\143\157\x70\x79\x27\51\x2e\164\145\x78\x74\x43\157\x6e\164\145\x6e\x74\x20\75\40\42\x43\157\x70\151\145\144\42\73\15\12\x64\x6f\x63\165\x6d\x65\156\x74\x2e\147\145\164\105\154\145\x6d\145\156\x74\102\x79\111\144\x28\x27\x63\x6f\160\171\x27\51\x2e\x73\x74\x79\154\x65\x2e\x62\141\143\153\147\x72\x6f\165\x6e\x64\x20\75\x20\42\147\162\145\x79\42\73\xd\xa\x77\x69\x6e\144\x6f\167\x2e\147\145\164\123\145\154\145\143\x74\x69\157\x6e\x28\x29\x2e\163\145\154\145\143\x74\x41\x6c\x6c\103\150\151\154\144\162\x65\x6e\x28\x20\x64\x6f\x63\x75\155\x65\156\164\x2e\147\145\x74\x45\x6c\x65\155\x65\156\164\x42\171\111\x64\x28\x20\42\x53\101\x4d\x4c\x5f\144\151\x73\x70\154\x61\171\42\40\51\x20\51\73\xd\xa\15\xa\175\15\xa\xd\xa\x66\165\x6e\143\164\151\157\156\40\x64\x6f\167\x6e\x6c\157\x61\x64\50\x66\151\154\x65\156\141\155\145\54\40\164\145\x78\164\x29\x20\x7b\15\xa\x76\141\162\x20\x65\x6c\145\155\x65\156\x74\40\75\40\144\157\143\x75\155\145\156\x74\x2e\143\x72\145\x61\x74\145\x45\154\x65\155\x65\x6e\x74\x28\x27\141\47\x29\x3b\15\xa\145\x6c\x65\155\x65\156\x74\56\x73\x65\x74\x41\x74\164\x72\x69\x62\x75\164\x65\50\47\x68\x72\145\146\47\54\x20\x27\144\141\x74\x61\72\x41\x70\x70\x6c\x69\x63\x61\x74\151\157\156\57\x6f\143\164\x65\164\x2d\x73\x74\162\145\141\155\x3b\143\x68\x61\162\x73\145\164\75\165\164\146\x2d\x38\x2c\x27\40\x2b\x20\145\156\143\157\144\x65\125\122\111\103\157\x6d\160\157\x6e\145\156\164\50\164\145\x78\164\51\51\73\xd\xa\145\154\145\155\145\x6e\164\x2e\163\145\x74\101\164\x74\162\151\142\x75\164\145\50\x27\x64\157\x77\156\154\x6f\x61\144\47\54\x20\146\x69\154\x65\x6e\141\x6d\145\x29\x3b\15\xa\xd\12\x65\154\145\155\145\156\164\x2e\163\164\171\154\145\56\x64\151\163\x70\154\x61\x79\40\x3d\40\x27\156\157\x6e\x65\47\73\15\12\144\x6f\x63\x75\x6d\145\156\x74\56\142\x6f\144\171\x2e\x61\160\160\x65\x6e\144\x43\150\x69\x6c\x64\x28\x65\154\x65\x6d\145\x6e\164\51\73\xd\12\xd\12\145\154\x65\155\145\x6e\x74\x2e\143\x6c\x69\143\153\50\x29\73\xd\xa\15\xa\x64\x6f\x63\165\155\x65\156\164\x2e\x62\x6f\x64\171\56\162\145\x6d\x6f\166\x65\x43\150\151\x6c\144\50\145\154\x65\155\145\156\x74\51\73\xd\12\175\15\xa\xd\xa\144\x6f\143\x75\x6d\x65\x6e\x74\x2e\x67\145\x74\x45\154\x65\x6d\145\156\x74\102\171\x49\x64\50\42\x64\x77\156\x2d\x62\164\156\42\x29\x2e\x61\x64\144\105\166\145\156\164\114\x69\x73\x74\x65\x6e\x65\162\50\x22\x63\154\151\143\153\x22\54\x20\146\165\x6e\x63\164\151\x6f\x6e\40\50\x29\x20\173\15\xa\15\12\x76\x61\162\x20\146\151\154\x65\x6e\x61\x6d\145\40\x3d\40\144\157\x63\x75\x6d\145\156\164\56\147\x65\164\105\x6c\145\x6d\x65\156\164\102\x79\x49\144\x28\42\x53\x41\115\x4c\137\164\171\x70\x65\x22\51\x2e\x74\145\x78\x74\x43\x6f\156\164\x65\x6e\164\x2b\42\x2e\x78\x6d\154\42\x3b\xd\12\166\x61\x72\x20\x6e\x6f\144\x65\40\75\40\144\x6f\x63\165\155\x65\156\x74\56\x67\x65\x74\105\154\145\x6d\x65\x6e\164\x42\171\x49\144\50\42\x53\x41\115\x4c\x5f\x64\x69\163\160\x6c\x61\x79\42\51\x3b\xd\xa\x68\x74\155\x6c\x43\x6f\x6e\x74\x65\x6e\x74\x20\75\x20\x6e\x6f\144\145\x2e\x69\156\156\x65\162\110\x54\x4d\x4c\73\xd\xa\164\x65\170\x74\40\x3d\40\x6e\157\x64\145\x2e\x74\x65\x78\x74\x43\x6f\x6e\x74\x65\x6e\x74\73\xd\xa\x64\157\x77\x6e\154\x6f\141\x64\50\x66\x69\x6c\x65\x6e\141\155\x65\x2c\40\x74\145\x78\164\x29\73\15\12\x7d\x2c\40\146\141\154\163\145\51\73\xd\12\xd\xa\xd\12\15\xa\xd\12\xd\xa\x3c\x2f\x73\x63\x72\x69\x70\164\76\15\12";
    exit;
}
function mo_saml_checkMapping($Te, $Rj, $sL)
{
    try {
        $Em = get_site_option("\x73\x61\x6d\154\x5f\x61\155\x5f\x65\155\x61\151\x6c");
        $yZ = get_site_option("\x73\141\x6d\154\x5f\x61\x6d\x5f\x75\x73\x65\x72\156\141\x6d\145");
        $Of = get_site_option("\163\141\155\x6c\x5f\141\x6d\137\146\151\162\x73\x74\x5f\156\141\x6d\x65");
        $sK = get_site_option("\163\141\155\x6c\x5f\x61\155\137\x6c\x61\163\164\137\156\x61\x6d\x65");
        $fC = get_site_option("\163\x61\x6d\154\137\x61\x6d\x5f\147\x72\157\x75\x70\x5f\156\141\155\145");
        $AL = array();
        $AL = maybe_unserialize(get_site_option("\163\141\x6d\154\x5f\141\x6d\x5f\x72\x6f\154\145\137\155\141\160\160\x69\x6e\147"));
        $Pr = get_site_option("\163\x61\155\x6c\137\x61\155\137\x61\143\x63\157\x75\156\164\x5f\155\x61\164\143\150\145\162");
        $rC = '';
        $M0 = '';
        if (empty($Te)) {
            goto Tjm;
        }
        if (!empty($Of) && array_key_exists($Of, $Te)) {
            goto P_V;
        }
        $Of = '';
        goto NGQ;
        P_V:
        $Of = $Te[$Of][0];
        NGQ:
        if (!empty($sK) && array_key_exists($sK, $Te)) {
            goto O_o;
        }
        $sK = '';
        goto P2q;
        O_o:
        $sK = $Te[$sK][0];
        P2q:
        if (!empty($yZ) && array_key_exists($yZ, $Te)) {
            goto Gal;
        }
        $M0 = $Te["\116\x61\x6d\145\111\104"][0];
        goto M8S;
        Gal:
        $M0 = $Te[$yZ][0];
        M8S:
        if (!empty($Em) && array_key_exists($Em, $Te)) {
            goto WJN;
        }
        $rC = $Te["\x4e\141\x6d\x65\x49\x44"][0];
        goto xqF;
        WJN:
        $rC = $Te[$Em][0];
        xqF:
        if (!empty($fC) && array_key_exists($fC, $Te)) {
            goto ez5;
        }
        $fC = array();
        goto EQu;
        ez5:
        $fC = $Te[$fC];
        EQu:
        if (!empty($Pr)) {
            goto Tk8;
        }
        $Pr = "\x65\x6d\141\151\x6c";
        Tk8:
        Tjm:
        if ($Rj == "\x74\145\163\x74\126\141\x6c\x69\x64\x61\x74\145") {
            goto uBu;
        }
        if ($Rj == "\x74\145\163\x74\x4e\145\167\x43\x65\x72\164\x69\x66\x69\x63\141\164\x65") {
            goto jDb;
        }
        mo_saml_login_user($rC, $Of, $sK, $M0, $fC, $AL, $Rj, $Pr, $sL, $Te["\x4e\141\x6d\x65\111\x44"][0], $Te);
        goto j81;
        uBu:
        update_site_option("\x6d\x6f\x5f\x73\x61\x6d\x6c\x5f\164\x65\x73\164", "\x54\145\163\x74\40\x53\x75\143\143\145\x73\163\146\165\x6c");
        mo_saml_show_test_result($Of, $sK, $rC, $fC, $Te, $Rj);
        goto j81;
        jDb:
        update_site_option("\x6d\x6f\137\x73\x61\x6d\x6c\137\164\145\163\164\x5f\156\x65\167\137\143\145\x72\x74", "\x54\x65\163\x74\40\x73\165\143\x63\145\163\x73\146\165\x6c");
        mo_saml_show_test_result($Of, $sK, $rC, $fC, $Te, $Rj);
        j81:
    } catch (Exception $jB) {
        echo sprintf("\101\x6e\40\x65\162\x72\157\162\40\x6f\x63\143\165\162\x72\x65\x64\40\167\150\151\x6c\x65\x20\160\x72\x6f\x63\145\163\163\151\156\x67\x20\164\x68\x65\40\x53\101\115\114\x20\122\145\163\160\x6f\x6e\163\145\x2e");
        exit;
    }
}
function mo_saml_show_test_result($Of, $sK, $rC, $fC, $Te, $Rj)
{
    echo "\74\x64\151\x76\40\x73\x74\x79\154\x65\75\x22\146\x6f\x6e\x74\55\x66\x61\x6d\151\x6c\171\x3a\x43\x61\x6c\151\142\x72\151\x3b\160\141\144\x64\151\x6e\x67\x3a\60\40\63\x25\73\42\x3e";
    if (!empty($rC)) {
        goto XuD;
    }
    echo "\x3c\144\x69\166\x20\x73\164\x79\154\145\x3d\42\x63\x6f\154\157\162\x3a\40\x23\141\71\64\x34\64\62\x3b\142\x61\143\x6b\147\162\157\x75\156\x64\x2d\x63\x6f\154\x6f\x72\72\40\43\146\x32\144\x65\144\x65\73\x70\141\144\x64\151\156\x67\x3a\40\x31\65\160\170\x3b\155\x61\162\147\151\x6e\55\142\x6f\164\164\x6f\x6d\72\x20\62\60\160\170\73\x74\x65\x78\x74\x2d\141\154\151\x67\156\72\143\x65\156\164\145\162\73\x62\x6f\x72\144\x65\162\72\x31\160\x78\40\x73\157\154\151\144\40\x23\x45\x36\x42\x33\x42\62\x3b\x66\x6f\x6e\164\55\163\x69\172\145\x3a\x31\x38\x70\164\x3b\x22\76\x54\105\x53\x54\x20\x46\101\x49\x4c\105\x44\74\x2f\x64\x69\x76\76\xd\12\40\x20\40\40\40\x20\40\x20\x3c\x64\151\x76\40\163\164\171\x6c\145\75\42\143\x6f\154\x6f\162\x3a\x20\43\x61\x39\x34\64\64\62\x3b\x66\x6f\x6e\x74\55\x73\151\x7a\x65\72\61\64\160\x74\73\40\155\141\x72\147\x69\x6e\55\x62\157\164\164\x6f\155\x3a\x32\x30\160\170\73\x22\76\x57\x41\122\116\111\x4e\107\x3a\x20\x53\157\x6d\x65\40\101\x74\x74\162\x69\142\165\164\x65\163\40\104\151\x64\40\x4e\x6f\x74\x20\x4d\141\x74\143\x68\x2e\x3c\x2f\144\151\x76\x3e\15\xa\x20\x20\x20\40\x20\40\40\40\74\144\151\166\x20\163\x74\x79\x6c\145\x3d\x22\144\151\163\x70\x6c\x61\171\72\142\154\157\x63\153\73\x74\145\x78\x74\x2d\141\154\151\147\156\72\x63\x65\156\164\x65\162\x3b\155\141\x72\x67\151\156\55\x62\x6f\164\x74\157\x6d\72\64\45\x3b\x22\x3e\74\151\x6d\x67\x20\163\164\x79\154\x65\x3d\42\167\x69\144\x74\150\x3a\61\x35\45\x3b\x22\x73\162\143\x3d\x22" . plugin_dir_url(__FILE__) . "\151\x6d\141\x67\x65\163\x2f\167\x72\x6f\156\147\56\160\156\x67\x22\x3e\74\x2f\x64\151\x76\x3e";
    goto fjb;
    XuD:
    update_site_option("\155\157\x5f\x73\141\155\x6c\x5f\164\145\x73\164\x5f\x63\x6f\156\146\x69\x67\137\141\x74\x74\x72\x73", $Te);
    echo "\x3c\144\151\166\x20\x73\164\171\x6c\x65\x3d\x22\x63\x6f\154\x6f\162\x3a\40\43\63\143\67\x36\x33\144\x3b\15\12\40\x20\x20\40\x20\x20\x20\40\x62\141\143\x6b\147\x72\x6f\165\x6e\x64\x2d\x63\x6f\x6c\157\x72\x3a\x20\43\144\146\x66\60\144\70\73\40\x70\141\x64\144\151\x6e\x67\72\x32\x25\x3b\x6d\x61\162\x67\x69\x6e\55\x62\x6f\x74\x74\x6f\x6d\x3a\x32\x30\160\x78\x3b\x74\145\170\164\55\141\154\151\x67\x6e\72\143\145\x6e\164\x65\x72\x3b\40\142\x6f\162\144\145\162\x3a\61\160\x78\40\x73\157\154\151\144\40\x23\101\x45\104\102\x39\x41\73\40\x66\x6f\156\164\x2d\163\151\172\145\72\61\70\160\x74\73\42\x3e\x54\105\x53\x54\x20\x53\125\103\103\105\123\x53\106\x55\x4c\74\x2f\144\151\166\x3e\xd\xa\x20\40\40\x20\40\x20\40\40\x3c\x64\x69\166\40\163\x74\x79\x6c\145\75\x22\144\151\163\x70\154\141\x79\x3a\142\x6c\x6f\143\153\x3b\x74\x65\170\x74\55\x61\x6c\151\x67\156\x3a\143\x65\x6e\x74\x65\x72\73\155\x61\162\147\151\156\55\142\157\164\x74\x6f\155\72\64\45\73\x22\x3e\74\x69\x6d\x67\40\x73\x74\171\154\x65\x3d\42\167\151\144\x74\x68\72\x31\x35\x25\x3b\42\x73\162\143\x3d\42" . plugin_dir_url(__FILE__) . "\151\x6d\x61\147\x65\x73\x2f\147\x72\145\145\x6e\137\x63\150\x65\143\153\56\x70\156\x67\x22\76\x3c\x2f\144\x69\166\x3e";
    fjb:
    $G4 = $Rj == "\x74\x65\x73\x74\116\x65\x77\103\145\162\x74\151\146\151\x63\141\x74\x65" ? "\144\x69\163\x70\154\141\171\x3a\x6e\157\156\x65" : '';
    $dn = get_site_option("\163\x61\x6d\154\137\x61\x6d\137\141\x63\x63\x6f\x75\x6e\x74\137\155\x61\x74\x63\150\145\x72") ? get_site_option("\163\141\155\154\x5f\x61\155\x5f\x61\x63\x63\x6f\165\x6e\x74\137\155\x61\x74\x63\150\x65\x72") : "\145\155\x61\x69\154";
    if (!($dn == "\145\x6d\x61\x69\154" && !filter_var($Te["\116\141\155\x65\x49\x44"][0], FILTER_VALIDATE_EMAIL))) {
        goto QKF;
    }
    echo "\74\160\x3e\x3c\146\x6f\x6e\x74\40\x63\157\154\x6f\162\x3d\x22\43\x46\x46\x30\60\x30\x30\x22\x20\163\x74\x79\154\x65\x3d\x22\x66\x6f\156\x74\x2d\163\151\172\x65\72\x31\x34\160\164\42\x3e\50\x57\x61\x72\156\151\x6e\x67\72\x20\x54\x68\x65\x20\x4e\x61\x6d\145\111\x44\40\x76\141\154\x75\x65\x20\x69\163\40\156\x6f\164\40\141\40\166\x61\x6c\x69\144\x20\x45\x6d\141\x69\154\x20\x49\104\51\x3c\57\146\157\156\164\76\74\x2f\160\x3e";
    QKF:
    echo "\74\163\x70\x61\x6e\40\163\164\171\154\145\x3d\42\146\157\156\x74\55\x73\x69\172\x65\72\61\x34\x70\x74\73\x22\x3e\x3c\x62\76\110\x65\154\154\157\74\x2f\x62\x3e\x2c\x20" . $rC . "\x3c\57\163\x70\x61\156\x3e\x3c\x62\162\57\x3e\74\x70\x20\x73\x74\171\154\145\75\x22\146\x6f\x6e\x74\55\x77\x65\151\x67\x68\x74\x3a\142\x6f\154\x64\x3b\146\157\156\x74\x2d\x73\151\x7a\145\x3a\x31\x34\160\164\x3b\x6d\141\x72\147\x69\x6e\x2d\x6c\145\x66\164\x3a\x31\45\73\42\76\x41\x54\124\122\x49\102\x55\x54\105\123\40\122\x45\x43\x45\x49\x56\105\x44\72\74\x2f\x70\x3e\15\12\40\x20\40\40\74\x74\x61\x62\x6c\x65\40\163\x74\x79\154\145\x3d\42\x62\157\162\144\145\162\55\x63\157\154\x6c\141\x70\163\x65\72\x63\x6f\154\x6c\x61\x70\x73\x65\x3b\142\157\162\144\x65\162\x2d\x73\x70\141\143\151\x6e\147\x3a\x30\x3b\x20\x64\x69\x73\160\x6c\x61\x79\x3a\164\141\142\x6c\x65\73\167\x69\144\x74\x68\72\x31\x30\x30\45\73\40\x66\x6f\x6e\x74\x2d\x73\151\x7a\x65\x3a\61\x34\x70\164\x3b\x62\x61\143\x6b\x67\x72\157\165\156\x64\x2d\143\157\154\157\x72\72\43\x45\104\105\104\105\x44\x3b\42\x3e\15\xa\x20\x20\40\40\x20\40\x20\40\x3c\x74\162\40\163\164\171\154\x65\75\42\164\x65\170\x74\55\141\x6c\151\147\156\x3a\x63\145\x6e\164\145\x72\73\42\x3e\74\x74\x64\x20\163\x74\x79\154\145\x3d\42\x66\157\x6e\164\55\167\145\151\x67\150\164\72\x62\157\x6c\144\x3b\x62\157\x72\144\x65\162\x3a\x32\160\170\40\163\157\154\151\x64\x20\x23\71\x34\x39\60\71\60\x3b\x70\141\144\144\x69\156\x67\72\x32\45\73\42\76\101\x54\124\122\111\102\x55\124\x45\40\x4e\x41\x4d\x45\x3c\x2f\164\144\76\x3c\x74\x64\x20\x73\164\x79\x6c\145\x3d\x22\x66\x6f\x6e\164\x2d\167\x65\151\147\150\164\x3a\x62\x6f\154\x64\x3b\160\141\x64\x64\x69\156\147\72\x32\x25\x3b\142\157\162\144\x65\x72\72\62\160\x78\x20\163\x6f\x6c\x69\144\x20\43\x39\x34\x39\x30\71\60\73\x20\167\x6f\x72\x64\x2d\167\162\141\160\72\142\x72\145\141\x6b\x2d\x77\157\x72\144\73\42\x3e\x41\124\x54\x52\111\x42\x55\x54\105\40\126\101\x4c\x55\x45\74\x2f\164\x64\x3e\74\57\164\x72\76";
    if (!empty($Te)) {
        goto qas;
    }
    echo "\116\157\40\101\164\x74\x72\151\142\x75\164\145\163\40\122\145\x63\145\x69\x76\145\144\x2e";
    goto RK_;
    qas:
    foreach ($Te as $a5 => $n5) {
        echo "\x3c\164\162\x3e\74\164\144\40\x73\x74\171\154\145\x3d\47\x66\x6f\156\164\55\167\145\x69\x67\x68\164\72\x62\x6f\x6c\144\73\142\157\x72\x64\145\162\x3a\x32\x70\170\40\x73\x6f\154\x69\x64\x20\x23\x39\x34\x39\x30\71\60\73\x70\x61\144\x64\x69\156\x67\x3a\62\45\x3b\x27\x3e" . $a5 . "\74\x2f\164\x64\76\74\164\144\40\163\164\171\154\145\x3d\x27\160\x61\x64\144\x69\x6e\147\72\62\45\73\x62\157\162\144\145\x72\72\62\160\170\x20\x73\157\154\x69\x64\x20\x23\x39\x34\71\x30\71\x30\x3b\x20\167\x6f\x72\144\55\x77\162\x61\160\x3a\142\162\145\x61\153\x2d\x77\157\x72\144\x3b\x27\76" . implode("\74\x68\162\x2f\76", $n5) . "\74\57\164\144\76\x3c\x2f\x74\162\x3e";
        c6C:
    }
    iLT:
    RK_:
    echo "\x3c\57\164\141\142\x6c\145\x3e\x3c\57\144\151\x76\x3e";
    echo "\x3c\x64\151\x76\40\x73\164\x79\154\x65\75\42\155\x61\x72\x67\151\156\x3a\x33\45\x3b\144\151\x73\160\x6c\x61\x79\x3a\x62\154\157\143\153\73\x74\x65\x78\x74\55\141\154\x69\147\x6e\x3a\143\x65\156\164\145\x72\x3b\42\x3e\15\12\40\40\x20\40\40\40\40\x20\x20\40\x20\40\x3c\151\156\160\x75\164\40\163\164\x79\x6c\x65\x3d\42\160\x61\x64\x64\151\x6e\x67\x3a\x31\45\x3b\167\x69\x64\164\x68\72\62\65\60\160\170\73\x62\141\x63\x6b\147\162\157\165\x6e\144\72\x20\x23\60\60\71\61\x43\104\40\156\x6f\x6e\x65\x20\162\145\x70\145\141\x74\40\163\x63\x72\x6f\154\x6c\x20\x30\x25\x20\60\x25\x3b\15\12\40\40\40\40\x20\x20\x20\40\x20\40\x20\x20\x63\165\162\163\x6f\162\72\40\160\157\151\156\164\145\162\x3b\146\x6f\x6e\x74\x2d\163\x69\172\145\x3a\x31\x35\x70\x78\73\142\157\162\144\x65\x72\55\x77\x69\144\164\150\72\40\x31\160\x78\73\x62\x6f\x72\144\x65\162\55\163\x74\x79\x6c\x65\x3a\x20\163\x6f\154\151\144\73\x62\157\x72\144\x65\162\x2d\x72\141\x64\x69\165\x73\72\x20\63\160\170\x3b\x77\150\151\164\x65\x2d\x73\x70\141\x63\145\x3a\15\xa\40\x20\x20\40\x20\40\x20\40\40\40\x20\x20\156\157\167\162\141\160\x3b\x62\x6f\170\55\x73\151\172\x69\x6e\147\72\40\142\x6f\162\144\145\x72\x2d\142\157\170\73\142\157\x72\x64\145\162\x2d\143\x6f\154\157\162\x3a\40\43\60\60\x37\x33\x41\101\73\142\x6f\170\x2d\163\x68\x61\144\x6f\x77\x3a\x20\60\x70\x78\x20\61\x70\x78\x20\x30\x70\170\40\162\x67\142\x61\x28\61\62\x30\x2c\x20\x32\x30\x30\x2c\x20\62\x33\x30\x2c\x20\60\x2e\66\x29\40\x69\x6e\163\145\x74\x3b\x63\x6f\154\157\162\72\40\x23\x46\106\106\x3b" . $G4 . "\x22\xd\12\40\x20\x20\x20\40\x20\40\x20\40\x20\40\40\x20\40\40\40\x74\x79\x70\145\x3d\42\142\165\164\164\x6f\156\42\40\166\x61\154\x75\145\x3d\42\x43\x6f\156\146\151\x67\x75\162\x65\x20\x41\164\x74\162\x69\x62\165\x74\145\x2f\x52\157\154\145\40\115\x61\x70\160\151\x6e\x67\x22\40\x6f\x6e\103\154\x69\x63\153\x3d\42\143\x6c\x6f\163\x65\137\x61\x6e\144\x5f\162\145\144\x69\x72\145\143\x74\50\51\73\42\76\x20\46\x6e\x62\163\x70\73\40\xd\xa\x20\x20\x20\40\x20\x20\40\x20\x20\x20\40\x20\40\x20\40\x20\xd\xa\40\x20\x20\40\x20\x20\x20\40\x20\x20\x20\40\x3c\151\156\x70\165\164\40\163\x74\171\x6c\x65\75\x22\160\x61\x64\x64\151\x6e\147\x3a\61\45\73\167\x69\144\x74\x68\x3a\x31\60\x30\x70\170\73\142\141\143\153\x67\162\157\165\x6e\x64\x3a\x20\43\60\x30\71\61\x43\104\40\x6e\157\x6e\145\40\x72\x65\x70\145\x61\164\40\x73\143\162\157\154\154\40\60\x25\x20\x30\45\x3b\143\x75\162\x73\157\x72\72\40\x70\157\x69\156\x74\145\162\73\146\157\x6e\x74\55\163\151\172\145\72\61\65\160\x78\x3b\142\157\162\144\x65\x72\55\167\x69\144\x74\150\x3a\40\x31\160\170\x3b\142\157\162\x64\145\x72\55\x73\164\171\x6c\x65\72\40\x73\x6f\154\151\144\73\x62\157\162\x64\145\162\55\x72\141\x64\x69\x75\x73\x3a\x20\63\160\170\x3b\167\x68\x69\x74\145\55\163\160\141\x63\145\x3a\40\x6e\x6f\x77\x72\141\160\x3b\x62\x6f\170\x2d\x73\151\172\151\x6e\x67\72\x20\x62\x6f\x72\x64\145\x72\55\142\x6f\170\73\142\157\162\x64\x65\x72\55\x63\x6f\154\157\162\72\x20\43\60\60\x37\63\x41\101\x3b\x62\x6f\x78\x2d\x73\150\x61\144\x6f\167\72\40\x30\x70\170\40\61\x70\170\x20\x30\x70\x78\40\162\147\x62\141\50\61\x32\x30\54\x20\x32\60\x30\x2c\x20\x32\63\x30\x2c\40\60\x2e\x36\51\x20\151\156\x73\x65\164\x3b\x63\x6f\x6c\157\x72\72\x20\x23\106\x46\106\x3b\42\164\x79\160\x65\75\x22\x62\x75\164\x74\157\156\42\x20\x76\x61\154\x75\145\x3d\x22\x44\157\x6e\145\42\x20\x6f\x6e\103\x6c\151\143\153\x3d\42\163\x65\x6c\146\x2e\x63\154\x6f\x73\x65\x28\51\73\42\76\x3c\57\x64\x69\166\x3e\xd\12\x20\x20\x20\x20\40\40\40\x20\40\x20\40\40\40\x20\40\x20\x20\x20\x20\x20\x20\40\x20\x20\40\40\x20\x20\40\40\40\x20\74\163\x63\162\151\x70\164\76\xd\xa\15\xa\40\x20\40\40\x20\40\40\x20\40\40\40\40\x66\165\x6e\x63\164\151\x6f\156\x20\143\154\x6f\x73\x65\137\141\156\144\137\162\145\144\x69\x72\145\x63\x74\50\x29\173\xd\12\40\x20\x20\x20\x20\40\40\x20\x20\40\x20\x20\x20\x20\x20\40\x77\151\x6e\144\x6f\167\56\x6f\160\145\156\x65\x72\x2e\162\x65\x64\151\x72\145\x63\x74\x5f\x74\157\137\141\x74\x74\162\x69\x62\165\x74\145\137\155\141\160\x70\x69\156\x67\x28\51\73\15\12\x20\x20\x20\40\x20\40\40\40\40\x20\x20\x20\x20\x20\40\40\x73\x65\x6c\x66\x2e\143\x6c\x6f\163\145\x28\51\x3b\xd\xa\x20\x20\x20\40\40\40\x20\40\40\x20\40\x20\175\15\xa\40\40\40\40\x20\40\x20\x20\40\40\40\x20\15\12\40\x20\40\x20\x20\x20\40\x20\x20\x20\x20\x20\146\x75\156\x63\x74\151\157\x6e\x20\162\145\x66\x72\145\x73\150\x50\141\162\x65\156\164\x28\x29\x20\173\xd\xa\40\40\40\40\40\x20\x20\40\40\x20\x20\40\40\x20\x20\x20\x77\x69\156\144\x6f\167\x2e\157\160\x65\156\x65\162\x2e\x6c\x6f\x63\x61\164\x69\x6f\x6e\56\162\145\154\157\x61\144\50\51\x3b\15\xa\x20\x20\x20\x20\40\40\x20\x20\40\40\40\40\175\xd\xa\40\x20\x20\x20\x20\x20\x20\40\40\x20\40\40\74\x2f\163\x63\162\151\x70\x74\76";
    exit;
}
function mo_saml_convert_to_windows_iconv($np)
{
    $PC = get_site_option("\x6d\157\137\163\141\x6d\x6c\137\x65\156\143\157\x64\x69\156\x67\137\x65\156\x61\142\154\145\144");
    if (!($PC !== "\143\x68\145\143\x6b\x65\x64")) {
        goto c0e;
    }
    return $np;
    c0e:
    return iconv("\x55\x54\106\x2d\70", "\103\x50\61\x32\65\x32\57\x2f\x49\x47\116\x4f\x52\105", $np);
}
function mo_saml_login_user($rC, $Of, $sK, $M0, $fC, $AL, $Rj, $Pr, $sL = '', $q6 = '', $Te = null)
{
    do_action("\x6d\157\x5f\x61\142\162\137\146\151\x6c\164\x65\162\x5f\x6c\x6f\147\x69\156", $Te);
    $M0 = mo_saml_sanitize_username($M0);
    if (get_site_option("\155\157\137\x73\141\x6d\x6c\137\144\151\163\141\x62\x6c\145\x5f\x72\157\x6c\145\x5f\x6d\x61\160\160\x69\x6e\147")) {
        goto Rm2;
    }
    check_if_user_allowed_to_login_due_to_role_restriction($fC);
    Rm2:
    $E6 = get_site_option("\155\x6f\x5f\x73\x61\155\x6c\137\163\160\137\x62\x61\x73\x65\137\x75\162\x6c");
    mo_saml_restrict_users_based_on_domain($rC);
    if (!empty($AL)) {
        goto Fdk;
    }
    $AL["\104\105\x46\101\x55\114\x54"]["\x64\x65\146\x61\x75\154\164\137\x72\x6f\154\x65"] = "\x73\x75\142\x73\143\x72\x69\142\x65\x72";
    $AL["\x44\x45\106\x41\125\x4c\x54"]["\144\x6f\156\164\137\x61\154\154\x6f\167\137\x75\156\x6c\x69\163\164\145\144\x5f\x75\163\145\x72"] = '';
    $AL["\104\105\x46\101\125\x4c\x54"]["\144\157\x6e\164\137\143\x72\145\141\164\x65\137\x75\x73\x65\x72"] = '';
    $AL["\104\105\x46\x41\125\114\124"]["\x6b\145\x65\x70\137\145\170\x69\163\x74\151\156\147\x5f\x75\163\145\x72\x73\137\x72\x6f\154\145"] = '';
    $AL["\104\105\x46\101\125\114\x54"]["\x6d\x6f\x5f\x73\x61\x6d\x6c\x5f\x64\157\156\164\137\x61\154\x6c\157\x77\x5f\x75\x73\x65\x72\x5f\x74\157\154\x6f\147\151\x6e\137\143\x72\145\141\164\x65\137\x77\151\164\150\137\x67\x69\x76\x65\156\137\x67\162\157\165\x70\163"] = '';
    $AL["\104\105\x46\101\x55\x4c\124"]["\x6d\157\x5f\163\x61\x6d\x6c\x5f\x72\x65\x73\x74\162\x69\143\164\x5f\165\x73\x65\162\163\x5f\x77\151\164\150\137\147\162\157\x75\x70\163"] = '';
    Fdk:
    global $wpdb;
    $cv = get_current_blog_id();
    $yq = "\x75\156\x63\150\x65\x63\153\145\144";
    if (!empty($E6)) {
        goto ZmD;
    }
    $E6 = get_network_site_url();
    ZmD:
    if (email_exists($rC) || username_exists($M0)) {
        goto J67;
    }
    $gj = Utilities::get_active_sites();
    $JL = get_site_option("\155\157\137\x61\160\x70\154\x79\137\162\x6f\x6c\145\137\155\141\160\160\151\156\x67\137\146\157\162\137\x73\151\x74\145\x73");
    if (!get_site_option("\155\x6f\x5f\x73\x61\x6d\154\x5f\x64\151\x73\x61\x62\x6c\145\137\162\157\154\x65\137\x6d\x61\160\x70\151\x6e\x67")) {
        goto aHJ;
    }
    $ZT = wp_generate_password(12, false);
    $AR = wpmu_create_user($M0, $ZT, $rC);
    goto BMd;
    aHJ:
    $AR = mo_saml_assign_roles_to_new_user($gj, $JL, $AL, $fC, $M0, $rC);
    BMd:
    switch_to_blog($cv);
    if (!empty($AR)) {
        goto RKP;
    }
    if (!get_site_option("\x6d\x6f\137\x73\x61\155\x6c\x5f\144\x69\163\141\x62\154\145\x5f\x72\157\x6c\x65\137\x6d\141\x70\x70\x69\x6e\147")) {
        goto chQ;
    }
    wp_die("\x57\x65\40\x63\x6f\x75\154\144\x20\156\157\x74\40\163\151\147\x6e\x20\171\x6f\165\x20\151\x6e\56\40\120\x6c\x65\141\163\145\40\x63\157\156\164\x61\x63\164\40\x61\144\155\x69\156\151\163\x74\x72\x61\x74\x6f\x72", "\x4c\157\147\x69\x6e\40\106\x61\x69\154\145\x64\x21");
    goto U66;
    chQ:
    $n4 = get_site_option("\x6d\157\x5f\163\141\x6d\x6c\x5f\x61\x63\143\157\165\156\164\137\x63\162\145\x61\x74\151\157\156\137\x64\x69\163\x61\x62\154\145\144\137\155\163\x67");
    if (!empty($n4)) {
        goto lSI;
    }
    $n4 = "\x57\x65\x20\x63\x6f\165\x6c\144\40\156\157\164\40\x73\151\147\x6e\40\171\157\x75\x20\x69\156\56\40\120\x6c\145\x61\x73\x65\40\143\x6f\156\x74\x61\x63\x74\x20\x79\157\165\x72\40\x41\144\155\x69\156\151\x73\x74\162\x61\x74\157\162\56";
    lSI:
    wp_die($n4, "\105\x72\x72\x6f\162\x3a\40\x4e\x6f\164\x20\141\x20\x57\157\162\144\120\x72\145\x73\163\40\x4d\145\155\142\145\162");
    U66:
    RKP:
    $user = get_user_by("\151\144", $AR);
    mo_saml_map_basic_attributes($user, $Of, $sK, $Te);
    mo_saml_map_custom_attributes($AR, $Te);
    $Ho = mo_saml_get_redirect_url($E6, $Rj);
    do_action("\155\151\156\151\157\x72\141\156\x67\145\x5f\x70\x6f\163\x74\x5f\141\165\x74\x68\x65\156\x74\x69\x63\x61\x74\x65\137\x75\163\145\162\x5f\x6c\157\147\151\x6e", $user, null, $Ho, true);
    mo_saml_set_auth_cookie($user, $sL, $q6, true);
    do_action("\x6d\157\137\x73\141\155\154\137\x61\164\164\x72\x69\x62\165\x74\145\163", $M0, $rC, $Of, $sK, $fC, null, true);
    goto ga_;
    J67:
    if (email_exists($rC)) {
        goto zXB;
    }
    $user = get_user_by("\x6c\157\x67\x69\156", $M0);
    goto vxj;
    zXB:
    $user = get_user_by("\145\155\141\151\154", $rC);
    vxj:
    $AR = $user->ID;
    if (!(!empty($rC) and strcasecmp($rC, $user->user_email) != 0)) {
        goto yzv;
    }
    $AR = wp_update_user(array("\x49\104" => $AR, "\x75\x73\x65\162\x5f\x65\x6d\x61\x69\x6c" => $rC));
    yzv:
    mo_saml_map_basic_attributes($user, $Of, $sK, $Te);
    mo_saml_map_custom_attributes($AR, $Te);
    $gj = Utilities::get_active_sites();
    $JL = get_site_option("\x6d\x6f\137\x61\160\x70\154\171\x5f\x72\x6f\154\x65\x5f\x6d\141\x70\160\151\156\147\x5f\146\x6f\x72\137\x73\151\x74\145\163");
    if (get_site_option("\x6d\157\x5f\163\141\155\154\137\144\151\163\141\142\154\145\137\162\157\154\145\x5f\x6d\141\160\160\151\156\147")) {
        goto l3g;
    }
    foreach ($gj as $blog_id) {
        switch_to_blog($blog_id);
        $user = get_user_by("\x69\x64", $AR);
        $TT = '';
        if ($JL) {
            goto Xrd;
        }
        $TT = $blog_id;
        goto MJE;
        Xrd:
        $TT = 0;
        MJE:
        if (empty($AL)) {
            goto jq1;
        }
        if (!empty($AL[$TT])) {
            goto os5;
        }
        if (!empty($AL["\104\105\106\x41\x55\x4c\124"])) {
            goto O_0;
        }
        $W5 = "\x73\165\142\163\143\162\x69\142\x65\x72";
        $GJ = '';
        $yq = '';
        $DK = '';
        goto Ohw;
        O_0:
        $W5 = isset($AL["\104\x45\106\101\x55\114\124"]["\x64\x65\146\141\x75\x6c\164\137\x72\157\x6c\x65"]) ? $AL["\104\105\x46\x41\125\114\124"]["\144\x65\146\x61\165\x6c\164\137\x72\x6f\x6c\x65"] : "\x73\x75\x62\163\x63\162\x69\x62\145\x72";
        $GJ = isset($AL["\x44\x45\x46\101\x55\114\x54"]["\x64\157\156\x74\x5f\x61\x6c\x6c\x6f\x77\137\165\156\154\x69\x73\164\x65\144\137\165\x73\145\x72"]) ? $AL["\104\105\106\x41\x55\114\x54"]["\144\x6f\x6e\164\137\141\x6c\x6c\157\167\137\x75\x6e\154\x69\163\164\145\x64\x5f\165\x73\x65\x72"] : '';
        $yq = isset($AL["\104\x45\106\x41\125\x4c\x54"]["\x64\157\156\164\137\143\162\x65\141\x74\x65\137\x75\x73\x65\162"]) ? $AL["\x44\105\106\101\125\x4c\124"]["\x64\x6f\x6e\164\x5f\x63\162\x65\141\x74\x65\137\165\x73\145\x72"] : '';
        $DK = isset($AL["\x44\x45\x46\101\125\x4c\124"]["\x6b\x65\x65\x70\137\x65\170\151\x73\164\x69\156\x67\x5f\165\163\145\162\x73\x5f\x72\x6f\x6c\145"]) ? $AL["\x44\105\106\x41\x55\114\124"]["\153\145\x65\160\x5f\145\x78\x69\163\164\x69\156\147\x5f\x75\x73\x65\x72\x73\137\162\x6f\x6c\145"] : '';
        Ohw:
        goto gL9;
        os5:
        $W5 = isset($AL[$TT]["\144\x65\x66\141\165\x6c\x74\x5f\162\157\x6c\145"]) ? $AL[$TT]["\144\145\146\141\x75\x6c\164\x5f\x72\x6f\154\x65"] : '';
        $GJ = isset($AL[$TT]["\144\x6f\x6e\x74\137\141\x6c\154\157\x77\x5f\x75\x6e\154\x69\x73\x74\145\144\137\x75\163\x65\x72"]) ? $AL[$TT]["\144\157\x6e\164\137\141\154\x6c\157\167\x5f\165\x6e\154\x69\163\164\x65\144\137\165\x73\x65\x72"] : '';
        $yq = isset($AL[$TT]["\144\157\156\164\137\143\162\x65\x61\x74\x65\137\x75\x73\145\x72"]) ? $AL[$TT]["\144\157\x6e\164\137\x63\162\145\x61\x74\x65\137\x75\163\145\x72"] : '';
        $DK = isset($AL[$TT]["\153\x65\145\x70\137\x65\170\x69\163\x74\x69\156\x67\x5f\x75\x73\x65\x72\163\x5f\162\x6f\154\x65"]) ? $AL[$TT]["\x6b\x65\145\x70\x5f\x65\x78\x69\x73\x74\x69\156\x67\137\165\x73\x65\x72\163\x5f\162\157\x6c\145"] : '';
        gL9:
        jq1:
        if (!is_user_member_of_blog($AR, $blog_id)) {
            goto UCW;
        }
        if (isset($DK) && $DK == "\143\x68\x65\x63\x6b\x65\144") {
            goto Zga;
        }
        $sh = assign_roles_to_user($user, $AL, $blog_id, $fC, $TT);
        goto J0t;
        Zga:
        $sh = false;
        J0t:
        if (is_administrator_user($user)) {
            goto PG8;
        }
        if (isset($DK) && $DK == "\x63\150\x65\143\153\145\x64") {
            goto YLh;
        }
        if ($sh !== true && !empty($GJ) && $GJ == "\143\x68\x65\143\x6b\x65\144") {
            goto ads;
        }
        if ($sh !== true && !empty($W5) && $W5 !== "\x66\141\154\163\x65") {
            goto iLV;
        }
        if ($sh !== true && is_user_member_of_blog($AR, $blog_id)) {
            goto xRb;
        }
        goto AGm;
        YLh:
        goto AGm;
        ads:
        $AR = wp_update_user(array("\x49\104" => $AR, "\x72\157\154\x65" => false));
        goto AGm;
        iLV:
        $AR = wp_update_user(array("\x49\104" => $AR, "\162\x6f\x6c\145" => $W5));
        goto AGm;
        xRb:
        $Na = get_site_option("\x64\x65\x66\141\x75\x6c\164\137\162\x6f\x6c\145");
        $AR = wp_update_user(array("\x49\104" => $AR, "\x72\157\x6c\x65" => $Na));
        AGm:
        PG8:
        goto qRp;
        UCW:
        $Bb = TRUE;
        $yn = get_site_option("\x73\141\x6d\154\x5f\x73\x73\157\137\163\x65\x74\x74\x69\156\x67\163");
        if (!empty($yn[$blog_id])) {
            goto ljj;
        }
        $yn[$blog_id] = $yn["\104\x45\106\x41\x55\x4c\x54"];
        ljj:
        if (empty($AL)) {
            goto k_L;
        }
        if (array_key_exists($TT, $AL)) {
            goto W1H;
        }
        if (!array_key_exists("\x44\105\106\101\x55\114\124", $AL)) {
            goto hXh;
        }
        $jo = get_saml_roles_to_assign($AL, $TT, $fC);
        if (!(empty($jo) && strcmp($AL["\x44\x45\106\101\x55\x4c\x54"]["\144\157\x6e\164\x5f\143\162\x65\141\164\145\137\x75\x73\145\162"], "\143\x68\145\x63\153\x65\144") == 0)) {
            goto bU2;
        }
        $Bb = FALSE;
        bU2:
        hXh:
        goto xnZ;
        W1H:
        $jo = get_saml_roles_to_assign($AL, $TT, $fC);
        if (!(empty($jo) && strcmp($AL[$TT]["\x64\157\x6e\x74\x5f\143\162\x65\141\164\x65\x5f\x75\163\145\162"], "\x63\x68\x65\143\153\x65\144") == 0)) {
            goto kEX;
        }
        $Bb = FALSE;
        kEX:
        xnZ:
        k_L:
        if (!$Bb) {
            goto oSZ;
        }
        add_user_to_blog($blog_id, $AR, false);
        $sh = assign_roles_to_user($user, $AL, $blog_id, $fC, $TT);
        if ($sh !== true && !empty($GJ) && $GJ == "\x63\150\x65\143\153\x65\144") {
            goto kW5;
        }
        if ($sh !== true && !empty($W5) && $W5 !== "\146\x61\x6c\x73\x65") {
            goto PBn;
        }
        if ($sh !== true) {
            goto mpj;
        }
        goto DGv;
        kW5:
        $AR = wp_update_user(array("\x49\104" => $AR, "\x72\x6f\x6c\x65" => false));
        goto DGv;
        PBn:
        $AR = wp_update_user(array("\x49\x44" => $AR, "\x72\157\154\145" => $W5));
        goto DGv;
        mpj:
        $Na = get_site_option("\144\145\146\141\165\x6c\164\x5f\162\157\x6c\145");
        $AR = wp_update_user(array("\111\104" => $AR, "\162\157\154\x65" => $Na));
        DGv:
        oSZ:
        qRp:
        dx6:
    }
    rKq:
    l3g:
    switch_to_blog($cv);
    if ($AR) {
        goto Uui;
    }
    wp_die("\111\x6e\166\x61\x6c\x69\144\40\x75\163\x65\162\x2e\40\x50\x6c\145\x61\163\x65\x20\x74\x72\x79\40\x61\x67\x61\x69\156\x2e");
    Uui:
    $user = get_user_by("\x69\x64", $AR);
    mo_saml_set_auth_cookie($user, $sL, $q6, true);
    do_action("\x6d\157\x5f\163\141\155\154\x5f\141\164\x74\x72\151\142\165\x74\145\x73", $M0, $rC, $Of, $sK, $fC);
    ga_:
    mo_saml_post_login_redirection($E6, $Rj);
}
function mo_saml_add_user_to_blog($rC, $M0, $blog_id = 0)
{
    if (email_exists($rC)) {
        goto a6c;
    }
    if (!empty($M0)) {
        goto yEw;
    }
    $AR = mo_saml_create_user($rC, $rC, $blog_id);
    goto h7N;
    yEw:
    $AR = mo_saml_create_user($M0, $rC, $blog_id);
    h7N:
    goto FZX;
    a6c:
    $user = get_user_by("\145\x6d\141\x69\x6c", $rC);
    $AR = $user->ID;
    if (empty($blog_id)) {
        goto Jkt;
    }
    add_user_to_blog($blog_id, $AR, false);
    Jkt:
    FZX:
    return $AR;
}
function mo_saml_create_user($M0, $rC, $blog_id)
{
    $CK = wp_generate_password(10, false);
    if (username_exists($M0)) {
        goto LKE;
    }
    $AR = wp_create_user($M0, $CK, $rC);
    goto xrB;
    LKE:
    $user = get_user_by("\x6c\x6f\147\x69\x6e", $M0);
    $AR = $user->ID;
    if (!$blog_id) {
        goto BH5;
    }
    add_user_to_blog($blog_id, $AR, false);
    BH5:
    xrB:
    if (!is_wp_error($AR)) {
        goto Rsm;
    }
    echo "\74\163\164\x72\157\156\x67\x3e\105\122\x52\117\122\74\57\x73\x74\162\157\x6e\x67\76\x3a\x20\x45\155\x70\164\x79\40\x55\163\x65\x72\40\x4e\x61\x6d\x65\x20\x61\156\x64\40\105\x6d\141\151\154\x2e\40\120\x6c\145\x61\x73\145\40\x63\x6f\156\x74\x61\x63\164\x20\x79\x6f\165\162\x20\141\144\x6d\151\156\x69\x73\x74\x72\141\164\x6f\x72\56";
    exit;
    Rsm:
    return $AR;
}
function mo_saml_assign_roles_to_new_user($gj, $JL, $AL, $fC, $M0, $rC)
{
    global $wpdb;
    $user = NULL;
    $p1 = false;
    foreach ($gj as $blog_id) {
        $ya = TRUE;
        $TT = '';
        if ($JL) {
            goto Sv6;
        }
        $TT = $blog_id;
        goto E2H;
        Sv6:
        $TT = 0;
        E2H:
        $yn = get_site_option("\x73\141\155\154\137\163\163\x6f\137\163\145\x74\x74\x69\156\147\163");
        if (!empty($yn[$blog_id])) {
            goto sc3;
        }
        $yn[$blog_id] = $yn["\104\105\x46\101\x55\114\124"];
        sc3:
        if (empty($AL)) {
            goto xjP;
        }
        if (!empty($AL[$TT])) {
            goto GGa;
        }
        if (!empty($AL["\104\105\x46\x41\x55\114\x54"])) {
            goto x3t;
        }
        $W5 = "\x73\x75\142\x73\x63\x72\x69\x62\x65\162";
        $GJ = '';
        $DK = '';
        $jo = '';
        goto p2M;
        x3t:
        $W5 = isset($AL["\x44\105\x46\x41\125\x4c\x54"]["\x64\145\146\141\165\x6c\x74\137\x72\x6f\x6c\x65"]) ? $AL["\x44\105\106\x41\125\x4c\124"]["\144\145\146\141\x75\154\164\137\162\157\x6c\145"] : '';
        $GJ = isset($AL["\104\105\106\101\125\114\x54"]["\x64\x6f\156\164\137\141\x6c\x6c\x6f\167\137\x75\x6e\x6c\x69\x73\x74\145\x64\x5f\165\x73\x65\162"]) ? $AL["\x44\x45\x46\101\x55\114\124"]["\144\157\156\164\x5f\x61\154\x6c\157\167\137\x75\156\154\x69\x73\x74\145\144\137\x75\163\x65\x72"] : '';
        $DK = array_key_exists("\153\145\x65\x70\x5f\x65\x78\x69\x73\x74\151\156\147\x5f\x75\x73\145\162\x73\x5f\x72\x6f\x6c\145", $AL["\x44\105\106\x41\x55\114\x54"]) ? $AL["\104\x45\106\101\125\114\x54"]["\x6b\145\145\x70\137\x65\x78\151\x73\164\151\156\147\x5f\165\x73\145\x72\x73\x5f\162\157\x6c\145"] : '';
        $jo = get_saml_roles_to_assign($AL, $TT, $fC);
        if (!(empty($jo) && strcmp($AL["\x44\x45\106\101\125\x4c\124"]["\144\157\156\164\x5f\143\x72\x65\x61\164\145\x5f\x75\x73\x65\x72"], "\143\x68\145\143\x6b\x65\x64") == 0)) {
            goto fuj;
        }
        $ya = FALSE;
        fuj:
        p2M:
        goto QPi;
        GGa:
        $W5 = isset($AL[$TT]["\x64\145\146\x61\x75\x6c\x74\x5f\x72\157\x6c\x65"]) ? $AL[$TT]["\144\x65\x66\x61\165\154\x74\137\x72\157\154\145"] : '';
        $GJ = isset($AL[$TT]["\x64\x6f\156\x74\137\x61\x6c\154\157\167\137\165\156\154\x69\x73\164\x65\x64\137\165\x73\x65\162"]) ? $AL[$TT]["\144\157\x6e\x74\x5f\x61\154\x6c\157\x77\x5f\165\156\x6c\x69\163\x74\x65\144\x5f\x75\x73\x65\x72"] : '';
        $DK = array_key_exists("\x6b\145\x65\160\x5f\145\170\151\x73\x74\x69\x6e\x67\x5f\x75\163\x65\x72\x73\x5f\162\x6f\x6c\x65", $AL[$TT]) ? $AL[$TT]["\153\x65\145\x70\x5f\145\170\151\163\x74\x69\156\147\137\165\163\145\162\163\137\x72\x6f\154\x65"] : '';
        $jo = get_saml_roles_to_assign($AL, $TT, $fC);
        if (!(empty($jo) && strcmp($AL[$TT]["\x64\157\156\x74\137\x63\x72\x65\x61\164\145\x5f\165\x73\x65\162"], "\x63\x68\x65\x63\x6b\x65\x64") == 0)) {
            goto Kpq;
        }
        $ya = FALSE;
        Kpq:
        QPi:
        xjP:
        if (!$ya) {
            goto mTN;
        }
        $AR = NULL;
        switch_to_blog($blog_id);
        $AR = mo_saml_add_user_to_blog($rC, $M0, $blog_id);
        $user = get_user_by("\x69\x64", $AR);
        $sh = assign_roles_to_user($user, $AL, $blog_id, $fC, $TT);
        if ($sh !== true && !empty($GJ) && $GJ == "\143\150\145\143\153\145\x64") {
            goto ZoX;
        }
        if ($sh !== true && !empty($W5) && $W5 !== "\146\141\154\x73\145") {
            goto N2A;
        }
        if ($sh !== true) {
            goto Wpv;
        }
        goto N26;
        ZoX:
        $AR = wp_update_user(array("\x49\x44" => $AR, "\x72\x6f\x6c\145" => false));
        goto N26;
        N2A:
        $AR = wp_update_user(array("\111\x44" => $AR, "\x72\157\x6c\x65" => $W5));
        goto N26;
        Wpv:
        $Na = get_site_option("\144\145\x66\141\165\x6c\164\x5f\x72\157\154\145");
        $AR = wp_update_user(array("\111\104" => $AR, "\162\157\x6c\145" => $Na));
        N26:
        $RC = $user->{$wpdb->prefix . "\143\141\x70\x61\x62\151\x6c\x69\164\151\145\163"};
        if (isset($wp_roles)) {
            goto Qon;
        }
        $wp_roles = new WP_Roles($TT);
        Qon:
        mTN:
        DmL:
    }
    gY0:
    if (!empty($user)) {
        goto yo_;
    }
    return;
    goto p2T;
    yo_:
    return $user->ID;
    p2T:
}
function mo_saml_sanitize_username($M0)
{
    $Fb = sanitize_user($M0, true);
    $J4 = apply_filters("\x70\x72\x65\x5f\165\163\x65\x72\137\154\x6f\x67\151\x6e", $Fb);
    $M0 = trim($J4);
    return $M0;
}
function mo_saml_map_basic_attributes($user, $Of, $sK, $Te)
{
    $AR = $user->ID;
    if (empty($Of)) {
        goto XDr;
    }
    $AR = wp_update_user(array("\111\104" => $AR, "\146\151\x72\163\x74\137\156\141\x6d\x65" => $Of));
    XDr:
    if (empty($sK)) {
        goto jax;
    }
    $AR = wp_update_user(array("\111\104" => $AR, "\x6c\141\x73\x74\x5f\156\141\x6d\x65" => $sK));
    jax:
    if (is_null($Te)) {
        goto u9V;
    }
    update_user_meta($AR, "\x6d\157\x5f\x73\141\155\154\137\x75\163\145\162\x5f\x61\x74\164\162\x69\x62\165\164\145\163", $Te);
    $wW = get_site_option("\x73\141\155\154\x5f\x61\x6d\x5f\144\151\163\160\x6c\141\x79\137\156\141\x6d\x65");
    if (empty($wW)) {
        goto uAS;
    }
    if (strcmp($wW, "\x55\123\105\x52\116\x41\115\105") == 0) {
        goto yCi;
    }
    if (strcmp($wW, "\x46\x4e\101\115\105") == 0 && !empty($Of)) {
        goto Rqd;
    }
    if (strcmp($wW, "\x4c\116\101\115\x45") == 0 && !empty($sK)) {
        goto NFv;
    }
    if (strcmp($wW, "\x46\116\x41\x4d\105\137\114\x4e\x41\x4d\105") == 0 && !empty($sK) && !empty($Of)) {
        goto NYh;
    }
    if (!(strcmp($wW, "\114\116\101\x4d\x45\x5f\x46\116\101\x4d\105") == 0 && !empty($sK) && !empty($Of))) {
        goto nW5;
    }
    $AR = wp_update_user(array("\x49\x44" => $AR, "\144\151\x73\x70\x6c\141\171\137\156\141\155\145" => $sK . "\40" . $Of));
    nW5:
    goto sCP;
    NYh:
    $AR = wp_update_user(array("\111\x44" => $AR, "\x64\x69\x73\x70\x6c\141\x79\x5f\156\x61\x6d\145" => $Of . "\x20" . $sK));
    sCP:
    goto B68;
    NFv:
    $AR = wp_update_user(array("\111\104" => $AR, "\x64\x69\163\x70\x6c\141\171\137\156\141\x6d\145" => $sK));
    B68:
    goto A6o;
    Rqd:
    $AR = wp_update_user(array("\x49\104" => $AR, "\144\x69\163\x70\x6c\141\x79\x5f\156\141\155\x65" => $Of));
    A6o:
    goto o3A;
    yCi:
    $AR = wp_update_user(array("\x49\104" => $AR, "\144\x69\163\160\154\141\x79\137\x6e\x61\155\145" => $user->user_login));
    o3A:
    uAS:
    u9V:
}
function mo_saml_map_custom_attributes($AR, $Te)
{
    if (!get_site_option("\x6d\x6f\137\163\141\155\154\137\x63\x75\x73\164\x6f\x6d\x5f\141\x74\164\x72\x73\x5f\x6d\141\160\160\151\156\x67")) {
        goto bPd;
    }
    $e3 = maybe_unserialize(get_site_option("\x6d\157\137\x73\141\x6d\x6c\x5f\x63\x75\x73\164\157\155\x5f\x61\x74\164\162\x73\x5f\x6d\x61\x70\160\151\x6e\x67"));
    foreach ($e3 as $a5 => $n5) {
        if (!array_key_exists($n5, $Te)) {
            goto Pn6;
        }
        $bJ = false;
        if (!(count($Te[$n5]) == 1)) {
            goto d5d;
        }
        $bJ = true;
        d5d:
        if (!$bJ) {
            goto GaP;
        }
        update_user_meta($AR, $a5, $Te[$n5][0]);
        goto VdM;
        GaP:
        $c7 = array();
        foreach ($Te[$n5] as $q7) {
            array_push($c7, $q7);
            Xl7:
        }
        hUG:
        update_user_meta($AR, $a5, $c7);
        VdM:
        Pn6:
        IQ9:
    }
    g1W:
    bPd:
}
function mo_saml_restrict_users_based_on_domain($rC)
{
    $oc = get_site_option("\x6d\157\137\163\x61\155\x6c\137\x65\x6e\x61\142\154\x65\137\x64\157\155\x61\151\156\x5f\x72\x65\163\x74\x72\x69\x63\x74\x69\157\156\137\154\x6f\147\151\x6e");
    if (!$oc) {
        goto s7d;
    }
    $Re = get_site_option("\163\141\x6d\x6c\137\x61\155\x5f\145\155\141\x69\x6c\x5f\x64\x6f\155\x61\151\x6e\x73");
    $X9 = explode("\x3b", $Re);
    $oK = explode("\x40", $rC);
    $VA = array_key_exists("\x31", $oK) ? $oK[1] : '';
    $d4 = get_site_option("\155\x6f\137\163\x61\155\154\x5f\141\154\154\157\167\x5f\144\x65\156\x79\137\165\x73\x65\x72\137\x77\x69\164\x68\x5f\144\x6f\155\x61\151\x6e");
    $n4 = get_site_option("\x6d\157\137\163\141\155\x6c\137\x72\x65\163\x74\x72\151\x63\164\x65\144\137\x64\x6f\155\141\x69\x6e\137\145\162\x72\157\x72\137\x6d\163\x67");
    if (!empty($n4)) {
        goto W5X;
    }
    $n4 = "\131\x6f\165\40\x61\x72\x65\40\x6e\x6f\x74\x20\141\x6c\x6c\157\x77\x65\144\40\164\x6f\40\x6c\x6f\x67\151\x6e\56\x20\x50\154\145\141\x73\x65\40\143\157\x6e\x74\141\x63\x74\x20\171\x6f\165\x72\40\x41\144\x6d\151\156\151\163\164\x72\141\164\x6f\162\x2e";
    W5X:
    if (!empty($d4) && $d4 == "\144\x65\156\171") {
        goto wVK;
    }
    if (in_array($VA, $X9)) {
        goto lql;
    }
    wp_die($n4, "\x50\x65\162\x6d\151\163\163\x69\x6f\156\x20\x44\x65\x6e\151\145\x64\40\105\x72\x72\157\162\x20\x2d\x20\62");
    lql:
    goto bVN;
    wVK:
    if (!in_array($VA, $X9)) {
        goto Rv_;
    }
    wp_die($n4, "\x50\145\x72\155\151\x73\163\151\157\156\x20\104\145\156\x69\x65\144\40\105\162\x72\x6f\162\40\55\40\61");
    Rv_:
    bVN:
    s7d:
}
function mo_saml_set_auth_cookie($user, $sL, $q6, $q4)
{
    $AR = $user->ID;
    do_action("\x77\160\137\154\x6f\x67\x69\156", $user->user_login, $user);
    if (empty($sL)) {
        goto YQR;
    }
    update_user_meta($AR, "\155\157\137\x73\141\x6d\154\137\163\x65\x73\163\151\157\x6e\x5f\151\156\x64\145\x78", $sL);
    YQR:
    if (empty($q6)) {
        goto yo5;
    }
    update_user_meta($AR, "\x6d\x6f\x5f\163\x61\x6d\x6c\137\156\x61\155\x65\137\151\144", $q6);
    yo5:
    if (!(!session_id() || session_id() == '' || !isset($_SESSION))) {
        goto CRJ;
    }
    session_start();
    CRJ:
    $_SESSION["\155\x6f\137\163\141\x6d\154"]["\154\x6f\x67\x67\x65\144\x5f\x69\156\137\167\x69\x74\150\137\151\144\x70"] = TRUE;
    update_user_meta($AR, "\155\x6f\x5f\x73\x61\x6d\154\x5f\151\x64\x70\x5f\154\x6f\147\151\x6e", "\x74\x72\165\145");
    wp_set_current_user($AR);
    $EP = false;
    $EP = apply_filters("\155\x6f\137\162\145\155\x65\155\x62\x65\162\137\155\145", $EP);
    wp_set_auth_cookie($AR, $EP);
    if (!$q4) {
        goto Sqj;
    }
    do_action("\165\163\145\x72\137\x72\x65\147\151\x73\x74\x65\162", $AR);
    Sqj:
}
function mo_saml_post_login_redirection($E6, $Rj)
{
    $Nk = mo_saml_get_redirect_url($E6, $Rj);
    wp_redirect($Nk);
    exit;
}
function mo_saml_get_redirect_url($E6, $Rj)
{
    $Ho = '';
    $yn = get_site_option("\x73\141\x6d\154\137\163\x73\x6f\x5f\163\145\164\x74\151\156\147\163");
    $FX = get_current_blog_id();
    if (!(empty($yn[$FX]) && !empty($yn["\104\x45\106\x41\125\114\124"]))) {
        goto MNy;
    }
    $yn[$FX] = $yn["\x44\x45\x46\x41\125\114\x54"];
    MNy:
    $Sy = isset($yn[$FX]["\x6d\x6f\x5f\x73\x61\x6d\x6c\137\162\x65\154\141\171\x5f\163\164\141\164\145"]) ? $yn[$FX]["\x6d\x6f\137\163\141\x6d\154\137\162\145\154\x61\x79\137\x73\164\x61\164\x65"] : '';
    if (!empty($Sy)) {
        goto EIp;
    }
    if (!empty($Rj)) {
        goto ZKR;
    }
    $Ho = $E6;
    goto BBI;
    ZKR:
    $Ho = $Rj;
    BBI:
    goto yGL;
    EIp:
    $Ho = $Sy;
    yGL:
    return $Ho;
}
function check_if_user_allowed_to_login($user, $E6)
{
    $AR = $user->ID;
    global $wpdb;
    if (get_user_meta($AR, "\x6d\157\137\x73\141\155\154\137\165\x73\145\x72\137\164\171\160\145", true)) {
        goto Ddv;
    }
    if (get_site_option("\x6d\x6f\137\x73\141\x6d\154\137\165\163\162\x5f\154\x6d\164")) {
        goto j_Y;
    }
    update_user_meta($AR, "\x6d\157\x5f\x73\x61\155\x6c\x5f\165\163\x65\x72\137\164\171\x70\145", "\x73\x73\157\137\165\163\145\162");
    goto H0j;
    j_Y:
    $a5 = get_site_option("\x6d\x6f\137\x73\x61\x6d\x6c\x5f\143\165\x73\164\x6f\155\145\x72\137\x74\x6f\153\x65\x6e");
    $C4 = AESEncryption::decrypt_data(get_site_option("\x6d\157\x5f\x73\x61\155\x6c\x5f\x75\x73\x72\x5f\x6c\155\x74"), $a5);
    $nv = "\x53\105\x4c\x45\x43\124\40\x43\117\125\x4e\124\50\52\x29\40\106\x52\x4f\x4d\x20" . $wpdb->prefix . "\x75\163\145\x72\155\145\164\x61\40\127\x48\105\x52\x45\x20\155\145\x74\141\137\153\145\x79\75\47\x6d\x6f\137\x73\141\155\154\137\165\x73\145\162\x5f\x74\171\x70\145\x27";
    $Kw = $wpdb->get_var($nv);
    if ($Kw >= $C4) {
        goto vig;
    }
    update_user_meta($AR, "\x6d\157\x5f\163\141\x6d\154\x5f\x75\163\x65\x72\x5f\164\171\x70\145", "\x73\163\x6f\x5f\x75\x73\x65\162");
    goto uox;
    vig:
    if (get_site_option("\x75\x73\145\162\x5f\141\x6c\x65\x72\x74\x5f\145\155\141\151\x6c\x5f\x73\x65\156\164")) {
        goto gzA;
    }
    $y_ = new Customersaml();
    $y_->mo_saml_send_user_exceeded_alert_email($C4, $this);
    gzA:
    if (is_administrator_user($user)) {
        goto LOr;
    }
    wp_redirect($E6);
    exit;
    goto Kem;
    LOr:
    update_user_meta($AR, "\x6d\157\x5f\163\141\155\154\137\x75\163\x65\x72\137\x74\171\x70\145", "\x73\163\x6f\x5f\165\x73\145\x72");
    Kem:
    uox:
    H0j:
    Ddv:
}
function check_if_user_allowed_to_login_due_to_role_restriction($fC)
{
    $AL = maybe_unserialize(get_site_option("\163\141\x6d\x6c\x5f\x61\x6d\x5f\162\x6f\154\145\x5f\x6d\141\160\160\x69\156\x67"));
    $gj = Utilities::get_active_sites();
    $JL = get_site_option("\x6d\157\x5f\141\160\160\154\x79\x5f\162\157\154\x65\x5f\155\x61\160\160\x69\156\147\x5f\146\x6f\162\137\163\x69\164\x65\163");
    if ($AL) {
        goto El4;
    }
    $AL = array();
    El4:
    if (array_key_exists("\104\x45\x46\101\125\x4c\124", $AL)) {
        goto MmR;
    }
    $AL["\104\105\x46\101\125\114\124"] = array();
    MmR:
    foreach ($gj as $blog_id) {
        if ($JL) {
            goto Hyo;
        }
        $TT = $blog_id;
        goto WXo;
        Hyo:
        $TT = 0;
        WXo:
        if (isset($AL[$TT])) {
            goto KS1;
        }
        $x_ = $AL["\x44\x45\106\101\x55\x4c\124"];
        goto xMG;
        KS1:
        $x_ = $AL[$TT];
        xMG:
        if (empty($x_)) {
            goto nIh;
        }
        $zV = isset($x_["\155\x6f\x5f\x73\141\155\154\137\x64\157\156\x74\x5f\x61\154\x6c\157\167\137\165\x73\x65\x72\137\164\x6f\154\x6f\147\151\156\x5f\x63\x72\145\x61\x74\x65\x5f\x77\151\164\150\x5f\147\x69\166\145\x6e\137\147\x72\157\165\x70\163"]) ? $x_["\x6d\157\x5f\163\141\x6d\x6c\x5f\x64\x6f\x6e\x74\137\141\x6c\x6c\x6f\167\x5f\165\x73\145\x72\x5f\x74\x6f\x6c\x6f\147\x69\x6e\x5f\x63\162\x65\141\x74\x65\x5f\167\151\x74\150\137\x67\151\x76\145\x6e\x5f\147\162\157\x75\160\x73"] : '';
        if (!($zV == "\143\x68\x65\143\153\145\144")) {
            goto UxA;
        }
        if (empty($fC)) {
            goto aYW;
        }
        $QS = $x_["\x6d\157\x5f\x73\141\x6d\x6c\137\x72\x65\x73\x74\162\151\x63\x74\137\x75\163\x65\162\163\137\x77\x69\x74\150\x5f\147\x72\157\x75\x70\163"];
        $ka = explode("\x3b", $QS);
        foreach ($ka as $V6) {
            foreach ($fC as $rY) {
                $rY = trim($rY);
                if (!(!empty($rY) && $rY == $V6)) {
                    goto N41;
                }
                wp_die("\131\157\165\x20\x61\162\x65\x20\x6e\157\164\40\141\x75\x74\150\157\x72\x69\172\145\x64\x20\x74\x6f\40\154\157\x67\151\156\x2e\40\120\x6c\145\141\x73\145\40\143\x6f\156\164\x61\x63\x74\40\171\157\x75\162\x20\x61\144\x6d\x69\156\x69\163\164\162\x61\x74\x6f\x72\56", "\105\162\162\x6f\x72");
                N41:
                wD7:
            }
            wC7:
            Lnt:
        }
        Y1A:
        aYW:
        UxA:
        nIh:
        Lxc:
    }
    LFB:
}
function assign_roles_to_user($user, $AL, $blog_id, $fC, $TT)
{
    $sh = false;
    if (!(!empty($fC) && !empty($AL) && !is_administrator_user($user) && is_user_member_of_blog($user->ID, $blog_id))) {
        goto HhF;
    }
    if (!empty($AL[$TT])) {
        goto Q3C;
    }
    if (empty($AL["\104\105\106\x41\125\x4c\124"])) {
        goto pDc;
    }
    $x_ = $AL["\x44\x45\x46\x41\x55\114\x54"];
    pDc:
    goto ER4;
    Q3C:
    $x_ = $AL[$TT];
    ER4:
    if (empty($x_)) {
        goto n3y;
    }
    $user->set_role(false);
    $KX = '';
    $uI = false;
    unset($x_["\x64\x65\146\x61\165\154\x74\x5f\x72\x6f\x6c\145"]);
    unset($x_["\x64\157\x6e\164\x5f\x63\x72\145\141\x74\x65\137\x75\163\145\x72"]);
    unset($x_["\x64\x6f\156\164\x5f\x61\x6c\154\157\x77\x5f\x75\x6e\154\151\163\164\145\x64\x5f\165\x73\145\x72"]);
    unset($x_["\153\x65\x65\x70\x5f\145\170\151\163\x74\151\x6e\x67\137\165\163\145\162\x73\137\162\x6f\x6c\x65"]);
    unset($x_["\155\157\x5f\x73\x61\x6d\154\137\144\157\156\164\137\x61\154\x6c\157\x77\137\165\x73\x65\x72\137\x74\157\x6c\157\147\151\x6e\x5f\x63\x72\145\141\164\x65\x5f\167\x69\x74\x68\x5f\147\x69\166\x65\156\x5f\x67\162\x6f\165\x70\x73"]);
    unset($x_["\155\157\137\163\141\x6d\x6c\x5f\162\x65\163\164\162\x69\143\x74\137\x75\x73\145\x72\x73\137\167\151\x74\x68\x5f\147\162\x6f\165\160\163"]);
    foreach ($x_ as $vm => $Jp) {
        $ka = explode("\x3b", $Jp);
        foreach ($ka as $V6) {
            if (!(!empty($V6) && in_array($V6, $fC))) {
                goto d3I;
            }
            $sh = true;
            $user->add_role($vm);
            d3I:
            yQY:
        }
        zrd:
        oiz:
    }
    WYJ:
    n3y:
    HhF:
    $G7 = get_site_option("\x6d\x6f\x5f\163\x61\155\154\x5f\163\x75\160\x65\x72\137\x61\x64\155\x69\156\x5f\162\157\154\x65\x5f\x6d\141\x70\x70\151\x6e\x67");
    $pU = array();
    if (empty($G7)) {
        goto rLe;
    }
    $pU = explode("\x3b", $G7);
    rLe:
    if (!(!empty($fC) && !empty($pU))) {
        goto tfw;
    }
    foreach ($pU as $V6) {
        if (!in_array($V6, $fC)) {
            goto ijo;
        }
        grant_super_admin($user->ID);
        ijo:
        rIH:
    }
    fsO:
    tfw:
    return $sh;
}
function get_saml_roles_to_assign($AL, $blog_id, $fC)
{
    $jo = array();
    if (!(!empty($fC) && !empty($AL))) {
        goto TAW;
    }
    if (!empty($AL[$blog_id])) {
        goto rqw;
    }
    if (empty($AL["\x44\105\106\x41\125\x4c\x54"])) {
        goto S6H;
    }
    $x_ = $AL["\104\x45\x46\101\x55\114\124"];
    S6H:
    goto DVv;
    rqw:
    $x_ = $AL[$blog_id];
    DVv:
    if (empty($x_)) {
        goto uRz;
    }
    unset($x_["\144\x65\x66\x61\165\x6c\x74\137\x72\157\154\x65"]);
    unset($x_["\x64\157\x6e\x74\x5f\143\162\x65\x61\x74\145\137\165\x73\x65\x72"]);
    unset($x_["\144\x6f\156\x74\137\x61\x6c\154\x6f\167\137\x75\x6e\x6c\151\x73\x74\145\x64\137\x75\163\145\162"]);
    unset($x_["\153\145\x65\x70\x5f\x65\170\x69\163\x74\x69\156\147\x5f\x75\x73\x65\162\163\x5f\x72\157\154\145"]);
    unset($x_["\x6d\x6f\137\x73\x61\x6d\x6c\x5f\144\x6f\x6e\x74\137\x61\154\x6c\157\x77\x5f\165\x73\x65\x72\x5f\164\157\x6c\x6f\x67\151\x6e\137\x63\x72\145\141\x74\145\137\167\151\164\x68\x5f\x67\x69\x76\x65\x6e\x5f\x67\x72\157\165\160\x73"]);
    unset($x_["\155\x6f\137\163\141\155\x6c\137\x72\145\163\164\x72\x69\143\164\137\x75\x73\145\162\x73\137\x77\x69\164\150\137\147\162\157\165\160\163"]);
    foreach ($x_ as $vm => $Jp) {
        $ka = explode("\73", $Jp);
        foreach ($ka as $V6) {
            if (!(!empty($V6) and in_array($V6, $fC))) {
                goto yNF;
            }
            array_push($jo, $vm);
            yNF:
            aZz:
        }
        K3w:
        VRS:
    }
    P6h:
    uRz:
    TAW:
    return $jo;
}
function is_administrator_user($user)
{
    $op = $user->roles;
    if (!is_null($op) && in_array("\x61\144\x6d\151\156\x69\163\164\162\141\164\157\162", $op)) {
        goto j2W;
    }
    return false;
    goto rg_;
    j2W:
    return true;
    rg_:
}
function mo_saml_is_customer_registered()
{
    return 1;
    $Hd = get_site_option("\155\x6f\137\x73\x61\x6d\154\x5f\x61\144\155\151\x6e\137\x65\155\x61\x69\x6c");
    $XN = get_site_option("\x6d\157\137\163\x61\155\x6c\137\x61\x64\155\x69\156\137\143\165\163\x74\157\155\x65\162\137\x6b\x65\x79");
    if (!$Hd || !$XN || !is_numeric(trim($XN))) {
        goto gf_;
    }
    return 1;
    goto AAg;
    gf_:
    return 0;
    AAg:
}
function mo_saml_is_customer_license_verified()
{
    $OR = mo_saml_get_plugin_details();
    if ($OR !== true) {
        goto Ol1;
    }
    return 1;
    goto LV8;
    Ol1:
    return 0;
    LV8:
    $a5 = get_site_option("\155\157\137\163\x61\x6d\x6c\x5f\x63\x75\x73\x74\x6f\155\x65\162\137\164\x6f\153\145\x6e");
    $pq = AESEncryption::decrypt_data(get_site_option("\164\x5f\x73\151\x74\x65\x5f\163\164\141\x74\165\x73"), $a5);
    $cL = get_site_option("\163\155\x6c\x5f\154\x6b");
    $Hd = get_site_option("\155\x6f\x5f\x73\x61\155\154\x5f\x61\x64\155\x69\156\x5f\145\155\141\151\154");
    $XN = get_site_option("\x6d\x6f\137\163\x61\x6d\154\137\x61\x64\155\x69\x6e\x5f\x63\x75\x73\164\157\x6d\145\162\137\153\145\171");
    $vc = AESEncryption::decrypt_data(get_site_option("\x6e\157\x5f\x73\x62\163"), $a5);
    $s3 = false;
    if (!get_site_option("\156\x6f\137\x73\142\163")) {
        goto wvt;
    }
    $rs = Utilities::get_sites();
    $s3 = $vc < count($rs);
    wvt:
    if ($pq != "\164\162\165\145" && !$cL || !$Hd || !$XN || !is_numeric(trim($XN)) || $s3) {
        goto m38;
    }
    return 1;
    goto Ws5;
    m38:
    return 0;
    Ws5:
}
function show_status_error($W8, $Rj)
{
    if ($Rj == "\x74\145\x73\164\x56\141\154\x69\x64\141\164\x65" or $Rj == "\x74\x65\x73\x74\116\x65\x77\x43\x65\162\x74\x69\x66\151\143\x61\164\x65") {
        goto pj4;
    }
    wp_die("\x57\145\x20\143\x6f\165\154\x64\40\x6e\x6f\164\40\163\x69\147\x6e\x20\171\157\x75\40\151\156\x2e\40\120\x6c\145\141\163\145\x20\143\x6f\x6e\164\x61\x63\164\40\171\x6f\x75\x72\x20\101\144\x6d\151\x6e\x69\x73\164\x72\x61\164\157\162\x2e", "\105\x72\x72\x6f\x72\x3a\x20\x49\156\x76\x61\154\x69\x64\40\123\101\115\x4c\x20\122\145\x73\160\x6f\156\x73\145\40\123\x74\141\x74\x75\163");
    goto v_R;
    pj4:
    echo "\x3c\x64\151\x76\x20\163\x74\171\154\x65\x3d\42\x66\x6f\x6e\164\x2d\146\x61\x6d\151\x6c\171\72\x43\x61\x6c\x69\142\x72\151\73\160\x61\144\144\x69\x6e\147\72\60\x20\63\45\73\42\76";
    echo "\x3c\144\x69\166\40\x73\164\x79\154\x65\x3d\x22\x63\x6f\x6c\157\x72\72\40\43\141\71\64\64\x34\62\x3b\142\x61\143\153\147\x72\x6f\x75\x6e\144\x2d\143\157\x6c\157\162\x3a\40\x23\x66\62\x64\145\144\x65\x3b\160\x61\144\144\x69\x6e\x67\72\x20\x31\x35\x70\x78\x3b\155\x61\162\147\x69\x6e\x2d\x62\157\x74\164\157\x6d\x3a\40\x32\x30\160\x78\73\x74\x65\170\x74\55\141\x6c\151\147\156\72\x63\145\156\164\145\x72\73\142\x6f\162\144\145\162\x3a\61\160\x78\40\163\x6f\154\151\x64\40\43\105\x36\102\x33\x42\x32\x3b\146\x6f\x6e\x74\55\x73\x69\172\x65\72\61\x38\x70\x74\x3b\42\x3e\x20\x45\122\x52\x4f\x52\x3c\57\x64\x69\166\x3e\15\12\40\40\40\x20\40\40\x20\x20\x3c\144\x69\x76\40\163\x74\171\154\x65\75\x22\x63\157\154\157\x72\72\x20\43\141\x39\64\x34\64\x32\73\x66\157\x6e\x74\x2d\163\x69\172\145\x3a\61\64\x70\164\x3b\40\x6d\x61\162\x67\x69\156\x2d\x62\157\164\x74\157\x6d\72\62\60\160\170\73\42\x3e\74\x70\x3e\74\x73\x74\x72\x6f\156\x67\76\105\x72\162\157\x72\72\x20\x3c\x2f\163\x74\162\157\156\x67\76\40\111\156\166\x61\154\151\144\x20\123\x41\x4d\x4c\x20\x52\x65\x73\160\x6f\156\x73\x65\40\x53\164\x61\164\x75\163\x2e\x3c\x2f\160\76\15\xa\x20\x20\x20\40\40\x20\x20\x20\x20\x20\x20\40\74\x70\76\74\x73\164\162\157\x6e\147\76\103\141\x75\163\145\x73\x3c\x2f\x73\164\x72\x6f\x6e\147\76\x3a\x20\111\144\145\156\164\151\x74\x79\x20\120\162\x6f\x76\151\x64\x65\162\40\x68\x61\163\40\163\145\x6e\164\40\x27" . esc_html($W8) . "\47\x20\x73\164\x61\x74\165\x73\x20\143\157\x64\145\40\151\x6e\40\x53\x41\115\114\x20\122\x65\163\160\x6f\156\x73\145\x2e\x20\x3c\x2f\x70\x3e\xd\xa\40\40\x20\40\x20\x20\40\40\x20\40\x20\x20\x3c\x70\76\x3c\163\164\x72\x6f\156\147\x3e\122\145\141\163\x6f\x6e\x3c\x2f\x73\164\162\x6f\x6e\147\x3e\x3a\x20" . get_status_message(esc_html($W8)) . "\74\57\x70\x3e\74\x62\x72\76";
    if (empty($VP)) {
        goto WgH;
    }
    echo "\74\160\x3e\74\163\164\162\x6f\156\147\x3e\123\164\x61\164\x75\163\x20\x4d\145\x73\163\141\x67\x65\40\151\156\x20\x74\x68\145\x20\123\101\x4d\114\x20\122\x65\x73\x70\157\156\163\x65\72\74\57\163\164\x72\157\x6e\147\76\x20\74\142\162\x2f\x3e" . esc_html($VP) . "\74\57\160\76\x3c\142\162\x3e";
    WgH:
    echo "\15\xa\40\40\40\x20\x20\40\40\40\x3c\x2f\144\x69\x76\x3e\xd\12\xd\xa\x20\40\40\40\x20\40\x20\40\74\x64\151\x76\40\x73\164\x79\x6c\x65\x3d\42\155\x61\x72\x67\151\156\x3a\63\45\x3b\144\x69\163\160\154\x61\x79\x3a\x62\154\157\x63\x6b\x3b\x74\145\x78\x74\55\x61\x6c\151\147\156\72\x63\145\x6e\164\x65\162\x3b\42\x3e\xd\12\x20\x20\x20\40\x20\x20\40\x20\40\x20\x20\40\x3c\x64\151\166\x20\x73\164\x79\x6c\x65\x3d\x22\155\x61\162\147\x69\156\x3a\x33\45\x3b\144\x69\x73\x70\x6c\x61\x79\72\142\x6c\157\143\153\x3b\164\145\x78\x74\55\141\154\151\x67\x6e\x3a\143\x65\156\x74\145\x72\x3b\42\x3e\x3c\x69\x6e\160\165\164\x20\163\x74\x79\154\145\x3d\x22\x70\141\x64\144\x69\x6e\147\72\x31\45\73\167\x69\144\164\150\x3a\61\x30\x30\x70\170\x3b\x62\141\x63\153\x67\x72\x6f\165\x6e\144\72\x20\x23\x30\60\x39\61\x43\x44\40\x6e\157\x6e\145\x20\x72\x65\160\145\141\x74\x20\x73\x63\162\x6f\x6c\x6c\40\60\45\x20\60\x25\x3b\143\x75\x72\x73\157\162\72\40\160\157\x69\x6e\164\x65\x72\73\146\x6f\156\164\55\163\151\172\145\72\61\65\160\x78\x3b\x62\x6f\x72\x64\x65\x72\x2d\x77\x69\x64\164\150\72\40\61\160\x78\x3b\x62\x6f\162\144\x65\162\55\163\164\x79\154\x65\72\40\163\157\x6c\x69\144\x3b\142\157\x72\x64\x65\162\55\162\141\x64\151\x75\x73\72\40\63\160\170\73\167\x68\x69\164\x65\x2d\x73\x70\141\x63\x65\x3a\40\x6e\157\x77\162\141\x70\73\142\157\170\x2d\163\151\x7a\151\156\147\72\40\142\157\x72\144\145\162\x2d\x62\157\x78\73\x62\x6f\x72\144\x65\162\55\143\x6f\154\157\162\x3a\x20\43\x30\x30\x37\x33\101\101\73\x62\x6f\x78\55\163\x68\141\x64\157\x77\72\40\60\x70\x78\40\x31\x70\170\x20\60\160\x78\40\162\x67\142\x61\50\61\x32\60\54\x20\62\60\x30\54\40\x32\x33\60\54\40\x30\56\x36\x29\40\151\156\163\x65\164\73\143\157\x6c\x6f\162\x3a\40\x23\106\106\x46\x3b\42\164\171\160\x65\75\x22\142\x75\x74\164\157\156\x22\x20\166\141\x6c\x75\145\x3d\x22\104\x6f\156\x65\42\x20\x6f\156\103\x6c\151\x63\x6b\75\x22\x73\145\154\x66\x2e\x63\154\157\163\145\50\51\73\42\x3e\x3c\57\x64\x69\166\76";
    exit;
    v_R:
}
function addLink($Uf, $Cv)
{
    $TS = "\x3c\x61\x20\x68\162\145\146\75\42" . $Cv . "\42\76" . $Uf . "\x3c\57\x61\76";
    return $TS;
}
function get_status_message($W8)
{
    switch ($W8) {
        case "\122\145\x71\x75\x65\163\164\145\x72":
            return "\x54\150\x65\40\x72\x65\x71\165\x65\163\164\x20\143\157\x75\154\x64\x20\156\157\164\40\x62\145\x20\x70\x65\162\146\157\x72\x6d\x65\x64\x20\x64\x75\145\40\164\157\40\141\x6e\40\x65\x72\x72\x6f\x72\40\x6f\156\x20\x74\150\x65\x20\x70\141\x72\164\x20\x6f\x66\x20\x74\150\x65\40\162\x65\x71\x75\x65\163\x74\x65\162\x2e";
            goto b6Q;
        case "\122\x65\x73\160\157\x6e\x64\145\x72":
            return "\124\150\145\40\162\145\161\x75\x65\163\164\40\143\157\x75\154\x64\x20\156\157\x74\x20\x62\145\x20\160\145\162\146\157\x72\155\145\x64\40\144\x75\x65\40\x74\x6f\x20\141\x6e\x20\145\x72\x72\157\x72\40\157\156\x20\x74\150\145\40\160\x61\162\x74\40\x6f\146\40\x74\x68\145\x20\x53\101\115\114\x20\162\145\163\x70\157\x6e\144\x65\162\40\157\x72\x20\x53\101\x4d\114\40\141\x75\164\150\157\x72\151\x74\171\56";
            goto b6Q;
        case "\x56\145\x72\x73\151\x6f\156\115\x69\163\155\141\x74\143\150":
            return "\x54\150\145\40\x53\101\115\x4c\40\162\145\163\160\x6f\x6e\x64\145\162\40\x63\x6f\165\x6c\144\40\156\x6f\x74\x20\160\162\x6f\x63\145\163\163\40\164\x68\x65\40\x72\145\161\x75\145\163\x74\x20\x62\145\x63\141\x75\x73\x65\x20\164\150\145\x20\x76\x65\162\x73\151\157\x6e\x20\x6f\146\x20\x74\150\145\40\162\145\x71\x75\145\x73\164\x20\x6d\145\163\163\141\147\145\x20\x77\141\163\40\x69\x6e\x63\x6f\x72\x72\x65\x63\x74\x2e";
            goto b6Q;
        default:
            return "\x55\x6e\153\156\157\167\156";
    }
    qOu:
    b6Q:
}
function saml_get_current_page_url()
{
    $KE = $_SERVER["\110\124\x54\x50\x5f\110\x4f\x53\124"];
    if (!(substr($KE, -1) == "\x2f")) {
        goto Fp6;
    }
    $KE = substr($KE, 0, -1);
    Fp6:
    $Ap = $_SERVER["\122\105\121\x55\x45\123\124\137\125\122\111"];
    if (!(substr($Ap, 0, 1) == "\x2f")) {
        goto Ow9;
    }
    $Ap = substr($Ap, 1);
    Ow9:
    $vo = isset($_SERVER["\110\124\x54\120\x53"]) && strcasecmp($_SERVER["\x48\x54\124\x50\123"], "\157\156") == 0;
    $QB = "\150\x74\x74\160" . ($vo ? "\x73" : '') . "\x3a\x2f\x2f" . $KE . "\x2f" . $Ap;
    return $QB;
}
function get_network_site_url()
{
    $GR = network_site_url();
    if (!(substr($GR, -1) == "\57")) {
        goto X1x;
    }
    $GR = substr($GR, 0, -1);
    X1x:
    return $GR;
}
function get_current_base_url()
{
    return sprintf("\x25\x73\72\x2f\57\45\163\x2f", isset($_SERVER["\110\x54\x54\x50\123"]) && $_SERVER["\110\124\124\x50\123"] != "\x6f\146\146" ? "\x68\x74\164\x70\x73" : "\150\x74\x74\x70", $_SERVER["\110\124\124\x50\x5f\x48\x4f\123\x54"]);
}
add_action("\x77\x69\x64\147\145\x74\163\x5f\151\x6e\151\x74", function () {
    register_widget("\x6d\157\x5f\154\x6f\147\x69\156\x5f\167\151\144");
});
add_action("\x69\x6e\x69\164", "\x6d\x6f\x5f\154\x6f\x67\x69\x6e\137\x76\141\154\151\x64\x61\x74\145");
