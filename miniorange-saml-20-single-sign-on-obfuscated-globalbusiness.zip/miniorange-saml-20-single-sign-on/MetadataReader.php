<?php


include_once "\x55\164\x69\154\x69\x74\151\x65\x73\56\160\150\x70";
class MetadataReader
{
    private $identityProviders;
    private $serviceProviders;
    public function __construct(DOMNode $Th = NULL)
    {
        $this->identityProviders = array();
        $this->serviceProviders = array();
        $Yi = Utilities::xpQuery($Th, "\56\x2f\x73\141\155\154\137\155\x65\164\x61\144\x61\x74\141\72\105\156\164\151\164\x69\x65\x73\x44\x65\163\x63\x72\x69\x70\x74\157\x72");
        if (!empty($Yi)) {
            goto cG;
        }
        $RL = Utilities::xpQuery($Th, "\x2e\57\163\x61\x6d\x6c\x5f\x6d\x65\x74\x61\x64\141\164\141\x3a\x45\156\x74\x69\x74\171\x44\145\163\143\x72\151\x70\x74\157\x72");
        goto xJ;
        cG:
        $RL = Utilities::xpQuery($Yi[0], "\x2e\x2f\x73\141\155\x6c\x5f\x6d\145\x74\141\x64\x61\164\141\x3a\x45\x6e\x74\x69\x74\x79\104\x65\x73\x63\x72\x69\160\x74\x6f\x72");
        xJ:
        foreach ($RL as $xX) {
            $kB = Utilities::xpQuery($xX, "\56\57\x73\141\x6d\154\x5f\155\x65\x74\141\x64\x61\x74\141\72\111\104\x50\123\123\x4f\x44\145\163\x63\162\x69\x70\164\x6f\x72");
            if (!(isset($kB) && !empty($kB))) {
                goto ZVS;
            }
            array_push($this->identityProviders, new IdentityProviders($xX));
            ZVS:
            xc:
        }
        bd:
    }
    public function getIdentityProviders()
    {
        return $this->identityProviders;
    }
    public function getServiceProviders()
    {
        return $this->serviceProviders;
    }
}
class IdentityProviders
{
    private $idpName;
    private $entityID;
    private $loginDetails;
    private $logoutDetails;
    private $signingCertificate;
    private $encryptionCertificate;
    private $signedRequest;
    private $loginbinding;
    private $logoutbinding;
    public function __construct(DOMElement $Th = NULL)
    {
        $this->idpName = '';
        $this->loginDetails = array();
        $this->logoutDetails = array();
        $this->signingCertificate = array();
        $this->encryptionCertificate = array();
        if (!$Th->hasAttribute("\x65\156\164\151\164\x79\x49\x44")) {
            goto Xa6;
        }
        $this->entityID = $Th->getAttribute("\145\156\x74\151\x74\171\x49\x44");
        Xa6:
        if (!$Th->hasAttribute("\x57\x61\156\164\101\x75\164\150\156\122\x65\161\165\x65\163\164\163\x53\x69\147\156\x65\x64")) {
            goto F1d;
        }
        $this->signedRequest = $Th->getAttribute("\127\x61\x6e\x74\x41\x75\x74\150\156\x52\145\x71\165\145\163\164\x73\x53\151\x67\156\145\x64");
        F1d:
        $kB = Utilities::xpQuery($Th, "\56\x2f\x73\x61\x6d\x6c\137\155\145\x74\141\144\141\x74\x61\72\111\104\x50\x53\x53\117\104\x65\163\x63\162\151\160\x74\x6f\x72");
        if (count($kB) > 1) {
            goto KkQ;
        }
        if (empty($kB)) {
            goto INi;
        }
        goto KYc;
        KkQ:
        throw new Exception("\115\157\162\x65\40\164\150\x61\x6e\40\x6f\x6e\145\x20\74\x49\104\120\123\123\x4f\104\145\x73\143\162\x69\160\164\157\x72\x3e\x20\x69\x6e\x20\74\x45\156\164\151\164\x79\104\145\163\143\162\x69\x70\164\x6f\x72\76\x2e");
        goto KYc;
        INi:
        throw new Exception("\x4d\x69\x73\x73\151\x6e\x67\x20\162\x65\161\x75\151\162\x65\144\x20\x3c\x49\x44\120\x53\123\x4f\104\x65\163\x63\x72\x69\160\x74\157\162\76\40\151\x6e\40\x3c\x45\x6e\164\151\164\171\x44\145\163\143\x72\151\x70\164\x6f\162\x3e\56");
        KYc:
        $R9 = $kB[0];
        $RP = Utilities::xpQuery($Th, "\56\57\163\x61\155\154\x5f\x6d\145\x74\141\144\x61\x74\141\72\105\x78\164\145\156\163\x69\x6f\156\163");
        if (!$RP) {
            goto Exk;
        }
        $this->parseInfo($R9);
        Exk:
        $this->parseSSOService($R9);
        $this->parseSLOService($R9);
        $this->parsex509Certificate($R9);
    }
    private function parseInfo($Th)
    {
        $CF = Utilities::xpQuery($Th, "\x2e\57\x6d\144\x75\x69\x3a\x55\x49\x49\x6e\x66\x6f\57\x6d\144\165\151\72\x44\x69\163\x70\154\141\171\x4e\x61\155\145");
        foreach ($CF as $Wu) {
            if (!($Wu->hasAttribute("\x78\155\154\72\x6c\141\156\147") && $Wu->getAttribute("\170\x6d\x6c\x3a\154\x61\156\147") == "\145\x6e")) {
                goto R8h;
            }
            $this->idpName = $Wu->textContent;
            R8h:
            JES:
        }
        nkL:
    }
    private function parseSSOService($Th)
    {
        $H1 = Utilities::xpQuery($Th, "\x2e\x2f\x73\141\155\x6c\x5f\x6d\x65\164\x61\144\141\x74\x61\72\123\x69\x6e\147\154\x65\x53\x69\x67\156\x4f\x6e\123\x65\x72\166\x69\143\145");
        $KZ = 0;
        foreach ($H1 as $zC) {
            $K0 = str_replace("\165\162\x6e\x3a\x6f\x61\x73\151\163\72\156\141\x6d\x65\163\72\x74\x63\72\123\101\x4d\114\72\x32\56\x30\72\x62\x69\x6e\x64\151\156\147\x73\x3a", '', $zC->getAttribute("\102\x69\x6e\144\151\x6e\x67"));
            $this->loginDetails = array_merge($this->loginDetails, array($K0 => $zC->getAttribute("\114\157\x63\x61\x74\x69\x6f\156")));
            if (!($K0 == "\110\x54\124\120\x2d\x52\x65\144\151\x72\145\143\164")) {
                goto IDe;
            }
            $KZ = 1;
            $this->loginbinding = "\110\x74\x74\160\x52\145\x64\151\162\x65\x63\164";
            IDe:
            kpV:
        }
        GNv:
        if ($KZ) {
            goto TlW;
        }
        $this->loginbinding = "\x48\164\164\x70\120\x6f\x73\164";
        TlW:
    }
    private function parseSLOService($Th)
    {
        $KZ = 0;
        $FZ = Utilities::xpQuery($Th, "\x2e\x2f\x73\141\x6d\154\x5f\155\x65\164\141\144\x61\x74\141\72\123\x69\156\x67\154\145\x4c\157\x67\157\x75\x74\123\145\x72\x76\x69\x63\145");
        foreach ($FZ as $gL) {
            $K0 = str_replace("\x75\162\x6e\72\157\141\x73\x69\163\72\x6e\x61\x6d\x65\163\72\164\143\x3a\123\101\x4d\114\72\x32\56\x30\x3a\x62\x69\156\x64\151\156\147\163\72", '', $gL->getAttribute("\102\x69\156\144\x69\156\x67"));
            $this->logoutDetails = array_merge($this->logoutDetails, array($K0 => $gL->getAttribute("\x4c\x6f\x63\141\164\x69\157\x6e")));
            if (!($K0 == "\x48\x54\124\x50\x2d\x52\145\x64\x69\x72\x65\x63\x74")) {
                goto LV7;
            }
            $KZ = 1;
            $this->logoutbinding = "\110\164\x74\x70\x52\x65\144\151\162\x65\x63\x74";
            LV7:
            G7D:
        }
        JKF:
        if (!empty($this->logoutbinding)) {
            goto zIV;
        }
        $this->logoutbinding = "\110\164\164\x70\x50\157\163\164";
        zIV:
    }
    private function parsex509Certificate($Th)
    {
        foreach (Utilities::xpQuery($Th, "\56\x2f\x73\x61\155\154\137\x6d\145\x74\141\x64\141\164\x61\72\x4b\x65\171\104\145\163\143\x72\151\x70\164\x6f\162") as $pk) {
            if ($pk->hasAttribute("\x75\163\x65")) {
                goto xIA;
            }
            $this->parseSigningCertificate($pk);
            goto hPN;
            xIA:
            if ($pk->getAttribute("\165\163\145") == "\x65\156\143\162\x79\x70\164\x69\x6f\156") {
                goto X1u;
            }
            $this->parseSigningCertificate($pk);
            goto CgV;
            X1u:
            $this->parseEncryptionCertificate($pk);
            CgV:
            hPN:
            aWR:
        }
        o4N:
    }
    private function parseSigningCertificate($Th)
    {
        $f7 = Utilities::xpQuery($Th, "\x2e\57\x64\x73\x3a\113\x65\171\x49\156\146\157\57\x64\x73\72\x58\x35\60\71\x44\141\164\x61\x2f\x64\x73\x3a\x58\x35\x30\x39\103\145\x72\164\x69\x66\151\x63\141\164\145");
        $bj = trim($f7[0]->textContent);
        $bj = str_replace(array("\15", "\xa", "\x9", "\x20"), '', $bj);
        if (empty($f7)) {
            goto ON5;
        }
        array_push($this->signingCertificate, $bj);
        ON5:
    }
    private function parseEncryptionCertificate($Th)
    {
        $f7 = Utilities::xpQuery($Th, "\56\57\144\163\x3a\x4b\145\x79\111\x6e\x66\157\57\x64\163\x3a\130\65\x30\71\x44\x61\x74\141\57\x64\x73\x3a\130\x35\60\x39\x43\x65\162\x74\151\146\151\x63\x61\164\x65");
        $bj = trim($f7[0]->textContent);
        $bj = str_replace(array("\15", "\12", "\x9", "\40"), '', $bj);
        if (empty($f7)) {
            goto nCG;
        }
        array_push($this->encryptionCertificate, $bj);
        nCG:
    }
    public function getIdpName()
    {
        return $this->idpName;
    }
    public function getEntityID()
    {
        return $this->entityID;
    }
    public function getLoginURL($K0)
    {
        return $this->loginDetails[$K0];
    }
    public function getLogoutURL($K0)
    {
        return $this->logoutDetails[$K0];
    }
    public function getLoginDetails()
    {
        return $this->loginDetails;
    }
    public function getLogoutDetails()
    {
        return $this->logoutDetails;
    }
    public function getSigningCertificate()
    {
        return $this->signingCertificate;
    }
    public function getEncryptionCertificate()
    {
        return $this->encryptionCertificate[0];
    }
    public function isRequestSigned()
    {
        return $this->signedRequest;
    }
    public function getBindingLogin()
    {
        return $this->loginbinding;
    }
    public function getBindingLogout()
    {
        return $this->logoutbinding;
    }
}
class ServiceProviders
{
}
