<?php


abstract class BasicEnum
{
    private static $constCacheArray = NULL;
    public static function getConstants()
    {
        if (!(self::$constCacheArray == NULL)) {
            goto CK;
        }
        self::$constCacheArray = array();
        CK:
        $Es = get_called_class();
        if (array_key_exists($Es, self::$constCacheArray)) {
            goto VD;
        }
        $RV = new ReflectionClass($Es);
        self::$constCacheArray[$Es] = $RV->getConstants();
        VD:
        return self::$constCacheArray[$Es];
    }
    public static function isValidName($Wu, $P4 = false)
    {
        $dk = self::getConstants();
        if (!$P4) {
            goto Xb;
        }
        return array_key_exists($Wu, $dk);
        Xb:
        $EE = array_map("\163\x74\x72\x74\x6f\x6c\157\167\145\x72", array_keys($dk));
        return in_array(strtolower($Wu), $EE);
    }
    public static function isValidValue($n5, $P4 = true)
    {
        $rj = array_values(self::getConstants());
        return in_array($n5, $rj, $P4);
    }
}
