<?php


namespace RobRichards\XMLSecLibs\Utils;

class XPath
{
    const ALPHANUMERIC = "\x5c\167\x5c\144";
    const NUMERIC = "\x5c\x64";
    const LETTERS = "\134\167";
    const EXTENDED_ALPHANUMERIC = "\134\x77\134\x64\x5c\163\x5c\55\137\x3a\x5c\x2e";
    const SINGLE_QUOTE = "\47";
    const DOUBLE_QUOTE = "\x22";
    const ALL_QUOTES = "\133\47\42\x5d";
    public static function filterAttrValue($n5, $TP = self::ALL_QUOTES)
    {
        return preg_replace("\43" . $TP . "\43", '', $n5);
    }
    public static function filterAttrName($Wu, $KD = self::EXTENDED_ALPHANUMERIC)
    {
        return preg_replace("\43\133\x5e" . $KD . "\x5d\x23", '', $Wu);
    }
}
