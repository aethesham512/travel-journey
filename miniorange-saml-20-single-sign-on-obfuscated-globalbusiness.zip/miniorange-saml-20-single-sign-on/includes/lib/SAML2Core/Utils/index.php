<?php


if (defined("\127\x50\111\116\x43")) {
    goto CT;
}
die;
CT:
