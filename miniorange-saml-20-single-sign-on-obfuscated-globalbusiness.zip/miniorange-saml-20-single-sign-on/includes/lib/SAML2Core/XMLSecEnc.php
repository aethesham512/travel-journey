<?php


namespace RobRichards\XMLSecLibs;

use DOMDocument;
use DOMNode;
use DOMXPath;
use Exception;
use RobRichards\XMLSecLibs\Utils\XPath as XPath;
class XMLSecEnc
{
    const template = "\x3c\170\145\156\143\x3a\x45\156\143\x72\171\160\x74\145\x64\x44\141\164\x61\40\170\155\154\x6e\163\72\170\145\x6e\x63\75\x27\150\164\164\x70\x3a\x2f\x2f\x77\x77\x77\56\x77\63\x2e\157\162\147\x2f\x32\60\60\x31\x2f\x30\x34\x2f\x78\x6d\154\x65\x6e\x63\x23\47\x3e\xd\xa\40\40\40\x3c\170\145\x6e\x63\72\x43\151\x70\150\145\162\x44\x61\x74\141\76\15\xa\40\40\x20\x20\x20\x20\x3c\x78\x65\156\143\x3a\x43\151\160\x68\145\x72\126\141\x6c\165\x65\76\x3c\x2f\x78\x65\156\143\x3a\x43\x69\160\150\x65\162\x56\141\154\165\145\x3e\xd\12\x20\40\40\x3c\57\x78\145\x6e\143\72\x43\x69\x70\150\x65\x72\x44\141\x74\x61\76\xd\xa\74\57\170\145\x6e\x63\72\x45\156\x63\x72\x79\x70\164\x65\x64\x44\x61\164\x61\x3e";
    const Element = "\150\164\164\x70\72\x2f\x2f\x77\x77\167\x2e\x77\63\x2e\x6f\162\147\x2f\62\60\60\x31\57\60\x34\x2f\170\155\154\x65\156\143\x23\x45\154\145\155\145\156\x74";
    const Content = "\150\164\164\160\72\57\x2f\x77\x77\167\56\x77\63\x2e\157\x72\x67\x2f\x32\x30\60\61\x2f\x30\64\x2f\170\155\x6c\145\x6e\x63\43\x43\157\x6e\164\145\x6e\164";
    const URI = 3;
    const XMLENCNS = "\150\x74\x74\160\72\x2f\57\167\x77\x77\56\x77\63\56\157\x72\147\57\62\60\x30\61\x2f\60\64\57\x78\x6d\x6c\145\156\x63\43";
    private $encdoc = null;
    private $rawNode = null;
    public $type = null;
    public $encKey = null;
    private $references = array();
    public function __construct()
    {
        $this->_resetTemplate();
    }
    private function _resetTemplate()
    {
        $this->encdoc = new DOMDocument();
        $this->encdoc->loadXML(self::template);
    }
    public function addReference($Wu, $Vf, $AG)
    {
        if ($Vf instanceof DOMNode) {
            goto JY;
        }
        throw new Exception("\x24\x6e\157\144\145\x20\151\x73\x20\156\157\164\40\x6f\146\40\164\171\160\x65\x20\104\117\x4d\x4e\x6f\144\145");
        JY:
        $we = $this->encdoc;
        $this->_resetTemplate();
        $mN = $this->encdoc;
        $this->encdoc = $we;
        $kn = XMLSecurityDSig::generateGUID();
        $RR = $mN->documentElement;
        $RR->setAttribute("\111\144", $kn);
        $this->references[$Wu] = array("\x6e\x6f\x64\145" => $Vf, "\x74\x79\x70\x65" => $AG, "\145\156\143\156\x6f\144\x65" => $mN, "\162\x65\146\x75\x72\151" => $kn);
    }
    public function setNode($Vf)
    {
        $this->rawNode = $Vf;
    }
    public function encryptNode($u8, $Ak = true)
    {
        $UF = '';
        if (!empty($this->rawNode)) {
            goto SP;
        }
        throw new Exception("\116\x6f\144\x65\40\164\x6f\x20\x65\x6e\x63\x72\x79\160\164\x20\x68\141\163\40\x6e\157\x74\40\x62\x65\x65\x6e\x20\x73\x65\164");
        SP:
        if ($u8 instanceof XMLSecurityKey) {
            goto kH;
        }
        throw new Exception("\111\156\166\x61\x6c\x69\x64\x20\x4b\145\171");
        kH:
        $Pj = $this->rawNode->ownerDocument;
        $VY = new DOMXPath($this->encdoc);
        $M4 = $VY->query("\57\170\x65\156\143\x3a\105\156\143\162\x79\160\x74\x65\144\x44\141\x74\x61\x2f\170\x65\156\143\x3a\x43\x69\x70\x68\x65\x72\x44\x61\164\141\57\x78\145\156\143\x3a\103\x69\160\150\145\162\x56\141\x6c\x75\145");
        $yS = $M4->item(0);
        if (!($yS == null)) {
            goto fx;
        }
        throw new Exception("\105\x72\162\157\x72\x20\x6c\157\x63\141\x74\151\x6e\x67\x20\x43\151\x70\x68\x65\162\x56\x61\154\x75\x65\x20\145\x6c\145\155\145\x6e\x74\x20\167\151\164\150\151\156\40\164\x65\155\x70\x6c\x61\x74\x65");
        fx:
        switch ($this->type) {
            case self::Element:
                $UF = $Pj->saveXML($this->rawNode);
                $this->encdoc->documentElement->setAttribute("\x54\171\160\145", self::Element);
                goto tw;
            case self::Content:
                $D1 = $this->rawNode->childNodes;
                foreach ($D1 as $Yn) {
                    $UF .= $Pj->saveXML($Yn);
                    Rz:
                }
                tW:
                $this->encdoc->documentElement->setAttribute("\x54\x79\160\145", self::Content);
                goto tw;
            default:
                throw new Exception("\x54\x79\x70\145\x20\151\x73\x20\x63\x75\x72\162\145\x6e\x74\154\171\40\156\x6f\x74\x20\163\x75\160\x70\x6f\x72\164\x65\x64");
        }
        qx:
        tw:
        $X2 = $this->encdoc->documentElement->appendChild($this->encdoc->createElementNS(self::XMLENCNS, "\170\145\x6e\143\72\x45\x6e\143\162\x79\x70\164\151\157\156\x4d\145\164\x68\157\144"));
        $X2->setAttribute("\x41\x6c\147\157\x72\x69\x74\150\x6d", $u8->getAlgorithm());
        $yS->parentNode->parentNode->insertBefore($X2, $yS->parentNode->parentNode->firstChild);
        $Fg = base64_encode($u8->encryptData($UF));
        $n5 = $this->encdoc->createTextNode($Fg);
        $yS->appendChild($n5);
        if ($Ak) {
            goto C9;
        }
        return $this->encdoc->documentElement;
        goto mk;
        C9:
        switch ($this->type) {
            case self::Element:
                if (!($this->rawNode->nodeType == XML_DOCUMENT_NODE)) {
                    goto bO;
                }
                return $this->encdoc;
                bO:
                $kC = $this->rawNode->ownerDocument->importNode($this->encdoc->documentElement, true);
                $this->rawNode->parentNode->replaceChild($kC, $this->rawNode);
                return $kC;
            case self::Content:
                $kC = $this->rawNode->ownerDocument->importNode($this->encdoc->documentElement, true);
                vD:
                if (!$this->rawNode->firstChild) {
                    goto z3;
                }
                $this->rawNode->removeChild($this->rawNode->firstChild);
                goto vD;
                z3:
                $this->rawNode->appendChild($kC);
                return $kC;
        }
        IM:
        TC:
        mk:
    }
    public function encryptReferences($u8)
    {
        $q2 = $this->rawNode;
        $hs = $this->type;
        foreach ($this->references as $Wu => $sF) {
            $this->encdoc = $sF["\x65\x6e\x63\x6e\157\144\x65"];
            $this->rawNode = $sF["\156\x6f\144\145"];
            $this->type = $sF["\164\171\x70\x65"];
            try {
                $t8 = $this->encryptNode($u8);
                $this->references[$Wu]["\x65\156\x63\156\x6f\x64\x65"] = $t8;
            } catch (Exception $jB) {
                $this->rawNode = $q2;
                $this->type = $hs;
                throw $jB;
            }
            H1:
        }
        kP:
        $this->rawNode = $q2;
        $this->type = $hs;
    }
    public function getCipherValue()
    {
        if (!empty($this->rawNode)) {
            goto lC;
        }
        throw new Exception("\x4e\157\144\145\x20\x74\157\40\144\145\x63\x72\x79\160\x74\40\x68\141\x73\40\156\157\164\40\x62\145\x65\156\x20\163\145\164");
        lC:
        $Pj = $this->rawNode->ownerDocument;
        $VY = new DOMXPath($Pj);
        $VY->registerNamespace("\170\x6d\x6c\x65\x6e\x63\162", self::XMLENCNS);
        $nv = "\56\57\x78\x6d\x6c\x65\156\143\162\x3a\x43\x69\x70\x68\x65\162\104\x61\x74\x61\57\x78\x6d\154\145\x6e\143\x72\72\103\151\160\150\145\x72\x56\x61\154\165\x65";
        $Rb = $VY->query($nv, $this->rawNode);
        $Vf = $Rb->item(0);
        if ($Vf) {
            goto c_;
        }
        return null;
        c_:
        return base64_decode($Vf->nodeValue);
    }
    public function decryptNode($u8, $Ak = true)
    {
        if ($u8 instanceof XMLSecurityKey) {
            goto O6;
        }
        throw new Exception("\111\x6e\166\141\x6c\x69\144\x20\x4b\145\171");
        O6:
        $h3 = $this->getCipherValue();
        if ($h3) {
            goto he;
        }
        throw new Exception("\x43\141\156\156\157\x74\x20\154\157\143\x61\x74\145\x20\145\x6e\x63\x72\171\x70\x74\145\144\40\144\141\164\141");
        goto a1;
        he:
        $Vc = $u8->decryptData($h3);
        if ($Ak) {
            goto Ij;
        }
        return $Vc;
        goto Cy;
        Ij:
        switch ($this->type) {
            case self::Element:
                $K8 = new DOMDocument();
                $K8->loadXML($Vc);
                if (!($this->rawNode->nodeType == XML_DOCUMENT_NODE)) {
                    goto F_;
                }
                return $K8;
                F_:
                $kC = $this->rawNode->ownerDocument->importNode($K8->documentElement, true);
                $this->rawNode->parentNode->replaceChild($kC, $this->rawNode);
                return $kC;
            case self::Content:
                if ($this->rawNode->nodeType == XML_DOCUMENT_NODE) {
                    goto ZT;
                }
                $Pj = $this->rawNode->ownerDocument;
                goto OT;
                ZT:
                $Pj = $this->rawNode;
                OT:
                $ua = $Pj->createDocumentFragment();
                $ua->appendXML($Vc);
                $V7 = $this->rawNode->parentNode;
                $V7->replaceChild($ua, $this->rawNode);
                return $V7;
            default:
                return $Vc;
        }
        xQ:
        Db:
        Cy:
        a1:
    }
    public function encryptKey($CS, $qT, $Qo = true)
    {
        if (!(!$CS instanceof XMLSecurityKey || !$qT instanceof XMLSecurityKey)) {
            goto B9;
        }
        throw new Exception("\111\x6e\x76\x61\154\x69\x64\x20\113\x65\171");
        B9:
        $cR = base64_encode($CS->encryptData($qT->key));
        $ym = $this->encdoc->documentElement;
        $hl = $this->encdoc->createElementNS(self::XMLENCNS, "\170\x65\x6e\143\x3a\105\156\x63\162\171\x70\x74\x65\x64\113\x65\171");
        if ($Qo) {
            goto vf;
        }
        $this->encKey = $hl;
        goto ta;
        vf:
        $En = $ym->insertBefore($this->encdoc->createElementNS("\x68\x74\x74\160\72\57\x2f\x77\x77\x77\x2e\x77\63\x2e\157\162\147\57\x32\60\x30\60\57\x30\71\x2f\x78\155\x6c\144\x73\151\147\43", "\144\x73\x69\147\x3a\113\x65\171\111\x6e\146\157"), $ym->firstChild);
        $En->appendChild($hl);
        ta:
        $X2 = $hl->appendChild($this->encdoc->createElementNS(self::XMLENCNS, "\170\145\156\x63\72\x45\x6e\143\162\171\160\x74\151\157\156\x4d\145\x74\x68\157\144"));
        $X2->setAttribute("\101\154\x67\x6f\x72\151\x74\x68\x6d", $CS->getAlgorith());
        if (empty($CS->name)) {
            goto KY;
        }
        $En = $hl->appendChild($this->encdoc->createElementNS("\x68\x74\x74\x70\72\57\x2f\167\x77\167\x2e\x77\63\56\157\162\147\57\62\60\x30\x30\x2f\60\x39\x2f\170\x6d\154\x64\163\151\147\43", "\144\163\x69\x67\x3a\113\145\x79\111\156\x66\x6f"));
        $En->appendChild($this->encdoc->createElementNS("\150\164\164\x70\72\x2f\57\167\167\x77\56\167\x33\x2e\157\x72\147\57\62\x30\60\x30\57\60\x39\57\x78\x6d\154\144\x73\x69\147\x23", "\x64\163\x69\147\x3a\x4b\145\171\x4e\141\155\145", $CS->name));
        KY:
        $zY = $hl->appendChild($this->encdoc->createElementNS(self::XMLENCNS, "\x78\x65\x6e\143\72\x43\x69\x70\150\x65\x72\x44\141\164\141"));
        $zY->appendChild($this->encdoc->createElementNS(self::XMLENCNS, "\170\145\x6e\x63\x3a\103\151\x70\150\x65\x72\126\x61\x6c\x75\145", $cR));
        if (!(is_array($this->references) && count($this->references) > 0)) {
            goto xT;
        }
        $d8 = $hl->appendChild($this->encdoc->createElementNS(self::XMLENCNS, "\x78\x65\x6e\143\x3a\x52\145\146\x65\x72\x65\156\x63\x65\114\151\x73\164"));
        foreach ($this->references as $Wu => $sF) {
            $kn = $sF["\x72\145\x66\x75\162\x69"];
            $Sp = $d8->appendChild($this->encdoc->createElementNS(self::XMLENCNS, "\170\x65\156\143\x3a\104\x61\164\x61\x52\x65\146\145\x72\145\156\x63\145"));
            $Sp->setAttribute("\x55\x52\x49", "\43" . $kn);
            b0:
        }
        pU:
        xT:
        return;
    }
    public function decryptKey($hl)
    {
        if ($hl->isEncrypted) {
            goto i8;
        }
        throw new Exception("\x4b\145\171\40\151\163\40\x6e\157\164\x20\x45\156\x63\162\171\x70\164\145\x64");
        i8:
        if (!empty($hl->key)) {
            goto XY;
        }
        throw new Exception("\113\145\x79\40\x69\x73\x20\x6d\x69\163\163\x69\156\x67\40\x64\141\x74\x61\40\x74\x6f\x20\160\145\162\x66\157\162\x6d\x20\164\x68\x65\40\x64\145\x63\x72\171\160\x74\x69\157\x6e");
        XY:
        return $this->decryptNode($hl, false);
    }
    public function locateEncryptedData($RR)
    {
        if ($RR instanceof DOMDocument) {
            goto U6;
        }
        $Pj = $RR->ownerDocument;
        goto wS;
        U6:
        $Pj = $RR;
        wS:
        if (!$Pj) {
            goto XR;
        }
        $Mn = new DOMXPath($Pj);
        $nv = "\x2f\x2f\52\x5b\154\x6f\x63\141\154\55\156\141\x6d\x65\x28\x29\x3d\47\105\x6e\x63\162\x79\160\x74\145\144\x44\x61\x74\141\47\x20\141\156\x64\x20\x6e\x61\155\145\x73\160\141\143\145\x2d\165\x72\151\50\x29\x3d\47" . self::XMLENCNS . "\x27\135";
        $Rb = $Mn->query($nv);
        return $Rb->item(0);
        XR:
        return null;
    }
    public function locateKey($Vf = null)
    {
        if (!empty($Vf)) {
            goto j1;
        }
        $Vf = $this->rawNode;
        j1:
        if ($Vf instanceof DOMNode) {
            goto Ru;
        }
        return null;
        Ru:
        if (!($Pj = $Vf->ownerDocument)) {
            goto r9;
        }
        $Mn = new DOMXPath($Pj);
        $Mn->registerNamespace("\x78\155\x6c\x73\145\x63\x65\156\143", self::XMLENCNS);
        $nv = "\x2e\x2f\57\170\x6d\x6c\x73\145\143\x65\x6e\x63\x3a\105\156\143\x72\171\160\164\x69\x6f\156\x4d\145\164\x68\157\144";
        $Rb = $Mn->query($nv, $Vf);
        if (!($mL = $Rb->item(0))) {
            goto WW;
        }
        $YS = $mL->getAttribute("\x41\x6c\147\157\x72\151\x74\150\x6d");
        try {
            $u8 = new XMLSecurityKey($YS, array("\164\171\x70\145" => "\160\162\x69\166\141\164\x65"));
        } catch (Exception $jB) {
            return null;
        }
        return $u8;
        WW:
        r9:
        return null;
    }
    public static function staticLocateKeyInfo($v1 = null, $Vf = null)
    {
        if (!(empty($Vf) || !$Vf instanceof DOMNode)) {
            goto dW;
        }
        return null;
        dW:
        $Pj = $Vf->ownerDocument;
        if ($Pj) {
            goto fD;
        }
        return null;
        fD:
        $Mn = new DOMXPath($Pj);
        $Mn->registerNamespace("\x78\155\x6c\163\x65\x63\x65\x6e\143", self::XMLENCNS);
        $Mn->registerNamespace("\x78\x6d\x6c\x73\145\143\x64\x73\x69\147", XMLSecurityDSig::XMLDSIGNS);
        $nv = "\x2e\x2f\170\155\x6c\163\145\x63\x64\x73\151\147\72\x4b\145\171\111\x6e\146\157";
        $Rb = $Mn->query($nv, $Vf);
        $mL = $Rb->item(0);
        if ($mL) {
            goto kq;
        }
        return $v1;
        kq:
        foreach ($mL->childNodes as $Yn) {
            switch ($Yn->localName) {
                case "\113\x65\171\116\x61\x6d\x65":
                    if (empty($v1)) {
                        goto NT;
                    }
                    $v1->name = $Yn->nodeValue;
                    NT:
                    goto LP;
                case "\x4b\145\171\126\141\x6c\165\x65":
                    foreach ($Yn->childNodes as $rx) {
                        switch ($rx->localName) {
                            case "\104\x53\x41\113\145\x79\x56\141\154\165\x65":
                                throw new Exception("\x44\x53\101\113\x65\x79\126\141\154\165\145\40\x63\165\162\x72\145\x6e\x74\x6c\171\x20\156\157\x74\40\163\165\x70\160\x6f\x72\x74\145\x64");
                            case "\122\x53\101\x4b\145\171\126\x61\x6c\x75\x65":
                                $e1 = null;
                                $a1 = null;
                                if (!($mf = $rx->getElementsByTagName("\115\157\x64\165\x6c\x75\x73")->item(0))) {
                                    goto a5;
                                }
                                $e1 = base64_decode($mf->nodeValue);
                                a5:
                                if (!($Ng = $rx->getElementsByTagName("\105\170\160\x6f\x6e\x65\x6e\164")->item(0))) {
                                    goto Ze;
                                }
                                $a1 = base64_decode($Ng->nodeValue);
                                Ze:
                                if (!(empty($e1) || empty($a1))) {
                                    goto fd;
                                }
                                throw new Exception("\115\x69\163\x73\x69\x6e\147\40\x4d\x6f\144\165\154\x75\x73\x20\x6f\162\40\105\170\160\x6f\x6e\145\x6e\164");
                                fd:
                                $GY = XMLSecurityKey::convertRSA($e1, $a1);
                                $v1->loadKey($GY);
                                goto bp;
                        }
                        B0:
                        bp:
                        VJ:
                    }
                    RI:
                    goto LP;
                case "\x52\x65\x74\162\151\145\166\141\x6c\x4d\145\164\150\x6f\x64":
                    $AG = $Yn->getAttribute("\124\x79\x70\145");
                    if (!($AG !== "\x68\x74\x74\160\x3a\x2f\x2f\x77\167\167\56\167\x33\56\157\162\147\x2f\62\60\60\x31\57\60\x34\57\170\155\154\x65\156\143\43\x45\156\143\162\x79\x70\x74\x65\144\x4b\x65\x79")) {
                        goto Aq;
                    }
                    goto LP;
                    Aq:
                    $gr = $Yn->getAttribute("\x55\122\x49");
                    if (!($gr[0] !== "\43")) {
                        goto Yq;
                    }
                    goto LP;
                    Yq:
                    $oH = substr($gr, 1);
                    $nv = "\x2f\x2f\x78\155\x6c\163\x65\x63\145\x6e\x63\x3a\x45\x6e\143\x72\x79\x70\164\x65\144\x4b\x65\x79\x5b\100\x49\144\75\42" . XPath::filterAttrValue($oH, XPath::DOUBLE_QUOTE) . "\x22\135";
                    $LP = $Mn->query($nv)->item(0);
                    if ($LP) {
                        goto cB;
                    }
                    throw new Exception("\x55\x6e\x61\x62\154\145\x20\164\x6f\x20\x6c\157\143\141\x74\145\x20\105\x6e\x63\162\171\x70\x74\x65\x64\113\145\171\x20\x77\x69\x74\150\x20\x40\111\144\75\47{$oH}\47\x2e");
                    cB:
                    return XMLSecurityKey::fromEncryptedKeyElement($LP);
                case "\105\156\x63\162\171\x70\164\x65\144\x4b\x65\x79":
                    return XMLSecurityKey::fromEncryptedKeyElement($Yn);
                case "\x58\65\60\71\x44\141\x74\x61":
                    if (!($ah = $Yn->getElementsByTagName("\x58\x35\x30\71\x43\x65\162\164\151\146\151\x63\141\x74\x65"))) {
                        goto Vi;
                    }
                    if (!($ah->length > 0)) {
                        goto YR;
                    }
                    $dJ = $ah->item(0)->textContent;
                    $dJ = str_replace(array("\xd", "\xa", "\x20"), '', $dJ);
                    $dJ = "\x2d\55\55\x2d\55\102\105\x47\x49\x4e\x20\x43\105\122\x54\x49\106\111\x43\101\124\105\x2d\55\55\x2d\x2d\xa" . chunk_split($dJ, 64, "\xa") . "\x2d\x2d\x2d\55\55\x45\x4e\x44\40\x43\x45\x52\x54\111\x46\x49\103\x41\124\105\x2d\x2d\x2d\55\x2d\xa";
                    $v1->loadKey($dJ, false, true);
                    YR:
                    Vi:
                    goto LP;
            }
            YC:
            LP:
            XG:
        }
        Rw:
        return $v1;
    }
    public function locateKeyInfo($v1 = null, $Vf = null)
    {
        if (!empty($Vf)) {
            goto VQ;
        }
        $Vf = $this->rawNode;
        VQ:
        return self::staticLocateKeyInfo($v1, $Vf);
    }
}
