<?php


namespace RobRichards\XMLSecLibs;

use DOMDocument;
use DOMElement;
use DOMNode;
use DOMXPath;
use Exception;
use RobRichards\XMLSecLibs\Utils\XPath as XPath;
class XMLSecurityDSig
{
    const XMLDSIGNS = "\150\x74\164\160\72\57\x2f\167\x77\x77\56\167\63\56\157\x72\147\57\x32\60\60\x30\x2f\x30\x39\57\x78\x6d\x6c\144\x73\151\x67\x23";
    const SHA1 = "\x68\x74\x74\160\72\x2f\57\x77\x77\x77\x2e\x77\63\56\157\162\x67\x2f\x32\60\x30\60\x2f\60\71\x2f\x78\155\x6c\x64\163\151\x67\x23\x73\x68\141\x31";
    const SHA256 = "\150\164\164\x70\72\x2f\57\x77\x77\x77\56\167\63\56\x6f\x72\x67\x2f\x32\x30\60\x31\x2f\60\64\57\x78\155\x6c\145\156\143\43\x73\150\x61\x32\x35\x36";
    const SHA384 = "\x68\x74\164\x70\x3a\x2f\x2f\x77\167\x77\56\167\x33\x2e\157\x72\x67\x2f\x32\60\60\61\x2f\60\64\57\170\x6d\x6c\144\163\x69\147\x2d\x6d\x6f\162\145\x23\163\150\x61\63\70\64";
    const SHA512 = "\x68\164\x74\x70\72\x2f\57\167\x77\x77\56\x77\x33\56\157\x72\147\x2f\62\60\x30\61\57\x30\64\57\170\155\154\145\156\x63\43\x73\150\x61\x35\61\x32";
    const RIPEMD160 = "\150\164\164\160\72\57\x2f\167\x77\167\x2e\x77\x33\56\x6f\162\147\x2f\x32\60\60\61\57\x30\64\57\170\155\154\145\x6e\143\x23\162\151\160\x65\155\x64\x31\x36\x30";
    const C14N = "\x68\164\164\160\72\x2f\x2f\x77\x77\x77\56\x77\63\56\x6f\x72\x67\x2f\124\x52\x2f\62\60\60\61\57\x52\105\103\x2d\170\155\154\55\143\61\x34\x6e\x2d\62\x30\60\61\60\x33\61\x35";
    const C14N_COMMENTS = "\x68\164\164\160\72\x2f\x2f\167\x77\x77\56\167\63\56\157\x72\147\57\x54\122\x2f\62\60\x30\x31\57\122\105\x43\x2d\x78\155\x6c\x2d\x63\x31\x34\x6e\55\x32\60\60\61\x30\x33\61\x35\x23\x57\x69\x74\150\103\157\155\155\x65\156\x74\163";
    const EXC_C14N = "\x68\164\164\160\x3a\x2f\x2f\167\167\167\x2e\167\63\x2e\x6f\x72\x67\57\x32\x30\x30\x31\x2f\x31\60\x2f\x78\x6d\x6c\x2d\x65\x78\143\55\x63\61\64\x6e\x23";
    const EXC_C14N_COMMENTS = "\x68\164\164\160\x3a\57\x2f\x77\x77\x77\x2e\x77\x33\56\157\x72\x67\x2f\x32\x30\x30\x31\x2f\x31\x30\x2f\170\x6d\154\55\x65\170\143\x2d\x63\61\x34\156\43\127\x69\x74\x68\103\157\x6d\x6d\145\x6e\x74\163";
    const template = "\74\x64\163\72\123\x69\x67\x6e\x61\x74\x75\162\x65\x20\170\155\x6c\x6e\x73\x3a\x64\163\x3d\x22\150\164\x74\x70\x3a\57\57\x77\x77\167\x2e\x77\x33\x2e\157\x72\x67\57\x32\x30\x30\60\57\x30\x39\57\x78\155\x6c\144\x73\151\x67\43\x22\x3e\xd\xa\40\40\74\144\x73\72\x53\x69\x67\x6e\x65\x64\x49\x6e\146\157\76\15\12\x20\x20\x20\x20\74\144\x73\x3a\123\x69\147\x6e\141\164\x75\162\x65\x4d\145\164\x68\x6f\x64\40\57\76\15\xa\40\x20\x3c\57\144\x73\x3a\123\151\x67\x6e\145\x64\111\x6e\x66\x6f\76\15\xa\x3c\57\144\x73\x3a\123\151\x67\156\141\164\165\162\145\x3e";
    const BASE_TEMPLATE = "\x3c\x53\x69\147\156\141\x74\165\162\x65\40\x78\x6d\154\156\x73\x3d\42\150\x74\x74\x70\x3a\57\57\167\x77\x77\x2e\x77\63\56\157\x72\147\x2f\x32\60\x30\x30\x2f\60\71\57\170\155\154\x64\163\151\x67\43\x22\76\xd\xa\40\40\74\x53\151\147\156\145\144\111\156\146\x6f\76\xd\12\x20\40\40\x20\x3c\123\151\147\x6e\x61\164\x75\x72\x65\115\145\164\x68\x6f\x64\x20\57\76\15\12\x20\x20\x3c\x2f\x53\x69\147\x6e\145\x64\x49\156\x66\157\76\15\xa\74\x2f\x53\151\x67\x6e\141\164\x75\x72\x65\x3e";
    public $sigNode = null;
    public $idKeys = array();
    public $idNS = array();
    private $signedInfo = null;
    private $xPathCtx = null;
    private $canonicalMethod = null;
    private $prefix = '';
    private $searchpfx = "\x73\145\143\x64\x73\151\x67";
    private $validatedNodes = null;
    public function __construct($wz = "\x64\163")
    {
        $uR = self::BASE_TEMPLATE;
        if (empty($wz)) {
            goto h9;
        }
        $this->prefix = $wz . "\x3a";
        $Mm = array("\74\123", "\x3c\x2f\x53", "\x78\x6d\154\x6e\x73\75");
        $Ak = array("\x3c{$wz}\x3a\123", "\74\x2f{$wz}\72\x53", "\x78\x6d\154\x6e\x73\72{$wz}\75");
        $uR = str_replace($Mm, $Ak, $uR);
        h9:
        $vj = new DOMDocument();
        $vj->loadXML($uR);
        $this->sigNode = $vj->documentElement;
    }
    private function resetXPathObj()
    {
        $this->xPathCtx = null;
    }
    private function getXPathObj()
    {
        if (!(empty($this->xPathCtx) && !empty($this->sigNode))) {
            goto wf;
        }
        $Mn = new DOMXPath($this->sigNode->ownerDocument);
        $Mn->registerNamespace("\x73\x65\x63\144\x73\151\x67", self::XMLDSIGNS);
        $this->xPathCtx = $Mn;
        wf:
        return $this->xPathCtx;
    }
    public static function generateGUID($wz = "\160\x66\170")
    {
        $Tq = md5(uniqid(mt_rand(), true));
        $ih = $wz . substr($Tq, 0, 8) . "\x2d" . substr($Tq, 8, 4) . "\x2d" . substr($Tq, 12, 4) . "\x2d" . substr($Tq, 16, 4) . "\x2d" . substr($Tq, 20, 12);
        return $ih;
    }
    public static function generate_GUID($wz = "\x70\x66\x78")
    {
        return self::generateGUID($wz);
    }
    public function locateSignature($LN, $Ut = 0)
    {
        if ($LN instanceof DOMDocument) {
            goto yP;
        }
        $Pj = $LN->ownerDocument;
        goto L5;
        yP:
        $Pj = $LN;
        L5:
        if (!$Pj) {
            goto pZ;
        }
        $Mn = new DOMXPath($Pj);
        $Mn->registerNamespace("\163\145\143\144\163\x69\147", self::XMLDSIGNS);
        $nv = "\56\57\x2f\x73\x65\x63\x64\163\x69\x67\x3a\123\151\147\156\141\x74\165\x72\x65";
        $Rb = $Mn->query($nv, $LN);
        $this->sigNode = $Rb->item($Ut);
        return $this->sigNode;
        pZ:
        return null;
    }
    public function createNewSignNode($Wu, $n5 = null)
    {
        $Pj = $this->sigNode->ownerDocument;
        if (!is_null($n5)) {
            goto GL;
        }
        $Vf = $Pj->createElementNS(self::XMLDSIGNS, $this->prefix . $Wu);
        goto vx;
        GL:
        $Vf = $Pj->createElementNS(self::XMLDSIGNS, $this->prefix . $Wu, $n5);
        vx:
        return $Vf;
    }
    public function setCanonicalMethod($j0)
    {
        switch ($j0) {
            case "\x68\164\x74\160\72\x2f\x2f\x77\167\167\56\167\x33\56\x6f\x72\147\57\124\122\57\62\x30\x30\x31\57\x52\x45\x43\55\x78\x6d\x6c\x2d\x63\61\64\x6e\x2d\x32\x30\x30\61\60\x33\x31\65":
            case "\150\164\164\x70\x3a\57\x2f\x77\x77\x77\56\167\63\56\157\x72\x67\x2f\x54\122\57\62\x30\60\x31\57\122\x45\x43\55\170\x6d\154\55\143\61\64\x6e\x2d\x32\x30\60\61\x30\63\x31\65\43\127\x69\164\150\x43\x6f\155\x6d\145\x6e\x74\163":
            case "\x68\164\x74\160\72\x2f\x2f\x77\x77\x77\56\167\x33\x2e\x6f\162\x67\57\x32\x30\x30\61\x2f\x31\60\x2f\x78\155\154\x2d\x65\170\143\55\x63\x31\64\x6e\43":
            case "\150\164\164\160\x3a\57\57\x77\x77\167\x2e\x77\63\x2e\157\x72\x67\x2f\x32\x30\x30\x31\x2f\61\60\57\170\x6d\x6c\55\x65\x78\x63\x2d\x63\61\x34\156\x23\127\x69\x74\x68\103\157\155\x6d\x65\156\x74\x73":
                $this->canonicalMethod = $j0;
                goto v0;
            default:
                throw new Exception("\111\x6e\x76\141\154\x69\x64\x20\x43\x61\x6e\x6f\156\x69\x63\141\154\x20\x4d\145\164\x68\157\x64");
        }
        zf:
        v0:
        if (!($Mn = $this->getXPathObj())) {
            goto Ih;
        }
        $nv = "\56\x2f" . $this->searchpfx . "\72\x53\x69\147\x6e\145\x64\x49\x6e\x66\x6f";
        $Rb = $Mn->query($nv, $this->sigNode);
        if (!($YW = $Rb->item(0))) {
            goto Ba;
        }
        $nv = "\56\x2f" . $this->searchpfx . "\x43\141\x6e\x6f\x6e\151\143\141\x6c\x69\x7a\141\x74\x69\x6f\x6e\x4d\x65\x74\150\157\144";
        $Rb = $Mn->query($nv, $YW);
        if ($sp = $Rb->item(0)) {
            goto AI;
        }
        $sp = $this->createNewSignNode("\x43\x61\x6e\157\x6e\151\143\x61\x6c\151\x7a\x61\x74\151\157\x6e\x4d\x65\164\150\157\x64");
        $YW->insertBefore($sp, $YW->firstChild);
        AI:
        $sp->setAttribute("\101\x6c\147\x6f\162\x69\164\150\x6d", $this->canonicalMethod);
        Ba:
        Ih:
    }
    private function canonicalizeData($Vf, $sX, $nY = null, $bl = null)
    {
        $WQ = false;
        $T7 = false;
        switch ($sX) {
            case "\150\x74\164\x70\x3a\x2f\57\167\x77\167\x2e\167\63\56\157\162\x67\57\x54\122\57\62\x30\60\x31\57\122\105\x43\x2d\170\155\x6c\55\143\x31\64\156\55\x32\60\60\61\x30\63\x31\65":
                $WQ = false;
                $T7 = false;
                goto MG;
            case "\x68\x74\164\x70\x3a\57\x2f\x77\x77\167\x2e\x77\63\x2e\157\x72\147\x2f\124\122\57\x32\x30\x30\x31\57\x52\x45\103\x2d\x78\155\x6c\55\143\x31\64\x6e\x2d\x32\x30\60\x31\x30\x33\x31\x35\x23\127\x69\164\150\103\x6f\155\x6d\x65\156\164\163":
                $T7 = true;
                goto MG;
            case "\x68\x74\x74\x70\x3a\x2f\57\167\167\167\56\167\63\56\x6f\162\147\x2f\x32\60\x30\61\x2f\61\x30\x2f\x78\x6d\x6c\55\x65\x78\143\55\143\x31\x34\156\x23":
                $WQ = true;
                goto MG;
            case "\150\x74\164\160\x3a\x2f\57\167\x77\x77\x2e\167\x33\x2e\x6f\162\147\x2f\62\60\60\x31\57\61\60\57\170\x6d\x6c\x2d\145\x78\143\55\143\x31\x34\156\x23\x57\151\x74\150\103\x6f\x6d\155\x65\156\164\163":
                $WQ = true;
                $T7 = true;
                goto MG;
        }
        i3:
        MG:
        if (!(is_null($nY) && $Vf instanceof DOMNode && $Vf->ownerDocument !== null && $Vf->isSameNode($Vf->ownerDocument->documentElement))) {
            goto QR;
        }
        $RR = $Vf;
        Jf:
        if (!($ex = $RR->previousSibling)) {
            goto QJ;
        }
        if (!($ex->nodeType == XML_PI_NODE || $ex->nodeType == XML_COMMENT_NODE && $T7)) {
            goto iX;
        }
        goto QJ;
        iX:
        $RR = $ex;
        goto Jf;
        QJ:
        if (!($ex == null)) {
            goto Bj;
        }
        $Vf = $Vf->ownerDocument;
        Bj:
        QR:
        return $Vf->C14N($WQ, $T7, $nY, $bl);
    }
    public function canonicalizeSignedInfo()
    {
        $Pj = $this->sigNode->ownerDocument;
        $sX = null;
        if (!$Pj) {
            goto D3;
        }
        $Mn = $this->getXPathObj();
        $nv = "\x2e\57\163\x65\x63\x64\163\x69\x67\x3a\123\x69\x67\156\x65\144\x49\156\146\x6f";
        $Rb = $Mn->query($nv, $this->sigNode);
        if (!($Vr = $Rb->item(0))) {
            goto I8;
        }
        $nv = "\56\57\x73\145\143\x64\x73\x69\x67\72\103\141\x6e\x6f\156\151\143\141\154\151\172\141\164\151\157\x6e\115\145\x74\150\157\144";
        $Rb = $Mn->query($nv, $Vr);
        if (!($sp = $Rb->item(0))) {
            goto Y1;
        }
        $sX = $sp->getAttribute("\x41\x6c\x67\157\x72\151\164\x68\155");
        Y1:
        $this->signedInfo = $this->canonicalizeData($Vr, $sX);
        return $this->signedInfo;
        I8:
        D3:
        return null;
    }
    public function calculateDigest($iL, $UF, $Cy = true)
    {
        switch ($iL) {
            case self::SHA1:
                $rw = "\163\x68\x61\61";
                goto B3;
            case self::SHA256:
                $rw = "\x73\x68\x61\62\65\x36";
                goto B3;
            case self::SHA384:
                $rw = "\163\150\141\63\x38\x34";
                goto B3;
            case self::SHA512:
                $rw = "\163\x68\x61\65\x31\62";
                goto B3;
            case self::RIPEMD160:
                $rw = "\162\151\x70\145\x6d\x64\x31\x36\x30";
                goto B3;
            default:
                throw new Exception("\x43\141\x6e\x6e\x6f\164\x20\x76\x61\x6c\x69\x64\141\164\145\x20\x64\x69\x67\145\x73\164\x3a\40\125\156\163\x75\x70\160\x6f\x72\164\x65\x64\40\101\154\147\157\x72\x69\x74\150\155\40\x3c{$iL}\76");
        }
        N5:
        B3:
        $HX = hash($rw, $UF, true);
        if (!$Cy) {
            goto fY;
        }
        $HX = base64_encode($HX);
        fY:
        return $HX;
    }
    public function validateDigest($Pb, $UF)
    {
        $Mn = new DOMXPath($Pb->ownerDocument);
        $Mn->registerNamespace("\x73\145\143\144\x73\151\x67", self::XMLDSIGNS);
        $nv = "\x73\164\162\151\156\147\x28\56\x2f\x73\x65\143\x64\163\x69\147\x3a\x44\x69\147\145\x73\164\115\x65\164\150\x6f\x64\x2f\x40\101\154\147\x6f\x72\151\x74\x68\155\x29";
        $iL = $Mn->evaluate($nv, $Pb);
        $SA = $this->calculateDigest($iL, $UF, false);
        $nv = "\163\x74\162\151\156\147\50\56\57\163\145\143\x64\x73\x69\147\72\104\x69\x67\145\163\164\126\141\154\x75\145\51";
        $JM = $Mn->evaluate($nv, $Pb);
        return $SA === base64_decode($JM);
    }
    public function processTransforms($Pb, $s0, $SJ = true)
    {
        $UF = $s0;
        $Mn = new DOMXPath($Pb->ownerDocument);
        $Mn->registerNamespace("\x73\x65\143\144\163\151\147", self::XMLDSIGNS);
        $nv = "\56\57\x73\x65\x63\144\x73\151\x67\72\124\x72\141\156\x73\146\157\x72\155\163\57\163\x65\143\144\163\151\147\x3a\124\x72\x61\x6e\x73\146\157\x72\x6d";
        $YH = $Mn->query($nv, $Pb);
        $x2 = "\x68\164\x74\x70\72\57\x2f\167\167\167\x2e\x77\63\56\157\x72\x67\x2f\124\x52\57\62\x30\60\x31\57\122\105\x43\x2d\170\x6d\154\x2d\143\61\64\156\x2d\62\60\x30\x31\60\x33\61\65";
        $nY = null;
        $bl = null;
        foreach ($YH as $pg) {
            $Td = $pg->getAttribute("\x41\154\x67\x6f\162\x69\164\x68\x6d");
            switch ($Td) {
                case "\150\x74\x74\x70\72\x2f\57\167\167\x77\56\x77\x33\x2e\x6f\162\147\x2f\62\x30\60\61\x2f\x31\x30\x2f\170\155\x6c\55\x65\x78\x63\x2d\143\x31\x34\x6e\x23":
                case "\x68\164\x74\x70\x3a\x2f\x2f\x77\167\167\56\x77\63\56\157\162\147\57\62\60\x30\x31\x2f\61\x30\x2f\x78\x6d\x6c\55\x65\x78\143\55\x63\61\64\156\x23\x57\151\x74\150\103\x6f\155\155\x65\x6e\x74\163":
                    if (!$SJ) {
                        goto BH;
                    }
                    $x2 = $Td;
                    goto Fx;
                    BH:
                    $x2 = "\x68\164\164\x70\x3a\x2f\57\x77\167\167\56\x77\63\56\157\162\147\57\62\60\x30\x31\x2f\61\x30\57\170\x6d\x6c\55\145\x78\143\55\x63\61\64\156\x23";
                    Fx:
                    $Vf = $pg->firstChild;
                    C6:
                    if (!$Vf) {
                        goto ld;
                    }
                    if (!($Vf->localName == "\x49\x6e\x63\x6c\x75\163\x69\166\145\116\141\x6d\145\x73\160\x61\x63\145\163")) {
                        goto ec;
                    }
                    if (!($EJ = $Vf->getAttribute("\x50\162\x65\x66\151\170\x4c\x69\163\x74"))) {
                        goto HB;
                    }
                    $OY = array();
                    $cc = explode("\x20", $EJ);
                    foreach ($cc as $EJ) {
                        $Aq = trim($EJ);
                        if (empty($Aq)) {
                            goto VP;
                        }
                        $OY[] = $Aq;
                        VP:
                        Ok:
                    }
                    L8:
                    if (!(count($OY) > 0)) {
                        goto CR;
                    }
                    $bl = $OY;
                    CR:
                    HB:
                    goto ld;
                    ec:
                    $Vf = $Vf->nextSibling;
                    goto C6;
                    ld:
                    goto Zp;
                case "\150\x74\x74\160\x3a\57\x2f\167\x77\167\56\x77\x33\56\157\x72\147\x2f\x54\122\57\62\60\60\x31\x2f\x52\105\103\x2d\x78\x6d\x6c\x2d\x63\x31\x34\x6e\x2d\x32\x30\60\x31\x30\x33\x31\x35":
                case "\150\x74\164\x70\x3a\x2f\57\167\167\167\x2e\x77\63\x2e\157\162\147\x2f\x54\122\x2f\62\x30\60\x31\57\122\x45\103\55\170\x6d\154\55\x63\61\64\156\x2d\62\x30\60\x31\x30\63\x31\x35\x23\x57\151\164\150\103\x6f\x6d\155\145\x6e\x74\163":
                    if (!$SJ) {
                        goto Ys;
                    }
                    $x2 = $Td;
                    goto AG;
                    Ys:
                    $x2 = "\x68\x74\x74\x70\x3a\57\x2f\167\x77\x77\56\x77\63\x2e\157\x72\x67\57\x54\122\x2f\x32\x30\x30\61\x2f\122\105\103\55\x78\155\154\x2d\143\61\64\156\x2d\62\x30\60\61\60\x33\x31\x35";
                    AG:
                    goto Zp;
                case "\x68\164\x74\x70\72\57\x2f\x77\167\167\x2e\x77\x33\x2e\x6f\x72\147\57\124\x52\57\x31\x39\71\71\x2f\x52\x45\103\55\x78\x70\141\x74\x68\55\61\71\x39\x39\61\x31\x31\x36":
                    $Vf = $pg->firstChild;
                    zt:
                    if (!$Vf) {
                        goto IP;
                    }
                    if (!($Vf->localName == "\130\x50\x61\x74\x68")) {
                        goto XM;
                    }
                    $nY = array();
                    $nY["\161\x75\x65\162\x79"] = "\x28\x2e\x2f\57\56\40\174\40\56\x2f\57\x40\x2a\40\x7c\40\x2e\x2f\57\x6e\141\x6d\145\163\x70\x61\x63\x65\x3a\72\x2a\51\x5b" . $Vf->nodeValue . "\x5d";
                    $NR["\x6e\141\x6d\145\163\x70\x61\143\x65\x73"] = array();
                    $OZ = $Mn->query("\x2e\x2f\x6e\x61\x6d\x65\x73\x70\141\143\145\x3a\x3a\x2a", $Vf);
                    foreach ($OZ as $zO) {
                        if (!($zO->localName != "\x78\155\x6c")) {
                            goto g6;
                        }
                        $nY["\156\x61\155\145\163\x70\141\143\x65\x73"][$zO->localName] = $zO->nodeValue;
                        g6:
                        iC:
                    }
                    wl:
                    goto IP;
                    XM:
                    $Vf = $Vf->nextSibling;
                    goto zt;
                    IP:
                    goto Zp;
            }
            x9:
            Zp:
            o7:
        }
        wA:
        if (!$UF instanceof DOMNode) {
            goto qr;
        }
        $UF = $this->canonicalizeData($s0, $x2, $nY, $bl);
        qr:
        return $UF;
    }
    public function processRefNode($Pb)
    {
        $oM = null;
        $SJ = true;
        if ($gr = $Pb->getAttribute("\x55\x52\111")) {
            goto G5;
        }
        $SJ = false;
        $oM = $Pb->ownerDocument;
        goto qY;
        G5:
        $Cc = parse_url($gr);
        if (!empty($Cc["\x70\x61\x74\x68"])) {
            goto sQ;
        }
        if ($XU = $Cc["\x66\162\x61\x67\x6d\x65\x6e\x74"]) {
            goto Iv;
        }
        $oM = $Pb->ownerDocument;
        goto tI;
        Iv:
        $SJ = false;
        $VY = new DOMXPath($Pb->ownerDocument);
        if (!($this->idNS && is_array($this->idNS))) {
            goto Lv;
        }
        foreach ($this->idNS as $nx => $Rq) {
            $VY->registerNamespace($nx, $Rq);
            gd:
        }
        dm:
        Lv:
        $ui = "\100\x49\x64\75\42" . XPath::filterAttrValue($XU, XPath::DOUBLE_QUOTE) . "\42";
        if (!is_array($this->idKeys)) {
            goto Kl;
        }
        foreach ($this->idKeys as $v4) {
            $ui .= "\40\x6f\x72\x20\x40" . XPath::filterAttrName($v4) . "\75\x22" . XPath::filterAttrValue($XU, XPath::DOUBLE_QUOTE) . "\42";
            Y4:
        }
        iY:
        Kl:
        $nv = "\57\x2f\52\x5b" . $ui . "\135";
        $oM = $VY->query($nv)->item(0);
        tI:
        sQ:
        qY:
        $UF = $this->processTransforms($Pb, $oM, $SJ);
        if ($this->validateDigest($Pb, $UF)) {
            goto EC;
        }
        return false;
        EC:
        if (!$oM instanceof DOMNode) {
            goto MK;
        }
        if (!empty($XU)) {
            goto tg;
        }
        $this->validatedNodes[] = $oM;
        goto YJ;
        tg:
        $this->validatedNodes[$XU] = $oM;
        YJ:
        MK:
        return true;
    }
    public function getRefNodeID($Pb)
    {
        if (!($gr = $Pb->getAttribute("\125\122\x49"))) {
            goto GR;
        }
        $Cc = parse_url($gr);
        if (!empty($Cc["\x70\141\164\150"])) {
            goto Ry;
        }
        if (!($XU = $Cc["\x66\162\141\147\x6d\145\156\x74"])) {
            goto fZ;
        }
        return $XU;
        fZ:
        Ry:
        GR:
        return null;
    }
    public function getRefIDs()
    {
        $WC = array();
        $Mn = $this->getXPathObj();
        $nv = "\x2e\57\x73\145\x63\144\x73\x69\147\72\x53\x69\147\x6e\145\144\x49\x6e\146\157\x2f\x73\x65\x63\x64\x73\151\147\x3a\122\145\x66\x65\162\145\x6e\x63\145";
        $Rb = $Mn->query($nv, $this->sigNode);
        if (!($Rb->length == 0)) {
            goto Ey;
        }
        throw new Exception("\x52\145\x66\x65\162\145\156\143\145\40\x6e\x6f\x64\145\163\x20\156\x6f\x74\x20\x66\157\x75\x6e\x64");
        Ey:
        foreach ($Rb as $Pb) {
            $WC[] = $this->getRefNodeID($Pb);
            wV:
        }
        nO:
        return $WC;
    }
    public function validateReference()
    {
        $Cw = $this->sigNode->ownerDocument->documentElement;
        if ($Cw->isSameNode($this->sigNode)) {
            goto vq;
        }
        if (!($this->sigNode->parentNode != null)) {
            goto n1;
        }
        $this->sigNode->parentNode->removeChild($this->sigNode);
        n1:
        vq:
        $Mn = $this->getXPathObj();
        $nv = "\x2e\57\163\x65\x63\x64\x73\x69\x67\72\123\151\147\x6e\145\144\111\156\146\x6f\57\x73\145\x63\x64\x73\x69\147\x3a\x52\x65\x66\145\162\x65\x6e\x63\145";
        $Rb = $Mn->query($nv, $this->sigNode);
        if (!($Rb->length == 0)) {
            goto Ap;
        }
        throw new Exception("\x52\145\x66\x65\162\145\156\x63\145\x20\x6e\157\144\x65\x73\40\x6e\157\x74\40\146\157\x75\x6e\144");
        Ap:
        $this->validatedNodes = array();
        foreach ($Rb as $Pb) {
            if ($this->processRefNode($Pb)) {
                goto dg;
            }
            $this->validatedNodes = null;
            throw new Exception("\x52\145\146\x65\x72\x65\156\143\145\40\166\x61\154\x69\144\141\x74\151\157\156\x20\x66\x61\151\x6c\x65\144");
            dg:
            k0:
        }
        m6:
        return true;
    }
    private function addRefInternal($m7, $Vf, $Td, $iG = null, $UV = null)
    {
        $wz = null;
        $j1 = null;
        $pQ = "\111\x64";
        $bH = true;
        $eA = false;
        if (!is_array($UV)) {
            goto Dd;
        }
        $wz = empty($UV["\160\x72\145\x66\x69\170"]) ? null : $UV["\160\162\x65\x66\151\170"];
        $j1 = empty($UV["\160\x72\x65\146\x69\x78\137\156\163"]) ? null : $UV["\160\162\145\x66\151\x78\x5f\x6e\x73"];
        $pQ = empty($UV["\151\x64\x5f\x6e\x61\155\145"]) ? "\x49\x64" : $UV["\151\144\x5f\156\x61\155\x65"];
        $bH = !isset($UV["\x6f\x76\x65\162\167\x72\x69\164\x65"]) ? true : (bool) $UV["\x6f\x76\145\x72\167\162\151\164\x65"];
        $eA = !isset($UV["\146\157\162\143\x65\137\x75\x72\x69"]) ? false : (bool) $UV["\146\x6f\x72\x63\x65\x5f\165\162\x69"];
        Dd:
        $N9 = $pQ;
        if (empty($wz)) {
            goto ay;
        }
        $N9 = $wz . "\x3a" . $N9;
        ay:
        $Pb = $this->createNewSignNode("\x52\145\146\145\x72\145\x6e\x63\145");
        $m7->appendChild($Pb);
        if (!$Vf instanceof DOMDocument) {
            goto sP;
        }
        if ($eA) {
            goto NI;
        }
        goto h1;
        sP:
        $gr = null;
        if ($bH) {
            goto Cz;
        }
        $gr = $j1 ? $Vf->getAttributeNS($j1, $pQ) : $Vf->getAttribute($pQ);
        Cz:
        if (!empty($gr)) {
            goto iw;
        }
        $gr = self::generateGUID();
        $Vf->setAttributeNS($j1, $N9, $gr);
        iw:
        $Pb->setAttribute("\125\x52\x49", "\x23" . $gr);
        goto h1;
        NI:
        $Pb->setAttribute("\x55\122\111", '');
        h1:
        $cM = $this->createNewSignNode("\x54\162\x61\156\x73\x66\157\x72\155\x73");
        $Pb->appendChild($cM);
        if (is_array($iG)) {
            goto Qq;
        }
        if (!empty($this->canonicalMethod)) {
            goto SD;
        }
        goto I3;
        Qq:
        foreach ($iG as $pg) {
            $XA = $this->createNewSignNode("\x54\162\141\x6e\163\x66\157\162\x6d");
            $cM->appendChild($XA);
            if (is_array($pg) && !empty($pg["\x68\x74\164\x70\72\57\x2f\x77\x77\x77\56\167\x33\x2e\157\x72\x67\x2f\x54\x52\x2f\61\x39\71\71\57\122\x45\103\x2d\170\x70\x61\164\x68\55\61\71\71\x39\x31\61\x31\x36"]) && !empty($pg["\x68\164\164\x70\x3a\x2f\57\167\167\x77\56\167\x33\56\x6f\162\x67\x2f\124\x52\x2f\61\x39\x39\71\x2f\122\105\x43\55\x78\160\141\164\150\x2d\61\71\x39\x39\61\x31\x31\x36"]["\161\165\x65\162\171"])) {
                goto PL;
            }
            $XA->setAttribute("\x41\154\x67\157\162\x69\164\x68\155", $pg);
            goto LE;
            PL:
            $XA->setAttribute("\101\154\147\x6f\x72\151\164\x68\x6d", "\x68\164\164\x70\72\57\57\167\167\x77\56\x77\x33\56\x6f\x72\x67\57\124\x52\x2f\x31\x39\71\71\x2f\x52\105\x43\x2d\170\160\141\x74\x68\55\x31\71\71\71\61\x31\61\66");
            $QY = $this->createNewSignNode("\x58\120\x61\164\150", $pg["\150\x74\x74\x70\x3a\x2f\x2f\x77\x77\x77\56\167\x33\56\157\162\x67\x2f\124\122\x2f\x31\x39\71\71\57\122\x45\103\x2d\x78\x70\141\x74\x68\x2d\61\x39\x39\x39\61\x31\61\x36"]["\161\x75\x65\x72\x79"]);
            $XA->appendChild($QY);
            if (empty($pg["\150\x74\x74\160\72\57\57\167\167\167\56\167\63\56\157\x72\147\57\x54\122\x2f\61\x39\x39\71\x2f\x52\x45\103\x2d\170\160\141\164\x68\55\x31\x39\x39\x39\x31\x31\61\66"]["\x6e\x61\x6d\145\163\x70\x61\143\x65\163"])) {
                goto Sj;
            }
            foreach ($pg["\x68\164\x74\160\x3a\57\x2f\x77\x77\x77\56\167\x33\x2e\157\x72\147\x2f\x54\x52\57\x31\x39\x39\71\x2f\x52\105\x43\x2d\x78\x70\x61\164\x68\55\x31\x39\x39\x39\61\x31\61\x36"]["\x6e\141\155\x65\x73\x70\141\x63\x65\x73"] as $wz => $CM) {
                $QY->setAttributeNS("\x68\x74\x74\x70\x3a\x2f\57\x77\167\167\56\x77\63\56\157\162\x67\57\62\x30\x30\60\x2f\170\155\154\x6e\163\x2f", "\x78\155\x6c\x6e\x73\x3a{$wz}", $CM);
                FK:
            }
            s2:
            Sj:
            LE:
            iZ:
        }
        pM:
        goto I3;
        SD:
        $XA = $this->createNewSignNode("\124\x72\x61\156\163\x66\157\x72\155");
        $cM->appendChild($XA);
        $XA->setAttribute("\x41\x6c\147\x6f\x72\151\164\150\x6d", $this->canonicalMethod);
        I3:
        $aS = $this->processTransforms($Pb, $Vf);
        $SA = $this->calculateDigest($Td, $aS);
        $Ki = $this->createNewSignNode("\x44\151\x67\x65\163\164\x4d\145\x74\x68\157\x64");
        $Pb->appendChild($Ki);
        $Ki->setAttribute("\x41\x6c\147\x6f\162\151\x74\x68\x6d", $Td);
        $JM = $this->createNewSignNode("\104\x69\x67\x65\x73\164\x56\141\x6c\165\145", $SA);
        $Pb->appendChild($JM);
    }
    public function addReference($Vf, $Td, $iG = null, $UV = null)
    {
        if (!($Mn = $this->getXPathObj())) {
            goto AY;
        }
        $nv = "\x2e\x2f\x73\x65\143\x64\x73\x69\147\x3a\123\x69\147\x6e\145\144\x49\156\146\x6f";
        $Rb = $Mn->query($nv, $this->sigNode);
        if (!($p_ = $Rb->item(0))) {
            goto ir;
        }
        $this->addRefInternal($p_, $Vf, $Td, $iG, $UV);
        ir:
        AY:
    }
    public function addReferenceList($jL, $Td, $iG = null, $UV = null)
    {
        if (!($Mn = $this->getXPathObj())) {
            goto E8;
        }
        $nv = "\56\57\x73\x65\x63\x64\x73\x69\147\72\x53\x69\x67\156\145\x64\111\156\x66\157";
        $Rb = $Mn->query($nv, $this->sigNode);
        if (!($p_ = $Rb->item(0))) {
            goto je;
        }
        foreach ($jL as $Vf) {
            $this->addRefInternal($p_, $Vf, $Td, $iG, $UV);
            OU:
        }
        vt:
        je:
        E8:
    }
    public function addObject($UF, $zq = null, $I4 = null)
    {
        $od = $this->createNewSignNode("\x4f\142\x6a\145\x63\164");
        $this->sigNode->appendChild($od);
        if (empty($zq)) {
            goto lA;
        }
        $od->setAttribute("\x4d\x69\x6d\145\124\x79\160\x65", $zq);
        lA:
        if (empty($I4)) {
            goto c4;
        }
        $od->setAttribute("\105\x6e\143\157\144\151\156\147", $I4);
        c4:
        if ($UF instanceof DOMElement) {
            goto oU;
        }
        $nd = $this->sigNode->ownerDocument->createTextNode($UF);
        goto JK;
        oU:
        $nd = $this->sigNode->ownerDocument->importNode($UF, true);
        JK:
        $od->appendChild($nd);
        return $od;
    }
    public function locateKey($Vf = null)
    {
        if (!empty($Vf)) {
            goto W2;
        }
        $Vf = $this->sigNode;
        W2:
        if ($Vf instanceof DOMNode) {
            goto v9;
        }
        return null;
        v9:
        if (!($Pj = $Vf->ownerDocument)) {
            goto kE;
        }
        $Mn = new DOMXPath($Pj);
        $Mn->registerNamespace("\163\x65\143\x64\x73\151\x67", self::XMLDSIGNS);
        $nv = "\x73\164\x72\151\156\147\x28\x2e\x2f\163\145\x63\x64\163\x69\x67\x3a\x53\151\x67\156\145\144\111\x6e\146\x6f\57\163\145\x63\144\x73\x69\x67\x3a\x53\x69\x67\156\x61\164\165\162\x65\115\x65\x74\x68\157\144\57\x40\x41\154\x67\x6f\162\151\164\x68\x6d\x29";
        $Td = $Mn->evaluate($nv, $Vf);
        if (!$Td) {
            goto WP;
        }
        try {
            $u8 = new XMLSecurityKey($Td, array("\x74\x79\160\x65" => "\x70\165\142\154\151\143"));
        } catch (Exception $jB) {
            return null;
        }
        return $u8;
        WP:
        kE:
        return null;
    }
    public function verify($u8)
    {
        $Pj = $this->sigNode->ownerDocument;
        $Mn = new DOMXPath($Pj);
        $Mn->registerNamespace("\163\145\x63\x64\x73\151\x67", self::XMLDSIGNS);
        $nv = "\x73\x74\162\x69\156\147\x28\x2e\x2f\163\145\x63\x64\x73\x69\x67\72\123\x69\147\x6e\141\x74\165\x72\145\x56\141\154\165\x65\51";
        $vi = $Mn->evaluate($nv, $this->sigNode);
        if (!empty($vi)) {
            goto de;
        }
        throw new Exception("\x55\x6e\x61\142\154\x65\x20\164\x6f\40\x6c\x6f\x63\141\164\145\x20\x53\x69\x67\x6e\141\164\x75\x72\145\x56\141\154\x75\145");
        de:
        return $u8->verifySignature($this->signedInfo, base64_decode($vi));
    }
    public function signData($u8, $UF)
    {
        return $u8->signData($UF);
    }
    public function sign($u8, $ML = null)
    {
        if (!($ML != null)) {
            goto D1;
        }
        $this->resetXPathObj();
        $this->appendSignature($ML);
        $this->sigNode = $ML->lastChild;
        D1:
        if (!($Mn = $this->getXPathObj())) {
            goto T5;
        }
        $nv = "\x2e\57\x73\145\143\x64\x73\x69\x67\72\123\151\x67\x6e\x65\x64\111\156\146\x6f";
        $Rb = $Mn->query($nv, $this->sigNode);
        if (!($p_ = $Rb->item(0))) {
            goto Qm;
        }
        $nv = "\x2e\x2f\x73\x65\x63\144\163\151\147\72\x53\x69\x67\156\x61\164\165\x72\145\115\145\164\150\157\x64";
        $Rb = $Mn->query($nv, $p_);
        $Sh = $Rb->item(0);
        $Sh->setAttribute("\101\154\x67\157\x72\x69\164\x68\x6d", $u8->type);
        $UF = $this->canonicalizeData($p_, $this->canonicalMethod);
        $vi = base64_encode($this->signData($u8, $UF));
        $HH = $this->createNewSignNode("\123\151\147\156\x61\164\165\162\x65\x56\141\x6c\x75\145", $vi);
        if ($BN = $p_->nextSibling) {
            goto CD;
        }
        $this->sigNode->appendChild($HH);
        goto wb;
        CD:
        $BN->parentNode->insertBefore($HH, $BN);
        wb:
        Qm:
        T5:
    }
    public function appendCert()
    {
    }
    public function appendKey($u8, $V7 = null)
    {
        $u8->serializeKey($V7);
    }
    public function insertSignature($Vf, $Sx = null)
    {
        $vy = $Vf->ownerDocument;
        $zf = $vy->importNode($this->sigNode, true);
        if ($Sx == null) {
            goto kj;
        }
        return $Vf->insertBefore($zf, $Sx);
        goto H9;
        kj:
        return $Vf->insertBefore($zf);
        H9:
    }
    public function appendSignature($qQ, $W2 = false)
    {
        $Sx = $W2 ? $qQ->firstChild : null;
        return $this->insertSignature($qQ, $Sx);
    }
    public static function get509XCert($u0, $qj = true)
    {
        $PO = self::staticGet509XCerts($u0, $qj);
        if (empty($PO)) {
            goto AZ;
        }
        return $PO[0];
        AZ:
        return '';
    }
    public static function staticGet509XCerts($PO, $qj = true)
    {
        if ($qj) {
            goto uv;
        }
        return array($PO);
        goto jf;
        uv:
        $UF = '';
        $wV = array();
        $uS = explode("\12", $PO);
        $Eg = false;
        foreach ($uS as $TI) {
            if (!$Eg) {
                goto Tx;
            }
            if (!(strncmp($TI, "\55\x2d\55\55\55\105\x4e\x44\40\103\105\x52\x54\111\x46\111\103\x41\x54\105", 20) == 0)) {
                goto QF;
            }
            $Eg = false;
            $wV[] = $UF;
            $UF = '';
            goto zH;
            QF:
            $UF .= trim($TI);
            goto T8;
            Tx:
            if (!(strncmp($TI, "\x2d\x2d\x2d\x2d\55\102\105\107\x49\x4e\40\103\x45\x52\124\x49\x46\111\x43\x41\x54\105", 22) == 0)) {
                goto s1;
            }
            $Eg = true;
            s1:
            T8:
            zH:
        }
        SW:
        return $wV;
        jf:
    }
    public static function staticAdd509Cert($oz, $u0, $qj = true, $KP = false, $Mn = null, $UV = null)
    {
        if (!$KP) {
            goto rU;
        }
        $u0 = file_get_contents($u0);
        rU:
        if ($oz instanceof DOMElement) {
            goto CJ;
        }
        throw new Exception("\111\156\166\x61\154\151\144\40\x70\141\162\145\156\164\40\116\157\x64\145\40\160\141\x72\141\x6d\x65\164\145\x72");
        CJ:
        $er = $oz->ownerDocument;
        if (!empty($Mn)) {
            goto DG;
        }
        $Mn = new DOMXPath($oz->ownerDocument);
        $Mn->registerNamespace("\163\x65\143\144\x73\x69\147", self::XMLDSIGNS);
        DG:
        $nv = "\x2e\57\x73\145\143\x64\x73\x69\x67\72\113\145\171\x49\x6e\x66\x6f";
        $Rb = $Mn->query($nv, $oz);
        $En = $Rb->item(0);
        $he = '';
        if (!$En) {
            goto cC;
        }
        $EJ = $En->lookupPrefix(self::XMLDSIGNS);
        if (empty($EJ)) {
            goto L_;
        }
        $he = $EJ . "\72";
        L_:
        goto Ph;
        cC:
        $EJ = $oz->lookupPrefix(self::XMLDSIGNS);
        if (empty($EJ)) {
            goto um;
        }
        $he = $EJ . "\72";
        um:
        $Xh = false;
        $En = $er->createElementNS(self::XMLDSIGNS, $he . "\x4b\145\x79\x49\156\146\157");
        $nv = "\56\x2f\163\x65\143\144\163\151\x67\72\x4f\x62\x6a\145\x63\x74";
        $Rb = $Mn->query($nv, $oz);
        if (!($rd = $Rb->item(0))) {
            goto QP;
        }
        $rd->parentNode->insertBefore($En, $rd);
        $Xh = true;
        QP:
        if ($Xh) {
            goto IR;
        }
        $oz->appendChild($En);
        IR:
        Ph:
        $PO = self::staticGet509XCerts($u0, $qj);
        $Ow = $er->createElementNS(self::XMLDSIGNS, $he . "\130\65\60\71\104\141\164\x61");
        $En->appendChild($Ow);
        $xj = false;
        $wN = false;
        if (!is_array($UV)) {
            goto Ob;
        }
        if (empty($UV["\151\163\x73\165\x65\162\123\145\x72\151\x61\x6c"])) {
            goto zY;
        }
        $xj = true;
        zY:
        if (empty($UV["\163\x75\142\x6a\145\x63\164\x4e\x61\x6d\x65"])) {
            goto RR;
        }
        $wN = true;
        RR:
        Ob:
        foreach ($PO as $dz) {
            if (!($xj || $wN)) {
                goto qo;
            }
            if (!($bj = openssl_x509_parse("\x2d\x2d\x2d\x2d\55\102\x45\107\x49\116\40\103\x45\122\124\x49\x46\x49\x43\101\x54\105\x2d\55\55\x2d\55\12" . chunk_split($dz, 64, "\xa") . "\x2d\x2d\55\55\55\105\x4e\x44\x20\103\105\122\x54\x49\106\x49\103\101\124\105\x2d\x2d\55\55\55\12"))) {
                goto bM;
            }
            if (!($wN && !empty($bj["\x73\x75\142\x6a\x65\x63\x74"]))) {
                goto e4;
            }
            if (is_array($bj["\x73\x75\x62\x6a\145\x63\x74"])) {
                goto Xl;
            }
            $PZ = $bj["\151\x73\x73\x75\145\x72"];
            goto Dw;
            Xl:
            $CY = array();
            foreach ($bj["\163\165\x62\152\145\x63\164"] as $a5 => $n5) {
                if (is_array($n5)) {
                    goto t7;
                }
                array_unshift($CY, "{$a5}\75{$n5}");
                goto Vm;
                t7:
                foreach ($n5 as $zz) {
                    array_unshift($CY, "{$a5}\x3d{$zz}");
                    hI:
                }
                vb:
                Vm:
                FM:
            }
            hx:
            $PZ = implode("\x2c", $CY);
            Dw:
            $Lz = $er->createElementNS(self::XMLDSIGNS, $he . "\x58\65\60\71\x53\165\x62\x6a\145\x63\x74\x4e\141\x6d\145", $PZ);
            $Ow->appendChild($Lz);
            e4:
            if (!($xj && !empty($bj["\151\x73\x73\x75\145\162"]) && !empty($bj["\x73\x65\162\x69\141\154\116\165\x6d\x62\145\x72"]))) {
                goto Jp;
            }
            if (is_array($bj["\151\163\163\165\x65\x72"])) {
                goto hu;
            }
            $cY = $bj["\151\163\163\x75\145\162"];
            goto Jk;
            hu:
            $CY = array();
            foreach ($bj["\151\x73\163\x75\145\x72"] as $a5 => $n5) {
                array_unshift($CY, "{$a5}\75{$n5}");
                yw:
            }
            Hf:
            $cY = implode("\54", $CY);
            Jk:
            $Fs = $er->createElementNS(self::XMLDSIGNS, $he . "\130\x35\60\71\x49\x73\163\x75\145\x72\123\145\x72\x69\141\154");
            $Ow->appendChild($Fs);
            $S8 = $er->createElementNS(self::XMLDSIGNS, $he . "\130\x35\60\x39\x49\x73\x73\165\x65\x72\x4e\x61\x6d\x65", $cY);
            $Fs->appendChild($S8);
            $S8 = $er->createElementNS(self::XMLDSIGNS, $he . "\x58\x35\60\x39\123\x65\x72\151\141\154\x4e\x75\x6d\142\145\162", $bj["\x73\145\x72\151\141\154\x4e\x75\x6d\142\x65\x72"]);
            $Fs->appendChild($S8);
            Jp:
            bM:
            qo:
            $I7 = $er->createElementNS(self::XMLDSIGNS, $he . "\x58\x35\x30\x39\x43\x65\162\164\x69\146\151\x63\141\x74\145", $dz);
            $Ow->appendChild($I7);
            SG:
        }
        s5:
    }
    public function add509Cert($u0, $qj = true, $KP = false, $UV = null)
    {
        if (!($Mn = $this->getXPathObj())) {
            goto GG;
        }
        self::staticAdd509Cert($this->sigNode, $u0, $qj, $KP, $Mn, $UV);
        GG:
    }
    public function appendToKeyInfo($Vf)
    {
        $oz = $this->sigNode;
        $er = $oz->ownerDocument;
        $Mn = $this->getXPathObj();
        if (!empty($Mn)) {
            goto gb;
        }
        $Mn = new DOMXPath($oz->ownerDocument);
        $Mn->registerNamespace("\163\145\x63\144\x73\x69\x67", self::XMLDSIGNS);
        gb:
        $nv = "\56\x2f\163\145\x63\144\163\151\x67\72\x4b\x65\171\111\156\x66\x6f";
        $Rb = $Mn->query($nv, $oz);
        $En = $Rb->item(0);
        if ($En) {
            goto jm;
        }
        $he = '';
        $EJ = $oz->lookupPrefix(self::XMLDSIGNS);
        if (empty($EJ)) {
            goto bk;
        }
        $he = $EJ . "\72";
        bk:
        $Xh = false;
        $En = $er->createElementNS(self::XMLDSIGNS, $he . "\x4b\145\x79\111\x6e\x66\x6f");
        $nv = "\x2e\57\163\145\x63\x64\x73\151\147\72\x4f\x62\x6a\x65\143\164";
        $Rb = $Mn->query($nv, $oz);
        if (!($rd = $Rb->item(0))) {
            goto n0;
        }
        $rd->parentNode->insertBefore($En, $rd);
        $Xh = true;
        n0:
        if ($Xh) {
            goto Jd;
        }
        $oz->appendChild($En);
        Jd:
        jm:
        $En->appendChild($Vf);
        return $En;
    }
    public function getValidatedNodes()
    {
        return $this->validatedNodes;
    }
}
