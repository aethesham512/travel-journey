<?php


namespace RobRichards\XMLSecLibs;

use DOMElement;
use Exception;
class XMLSecurityKey
{
    const TRIPLEDES_CBC = "\150\164\x74\x70\72\57\57\x77\x77\167\56\167\x33\x2e\x6f\162\x67\x2f\x32\60\x30\61\x2f\x30\x34\x2f\x78\x6d\154\x65\x6e\143\x23\x74\162\151\x70\x6c\145\144\x65\163\55\143\x62\143";
    const AES128_CBC = "\x68\x74\x74\x70\x3a\x2f\57\167\167\x77\x2e\167\x33\x2e\x6f\x72\147\x2f\x32\x30\x30\x31\57\x30\64\57\170\x6d\x6c\145\x6e\x63\43\x61\x65\x73\61\62\x38\55\x63\x62\143";
    const AES192_CBC = "\x68\164\x74\x70\x3a\x2f\57\x77\x77\x77\56\x77\63\56\x6f\162\x67\x2f\62\60\x30\x31\x2f\x30\x34\57\170\x6d\154\145\x6e\x63\43\x61\x65\163\x31\x39\62\x2d\x63\x62\x63";
    const AES256_CBC = "\x68\164\x74\160\72\57\x2f\167\167\x77\56\x77\63\x2e\x6f\x72\x67\x2f\62\x30\x30\x31\57\60\64\57\x78\x6d\154\x65\156\143\43\x61\x65\163\x32\65\66\55\143\x62\143";
    const RSA_1_5 = "\150\164\164\x70\x3a\x2f\x2f\x77\167\167\56\167\63\x2e\157\162\147\57\62\60\60\61\x2f\x30\x34\x2f\x78\x6d\x6c\145\156\143\43\162\163\x61\x2d\x31\x5f\x35";
    const RSA_OAEP_MGF1P = "\x68\164\164\x70\x3a\57\57\167\167\167\x2e\x77\63\x2e\x6f\x72\147\x2f\62\60\x30\61\x2f\60\x34\57\170\155\154\145\x6e\143\43\x72\163\141\x2d\157\141\x65\160\x2d\155\x67\x66\61\160";
    const DSA_SHA1 = "\150\x74\164\x70\72\x2f\x2f\x77\167\167\x2e\x77\63\56\157\x72\x67\57\x32\60\60\x30\57\x30\71\x2f\170\155\154\144\163\x69\x67\x23\144\x73\141\55\x73\x68\141\x31";
    const RSA_SHA1 = "\x68\x74\x74\x70\x3a\57\57\167\x77\167\x2e\x77\x33\x2e\x6f\x72\147\x2f\x32\60\x30\60\57\x30\x39\57\x78\155\154\144\163\x69\147\43\x72\x73\x61\55\163\150\141\61";
    const RSA_SHA256 = "\x68\x74\x74\x70\x3a\x2f\57\x77\x77\x77\56\167\63\x2e\x6f\x72\x67\57\x32\60\x30\61\57\60\64\57\x78\x6d\x6c\144\163\151\x67\55\x6d\x6f\x72\x65\x23\x72\x73\x61\x2d\163\150\x61\62\65\66";
    const RSA_SHA384 = "\150\164\x74\160\x3a\57\57\x77\167\167\56\x77\63\x2e\x6f\x72\x67\57\62\x30\60\61\x2f\60\x34\57\170\x6d\154\x64\163\151\147\x2d\155\x6f\162\145\43\162\x73\x61\55\x73\150\x61\63\70\x34";
    const RSA_SHA512 = "\150\x74\x74\x70\72\57\57\x77\167\x77\x2e\167\x33\x2e\157\162\x67\57\x32\60\60\61\x2f\60\x34\57\170\x6d\x6c\x64\x73\151\x67\x2d\155\157\162\145\x23\162\x73\141\x2d\x73\x68\x61\x35\61\62";
    const HMAC_SHA1 = "\x68\164\x74\160\x3a\x2f\57\167\167\167\56\167\x33\56\x6f\x72\147\57\62\x30\60\60\57\60\71\x2f\170\155\x6c\144\x73\x69\147\43\x68\155\141\143\55\163\150\141\x31";
    private $cryptParams = array();
    public $type = 0;
    public $key = null;
    public $passphrase = '';
    public $iv = null;
    public $name = null;
    public $keyChain = null;
    public $isEncrypted = false;
    public $encryptedCtx = null;
    public $guid = null;
    private $x509Certificate = null;
    private $X509Thumbprint = null;
    public function __construct($AG, $Bu = null)
    {
        switch ($AG) {
            case self::TRIPLEDES_CBC:
                $this->cryptParams["\154\x69\142\162\x61\x72\171"] = "\x6f\160\x65\x6e\x73\x73\x6c";
                $this->cryptParams["\x63\x69\160\x68\145\x72"] = "\144\145\x73\x2d\145\144\145\x33\55\x63\142\143";
                $this->cryptParams["\x74\x79\160\145"] = "\x73\x79\x6d\x6d\x65\x74\162\x69\143";
                $this->cryptParams["\x6d\x65\164\150\157\x64"] = "\150\164\164\160\72\57\57\x77\167\167\56\167\63\x2e\157\162\147\57\x32\60\60\x31\x2f\60\x34\x2f\x78\155\154\x65\156\143\x23\x74\x72\x69\x70\x6c\x65\x64\145\x73\55\143\142\143";
                $this->cryptParams["\153\145\171\163\x69\172\x65"] = 24;
                $this->cryptParams["\x62\154\x6f\x63\153\163\x69\172\145"] = 8;
                goto e2;
            case self::AES128_CBC:
                $this->cryptParams["\x6c\x69\x62\162\141\x72\x79"] = "\x6f\x70\x65\x6e\x73\163\x6c";
                $this->cryptParams["\x63\x69\160\x68\145\162"] = "\x61\145\x73\x2d\x31\x32\70\55\143\142\143";
                $this->cryptParams["\164\x79\160\x65"] = "\163\171\155\x6d\x65\x74\x72\151\143";
                $this->cryptParams["\x6d\145\164\x68\x6f\144"] = "\150\164\x74\x70\72\x2f\57\167\167\167\56\167\63\56\157\162\x67\57\62\x30\60\61\x2f\x30\x34\57\170\155\154\145\x6e\143\43\141\x65\x73\x31\x32\x38\55\x63\142\x63";
                $this->cryptParams["\x6b\145\x79\x73\x69\172\x65"] = 16;
                $this->cryptParams["\142\154\157\x63\x6b\163\x69\172\145"] = 16;
                goto e2;
            case self::AES192_CBC:
                $this->cryptParams["\x6c\151\x62\x72\x61\x72\171"] = "\157\x70\x65\156\x73\163\x6c";
                $this->cryptParams["\143\151\160\150\x65\x72"] = "\141\x65\x73\x2d\61\71\x32\55\143\142\143";
                $this->cryptParams["\x74\x79\x70\x65"] = "\x73\171\x6d\x6d\145\164\162\x69\x63";
                $this->cryptParams["\x6d\145\164\x68\157\144"] = "\x68\164\x74\x70\72\x2f\57\167\x77\x77\x2e\167\63\56\x6f\x72\147\x2f\x32\x30\60\61\x2f\x30\x34\x2f\170\155\x6c\x65\156\x63\x23\141\145\x73\x31\71\62\x2d\143\x62\x63";
                $this->cryptParams["\153\x65\171\x73\x69\172\145"] = 24;
                $this->cryptParams["\x62\x6c\x6f\x63\153\x73\151\172\x65"] = 16;
                goto e2;
            case self::AES256_CBC:
                $this->cryptParams["\x6c\x69\x62\x72\x61\x72\171"] = "\x6f\160\145\x6e\x73\x73\154";
                $this->cryptParams["\x63\151\x70\x68\x65\162"] = "\141\x65\x73\x2d\62\x35\66\x2d\x63\142\x63";
                $this->cryptParams["\164\171\x70\x65"] = "\163\171\155\155\145\x74\x72\151\x63";
                $this->cryptParams["\x6d\145\164\150\157\x64"] = "\x68\x74\164\160\x3a\57\57\x77\167\167\56\x77\63\x2e\x6f\162\x67\57\x32\60\x30\x31\57\x30\64\57\170\x6d\x6c\145\x6e\143\43\x61\x65\x73\x32\x35\66\55\143\142\x63";
                $this->cryptParams["\153\x65\x79\163\x69\172\x65"] = 32;
                $this->cryptParams["\142\154\x6f\x63\153\x73\x69\172\x65"] = 16;
                goto e2;
            case self::RSA_1_5:
                $this->cryptParams["\x6c\x69\x62\x72\x61\x72\x79"] = "\157\160\145\x6e\x73\163\154";
                $this->cryptParams["\x70\141\x64\x64\x69\x6e\x67"] = OPENSSL_PKCS1_PADDING;
                $this->cryptParams["\155\x65\x74\x68\157\x64"] = "\x68\164\x74\x70\72\57\x2f\167\167\x77\x2e\167\x33\x2e\x6f\x72\x67\57\62\60\x30\61\57\x30\x34\57\170\155\x6c\x65\156\x63\43\162\163\x61\55\x31\x5f\x35";
                if (!(is_array($Bu) && !empty($Bu["\164\x79\160\x65"]))) {
                    goto KM;
                }
                if (!($Bu["\164\171\160\x65"] == "\x70\165\142\x6c\151\x63" || $Bu["\x74\171\160\145"] == "\x70\162\x69\x76\141\x74\145")) {
                    goto m3;
                }
                $this->cryptParams["\x74\x79\x70\x65"] = $Bu["\164\x79\160\x65"];
                goto e2;
                m3:
                KM:
                throw new Exception("\103\x65\162\x74\x69\x66\x69\x63\141\164\145\x20\x22\x74\x79\x70\x65\42\40\50\160\x72\x69\166\x61\x74\145\x2f\160\x75\x62\x6c\x69\143\51\x20\155\x75\163\164\40\x62\145\40\x70\141\163\163\145\144\40\x76\151\141\40\x70\x61\162\141\155\145\164\145\162\163");
            case self::RSA_OAEP_MGF1P:
                $this->cryptParams["\x6c\x69\x62\162\141\162\171"] = "\157\160\x65\x6e\163\163\154";
                $this->cryptParams["\160\141\144\x64\151\156\x67"] = OPENSSL_PKCS1_OAEP_PADDING;
                $this->cryptParams["\155\x65\x74\150\x6f\144"] = "\150\164\164\x70\x3a\x2f\57\x77\x77\167\56\167\x33\x2e\x6f\162\147\57\x32\x30\x30\61\x2f\60\x34\x2f\x78\x6d\154\x65\156\143\43\x72\163\x61\55\157\141\145\160\55\155\x67\146\61\160";
                $this->cryptParams["\x68\141\163\150"] = null;
                if (!(is_array($Bu) && !empty($Bu["\x74\171\x70\145"]))) {
                    goto FE;
                }
                if (!($Bu["\164\171\x70\x65"] == "\160\x75\142\154\x69\x63" || $Bu["\x74\171\x70\145"] == "\160\162\151\x76\141\164\145")) {
                    goto qV;
                }
                $this->cryptParams["\x74\x79\x70\x65"] = $Bu["\164\x79\x70\145"];
                goto e2;
                qV:
                FE:
                throw new Exception("\103\x65\162\x74\151\146\x69\x63\x61\164\x65\x20\x22\164\171\x70\x65\x22\40\50\x70\162\x69\166\141\x74\145\57\160\x75\x62\x6c\151\x63\x29\40\155\x75\x73\164\x20\142\145\x20\x70\x61\163\x73\x65\144\x20\166\151\x61\40\160\x61\x72\141\155\145\164\145\x72\x73");
            case self::RSA_SHA1:
                $this->cryptParams["\154\151\x62\162\x61\x72\171"] = "\x6f\160\145\156\163\x73\154";
                $this->cryptParams["\155\x65\164\150\x6f\x64"] = "\x68\164\164\x70\72\x2f\x2f\167\x77\167\x2e\167\63\x2e\x6f\x72\147\x2f\x32\60\60\60\57\x30\71\x2f\x78\x6d\154\x64\163\151\147\43\162\163\141\x2d\x73\x68\x61\61";
                $this->cryptParams["\160\x61\144\144\151\x6e\147"] = OPENSSL_PKCS1_PADDING;
                if (!(is_array($Bu) && !empty($Bu["\x74\171\x70\x65"]))) {
                    goto oB;
                }
                if (!($Bu["\164\x79\x70\x65"] == "\x70\x75\x62\154\x69\x63" || $Bu["\164\171\160\145"] == "\160\x72\151\166\x61\164\x65")) {
                    goto En;
                }
                $this->cryptParams["\x74\x79\160\x65"] = $Bu["\164\171\x70\x65"];
                goto e2;
                En:
                oB:
                throw new Exception("\103\x65\162\164\x69\146\151\x63\141\x74\x65\x20\x22\164\x79\160\x65\x22\40\50\x70\162\151\166\x61\164\x65\57\160\x75\142\x6c\x69\x63\51\x20\x6d\x75\x73\x74\x20\x62\x65\x20\x70\x61\163\x73\x65\144\40\x76\x69\141\40\x70\141\x72\141\155\145\x74\145\162\163");
            case self::RSA_SHA256:
                $this->cryptParams["\x6c\x69\142\162\x61\x72\x79"] = "\x6f\x70\145\x6e\x73\x73\154";
                $this->cryptParams["\x6d\145\164\x68\x6f\x64"] = "\x68\x74\164\160\72\x2f\57\x77\167\167\56\x77\x33\56\157\162\x67\x2f\62\60\60\61\57\x30\x34\x2f\170\x6d\x6c\x64\x73\151\x67\x2d\155\x6f\162\145\43\x72\163\141\55\x73\x68\x61\62\65\x36";
                $this->cryptParams["\x70\141\144\x64\x69\x6e\147"] = OPENSSL_PKCS1_PADDING;
                $this->cryptParams["\x64\x69\x67\145\163\164"] = "\x53\x48\101\62\x35\66";
                if (!(is_array($Bu) && !empty($Bu["\x74\171\x70\x65"]))) {
                    goto zE;
                }
                if (!($Bu["\x74\171\x70\145"] == "\x70\165\142\x6c\151\x63" || $Bu["\x74\x79\160\145"] == "\160\x72\151\166\141\164\145")) {
                    goto dc;
                }
                $this->cryptParams["\164\x79\160\145"] = $Bu["\x74\x79\x70\x65"];
                goto e2;
                dc:
                zE:
                throw new Exception("\x43\145\162\x74\151\146\x69\143\x61\x74\x65\x20\x22\164\x79\160\x65\42\40\50\160\x72\151\166\141\x74\x65\x2f\160\165\x62\x6c\151\143\51\40\155\x75\x73\164\x20\x62\145\40\x70\x61\x73\x73\145\x64\40\x76\x69\x61\x20\160\141\x72\141\155\x65\164\x65\x72\x73");
            case self::RSA_SHA384:
                $this->cryptParams["\154\x69\142\x72\x61\x72\171"] = "\157\x70\x65\156\163\163\154";
                $this->cryptParams["\x6d\145\164\150\157\x64"] = "\150\164\164\x70\x3a\x2f\x2f\x77\167\167\x2e\x77\63\56\157\162\x67\57\x32\x30\60\61\57\x30\64\57\170\155\154\144\163\151\147\55\x6d\157\x72\x65\43\162\163\x61\55\163\150\x61\63\70\64";
                $this->cryptParams["\160\x61\x64\144\151\x6e\147"] = OPENSSL_PKCS1_PADDING;
                $this->cryptParams["\144\151\147\x65\x73\164"] = "\123\110\101\63\70\64";
                if (!(is_array($Bu) && !empty($Bu["\x74\171\x70\x65"]))) {
                    goto tv;
                }
                if (!($Bu["\x74\171\x70\x65"] == "\x70\165\x62\154\x69\143" || $Bu["\x74\171\160\145"] == "\x70\x72\x69\x76\141\x74\145")) {
                    goto ut;
                }
                $this->cryptParams["\x74\171\160\145"] = $Bu["\164\x79\x70\145"];
                goto e2;
                ut:
                tv:
                throw new Exception("\103\145\x72\x74\151\x66\151\143\x61\x74\x65\40\42\x74\x79\160\145\42\40\x28\x70\162\x69\166\141\x74\x65\57\x70\x75\x62\x6c\151\x63\x29\40\155\x75\x73\x74\x20\x62\145\x20\x70\x61\163\x73\x65\x64\x20\166\x69\141\40\160\x61\x72\x61\x6d\x65\164\x65\162\x73");
            case self::RSA_SHA512:
                $this->cryptParams["\154\x69\x62\x72\141\162\171"] = "\157\160\x65\156\x73\163\154";
                $this->cryptParams["\x6d\x65\x74\x68\x6f\x64"] = "\x68\164\164\x70\x3a\x2f\57\x77\x77\167\x2e\167\x33\x2e\157\162\x67\57\62\60\x30\61\57\60\64\57\x78\x6d\x6c\x64\x73\151\x67\55\155\x6f\x72\145\43\162\x73\x61\55\x73\x68\x61\x35\x31\62";
                $this->cryptParams["\160\x61\x64\144\x69\156\147"] = OPENSSL_PKCS1_PADDING;
                $this->cryptParams["\144\151\x67\145\x73\164"] = "\x53\110\101\65\61\62";
                if (!(is_array($Bu) && !empty($Bu["\x74\171\160\145"]))) {
                    goto dS;
                }
                if (!($Bu["\164\171\x70\x65"] == "\x70\165\x62\154\151\143" || $Bu["\x74\x79\160\x65"] == "\160\x72\151\166\141\164\145")) {
                    goto ES;
                }
                $this->cryptParams["\x74\x79\160\145"] = $Bu["\164\x79\x70\x65"];
                goto e2;
                ES:
                dS:
                throw new Exception("\x43\x65\162\164\151\146\151\143\141\x74\x65\x20\42\x74\171\160\145\42\40\50\160\162\151\x76\x61\164\145\57\x70\x75\x62\154\151\143\x29\40\155\x75\x73\x74\40\x62\145\40\160\141\x73\163\x65\x64\40\166\151\141\40\160\141\162\x61\155\x65\x74\x65\162\x73");
            case self::HMAC_SHA1:
                $this->cryptParams["\x6c\151\142\x72\141\x72\171"] = $AG;
                $this->cryptParams["\155\x65\164\150\157\144"] = "\150\x74\164\x70\x3a\57\x2f\167\x77\x77\x2e\167\x33\56\157\x72\147\57\x32\60\x30\x30\x2f\x30\71\57\x78\x6d\154\144\163\151\147\43\x68\x6d\x61\143\55\163\150\141\x31";
                goto e2;
            default:
                throw new Exception("\x49\156\x76\x61\x6c\x69\x64\x20\x4b\x65\171\x20\x54\x79\160\x65");
        }
        gG:
        e2:
        $this->type = $AG;
    }
    public function getSymmetricKeySize()
    {
        if (isset($this->cryptParams["\x6b\145\171\163\151\x7a\145"])) {
            goto wP;
        }
        return null;
        wP:
        return $this->cryptParams["\x6b\145\x79\x73\151\x7a\x65"];
    }
    public function generateSessionKey()
    {
        if (isset($this->cryptParams["\x6b\x65\x79\x73\x69\172\x65"])) {
            goto VR;
        }
        throw new Exception("\x55\156\153\x6e\157\167\x6e\x20\x6b\x65\171\x20\x73\151\172\145\x20\x66\157\x72\x20\164\171\160\x65\40\42" . $this->type . "\42\56");
        VR:
        $n0 = $this->cryptParams["\153\x65\171\163\x69\172\x65"];
        $a5 = openssl_random_pseudo_bytes($n0);
        if (!($this->type === self::TRIPLEDES_CBC)) {
            goto Ef;
        }
        $Cz = 0;
        oo:
        if (!($Cz < strlen($a5))) {
            goto LN;
        }
        $nu = ord($a5[$Cz]) & 0xfe;
        $AN = 1;
        $RO = 1;
        bn:
        if (!($RO < 8)) {
            goto H2;
        }
        $AN ^= $nu >> $RO & 1;
        Uz:
        $RO++;
        goto bn;
        H2:
        $nu |= $AN;
        $a5[$Cz] = chr($nu);
        du:
        $Cz++;
        goto oo;
        LN:
        Ef:
        $this->key = $a5;
        return $a5;
    }
    public static function getRawThumbprint($u0)
    {
        $uS = explode("\12", $u0);
        $UF = '';
        $Eg = false;
        foreach ($uS as $TI) {
            if (!$Eg) {
                goto No;
            }
            if (!(strncmp($TI, "\55\x2d\55\55\55\105\x4e\x44\40\x43\105\x52\x54\111\x46\111\x43\x41\124\105", 20) == 0)) {
                goto YI;
            }
            goto Wt;
            YI:
            $UF .= trim($TI);
            goto Im;
            No:
            if (!(strncmp($TI, "\x2d\55\x2d\x2d\55\x42\105\107\x49\x4e\40\x43\105\x52\x54\111\x46\111\x43\x41\x54\x45", 22) == 0)) {
                goto Oq;
            }
            $Eg = true;
            Oq:
            Im:
            l3:
        }
        Wt:
        if (empty($UF)) {
            goto mJ;
        }
        return strtolower(sha1(base64_decode($UF)));
        mJ:
        return null;
    }
    public function loadKey($a5, $DH = false, $MP = false)
    {
        if ($DH) {
            goto hp;
        }
        $this->key = $a5;
        goto l0;
        hp:
        $this->key = file_get_contents($a5);
        l0:
        if ($MP) {
            goto N3;
        }
        $this->x509Certificate = null;
        goto fR;
        N3:
        $this->key = openssl_x509_read($this->key);
        openssl_x509_export($this->key, $Rz);
        $this->x509Certificate = $Rz;
        $this->key = $Rz;
        fR:
        if (!($this->cryptParams["\154\151\x62\162\x61\x72\171"] == "\x6f\160\x65\156\163\163\154")) {
            goto Qo;
        }
        switch ($this->cryptParams["\164\171\x70\x65"]) {
            case "\x70\165\x62\x6c\151\x63":
                if (!$MP) {
                    goto pH;
                }
                $this->X509Thumbprint = self::getRawThumbprint($this->key);
                pH:
                $this->key = openssl_get_publickey($this->key);
                if ($this->key) {
                    goto Oj;
                }
                throw new Exception("\125\156\x61\142\x6c\145\x20\x74\x6f\x20\x65\x78\x74\x72\x61\143\164\x20\x70\165\142\154\151\x63\x20\x6b\145\171");
                Oj:
                goto pX;
            case "\160\162\x69\166\141\x74\x65":
                $this->key = openssl_get_privatekey($this->key, $this->passphrase);
                goto pX;
            case "\163\171\x6d\x6d\x65\164\162\151\x63":
                if (!(strlen($this->key) < $this->cryptParams["\153\145\x79\163\x69\x7a\145"])) {
                    goto r1;
                }
                throw new Exception("\x4b\145\171\x20\155\165\x73\164\x20\x63\x6f\x6e\x74\x61\151\156\40\141\x74\40\x6c\x65\x61\x73\164\40\62\x35\x20\x63\x68\x61\x72\x61\143\x74\x65\x72\163\40\146\157\162\40\x74\x68\x69\163\40\143\x69\x70\150\x65\162");
                r1:
                goto pX;
            default:
                throw new Exception("\125\x6e\x6b\x6e\x6f\167\x6e\x20\164\171\x70\x65");
        }
        Bf:
        pX:
        Qo:
    }
    private function padISO10126($UF, $aj)
    {
        if (!($aj > 256)) {
            goto Xr;
        }
        throw new Exception("\102\154\x6f\x63\x6b\x20\163\x69\172\145\x20\150\151\x67\150\x65\x72\40\x74\x68\x61\156\x20\62\x35\66\40\x6e\x6f\164\40\x61\x6c\154\x6f\167\145\144");
        Xr:
        $Ox = $aj - strlen($UF) % $aj;
        $F0 = chr($Ox);
        return $UF . str_repeat($F0, $Ox);
    }
    private function unpadISO10126($UF)
    {
        $Ox = substr($UF, -1);
        $LV = ord($Ox);
        return substr($UF, 0, -$LV);
    }
    private function encryptSymmetric($UF)
    {
        $this->iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length($this->cryptParams["\x63\x69\x70\150\145\162"]));
        $UF = $this->padISO10126($UF, $this->cryptParams["\142\154\157\x63\x6b\163\151\172\145"]);
        $wO = openssl_encrypt($UF, $this->cryptParams["\143\151\x70\150\x65\x72"], $this->key, OPENSSL_RAW_DATA | OPENSSL_ZERO_PADDING, $this->iv);
        if (!(false === $wO)) {
            goto pF;
        }
        throw new Exception("\x46\141\x69\154\165\x72\145\x20\145\x6e\x63\162\x79\x70\164\151\156\147\40\104\x61\164\141\40\x28\x6f\160\145\156\163\x73\154\40\x73\x79\155\155\145\x74\x72\151\143\51\x20\55\40" . openssl_error_string());
        pF:
        return $this->iv . $wO;
    }
    private function decryptSymmetric($UF)
    {
        $PS = openssl_cipher_iv_length($this->cryptParams["\x63\151\160\150\145\x72"]);
        $this->iv = substr($UF, 0, $PS);
        $UF = substr($UF, $PS);
        $Vc = openssl_decrypt($UF, $this->cryptParams["\143\x69\160\x68\145\x72"], $this->key, OPENSSL_RAW_DATA | OPENSSL_ZERO_PADDING, $this->iv);
        if (!(false === $Vc)) {
            goto NV;
        }
        throw new Exception("\106\x61\x69\154\165\x72\145\x20\x64\x65\x63\x72\x79\x70\164\151\156\147\40\x44\141\164\141\x20\x28\x6f\160\x65\x6e\163\x73\x6c\40\163\x79\155\155\145\x74\162\151\x63\51\x20\55\x20" . openssl_error_string());
        NV:
        return $this->unpadISO10126($Vc);
    }
    private function encryptPublic($UF)
    {
        if (openssl_public_encrypt($UF, $wO, $this->key, $this->cryptParams["\x70\141\x64\144\x69\156\x67"])) {
            goto Sa;
        }
        throw new Exception("\106\x61\151\154\165\x72\x65\x20\145\x6e\x63\x72\x79\160\x74\151\156\x67\x20\x44\x61\164\x61\40\x28\157\160\145\156\x73\163\154\40\x70\x75\x62\154\151\143\51\40\55\x20" . openssl_error_string());
        Sa:
        return $wO;
    }
    private function decryptPublic($UF)
    {
        if (openssl_public_decrypt($UF, $Vc, $this->key, $this->cryptParams["\160\x61\144\144\x69\x6e\x67"])) {
            goto zy;
        }
        throw new Exception("\x46\x61\x69\154\165\162\145\x20\144\x65\x63\x72\x79\160\x74\151\156\147\x20\x44\x61\x74\x61\40\x28\x6f\160\x65\x6e\163\163\154\x20\x70\165\142\x6c\x69\x63\x29\x20\x2d\40" . openssl_error_string());
        zy:
        return $Vc;
    }
    private function encryptPrivate($UF)
    {
        if (openssl_private_encrypt($UF, $wO, $this->key, $this->cryptParams["\160\141\x64\144\151\156\x67"])) {
            goto zF;
        }
        throw new Exception("\x46\x61\x69\154\x75\162\x65\x20\x65\x6e\143\162\171\x70\164\x69\156\147\x20\x44\141\164\x61\40\x28\x6f\x70\x65\x6e\163\163\x6c\40\x70\162\151\x76\141\x74\x65\51\40\x2d\40" . openssl_error_string());
        zF:
        return $wO;
    }
    private function decryptPrivate($UF)
    {
        if (openssl_private_decrypt($UF, $Vc, $this->key, $this->cryptParams["\x70\x61\x64\144\151\156\147"])) {
            goto bt;
        }
        throw new Exception("\x46\x61\151\154\x75\x72\145\40\x64\145\x63\x72\171\x70\164\151\156\147\x20\104\141\164\x61\x20\50\x6f\x70\x65\156\163\163\x6c\x20\x70\162\x69\166\x61\x74\x65\51\x20\x2d\40" . openssl_error_string());
        bt:
        return $Vc;
    }
    private function signOpenSSL($UF)
    {
        $LS = OPENSSL_ALGO_SHA1;
        if (empty($this->cryptParams["\x64\x69\x67\145\x73\x74"])) {
            goto Yt;
        }
        $LS = $this->cryptParams["\x64\151\147\145\163\164"];
        Yt:
        if (openssl_sign($UF, $Xe, $this->key, $LS)) {
            goto mF;
        }
        throw new Exception("\x46\141\151\x6c\165\x72\x65\x20\123\151\x67\156\x69\156\x67\x20\x44\141\x74\x61\x3a\x20" . openssl_error_string() . "\x20\55\40" . $LS);
        mF:
        return $Xe;
    }
    private function verifyOpenSSL($UF, $Xe)
    {
        $LS = OPENSSL_ALGO_SHA1;
        if (empty($this->cryptParams["\144\x69\x67\x65\163\164"])) {
            goto zb;
        }
        $LS = $this->cryptParams["\144\x69\147\145\x73\164"];
        zb:
        return openssl_verify($UF, $Xe, $this->key, $LS);
    }
    public function encryptData($UF)
    {
        if (!($this->cryptParams["\154\x69\x62\162\x61\162\171"] === "\157\160\145\156\163\163\154")) {
            goto cb;
        }
        switch ($this->cryptParams["\164\x79\160\145"]) {
            case "\x73\171\x6d\155\145\164\162\x69\x63":
                return $this->encryptSymmetric($UF);
            case "\160\165\142\154\x69\x63":
                return $this->encryptPublic($UF);
            case "\x70\162\x69\x76\x61\x74\x65":
                return $this->encryptPrivate($UF);
        }
        Lo:
        tG:
        cb:
    }
    public function decryptData($UF)
    {
        if (!($this->cryptParams["\x6c\x69\142\162\x61\x72\171"] === "\157\x70\145\x6e\x73\163\x6c")) {
            goto o9;
        }
        switch ($this->cryptParams["\x74\x79\x70\145"]) {
            case "\x73\171\155\x6d\145\x74\162\x69\143":
                return $this->decryptSymmetric($UF);
            case "\160\165\x62\x6c\151\x63":
                return $this->decryptPublic($UF);
            case "\160\x72\x69\x76\141\164\145":
                return $this->decryptPrivate($UF);
        }
        cY:
        jA:
        o9:
    }
    public function signData($UF)
    {
        switch ($this->cryptParams["\154\x69\x62\162\x61\x72\171"]) {
            case "\x6f\160\x65\156\x73\163\154":
                return $this->signOpenSSL($UF);
            case self::HMAC_SHA1:
                return hash_hmac("\x73\x68\x61\x31", $UF, $this->key, true);
        }
        rY:
        DP:
    }
    public function verifySignature($UF, $Xe)
    {
        switch ($this->cryptParams["\154\151\142\x72\x61\x72\171"]) {
            case "\157\x70\x65\156\x73\x73\154":
                return $this->verifyOpenSSL($UF, $Xe);
            case self::HMAC_SHA1:
                $hW = hash_hmac("\x73\x68\141\x31", $UF, $this->key, true);
                return strcmp($Xe, $hW) == 0;
        }
        YT:
        nJ:
    }
    public function getAlgorith()
    {
        return $this->getAlgorithm();
    }
    public function getAlgorithm()
    {
        return $this->cryptParams["\x6d\x65\x74\150\x6f\144"];
    }
    public static function makeAsnSegment($AG, $YN)
    {
        switch ($AG) {
            case 0x2:
                if (!(ord($YN) > 0x7f)) {
                    goto UM;
                }
                $YN = chr(0) . $YN;
                UM:
                goto DH;
            case 0x3:
                $YN = chr(0) . $YN;
                goto DH;
        }
        Vg:
        DH:
        $HD = strlen($YN);
        if ($HD < 128) {
            goto qS;
        }
        if ($HD < 0x100) {
            goto bN;
        }
        if ($HD < 0x10000) {
            goto p6;
        }
        $sJ = null;
        goto vs;
        p6:
        $sJ = sprintf("\45\x63\45\143\x25\x63\x25\x63\45\x73", $AG, 0x82, $HD / 0x100, $HD % 0x100, $YN);
        vs:
        goto uE;
        bN:
        $sJ = sprintf("\x25\143\x25\143\45\x63\45\163", $AG, 0x81, $HD, $YN);
        uE:
        goto JT;
        qS:
        $sJ = sprintf("\x25\x63\45\x63\45\x73", $AG, $HD, $YN);
        JT:
        return $sJ;
    }
    public static function convertRSA($e1, $a1)
    {
        $SU = self::makeAsnSegment(0x2, $a1);
        $eR = self::makeAsnSegment(0x2, $e1);
        $sC = self::makeAsnSegment(0x30, $eR . $SU);
        $iM = self::makeAsnSegment(0x3, $sC);
        $Nr = pack("\110\52", "\63\x30\60\x44\x30\66\x30\x39\x32\101\70\66\x34\x38\70\66\x46\x37\x30\x44\x30\61\x30\x31\x30\x31\60\65\60\x30");
        $u4 = self::makeAsnSegment(0x30, $Nr . $iM);
        $Ps = base64_encode($u4);
        $I4 = "\x2d\x2d\55\55\x2d\x42\105\x47\111\116\40\x50\x55\102\114\111\x43\x20\113\x45\131\x2d\55\x2d\55\x2d\12";
        $Lx = 0;
        rp:
        if (!($u7 = substr($Ps, $Lx, 64))) {
            goto Qv;
        }
        $I4 = $I4 . $u7 . "\xa";
        $Lx += 64;
        goto rp;
        Qv:
        return $I4 . "\x2d\x2d\x2d\x2d\x2d\105\x4e\104\x20\x50\125\102\x4c\111\x43\x20\x4b\x45\x59\55\x2d\x2d\x2d\x2d\12";
    }
    public function serializeKey($V7)
    {
    }
    public function getX509Certificate()
    {
        return $this->x509Certificate;
    }
    public function getX509Thumbprint()
    {
        return $this->X509Thumbprint;
    }
    public static function fromEncryptedKeyElement(DOMElement $RR)
    {
        $MF = new XMLSecEnc();
        $MF->setNode($RR);
        if ($u8 = $MF->locateKey()) {
            goto P6;
        }
        throw new Exception("\x55\x6e\141\142\x6c\x65\x20\164\157\40\x6c\157\x63\x61\164\145\x20\x61\154\147\157\162\151\x74\150\155\x20\146\157\162\x20\164\x68\151\163\40\x45\x6e\x63\162\171\x70\x74\x65\x64\x20\113\x65\x79");
        P6:
        $u8->isEncrypted = true;
        $u8->encryptedCtx = $MF;
        XMLSecEnc::staticLocateKeyInfo($u8, $RR);
        return $u8;
    }
}
