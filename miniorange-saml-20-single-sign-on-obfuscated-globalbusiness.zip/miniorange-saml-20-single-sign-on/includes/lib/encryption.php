<?php


class AESEncryption
{
    public static function encrypt_data($UF, $a5)
    {
        $a5 = openssl_digest($a5, "\x73\150\141\x32\65\66");
        $j0 = "\141\145\x73\x2d\x31\x32\70\x2d\145\143\x62";
        $o5 = openssl_encrypt($UF, $j0, $a5, OPENSSL_RAW_DATA || OPENSSL_ZERO_PADDING);
        return base64_encode($o5);
    }
    public static function decrypt_data($UF, $a5)
    {
        $l3 = base64_decode($UF);
        $a5 = openssl_digest($a5, "\163\150\x61\x32\x35\66");
        $j0 = "\101\x45\123\x2d\61\62\70\55\105\103\102";
        $QE = openssl_cipher_iv_length($j0);
        $s9 = substr($l3, 0, $QE);
        $UF = substr($l3, $QE);
        $YR = openssl_decrypt($UF, $j0, $a5, OPENSSL_RAW_DATA || OPENSSL_ZERO_PADDING, $s9);
        return $YR;
    }
}
