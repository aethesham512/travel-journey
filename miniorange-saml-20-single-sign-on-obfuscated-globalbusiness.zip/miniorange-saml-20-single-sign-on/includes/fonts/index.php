<?php


if (defined("\x57\120\x49\x4e\103")) {
    goto yv;
}
die;
yv:
