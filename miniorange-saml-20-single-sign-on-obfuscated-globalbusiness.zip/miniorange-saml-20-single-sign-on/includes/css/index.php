<?php


if (defined("\x57\120\111\x4e\103")) {
    goto mx;
}
die;
mx:
