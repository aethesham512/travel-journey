<?php


if (defined("\x57\120\111\116\103")) {
    goto dl;
}
die;
dl:
