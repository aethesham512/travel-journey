<?php


class CertificateUtility
{
    public static function generate_certificate($qe, $YI, $TH)
    {
        $lD = openssl_pkey_new();
        $tL = openssl_csr_new($qe, $lD, $YI);
        $Ry = openssl_csr_sign($tL, null, $lD, $TH, $YI, time());
        openssl_csr_export($tL, $xg);
        openssl_x509_export($Ry, $sk);
        openssl_pkey_export($lD, $qh);
        Re:
        if (!(($jB = openssl_error_string()) !== false)) {
            goto gK;
        }
        error_log("\103\145\x72\x74\151\x66\151\143\x61\x74\145\125\x74\x69\x6c\x69\x74\171\x3a\x20\x45\x72\x72\x6f\162\x20\x67\145\156\x65\162\x61\164\151\x6e\147\x20\143\145\x72\164\x69\146\151\x63\x61\x74\145\56\40" . $jB);
        goto Re;
        gK:
        $x4 = array("\x70\x75\x62\154\x69\x63\x5f\153\x65\171" => $sk, "\x70\162\x69\x76\141\164\145\x5f\153\x65\171" => $qh);
        return $x4;
    }
}
