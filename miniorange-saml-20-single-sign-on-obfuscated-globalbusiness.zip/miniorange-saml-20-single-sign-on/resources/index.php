<?php


if (defined("\127\120\111\x4e\103")) {
    goto nvV;
}
die;
nvV:
