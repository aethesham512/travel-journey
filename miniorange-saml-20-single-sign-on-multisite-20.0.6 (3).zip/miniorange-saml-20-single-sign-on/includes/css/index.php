<?php


if (defined("\x57\x50\111\116\x43")) {
    goto uJ;
}
die;
uJ:
