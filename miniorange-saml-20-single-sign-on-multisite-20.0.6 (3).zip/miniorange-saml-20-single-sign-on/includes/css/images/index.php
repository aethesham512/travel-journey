<?php


if (defined("\127\120\111\116\x43")) {
    goto N6;
}
die;
N6:
