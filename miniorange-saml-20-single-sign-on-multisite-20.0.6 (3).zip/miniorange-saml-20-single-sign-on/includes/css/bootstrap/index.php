<?php


if (defined("\127\x50\x49\x4e\103")) {
    goto ey;
}
die;
ey:
