<?php


if (defined("\127\120\111\x4e\103")) {
    goto rs;
}
die;
rs:
