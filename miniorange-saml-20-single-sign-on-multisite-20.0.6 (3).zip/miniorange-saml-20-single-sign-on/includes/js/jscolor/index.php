<?php


if (defined("\127\120\x49\x4e\103")) {
    goto aq;
}
die;
aq:
