<?php


if (defined("\x57\x50\x49\116\x43")) {
    goto tQF;
}
die;
tQF:
