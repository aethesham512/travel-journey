<?php


if (defined("\x57\120\x49\x4e\x43")) {
    goto Iu;
}
die;
Iu:
