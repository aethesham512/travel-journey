<?php


include "\x41\x73\163\x65\162\164\151\x6f\156\56\160\x68\x70";
class SAML2_Response
{
    private $assertions;
    private $destination;
    private $certificates;
    private $signatureData;
    public function __construct(DOMElement $tn = NULL, $rm)
    {
        $this->assertions = array();
        $this->certificates = array();
        if (!($tn === NULL)) {
            goto aJy;
        }
        return;
        aJy:
        $ad = Utilities::validateElement($tn);
        if (!($ad !== FALSE)) {
            goto aNZ;
        }
        $this->certificates = $ad["\103\145\162\164\151\x66\151\143\x61\x74\x65\163"];
        $this->signatureData = $ad;
        aNZ:
        if (!$tn->hasAttribute("\x44\145\x73\x74\x69\x6e\x61\164\151\x6f\156")) {
            goto Y2x;
        }
        $this->destination = $tn->getAttribute("\104\x65\x73\164\151\x6e\141\x74\x69\x6f\x6e");
        Y2x:
        $tB = $tn->firstChild;
        nXO:
        if (!($tB !== NULL)) {
            goto jYD;
        }
        if (!($tB->namespaceURI !== "\165\162\156\72\157\x61\x73\151\163\72\x6e\141\155\145\163\72\x74\143\72\123\x41\115\x4c\x3a\x32\x2e\60\72\x61\x73\163\x65\162\x74\151\157\x6e")) {
            goto nGS;
        }
        goto X0U;
        nGS:
        if (!($tB->localName === "\x41\x73\163\145\162\164\x69\x6f\x6e" || $tB->localName === "\x45\x6e\143\x72\171\x70\164\145\144\x41\163\x73\145\x72\x74\x69\x6f\156")) {
            goto Kig;
        }
        $this->assertions[] = new SAML2_Assertion($tB, $rm);
        Kig:
        X0U:
        $tB = $tB->nextSibling;
        goto nXO;
        jYD:
    }
    public function getAssertions()
    {
        return $this->assertions;
    }
    public function setAssertions(array $gp)
    {
        $this->assertions = $gp;
    }
    public function getDestination()
    {
        return $this->destination;
    }
    public function getCertificates()
    {
        return $this->certificates;
    }
    public function getSignatureData()
    {
        return $this->signatureData;
    }
}
