<?php


if (defined("\127\120\x49\x4e\x43")) {
    goto f2;
}
die;
f2:
