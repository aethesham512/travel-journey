<?php


if (defined("\127\x50\x49\116\x43")) {
    goto xl;
}
die;
xl:
