<?php


namespace RobRichards\XMLSecLibs\Utils;

class XPath
{
    const ALPHANUMERIC = "\x5c\167\134\144";
    const NUMERIC = "\x5c\x64";
    const LETTERS = "\134\x77";
    const EXTENDED_ALPHANUMERIC = "\x5c\x77\134\144\x5c\x73\x5c\55\x5f\72\x5c\56";
    const SINGLE_QUOTE = "\47";
    const DOUBLE_QUOTE = "\42";
    const ALL_QUOTES = "\x5b\x27\42\x5d";
    public static function filterAttrValue($jR, $yw = self::ALL_QUOTES)
    {
        return preg_replace("\43" . $yw . "\43", '', $jR);
    }
    public static function filterAttrName($Ym, $P3 = self::EXTENDED_ALPHANUMERIC)
    {
        return preg_replace("\x23\x5b\x5e" . $P3 . "\135\43", '', $Ym);
    }
}
