<?php


class AESEncryption
{
    public static function encrypt_data($Xu, $u_)
    {
        $u_ = openssl_digest($u_, "\163\x68\141\x32\65\x36");
        $Z7 = "\x61\x65\x73\55\61\x32\70\x2d\145\143\x62";
        $YI = openssl_encrypt($Xu, $Z7, $u_, OPENSSL_RAW_DATA || OPENSSL_ZERO_PADDING);
        return base64_encode($YI);
    }
    public static function decrypt_data($Xu, $u_)
    {
        $aD = base64_decode($Xu);
        $u_ = openssl_digest($u_, "\x73\x68\x61\62\x35\66");
        $Z7 = "\101\105\x53\55\61\62\x38\55\x45\103\x42";
        $zq = openssl_cipher_iv_length($Z7);
        $yz = substr($aD, 0, $zq);
        $Xu = substr($aD, $zq);
        $UL = openssl_decrypt($Xu, $Z7, $u_, OPENSSL_RAW_DATA || OPENSSL_ZERO_PADDING, $yz);
        return $UL;
    }
}
