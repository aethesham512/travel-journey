<?php


class CertificateUtility
{
    public static function generate_certificate($po, $d5, $Hu)
    {
        $Cs = openssl_pkey_new();
        $sg = openssl_csr_new($po, $Cs, $d5);
        $Kj = openssl_csr_sign($sg, null, $Cs, $Hu, $d5, time());
        openssl_csr_export($sg, $d1);
        openssl_x509_export($Kj, $vr);
        openssl_pkey_export($Cs, $jL);
        rl:
        if (!(($i0 = openssl_error_string()) !== false)) {
            goto bb;
        }
        error_log("\103\145\x72\164\x69\146\x69\143\x61\x74\x65\125\164\x69\x6c\151\x74\x79\72\x20\105\162\162\x6f\x72\40\x67\x65\x6e\x65\162\141\x74\151\x6e\x67\40\x63\145\x72\x74\151\146\151\143\x61\x74\x65\x2e\40" . $i0);
        goto rl;
        bb:
        $FD = array("\160\165\x62\x6c\151\x63\x5f\x6b\x65\171" => $vr, "\160\x72\x69\166\x61\x74\x65\x5f\153\145\x79" => $jL);
        return $FD;
    }
}
