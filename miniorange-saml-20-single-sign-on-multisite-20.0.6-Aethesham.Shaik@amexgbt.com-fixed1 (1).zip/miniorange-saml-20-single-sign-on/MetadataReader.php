<?php


include_once "\125\x74\x69\154\x69\x74\151\145\x73\x2e\x70\150\x70";
class MetadataReader
{
    private $identityProviders;
    private $serviceProviders;
    public function __construct(DOMNode $tn = NULL)
    {
        $this->identityProviders = array();
        $this->serviceProviders = array();
        $RV = Utilities::xpQuery($tn, "\x2e\x2f\x73\141\155\x6c\137\155\x65\164\x61\144\141\x74\x61\x3a\x45\156\x74\151\x74\x69\x65\x73\x44\x65\x73\143\x72\x69\x70\x74\157\x72");
        if (!empty($RV)) {
            goto OV;
        }
        $Ma = Utilities::xpQuery($tn, "\56\x2f\x73\x61\x6d\154\x5f\155\x65\x74\141\x64\x61\x74\x61\x3a\x45\x6e\164\x69\164\171\104\x65\x73\143\x72\151\160\164\x6f\162");
        goto c9;
        OV:
        $Ma = Utilities::xpQuery($RV[0], "\56\x2f\163\141\x6d\154\x5f\x6d\x65\x74\x61\144\x61\x74\x61\72\x45\156\164\x69\164\x79\104\145\x73\143\x72\x69\x70\x74\x6f\x72");
        c9:
        foreach ($Ma as $WJ) {
            $A1 = Utilities::xpQuery($WJ, "\x2e\x2f\x73\x61\155\x6c\x5f\x6d\145\164\x61\x64\141\164\141\72\x49\104\x50\x53\123\117\x44\x65\163\143\x72\151\x70\164\x6f\x72");
            if (!(isset($A1) && !empty($A1))) {
                goto HG;
            }
            array_push($this->identityProviders, new IdentityProviders($WJ));
            HG:
            fM:
        }
        fc:
    }
    public function getIdentityProviders()
    {
        return $this->identityProviders;
    }
    public function getServiceProviders()
    {
        return $this->serviceProviders;
    }
}
class IdentityProviders
{
    private $idpName;
    private $entityID;
    private $loginDetails;
    private $logoutDetails;
    private $signingCertificate;
    private $encryptionCertificate;
    private $signedRequest;
    private $loginbinding;
    private $logoutbinding;
    public function __construct(DOMElement $tn = NULL)
    {
        $this->idpName = '';
        $this->loginDetails = array();
        $this->logoutDetails = array();
        $this->signingCertificate = array();
        $this->encryptionCertificate = array();
        if (!$tn->hasAttribute("\x65\x6e\164\151\x74\171\111\104")) {
            goto lb;
        }
        $this->entityID = $tn->getAttribute("\x65\x6e\164\151\x74\x79\111\x44");
        lb:
        if (!$tn->hasAttribute("\127\x61\156\x74\101\x75\x74\x68\156\122\x65\161\165\145\x73\164\x73\123\x69\147\156\145\144")) {
            goto Xn;
        }
        $this->signedRequest = $tn->getAttribute("\x57\141\x6e\x74\x41\x75\x74\150\156\x52\x65\161\165\145\163\x74\x73\123\x69\147\x6e\145\144");
        Xn:
        $A1 = Utilities::xpQuery($tn, "\x2e\x2f\163\141\155\x6c\137\155\145\x74\141\144\141\164\141\72\111\104\x50\x53\123\x4f\104\x65\163\x63\x72\x69\160\x74\x6f\x72");
        if (count($A1) > 1) {
            goto Qz;
        }
        if (empty($A1)) {
            goto zI;
        }
        goto DC;
        Qz:
        throw new Exception("\x4d\157\x72\x65\40\x74\150\x61\156\40\157\x6e\x65\x20\x3c\111\104\x50\x53\x53\117\x44\145\163\143\162\x69\x70\x74\x6f\x72\76\x20\151\x6e\40\74\x45\x6e\164\x69\164\x79\x44\x65\163\x63\x72\151\x70\164\157\162\76\x2e");
        goto DC;
        zI:
        throw new Exception("\x4d\151\163\x73\x69\x6e\x67\x20\x72\x65\161\165\x69\x72\x65\x64\40\74\111\x44\x50\x53\123\x4f\x44\x65\x73\x63\x72\151\160\164\x6f\162\x3e\40\151\156\x20\74\105\x6e\164\x69\164\171\104\x65\x73\143\x72\x69\x70\x74\157\x72\76\56");
        DC:
        $Ux = $A1[0];
        $Tz = Utilities::xpQuery($tn, "\56\57\163\141\155\154\x5f\155\145\164\x61\144\x61\x74\x61\x3a\x45\x78\x74\145\156\x73\x69\x6f\156\163");
        if (!$Tz) {
            goto hq;
        }
        $this->parseInfo($Ux);
        hq:
        $this->parseSSOService($Ux);
        $this->parseSLOService($Ux);
        $this->parsex509Certificate($Ux);
    }
    private function parseInfo($tn)
    {
        $RO = Utilities::xpQuery($tn, "\x2e\x2f\155\144\x75\151\72\125\111\x49\x6e\146\x6f\57\155\x64\x75\151\x3a\x44\x69\163\160\154\x61\171\x4e\141\x6d\x65");
        foreach ($RO as $Ym) {
            if (!($Ym->hasAttribute("\x78\155\154\72\x6c\141\x6e\147") && $Ym->getAttribute("\170\155\154\x3a\x6c\x61\156\x67") == "\x65\156")) {
                goto jv;
            }
            $this->idpName = $Ym->textContent;
            jv:
            A4:
        }
        vg:
    }
    private function parseSSOService($tn)
    {
        $PA = Utilities::xpQuery($tn, "\56\x2f\163\x61\x6d\154\x5f\155\145\x74\x61\144\141\x74\x61\x3a\x53\x69\156\147\x6c\x65\x53\x69\x67\x6e\117\x6e\x53\145\162\166\x69\x63\145");
        $NW = 0;
        foreach ($PA as $Ex) {
            $yy = str_replace("\165\162\156\x3a\x6f\x61\163\151\x73\x3a\156\141\x6d\145\x73\x3a\x74\x63\72\123\101\x4d\114\x3a\62\56\x30\72\x62\151\x6e\x64\x69\x6e\147\163\x3a", '', $Ex->getAttribute("\x42\151\x6e\144\151\x6e\147"));
            $this->loginDetails = array_merge($this->loginDetails, array($yy => $Ex->getAttribute("\x4c\157\x63\141\x74\151\157\156")));
            if (!($yy == "\110\124\x54\120\x2d\x52\145\144\x69\x72\x65\143\164")) {
                goto jH;
            }
            $NW = 1;
            $this->loginbinding = "\110\164\x74\x70\122\145\x64\151\x72\145\x63\x74";
            jH:
            Wx:
        }
        mg:
        if ($NW) {
            goto Rc;
        }
        $this->loginbinding = "\x48\x74\164\160\x50\157\163\x74";
        Rc:
    }
    private function parseSLOService($tn)
    {
        $NW = 0;
        $Q4 = Utilities::xpQuery($tn, "\x2e\57\163\x61\x6d\154\137\155\x65\x74\x61\x64\x61\164\x61\72\x53\x69\156\147\154\145\114\157\x67\157\165\x74\123\145\x72\166\151\143\145");
        foreach ($Q4 as $bm) {
            $yy = str_replace("\x75\x72\156\x3a\157\x61\163\x69\x73\x3a\x6e\x61\155\145\163\x3a\164\143\x3a\123\x41\x4d\x4c\x3a\62\56\60\x3a\142\151\x6e\x64\151\156\147\x73\x3a", '', $bm->getAttribute("\102\151\156\144\151\x6e\x67"));
            $this->logoutDetails = array_merge($this->logoutDetails, array($yy => $bm->getAttribute("\x4c\x6f\x63\141\164\151\157\156")));
            if (!($yy == "\110\124\x54\x50\x2d\122\x65\x64\151\162\145\x63\x74")) {
                goto Wi;
            }
            $NW = 1;
            $this->logoutbinding = "\x48\x74\164\160\122\x65\144\151\162\145\143\164";
            Wi:
            MT:
        }
        VO:
        if (!empty($this->logoutbinding)) {
            goto z1;
        }
        $this->logoutbinding = "\110\164\x74\160\120\157\163\x74";
        z1:
    }
    private function parsex509Certificate($tn)
    {
        foreach (Utilities::xpQuery($tn, "\x2e\57\x73\x61\155\154\x5f\x6d\x65\164\141\x64\141\164\x61\x3a\x4b\145\x79\x44\x65\x73\143\162\151\160\x74\157\162") as $Mk) {
            if ($Mk->hasAttribute("\165\x73\x65")) {
                goto o4;
            }
            $this->parseSigningCertificate($Mk);
            goto rc;
            o4:
            if ($Mk->getAttribute("\x75\x73\145") == "\x65\x6e\143\162\x79\160\164\x69\157\x6e") {
                goto dG;
            }
            $this->parseSigningCertificate($Mk);
            goto Qi;
            dG:
            $this->parseEncryptionCertificate($Mk);
            Qi:
            rc:
            Qb:
        }
        uE:
    }
    private function parseSigningCertificate($tn)
    {
        $AY = Utilities::xpQuery($tn, "\x2e\57\x64\163\x3a\x4b\145\171\111\x6e\146\157\x2f\x64\163\72\130\65\60\x39\104\141\164\141\x2f\144\163\72\x58\x35\60\71\103\145\162\x74\x69\x66\x69\143\x61\164\x65");
        $sS = trim($AY[0]->textContent);
        $sS = str_replace(array("\xd", "\xa", "\11", "\40"), '', $sS);
        if (empty($AY)) {
            goto rt;
        }
        array_push($this->signingCertificate, $sS);
        rt:
    }
    private function parseEncryptionCertificate($tn)
    {
        $AY = Utilities::xpQuery($tn, "\56\57\144\163\x3a\x4b\x65\171\x49\x6e\146\x6f\57\144\x73\72\130\x35\x30\x39\x44\x61\164\x61\x2f\144\163\72\130\65\x30\71\103\x65\162\164\151\146\151\143\x61\x74\145");
        $sS = trim($AY[0]->textContent);
        $sS = str_replace(array("\15", "\xa", "\x9", "\x20"), '', $sS);
        if (empty($AY)) {
            goto Q4;
        }
        array_push($this->encryptionCertificate, $sS);
        Q4:
    }
    public function getIdpName()
    {
        return $this->idpName;
    }
    public function getEntityID()
    {
        return $this->entityID;
    }
    public function getLoginURL($yy)
    {
        return $this->loginDetails[$yy];
    }
    public function getLogoutURL($yy)
    {
        return $this->logoutDetails[$yy];
    }
    public function getLoginDetails()
    {
        return $this->loginDetails;
    }
    public function getLogoutDetails()
    {
        return $this->logoutDetails;
    }
    public function getSigningCertificate()
    {
        return $this->signingCertificate;
    }
    public function getEncryptionCertificate()
    {
        return $this->encryptionCertificate[0];
    }
    public function isRequestSigned()
    {
        return $this->signedRequest;
    }
    public function getBindingLogin()
    {
        return $this->loginbinding;
    }
    public function getBindingLogout()
    {
        return $this->logoutbinding;
    }
}
class ServiceProviders
{
}
