<section id="tab-buckets_<?php echo $section_id; ?>" class="tab-bucket">
    <div class="row">
        <div class="col base-12 medium-8">
            <h2 class="heading--large"><?php the_sub_field('section_heading'); ?></h2>
            <h3 class="heading--small"><?php the_sub_field('section_subtitle'); ?></h3>
        </div>
    </div>
    <div class="row">
        <div class="col base-12">
          <?php if( have_rows('bucket_group') ): ?>
            
            <nav class="bucket__nav" id="tab-buckets_<?php echo $section_id; ?>_nav">
              <?php $i = 0; while( have_rows('bucket_group') ): the_row(); ?>
                <a href="javascript:void(0);" class="bucket__navitem <?php echo( $i === 0 ) ? 'active' : ''; ?>" navslide="slick-slide0<?php echo $i; ?>"><?php the_sub_field('bucket_group_title'); ?></a>
              <?php $i++; endwhile; ?>
            </nav>
            <div class="buckets swipee" id="tab-buckets_<?php echo $section_id; ?>_content" style="padding: 25px 0;">
              <ul class="buckets__wrap swipe-wrapp">
                <?php while( have_rows('bucket_group') ): the_row(); ?>
                  <li class="bucket__group" style="display: flex !important;">
                    <?php while( have_rows('buckets') ): the_row(); ?>
                      <div class="bucket">
                        <div class="bucket__header" style="background-image:url(<?php the_sub_field('bucket_image'); ?>);"></div>
                        <div class="bucket__body">
                          <h4 class="heading--medium"><?php the_sub_field('bucket_title'); ?></h4>
                          <p class="bucket__content"><?php the_sub_field('bucket_content'); ?></p>
                          <?php if(get_sub_field('bucket_footer')): ?>
                          <p class="bucket__footer"><?php print the_sub_field('bucket_footer'); ?></p>
                          <?php endif; ?>
                        </div>
                        <?php if(get_sub_field('bucket_link')): ?>
                        <div class="bucket__action">
                          <a href="<?php print get_the_permalink(get_sub_field('bucket_link')); ?>" class="button button--outline button--medium"><?php _e('Learn More','amexgbt'); ?></a>
                        </div>
                        <?php endif; ?>
                      </div>
                    <?php endwhile; ?>
                  </li>
                <?php endwhile; ?>
              </ul>
            </div>
            <?php endif; ?>
          </div>
        </div>
      </section>
