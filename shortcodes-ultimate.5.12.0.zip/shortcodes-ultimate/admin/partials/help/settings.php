<?php defined( 'ABSPATH' ) or exit; ?>

<ul>
	<li><a href="https://getshortcodes.com/docs-category/getting-started/" target="_blank"><?php _e( 'Getting started', 'shortcodes-ultimate' ); ?></a></li>
	<li><a href="https://getshortcodes.com/docs/plugin-settings-overview/" target="_blank"><?php _e( 'Plugin settings overview', 'shortcodes-ultimate' ); ?></a></li>
	<li><a href="https://getshortcodes.com/docs/how-to-use-custom-css-editor/" target="_blank"><?php _e( 'How to use Custom CSS editor', 'shortcodes-ultimate' ); ?></a></li>
</ul>
