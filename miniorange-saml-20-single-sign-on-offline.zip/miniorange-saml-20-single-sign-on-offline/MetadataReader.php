<?php


include_once "\x55\x74\x69\x6c\151\x74\x69\145\163\x2e\160\x68\x70";
class MetadataReader
{
    private $identityProviders;
    private $serviceProviders;
    public function __construct(DOMNode $aa = NULL)
    {
        $this->identityProviders = array();
        $this->serviceProviders = array();
        $Cj = Utilities::xpQuery($aa, "\x2e\57\163\141\155\154\x5f\155\x65\x74\141\144\x61\164\141\72\105\x6e\164\x69\164\151\145\x73\x44\x65\163\143\162\x69\x70\164\x6f\162");
        if (!empty($Cj)) {
            goto Y0;
        }
        $j7 = Utilities::xpQuery($aa, "\56\x2f\163\141\155\x6c\x5f\155\145\x74\141\144\x61\164\x61\x3a\x45\156\164\x69\x74\x79\104\145\x73\143\x72\x69\x70\x74\x6f\x72");
        goto rQ;
        Y0:
        $j7 = Utilities::xpQuery($Cj[0], "\56\57\x73\x61\x6d\x6c\x5f\155\x65\x74\x61\x64\x61\164\141\x3a\x45\156\164\151\164\x79\x44\x65\163\143\162\x69\160\164\x6f\x72");
        rQ:
        foreach ($j7 as $TO) {
            $Em = Utilities::xpQuery($TO, "\x2e\57\163\x61\x6d\154\137\155\x65\164\141\x64\x61\164\x61\x3a\x49\104\x50\x53\x53\x4f\x44\x65\163\x63\162\151\160\x74\x6f\162");
            if (!(isset($Em) && !empty($Em))) {
                goto w5;
            }
            array_push($this->identityProviders, new IdentityProviders($TO));
            w5:
            Gf:
        }
        Uc:
    }
    public function getIdentityProviders()
    {
        return $this->identityProviders;
    }
    public function getServiceProviders()
    {
        return $this->serviceProviders;
    }
}
class IdentityProviders
{
    private $idpName;
    private $entityID;
    private $loginDetails;
    private $logoutDetails;
    private $signingCertificate;
    private $encryptionCertificate;
    private $signedRequest;
    private $loginbinding;
    private $logoutbinding;
    public function __construct(DOMElement $aa = NULL)
    {
        $this->idpName = '';
        $this->loginDetails = array();
        $this->logoutDetails = array();
        $this->signingCertificate = array();
        $this->encryptionCertificate = array();
        if (!$aa->hasAttribute("\145\x6e\164\x69\164\x79\x49\x44")) {
            goto Ui;
        }
        $this->entityID = $aa->getAttribute("\x65\x6e\x74\x69\x74\x79\x49\x44");
        Ui:
        if (!$aa->hasAttribute("\127\x61\156\x74\101\x75\164\150\156\x52\145\161\165\x65\x73\x74\x73\x53\151\x67\156\x65\x64")) {
            goto mh;
        }
        $this->signedRequest = $aa->getAttribute("\x57\x61\x6e\x74\101\x75\164\x68\156\122\x65\x71\165\x65\163\164\x73\x53\151\147\x6e\x65\144");
        mh:
        $Em = Utilities::xpQuery($aa, "\56\x2f\163\141\155\x6c\137\x6d\145\x74\141\144\141\164\x61\x3a\x49\104\x50\x53\x53\x4f\x44\x65\163\143\x72\151\160\x74\157\162");
        if (count($Em) > 1) {
            goto LW;
        }
        if (empty($Em)) {
            goto CY;
        }
        goto be;
        LW:
        throw new Exception("\115\157\162\145\40\x74\150\x61\x6e\40\157\x6e\145\x20\x3c\x49\104\x50\123\123\x4f\x44\x65\x73\143\x72\151\160\x74\x6f\162\76\40\x69\156\x20\74\105\156\x74\151\x74\x79\104\145\x73\x63\x72\151\x70\164\x6f\162\x3e\56");
        goto be;
        CY:
        throw new Exception("\115\x69\x73\x73\151\156\147\40\162\x65\161\165\151\x72\145\144\40\x3c\111\x44\x50\123\x53\117\104\x65\163\x63\x72\151\160\x74\x6f\x72\x3e\x20\x69\156\x20\x3c\x45\x6e\x74\x69\164\171\x44\x65\x73\x63\162\151\x70\x74\x6f\162\x3e\56");
        be:
        $Ob = $Em[0];
        $w3 = Utilities::xpQuery($aa, "\x2e\57\163\x61\x6d\154\137\x6d\x65\x74\141\144\x61\x74\x61\x3a\x45\170\164\145\156\x73\151\157\x6e\163");
        if (!$w3) {
            goto Yk;
        }
        $this->parseInfo($Ob);
        Yk:
        $this->parseSSOService($Ob);
        $this->parseSLOService($Ob);
        $this->parsex509Certificate($Ob);
    }
    private function parseInfo($aa)
    {
        $rA = Utilities::xpQuery($aa, "\56\57\x6d\x64\165\x69\72\125\x49\x49\x6e\x66\x6f\57\x6d\x64\x75\x69\72\x44\x69\163\160\x6c\141\x79\x4e\141\155\145");
        foreach ($rA as $vT) {
            if (!($vT->hasAttribute("\x78\x6d\154\x3a\x6c\x61\156\147") && $vT->getAttribute("\x78\155\154\x3a\x6c\141\x6e\x67") == "\x65\x6e")) {
                goto lh;
            }
            $this->idpName = $vT->textContent;
            lh:
            SR:
        }
        Nv:
    }
    private function parseSSOService($aa)
    {
        $IX = Utilities::xpQuery($aa, "\56\x2f\163\141\155\x6c\137\155\x65\x74\141\x64\x61\x74\141\x3a\x53\151\156\147\x6c\x65\x53\x69\x67\156\117\156\x53\x65\162\166\x69\x63\145");
        $zx = 0;
        foreach ($IX as $nX) {
            $qp = str_replace("\x75\x72\156\72\157\x61\x73\151\163\x3a\156\141\x6d\145\x73\x3a\x74\x63\x3a\x53\101\115\114\x3a\62\x2e\x30\72\142\151\156\x64\x69\156\147\163\x3a", '', $nX->getAttribute("\x42\151\x6e\x64\151\x6e\147"));
            $this->loginDetails = array_merge($this->loginDetails, array($qp => $nX->getAttribute("\114\157\143\141\164\151\157\156")));
            if (!($qp == "\x48\124\x54\120\x2d\122\x65\x64\x69\162\x65\143\x74")) {
                goto gk;
            }
            $zx = 1;
            $this->loginbinding = "\110\x74\x74\160\x52\145\x64\151\162\145\143\x74";
            gk:
            m0:
        }
        RJ:
        if ($zx) {
            goto zn;
        }
        $this->loginbinding = "\110\x74\164\160\x50\x6f\163\x74";
        zn:
    }
    private function parseSLOService($aa)
    {
        $zx = 0;
        $P1 = Utilities::xpQuery($aa, "\56\x2f\163\141\155\154\137\155\145\x74\x61\x64\141\x74\141\x3a\x53\151\x6e\147\x6c\x65\x4c\157\147\157\x75\x74\123\x65\x72\x76\x69\x63\x65");
        foreach ($P1 as $oh) {
            $qp = str_replace("\x75\x72\x6e\72\157\141\163\x69\x73\72\156\141\155\x65\163\x3a\x74\143\x3a\x53\x41\115\114\72\x32\x2e\60\72\142\151\x6e\144\x69\x6e\x67\163\x3a", '', $oh->getAttribute("\x42\151\156\144\151\x6e\x67"));
            $this->logoutDetails = array_merge($this->logoutDetails, array($qp => $oh->getAttribute("\x4c\157\x63\x61\164\x69\157\x6e")));
            if (!($qp == "\x48\124\124\120\x2d\x52\x65\x64\x69\x72\145\143\x74")) {
                goto Wq;
            }
            $zx = 1;
            $this->logoutbinding = "\x48\164\164\160\x52\x65\x64\x69\x72\x65\x63\x74";
            Wq:
            Dm:
        }
        oL:
        if (!empty($this->logoutbinding)) {
            goto iS;
        }
        $this->logoutbinding = "\110\164\164\x70\x50\157\163\x74";
        iS:
    }
    private function parsex509Certificate($aa)
    {
        foreach (Utilities::xpQuery($aa, "\x2e\57\x73\141\155\x6c\137\155\145\x74\x61\x64\141\x74\x61\72\x4b\145\x79\x44\145\163\x63\162\151\x70\164\x6f\162") as $zJ) {
            if ($zJ->hasAttribute("\165\x73\x65")) {
                goto M3;
            }
            $this->parseSigningCertificate($zJ);
            goto rD;
            M3:
            if ($zJ->getAttribute("\x75\163\145") == "\145\156\143\162\171\x70\164\151\x6f\x6e") {
                goto nn;
            }
            $this->parseSigningCertificate($zJ);
            goto ns;
            nn:
            $this->parseEncryptionCertificate($zJ);
            ns:
            rD:
            fE:
        }
        Pk:
    }
    private function parseSigningCertificate($aa)
    {
        $jh = Utilities::xpQuery($aa, "\x2e\57\x64\163\72\x4b\145\171\111\x6e\x66\157\57\x64\163\x3a\130\x35\x30\x39\104\141\164\141\57\x64\163\72\130\x35\x30\x39\x43\x65\x72\x74\x69\x66\151\x63\141\164\x65");
        $gS = trim($jh[0]->textContent);
        $gS = str_replace(array("\15", "\xa", "\11", "\40"), '', $gS);
        if (empty($jh)) {
            goto Yd;
        }
        array_push($this->signingCertificate, $gS);
        Yd:
    }
    private function parseEncryptionCertificate($aa)
    {
        $jh = Utilities::xpQuery($aa, "\x2e\x2f\x64\x73\x3a\113\x65\171\111\x6e\x66\x6f\x2f\x64\x73\72\130\65\60\x39\104\x61\164\x61\x2f\144\x73\72\x58\x35\x30\x39\x43\x65\162\164\x69\x66\x69\143\141\164\145");
        $gS = trim($jh[0]->textContent);
        $gS = str_replace(array("\xd", "\xa", "\11", "\x20"), '', $gS);
        if (empty($jh)) {
            goto mT;
        }
        array_push($this->encryptionCertificate, $gS);
        mT:
    }
    public function getIdpName()
    {
        return $this->idpName;
    }
    public function getEntityID()
    {
        return $this->entityID;
    }
    public function getLoginURL($qp)
    {
        return $this->loginDetails[$qp];
    }
    public function getLogoutURL($qp)
    {
        return $this->logoutDetails[$qp];
    }
    public function getLoginDetails()
    {
        return $this->loginDetails;
    }
    public function getLogoutDetails()
    {
        return $this->logoutDetails;
    }
    public function getSigningCertificate()
    {
        return $this->signingCertificate;
    }
    public function getEncryptionCertificate()
    {
        return $this->encryptionCertificate[0];
    }
    public function isRequestSigned()
    {
        return $this->signedRequest;
    }
    public function getBindingLogin()
    {
        return $this->loginbinding;
    }
    public function getBindingLogout()
    {
        return $this->logoutbinding;
    }
}
class ServiceProviders
{
}
