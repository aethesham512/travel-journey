<?php


include_once "\125\164\x69\154\151\x74\x69\x65\163\56\160\150\x70";
include_once "\x78\155\x6c\x73\x65\x63\154\151\x62\x73\x2e\x70\150\x70";
use RobRichards\XMLSecLibs\XMLSecurityKey;
use RobRichards\XMLSecLibs\XMLSecurityDSig;
use RobRichards\XMLSecLibs\XMLSecEnc;
class SAML2_LogoutRequest
{
    private $tagName;
    private $id;
    private $issuer;
    private $destination;
    private $issueInstant;
    private $certificates;
    private $validators;
    private $notOnOrAfter;
    private $encryptedNameId;
    private $nameId;
    private $sessionIndexes;
    public function __construct(DOMElement $aa = NULL)
    {
        $this->tagName = "\114\x6f\147\157\x75\164\x52\145\161\x75\x65\163\164";
        $this->id = Utilities::generateID();
        $this->issueInstant = time();
        $this->certificates = array();
        $this->validators = array();
        if (!($aa === NULL)) {
            goto RS;
        }
        return;
        RS:
        if ($aa->hasAttribute("\x49\x44")) {
            goto Ss;
        }
        throw new Exception("\115\151\163\x73\151\x6e\x67\40\111\104\x20\141\164\x74\x72\151\142\165\164\x65\40\x6f\156\40\123\x41\x4d\x4c\x20\x6d\x65\x73\x73\141\x67\x65\x2e");
        Ss:
        $this->id = $aa->getAttribute("\111\104");
        if (!($aa->getAttribute("\126\145\162\x73\151\x6f\156") !== "\x32\56\60")) {
            goto kU;
        }
        throw new Exception("\x55\x6e\163\165\160\x70\157\x72\x74\145\x64\x20\x76\x65\162\x73\x69\x6f\x6e\x3a\x20" . $aa->getAttribute("\126\145\162\163\151\x6f\156"));
        kU:
        $this->issueInstant = Utilities::xsDateTimeToTimestamp($aa->getAttribute("\x49\163\x73\x75\145\x49\x6e\163\x74\x61\156\x74"));
        if (!$aa->hasAttribute("\x44\145\x73\164\x69\x6e\x61\164\151\157\156")) {
            goto ys;
        }
        $this->destination = $aa->getAttribute("\x44\x65\163\164\151\156\x61\164\x69\157\156");
        ys:
        $pr = Utilities::xpQuery($aa, "\x2e\x2f\163\141\x6d\x6c\137\x61\x73\x73\x65\162\x74\x69\x6f\x6e\72\111\x73\x73\165\x65\x72");
        if (empty($pr)) {
            goto He;
        }
        $this->issuer = trim($pr[0]->textContent);
        He:
        try {
            $p0 = Utilities::validateElement($aa);
            if (!($p0 !== FALSE)) {
                goto SK;
            }
            $this->certificates = $p0["\103\145\x72\164\x69\x66\x69\x63\x61\x74\145\x73"];
            $this->validators[] = array("\x46\165\156\143\164\151\157\x6e" => array("\125\x74\151\154\x69\x74\x69\145\163", "\166\141\154\151\144\x61\x74\145\123\151\147\x6e\x61\164\x75\x72\145"), "\x44\x61\x74\141" => $p0);
            SK:
        } catch (Exception $GC) {
        }
        $this->sessionIndexes = array();
        if (!$aa->hasAttribute("\116\157\164\117\156\x4f\x72\x41\146\x74\x65\x72")) {
            goto k_;
        }
        $this->notOnOrAfter = Utilities::xsDateTimeToTimestamp($aa->getAttribute("\x4e\157\x74\117\156\x4f\162\x41\x66\164\145\x72"));
        k_:
        $Mo = Utilities::xpQuery($aa, "\x2e\57\163\x61\x6d\x6c\x5f\141\x73\x73\x65\x72\x74\151\x6f\x6e\72\x4e\x61\155\145\111\104\x20\174\x20\56\57\163\x61\155\x6c\x5f\x61\163\163\145\162\x74\x69\157\156\72\x45\x6e\x63\x72\x79\x70\164\x65\144\x49\104\x2f\170\x65\x6e\x63\x3a\105\156\x63\162\x79\160\x74\145\x64\x44\141\164\x61");
        if (empty($Mo)) {
            goto h2;
        }
        if (count($Mo) > 1) {
            goto NC;
        }
        goto mR;
        h2:
        throw new Exception("\115\151\x73\x73\x69\156\x67\40\74\x73\x61\x6d\154\x3a\116\x61\x6d\x65\111\104\x3e\40\157\162\40\74\163\x61\x6d\154\72\x45\x6e\143\x72\171\160\164\x65\144\x49\x44\76\40\151\x6e\x20\x3c\x73\x61\x6d\154\160\x3a\x4c\x6f\147\x6f\x75\x74\122\145\x71\x75\x65\x73\x74\x3e\56");
        goto mR;
        NC:
        throw new Exception("\x4d\157\x72\145\40\164\x68\x61\x6e\x20\157\156\145\40\x3c\x73\141\x6d\154\72\116\x61\155\x65\x49\104\x3e\x20\157\x72\40\74\163\x61\155\154\x3a\x45\x6e\143\162\x79\160\164\x65\144\x44\x3e\x20\151\x6e\x20\74\163\x61\155\x6c\160\72\x4c\157\x67\x6f\165\x74\122\145\x71\x75\145\x73\164\x3e\x2e");
        mR:
        $Mo = $Mo[0];
        if ($Mo->localName === "\105\156\143\x72\x79\x70\164\145\x64\104\141\164\141") {
            goto BH;
        }
        $this->nameId = Utilities::parseNameId($Mo);
        goto tT;
        BH:
        $this->encryptedNameId = $Mo;
        tT:
        $ak = Utilities::xpQuery($aa, "\56\57\163\141\155\x6c\137\160\162\157\x74\x6f\143\x6f\154\72\123\x65\x73\x73\151\x6f\x6e\111\156\144\145\170");
        foreach ($ak as $UP) {
            $this->sessionIndexes[] = trim($UP->textContent);
            ZY:
        }
        qx:
    }
    public function getNotOnOrAfter()
    {
        return $this->notOnOrAfter;
    }
    public function setNotOnOrAfter($VG)
    {
        $this->notOnOrAfter = $VG;
    }
    public function isNameIdEncrypted()
    {
        if (!($this->encryptedNameId !== NULL)) {
            goto TK;
        }
        return TRUE;
        TK:
        return FALSE;
    }
    public function encryptNameId(XMLSecurityKey $z5)
    {
        $YP = new DOMDocument();
        $FC = $YP->createElement("\x72\157\x6f\x74");
        $YP->appendChild($FC);
        SAML2_Utils::addNameId($FC, $this->nameId);
        $Mo = $FC->firstChild;
        SAML2_Utils::getContainer()->debugMessage($Mo, "\145\x6e\143\162\x79\160\164");
        $Cb = new XMLSecEnc();
        $Cb->setNode($Mo);
        $Cb->type = XMLSecEnc::Element;
        $i5 = new XMLSecurityKey(XMLSecurityKey::AES128_CBC);
        $i5->generateSessionKey();
        $Cb->encryptKey($z5, $i5);
        $this->encryptedNameId = $Cb->encryptNode($i5);
        $this->nameId = NULL;
    }
    public function decryptNameId(XMLSecurityKey $z5, array $BC = array())
    {
        if (!($this->encryptedNameId === NULL)) {
            goto vT;
        }
        return;
        vT:
        $Mo = SAML2_Utils::decryptElement($this->encryptedNameId, $z5, $BC);
        SAML2_Utils::getContainer()->debugMessage($Mo, "\x64\x65\143\162\x79\x70\164");
        $this->nameId = SAML2_Utils::parseNameId($Mo);
        $this->encryptedNameId = NULL;
    }
    public function getNameId()
    {
        if (!($this->encryptedNameId !== NULL)) {
            goto tm;
        }
        throw new Exception("\x41\x74\164\145\155\160\164\145\x64\x20\x74\x6f\40\162\x65\164\x72\151\x65\x76\145\40\145\156\143\162\171\160\164\x65\x64\x20\x4e\141\x6d\145\x49\104\40\x77\x69\164\x68\x6f\x75\164\x20\144\145\143\x72\171\160\x74\x69\x6e\x67\40\x69\164\40\x66\x69\x72\x73\x74\x2e");
        tm:
        return $this->nameId;
    }
    public function setNameId($Mo)
    {
        $this->nameId = $Mo;
    }
    public function getSessionIndexes()
    {
        return $this->sessionIndexes;
    }
    public function setSessionIndexes(array $ak)
    {
        $this->sessionIndexes = $ak;
    }
    public function getSessionIndex()
    {
        if (!empty($this->sessionIndexes)) {
            goto HR;
        }
        return NULL;
        HR:
        return $this->sessionIndexes[0];
    }
    public function setSessionIndex($UP)
    {
        if (is_null($UP)) {
            goto ac;
        }
        $this->sessionIndexes = array($UP);
        goto N0;
        ac:
        $this->sessionIndexes = array();
        N0:
    }
    public function getId()
    {
        return $this->id;
    }
    public function setId($Z_)
    {
        $this->id = $Z_;
    }
    public function getIssueInstant()
    {
        return $this->issueInstant;
    }
    public function setIssueInstant($Gx)
    {
        $this->issueInstant = $Gx;
    }
    public function getDestination()
    {
        return $this->destination;
    }
    public function setDestination($b2)
    {
        $this->destination = $b2;
    }
    public function getIssuer()
    {
        return $this->issuer;
    }
    public function setIssuer($pr)
    {
        $this->issuer = $pr;
    }
}
