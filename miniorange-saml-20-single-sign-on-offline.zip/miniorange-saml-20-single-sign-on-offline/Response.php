<?php


include "\101\x73\x73\x65\x72\x74\x69\157\156\x2e\x70\x68\160";
class SAML2_Response
{
    private $assertions;
    private $destination;
    private $certificates;
    private $signatureData;
    public function __construct(DOMElement $aa = NULL, $zq)
    {
        $this->assertions = array();
        $this->certificates = array();
        if (!($aa === NULL)) {
            goto BD9;
        }
        return;
        BD9:
        $p0 = Utilities::validateElement($aa);
        if (!($p0 !== FALSE)) {
            goto Cgm;
        }
        $this->certificates = $p0["\103\145\162\x74\x69\146\x69\x63\141\x74\x65\163"];
        $this->signatureData = $p0;
        Cgm:
        if (!$aa->hasAttribute("\104\x65\x73\164\151\x6e\141\x74\151\157\x6e")) {
            goto fc5;
        }
        $this->destination = $aa->getAttribute("\104\x65\163\x74\x69\x6e\141\x74\151\157\156");
        fc5:
        $oe = $aa->firstChild;
        HE0:
        if (!($oe !== NULL)) {
            goto L79;
        }
        if (!($oe->namespaceURI !== "\165\162\156\x3a\157\141\163\151\x73\x3a\156\x61\155\x65\163\x3a\164\143\x3a\123\x41\115\x4c\x3a\x32\x2e\x30\x3a\141\x73\163\145\x72\164\x69\157\x6e")) {
            goto C2s;
        }
        goto WV8;
        C2s:
        if (!($oe->localName === "\101\x73\163\x65\x72\x74\151\x6f\156" || $oe->localName === "\105\x6e\143\162\171\x70\x74\x65\144\x41\163\163\145\162\164\x69\157\156")) {
            goto O9l;
        }
        $this->assertions[] = new SAML2_Assertion($oe, $zq);
        O9l:
        WV8:
        $oe = $oe->nextSibling;
        goto HE0;
        L79:
    }
    public function getAssertions()
    {
        return $this->assertions;
    }
    public function setAssertions(array $iD)
    {
        $this->assertions = $iD;
    }
    public function getDestination()
    {
        return $this->destination;
    }
    public function getCertificates()
    {
        return $this->certificates;
    }
    public function getSignatureData()
    {
        return $this->signatureData;
    }
}
