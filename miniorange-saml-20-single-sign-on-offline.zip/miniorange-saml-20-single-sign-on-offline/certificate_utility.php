<?php


class CertificateUtility
{
    public static function generate_certificate($Y0, $xi, $RQ)
    {
        $fl = openssl_pkey_new();
        $yQ = openssl_csr_new($Y0, $fl, $xi);
        $Y8 = openssl_csr_sign($yQ, null, $fl, $RQ, $xi, time());
        openssl_csr_export($yQ, $LD);
        openssl_x509_export($Y8, $tc);
        openssl_pkey_export($fl, $FS);
        ww:
        if (!(($GC = openssl_error_string()) !== false)) {
            goto z4;
        }
        error_log("\103\x65\162\x74\151\146\151\x63\x61\x74\145\125\x74\x69\x6c\x69\164\171\72\x20\105\162\162\157\162\40\147\x65\x6e\x65\x72\141\x74\x69\156\147\x20\x63\145\x72\164\151\x66\x69\x63\141\x74\x65\x2e\40" . $GC);
        goto ww;
        z4:
        $mn = array("\160\165\142\154\151\x63\x5f\x6b\145\171" => $tc, "\x70\x72\151\x76\141\164\145\137\x6b\x65\x79" => $FS);
        return $mn;
    }
}
