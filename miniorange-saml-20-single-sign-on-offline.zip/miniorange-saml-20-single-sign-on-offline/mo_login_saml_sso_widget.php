<?php


include_once dirname(__FILE__) . "\57\x55\164\151\154\x69\x74\x69\x65\163\x2e\160\x68\x70";
include_once dirname(__FILE__) . "\57\x52\145\x73\160\157\x6e\x73\145\x2e\160\x68\x70";
include_once dirname(__FILE__) . "\57\x4c\157\147\x6f\165\164\x52\145\x71\x75\x65\163\164\x2e\x70\x68\x70";
require_once dirname(__FILE__) . "\x2f\x69\x6e\143\154\165\144\145\163\57\154\x69\142\x2f\145\156\x63\162\171\x70\164\151\x6f\156\56\x70\x68\x70";
include_once "\x78\x6d\x6c\x73\145\143\x6c\151\142\x73\x2e\160\150\x70";
use RobRichards\XMLSecLibs\XMLSecurityKey;
use RobRichards\XMLSecLibs\XMLSecurityDSig;
use RobRichards\XMLSecLibs\XMLSecEnc;
class mo_login_wid extends WP_Widget
{
    public function __construct()
    {
        $sh = get_site_option("\163\x61\x6d\x6c\x5f\151\x64\x65\156\164\x69\x74\171\137\156\141\x6d\x65");
        parent::__construct("\x53\x61\x6d\x6c\x5f\x4c\157\x67\151\156\137\x57\151\x64\x67\145\164", "\114\x6f\x67\151\x6e\40\x77\151\x74\150\40" . $sh, array("\x64\x65\163\x63\x72\151\x70\164\151\x6f\156" => __("\x54\150\151\x73\x20\151\163\40\141\40\155\151\x6e\x69\117\162\x61\156\147\x65\40\123\101\x4d\114\40\x6c\157\x67\151\x6e\x20\x77\x69\x64\x67\x65\x74\x2e", "\155\157\x73\141\x6d\154")));
    }
    public function widget($P0, $L7)
    {
        extract($P0);
        $T6 = apply_filters("\167\151\x64\147\x65\164\x5f\164\x69\x74\154\145", $L7["\x77\x69\x64\x5f\164\151\x74\x6c\x65"]);
        echo $P0["\142\145\x66\157\162\145\137\x77\x69\x64\x67\x65\x74"];
        if (empty($T6)) {
            goto Tj;
        }
        echo $P0["\142\x65\x66\157\x72\145\x5f\x74\x69\x74\x6c\145"] . $T6 . $P0["\141\146\164\145\162\x5f\164\x69\x74\x6c\x65"];
        Tj:
        $this->loginForm();
        echo $P0["\x61\x66\x74\x65\162\137\167\x69\144\147\x65\x74"];
    }
    public function update($pC, $im)
    {
        $L7 = array();
        $L7["\167\x69\x64\137\x74\151\164\x6c\x65"] = strip_tags($pC["\167\151\144\137\164\151\x74\154\145"]);
        return $L7;
    }
    public function form($L7)
    {
        $T6 = '';
        if (!array_key_exists("\167\151\144\x5f\x74\x69\164\x6c\x65", $L7)) {
            goto TX;
        }
        $T6 = $L7["\x77\151\144\x5f\164\x69\x74\x6c\x65"];
        TX:
        echo "\15\xa\11\x9\x3c\160\x3e\74\x6c\x61\x62\x65\x6c\40\x66\157\162\75\42" . $this->get_field_id("\x77\151\x64\x5f\x74\151\x74\154\145") . "\40\x22\x3e" . _e("\x54\x69\x74\154\145\x3a") . "\x20\74\57\154\x61\x62\145\154\76\15\xa\x9\11\11\74\x69\156\x70\165\164\40\143\x6c\141\163\x73\x3d\x22\167\x69\x64\145\146\x61\164\x22\x20\x69\x64\x3d\x22" . $this->get_field_id("\x77\151\x64\137\164\x69\x74\x6c\x65") . "\42\40\156\141\155\x65\75\x22" . $this->get_field_name("\x77\x69\x64\137\x74\151\164\154\x65") . "\42\40\x74\x79\160\x65\x3d\42\x74\x65\x78\x74\x22\x20\166\141\x6c\x75\x65\x3d\42" . $T6 . "\x22\x20\57\76\15\12\11\11\x3c\x2f\160\76";
    }
    public function loginForm()
    {
        global $post;
        $gh = get_site_option("\x73\x61\x6d\x6c\x5f\163\163\x6f\137\163\145\x74\x74\151\x6e\x67\163");
        $GU = get_current_blog_id();
        $Ef = Utilities::get_active_sites();
        if (in_array($GU, $Ef)) {
            goto iw;
        }
        return;
        iw:
        if (!(empty($gh[$GU]) && !empty($gh["\104\x45\106\x41\x55\114\x54"]))) {
            goto wc;
        }
        $gh[$GU] = $gh["\104\105\x46\x41\x55\x4c\x54"];
        wc:
        if (!is_user_logged_in()) {
            goto ry;
        }
        $current_user = wp_get_current_user();
        $I3 = "\x48\x65\x6c\154\157\54";
        if (empty($gh[$GU]["\x6d\x6f\x5f\163\141\155\x6c\x5f\143\165\x73\164\x6f\x6d\137\x67\x72\x65\145\x74\151\156\x67\137\164\145\170\x74"])) {
            goto FW;
        }
        $I3 = $gh[$GU]["\x6d\x6f\x5f\163\x61\x6d\154\137\x63\165\163\164\x6f\155\137\147\x72\x65\x65\164\x69\156\147\137\x74\145\170\x74"];
        FW:
        $fY = '';
        if (empty($gh[$GU]["\155\x6f\137\163\x61\x6d\x6c\137\x67\162\x65\145\x74\151\x6e\147\x5f\156\x61\x6d\x65"])) {
            goto iz;
        }
        switch ($gh[$GU]["\x6d\x6f\x5f\163\141\x6d\154\137\x67\162\x65\145\164\x69\x6e\x67\137\x6e\141\x6d\145"]) {
            case "\x55\123\105\122\x4e\101\115\105":
                $fY = $current_user->user_login;
                goto nI;
            case "\x45\x4d\101\x49\x4c":
                $fY = $current_user->user_email;
                goto nI;
            case "\106\116\x41\115\x45":
                $fY = $current_user->user_firstname;
                goto nI;
            case "\114\x4e\x41\115\105":
                $fY = $current_user->user_lastname;
                goto nI;
            case "\x46\116\x41\x4d\105\x5f\x4c\116\x41\115\x45":
                $fY = $current_user->user_firstname . "\40" . $current_user->user_lastname;
                goto nI;
            case "\114\116\101\115\x45\137\x46\x4e\101\x4d\105":
                $fY = $current_user->user_lastname . "\x20" . $current_user->user_firstname;
                goto nI;
            default:
                $fY = $current_user->user_login;
        }
        iM:
        nI:
        iz:
        if (!empty(trim($fY))) {
            goto It;
        }
        $fY = $current_user->user_login;
        It:
        $OR = $I3 . "\x20" . $fY;
        $yF = "\x4c\157\x67\157\165\x74";
        if (empty($gh[$GU]["\155\157\x5f\163\x61\x6d\154\137\143\165\163\164\x6f\x6d\x5f\x6c\x6f\147\x6f\x75\x74\137\164\145\x78\164"])) {
            goto on;
        }
        $yF = $gh[$GU]["\155\157\137\x73\141\155\154\x5f\x63\x75\x73\x74\157\155\137\x6c\157\x67\x6f\165\x74\137\164\x65\x78\x74"];
        on:
        echo $OR . "\x20\x7c\x20\x3c\141\40\x68\162\x65\146\75\x22" . wp_logout_url(home_url()) . "\42\x20\164\151\x74\x6c\x65\75\x22\x6c\157\x67\x6f\165\x74\x22\x20\x3e" . $yF . "\74\57\141\76\x3c\57\x6c\151\76";
        goto Gw;
        ry:
        echo "\xd\12\11\x9\11\x3c\x73\143\162\151\160\x74\x3e\xd\12\11\11\x9\11\x66\x75\156\143\164\x69\x6f\x6e\40\163\165\142\155\x69\x74\123\141\x6d\154\x46\157\162\x6d\50\x29\173\40\x64\x6f\143\x75\x6d\145\156\164\x2e\147\145\x74\x45\x6c\x65\x6d\145\156\x74\102\x79\111\144\x28\x22\154\x6f\x67\x69\x6e\42\x29\x2e\x73\165\142\155\151\x74\50\51\73\x20\175\15\12\11\11\x9\74\x2f\163\x63\162\151\x70\x74\x3e\xd\12\x9\11\x9\x3c\x66\157\x72\155\x20\x6e\141\x6d\x65\75\42\x6c\157\x67\151\x6e\42\x20\151\x64\x3d\42\154\157\x67\151\x6e\x22\x20\x6d\145\164\x68\x6f\x64\x3d\x22\x70\157\163\164\42\x20\x61\143\164\x69\157\156\x3d\x22\42\x3e\xd\xa\11\x9\11\11\x3c\x69\156\160\165\x74\x20\164\x79\160\145\x3d\42\150\x69\144\144\x65\156\x22\40\x6e\141\x6d\145\75\42\157\160\164\x69\x6f\156\x22\40\x76\x61\154\165\x65\75\x22\163\141\155\154\x5f\165\x73\145\x72\x5f\x6c\157\147\x69\x6e\x22\x20\x2f\x3e\15\xa\xd\12\11\11\11\x9\74\x66\x6f\x6e\x74\40\163\151\x7a\145\75\x22\x2b\61\42\x20\x73\x74\171\x6c\145\75\42\166\x65\162\x74\x69\x63\141\154\55\x61\x6c\151\x67\x6e\x3a\164\157\160\x3b\42\76\40\x3c\x2f\146\x6f\156\x74\x3e";
        $Sn = get_site_option("\x73\141\155\154\x5f\x69\x64\x65\x6e\164\151\x74\x79\137\x6e\141\155\145");
        $x_ = get_site_option("\x73\141\x6d\154\x5f\170\65\60\71\x5f\x63\145\x72\164\x69\146\x69\x63\141\164\x65");
        if (!empty($Sn) && !empty($x_)) {
            goto lW;
        }
        echo "\x50\154\145\x61\x73\x65\x20\x63\x6f\156\x66\x69\147\x75\x72\x65\x20\x74\x68\145\40\x6d\151\156\151\117\162\141\x6e\147\145\40\123\101\115\x4c\x20\120\x6c\x75\x67\151\156\x20\146\151\162\163\x74\x2e";
        goto Qe;
        lW:
        $B3 = "\114\157\x67\x69\156\40\x77\x69\164\150\40\43\x23\x49\x44\x50\x23\x23";
        if (empty($gh[$GU]["\x6d\x6f\137\163\x61\155\154\137\143\165\163\164\x6f\x6d\x5f\154\x6f\147\x69\156\137\164\145\x78\x74"])) {
            goto yh;
        }
        $B3 = $gh[$GU]["\x6d\x6f\x5f\163\x61\155\x6c\x5f\143\x75\x73\x74\x6f\155\137\x6c\x6f\147\151\x6e\x5f\164\145\x78\x74"];
        yh:
        $B3 = str_replace("\43\x23\111\x44\120\43\43", $Sn, $B3);
        $Q6 = false;
        if (!(isset($gh[$GU]["\155\157\137\x73\x61\x6d\x6c\x5f\x75\x73\145\137\x62\x75\164\x74\x6f\x6e\137\x61\x73\x5f\167\151\144\147\x65\164"]) && $gh[$GU]["\x6d\x6f\137\x73\x61\x6d\x6c\x5f\165\163\x65\137\142\x75\164\x74\157\156\x5f\141\163\x5f\x77\x69\x64\x67\x65\x74"] == "\164\162\165\145")) {
            goto Vj;
        }
        $Q6 = true;
        Vj:
        if (!$Q6) {
            goto i7;
        }
        $Bx = isset($gh[$GU]["\155\157\137\x73\141\x6d\x6c\137\x62\x75\164\x74\157\156\137\x77\151\x64\x74\150"]) ? $gh[$GU]["\x6d\x6f\x5f\x73\x61\x6d\154\137\142\165\x74\164\157\x6e\x5f\167\151\x64\164\150"] : "\x31\60\x30";
        $eT = isset($gh[$GU]["\x6d\x6f\x5f\163\141\155\x6c\x5f\142\165\x74\x74\157\156\137\150\x65\151\x67\x68\x74"]) ? $gh[$GU]["\155\x6f\137\163\141\x6d\154\x5f\x62\165\164\164\x6f\156\137\150\x65\x69\147\150\x74"] : "\65\60";
        $aM = isset($gh[$GU]["\155\x6f\137\163\x61\x6d\154\x5f\x62\165\x74\x74\157\156\x5f\x73\x69\x7a\x65"]) ? $gh[$GU]["\x6d\x6f\x5f\x73\141\x6d\154\137\x62\x75\164\x74\x6f\156\x5f\x73\151\172\145"] : "\65\x30";
        $iy = isset($gh[$GU]["\x6d\157\137\x73\141\155\154\137\x62\x75\164\164\x6f\x6e\x5f\143\165\x72\x76\x65"]) ? $gh[$GU]["\155\x6f\137\163\141\x6d\154\137\x62\165\164\x74\x6f\x6e\x5f\143\165\162\166\x65"] : "\x35";
        $zC = isset($gh[$GU]["\x6d\x6f\137\x73\x61\155\x6c\137\142\165\x74\x74\x6f\x6e\137\143\157\x6c\157\x72"]) ? $gh[$GU]["\x6d\157\137\x73\x61\x6d\x6c\137\142\165\164\x74\x6f\x6e\137\143\157\x6c\157\162"] : "\x30\x30\70\65\142\x61";
        $iq = isset($gh[$GU]["\x6d\x6f\x5f\x73\x61\155\x6c\137\142\x75\164\x74\157\x6e\137\x74\x68\x65\x6d\145"]) ? $gh[$GU]["\x6d\x6f\137\x73\x61\155\154\x5f\142\x75\x74\x74\157\x6e\137\x74\x68\145\155\x65"] : "\154\x6f\156\x67\142\x75\164\164\x6f\x6e";
        $tL = isset($gh[$GU]["\155\x6f\137\163\141\x6d\154\137\142\165\x74\164\157\156\137\164\145\x78\x74"]) ? $gh[$GU]["\x6d\157\137\x73\x61\x6d\x6c\x5f\142\165\x74\x74\x6f\x6e\137\x74\x65\170\x74"] : (get_site_option("\x73\141\155\154\x5f\151\x64\145\x6e\164\151\164\171\x5f\156\141\x6d\x65") ? get_site_option("\x73\141\x6d\x6c\137\151\x64\145\156\164\x69\164\171\137\x6e\141\155\145") : "\x4c\157\147\151\x6e");
        $nG = isset($gh[$GU]["\155\x6f\137\x73\x61\x6d\154\137\146\157\156\164\137\x63\x6f\154\157\162"]) ? $gh[$GU]["\155\x6f\137\163\141\x6d\154\x5f\146\x6f\156\164\x5f\143\x6f\154\x6f\162"] : "\146\146\146\x66\x66\x66";
        $Iw = isset($gh[$GU]["\155\157\137\x73\x61\x6d\154\x5f\x66\157\x6e\x74\137\163\x69\x7a\x65"]) ? $gh[$GU]["\x6d\157\x5f\163\141\155\x6c\137\146\157\x6e\164\137\x73\x69\172\145"] : "\62\60";
        $rg = isset($gh[$GU]["\x73\x73\x6f\137\142\165\x74\164\x6f\156\137\154\x6f\147\x69\156\137\146\157\162\x6d\x5f\160\157\x73\151\164\x69\157\156"]) ? $gh[$GU]["\163\163\157\x5f\142\x75\x74\164\x6f\156\137\154\x6f\x67\x69\x6e\137\x66\157\162\x6d\x5f\160\157\163\151\x74\x69\157\156"] : "\141\x62\157\x76\x65";
        $B3 = "\x3c\151\x6e\160\165\164\40\164\171\x70\145\x3d\42\x62\x75\164\x74\157\x6e\42\x20\x6e\141\155\x65\x3d\x22\x6d\157\137\x73\141\x6d\x6c\x5f\x77\x70\137\x73\163\157\137\142\x75\164\x74\157\x6e\x22\40\x76\141\x6c\165\x65\75\42" . $tL . "\x22\40\163\x74\171\x6c\145\x3d\42";
        $Om = '';
        if ($iq == "\154\157\x6e\x67\142\165\x74\164\x6f\x6e") {
            goto Gv;
        }
        if ($iq == "\143\151\x72\x63\154\145") {
            goto Vr;
        }
        if ($iq == "\x6f\x76\141\154") {
            goto Et;
        }
        if ($iq == "\163\161\165\141\162\145") {
            goto jC;
        }
        goto RV;
        Vr:
        $Om = $Om . "\x77\151\144\164\x68\x3a" . $aM . "\x70\170\x3b";
        $Om = $Om . "\150\x65\151\147\x68\x74\x3a" . $aM . "\160\170\x3b";
        $Om = $Om . "\142\x6f\x72\x64\x65\x72\x2d\162\141\144\x69\165\x73\x3a\71\x39\71\x70\170\x3b";
        goto RV;
        Et:
        $Om = $Om . "\x77\151\x64\x74\x68\72" . $aM . "\x70\x78\x3b";
        $Om = $Om . "\150\x65\x69\147\x68\x74\x3a" . $aM . "\x70\x78\x3b";
        $Om = $Om . "\x62\157\162\144\145\162\x2d\x72\141\x64\151\165\163\x3a\65\x70\x78\x3b";
        goto RV;
        jC:
        $Om = $Om . "\x77\151\144\164\x68\x3a" . $aM . "\x70\170\x3b";
        $Om = $Om . "\x68\x65\x69\147\x68\164\72" . $aM . "\160\170\73";
        $Om = $Om . "\142\x6f\162\144\x65\x72\x2d\x72\x61\x64\151\165\x73\x3a\x30\160\x78\x3b";
        RV:
        goto Ik;
        Gv:
        $Om = $Om . "\167\x69\144\164\150\72" . $Bx . "\160\170\73";
        $Om = $Om . "\150\x65\151\x67\x68\164\72" . $eT . "\160\x78\x3b";
        $Om = $Om . "\x62\x6f\162\x64\x65\x72\55\x72\141\x64\151\x75\163\x3a" . $iy . "\160\x78\x3b";
        Ik:
        $Om = $Om . "\x62\x61\143\x6b\147\x72\x6f\x75\156\x64\x2d\143\157\154\157\x72\72\x23" . $zC . "\x3b";
        $Om = $Om . "\142\x6f\x72\x64\145\162\55\143\157\x6c\157\162\72\x74\162\x61\x6e\x73\160\x61\x72\145\156\x74\x3b";
        $Om = $Om . "\x63\x6f\x6c\x6f\x72\x3a\x23" . $nG . "\x3b";
        $Om = $Om . "\x66\x6f\x6e\x74\x2d\163\x69\172\145\72" . $Iw . "\x70\170\73";
        $Om = $Om . "\x70\141\x64\x64\151\x6e\147\72\x30\160\x78\x3b";
        $B3 = $B3 . $Om . "\42\x2f\x3e";
        i7:
        echo "\x20\x3c\x61\x20\150\x72\145\x66\x3d\x22\43\x22\40\157\156\x43\x6c\x69\x63\153\x3d\x22\x73\165\142\155\151\x74\123\141\155\154\106\157\162\155\x28\51\x22\x3e";
        echo $B3;
        echo "\x3c\x2f\141\x3e\x3c\57\146\x6f\x72\155\x3e\40";
        Qe:
        if ($this->mo_saml_check_empty_or_null_val(get_site_option("\x6d\157\x5f\x73\x61\x6d\x6c\x5f\162\145\x64\x69\162\x65\143\x74\137\145\x72\162\x6f\x72\x5f\143\157\x64\x65"))) {
            goto k5;
        }
        echo "\74\144\x69\166\76\74\x2f\x64\151\166\x3e\74\x64\x69\166\x20\164\151\164\x6c\x65\x3d\42\114\x6f\147\151\x6e\x20\105\x72\162\157\x72\x22\x3e\74\x66\x6f\156\x74\40\143\157\154\x6f\162\75\x22\x72\145\x64\42\76\127\145\40\143\x6f\165\154\x64\40\x6e\x6f\x74\40\x73\x69\x67\x6e\40\x79\x6f\x75\40\151\x6e\56\x20\x50\154\145\141\163\145\x20\x63\157\156\164\141\143\x74\40\171\157\165\x72\x20\101\144\x6d\x69\x6e\151\x73\164\x72\x61\x74\x6f\x72\56\74\x2f\x66\x6f\x6e\164\76\x3c\57\144\151\x76\x3e";
        delete_site_option("\x6d\157\x5f\x73\141\x6d\x6c\x5f\x72\145\144\x69\162\x65\143\x74\x5f\x65\x72\x72\x6f\162\137\143\157\x64\x65");
        delete_site_option("\x6d\157\137\163\141\155\x6c\137\162\x65\144\x69\x72\x65\x63\x74\137\145\x72\x72\x6f\162\137\x72\x65\x61\163\x6f\x6e");
        k5:
        echo "\x3c\141\x20\150\x72\x65\146\x3d\x22\150\164\164\x70\x3a\57\57\155\x69\156\151\157\x72\x61\x6e\147\x65\x2e\143\x6f\155\x2f\x77\157\x72\144\160\x72\x65\x73\163\55\x6c\x64\x61\160\x2d\154\x6f\x67\151\156\x22\x20\163\164\x79\x6c\145\x3d\42\x64\151\163\x70\x6c\141\x79\x3a\156\x6f\x6e\x65\42\x3e\x4c\x6f\147\x69\156\x20\x74\x6f\x20\x57\x6f\x72\144\120\162\145\x73\x73\40\x75\x73\151\x6e\x67\x20\114\x44\x41\x50\x3c\57\x61\x3e\xd\xa\11\11\11\11\x3c\x61\40\150\x72\145\146\x3d\x22\150\164\164\160\x3a\x2f\x2f\155\x69\x6e\151\157\x72\141\x6e\x67\x65\x2e\143\x6f\x6d\57\x63\154\157\x75\x64\55\x69\x64\x65\x6e\x74\x69\164\171\55\x62\162\157\x6b\x65\x72\x2d\163\x65\x72\x76\x69\x63\x65\x22\x20\163\164\171\x6c\x65\75\x22\144\151\x73\160\x6c\141\171\72\x6e\x6f\x6e\x65\42\76\x43\x6c\157\165\x64\40\111\x64\x65\x6e\164\151\x74\x79\x20\x62\x72\x6f\153\x65\x72\40\163\145\162\166\151\x63\x65\x3c\57\141\76\15\12\11\x9\x9\11\74\x61\40\x68\x72\145\x66\x3d\42\150\x74\164\x70\72\57\x2f\155\151\156\151\157\162\141\x6e\147\145\56\143\x6f\x6d\x2f\163\x74\162\x6f\x6e\147\x5f\x61\165\x74\150\42\40\x73\x74\171\154\x65\x3d\x22\x64\x69\x73\x70\x6c\141\x79\72\156\x6f\x6e\145\73\42\x3e\x3c\x2f\x61\x3e\15\xa\x9\11\11\11\74\141\40\x68\x72\145\146\x3d\x22\150\164\x74\160\x3a\x2f\57\155\x69\x6e\x69\157\x72\141\x6e\x67\145\56\143\x6f\x6d\x2f\163\151\156\147\154\145\x2d\x73\151\147\156\55\x6f\156\x2d\x73\x73\157\42\x20\x73\x74\171\x6c\145\75\42\x64\151\163\160\x6c\x61\x79\72\156\x6f\x6e\145\73\42\x3e\74\57\x61\76\xd\12\11\x9\x9\x9\x3c\141\40\x68\x72\x65\x66\75\x22\150\x74\x74\160\x3a\57\x2f\x6d\151\156\151\157\x72\141\156\x67\x65\56\143\157\x6d\57\146\x72\x61\x75\144\x22\40\163\x74\171\x6c\145\75\x22\x64\x69\x73\x70\154\141\x79\x3a\x6e\157\156\x65\x3b\x22\x3e\74\57\141\x3e\xd\12\xd\12\11\x9\11\x3c\x2f\165\154\76\15\xa\11\x9\74\x2f\x66\157\162\155\76";
        Gw:
    }
    public function mo_saml_check_empty_or_null_val($d1)
    {
        if (!(!isset($d1) || empty($d1))) {
            goto Yf;
        }
        return true;
        Yf:
        return false;
    }
    function mo_saml_logout($XP)
    {
        $user = get_user_by("\151\x64", $XP);
        $GH = get_site_option("\x73\141\x6d\154\x5f\154\157\x67\157\x75\164\137\x75\162\x6c");
        $q1 = get_site_option("\163\141\155\x6c\137\154\157\x67\157\165\164\x5f\x62\151\x6e\144\x69\156\x67\137\x74\x79\x70\x65");
        $current_user = $user;
        $df = get_user_meta($current_user->ID, "\x6d\x6f\x5f\163\x61\x6d\x6c\137\151\x64\160\x5f\154\157\147\x69\156");
        $df = isset($df[0]) ? $df[0] : '';
        $CP = wp_get_referer();
        if (!empty($CP)) {
            goto me;
        }
        $CP = !empty(get_site_option("\155\x6f\137\163\x61\x6d\x6c\x5f\163\160\137\142\141\163\x65\137\x75\162\154")) ? get_site_option("\x6d\x6f\137\x73\141\x6d\154\137\163\160\x5f\142\x61\x73\x65\x5f\165\162\154") : get_network_site_url();
        me:
        if (empty($GH)) {
            goto WK;
        }
        if (!(!session_id() || session_id() == '' || !isset($_SESSION))) {
            goto Wf;
        }
        session_start();
        Wf:
        if (isset($_SESSION["\155\x6f\137\x73\x61\x6d\x6c\137\x6c\157\x67\x6f\165\164\x5f\162\x65\161\165\x65\163\164"])) {
            goto Ey;
        }
        if ($df == "\x74\x72\165\145") {
            goto mi;
        }
        goto BI;
        Ey:
        self::createLogoutResponseAndRedirect($GH, $q1);
        exit;
        goto BI;
        mi:
        delete_user_meta($current_user->ID, "\155\x6f\137\163\141\155\154\137\151\x64\x70\x5f\154\157\x67\151\x6e");
        $Mo = get_user_meta($current_user->ID, "\155\157\x5f\x73\141\x6d\154\137\156\x61\155\145\137\x69\144");
        $UP = get_user_meta($current_user->ID, "\x6d\x6f\x5f\163\x61\155\154\x5f\x73\145\163\163\x69\x6f\x6e\x5f\x69\156\x64\145\170");
        mo_saml_create_logout_request($Mo, $UP, $GH, $q1, $CP);
        BI:
        WK:
        wp_redirect($CP);
        exit;
    }
    function createLogoutResponseAndRedirect($GH, $q1)
    {
        $Dn = get_site_option("\x6d\x6f\x5f\163\141\155\154\137\x73\x70\x5f\142\141\x73\145\137\165\x72\x6c");
        if (!empty($Dn)) {
            goto c9;
        }
        $Dn = get_network_site_url();
        c9:
        $cr = $_SESSION["\x6d\157\x5f\x73\x61\155\154\x5f\154\157\147\157\x75\x74\137\162\145\x71\x75\145\x73\164"];
        $sB = $_SESSION["\155\157\137\x73\141\x6d\x6c\x5f\154\x6f\x67\157\x75\164\137\x72\x65\154\141\x79\x5f\x73\x74\141\x74\145"];
        unset($_SESSION["\155\x6f\x5f\163\141\155\x6c\x5f\x6c\x6f\x67\157\165\164\137\162\145\x71\x75\145\163\164"]);
        unset($_SESSION["\155\157\x5f\163\141\155\154\x5f\x6c\157\147\157\165\x74\137\x72\145\154\x61\171\x5f\163\x74\141\x74\x65"]);
        $AI = new DOMDocument();
        $AI->loadXML($cr);
        $cr = $AI->firstChild;
        if (!($cr->localName == "\114\x6f\147\x6f\x75\164\122\145\x71\x75\x65\x73\x74")) {
            goto XM;
        }
        $yg = new SAML2_LogoutRequest($cr);
        $DU = get_site_option("\155\157\x5f\163\141\x6d\x6c\x5f\x73\160\137\x65\156\164\151\164\x79\x5f\x69\144");
        if (!empty($DU)) {
            goto Ua;
        }
        $DU = $Dn . "\57\167\x70\55\143\x6f\156\164\145\156\x74\x2f\160\x6c\165\x67\151\x6e\x73\57\155\151\156\x69\x6f\162\x61\156\147\x65\x2d\163\141\x6d\x6c\x2d\x32\60\x2d\x73\151\156\x67\x6c\145\x2d\163\x69\147\x6e\55\x6f\156\57";
        Ua:
        $b2 = $GH;
        $L5 = Utilities::createLogoutResponse($yg->getId(), $DU, $b2, $q1);
        if (empty($q1) || $q1 == "\x48\164\164\160\x52\145\x64\151\162\145\x63\164") {
            goto N9;
        }
        if (!(get_site_option("\x73\x61\x6d\154\x5f\162\145\x71\165\145\x73\x74\137\x73\x69\147\156\145\x64") == "\165\x6e\x63\x68\145\x63\x6b\x65\144")) {
            goto lC;
        }
        $LR = base64_encode($L5);
        Utilities::postSAMLResponse($GH, $LR, $sB);
        exit;
        lC:
        $Vr = '';
        $Je = '';
        $LR = Utilities::signXML($L5, "\x53\x74\x61\164\x75\x73");
        Utilities::postSAMLResponse($GH, $LR, $sB);
        goto j7;
        N9:
        $ib = $GH;
        if (strpos($GH, "\x3f") !== false) {
            goto uS;
        }
        $ib .= "\x3f";
        goto QM;
        uS:
        $ib .= "\46";
        QM:
        if (!(get_site_option("\163\x61\155\x6c\x5f\162\145\x71\x75\x65\x73\x74\137\163\151\x67\156\x65\144") == "\165\156\143\x68\145\x63\x6b\x65\x64")) {
            goto jz;
        }
        $ib .= "\123\x41\x4d\114\122\x65\163\x70\157\x6e\x73\145\75" . $L5 . "\x26\x52\145\154\x61\x79\x53\164\141\x74\145\x3d" . urlencode($sB);
        header("\x4c\157\143\141\164\x69\x6f\x6e\72\x20" . $ib);
        exit;
        jz:
        $ib .= "\x53\x41\x4d\x4c\x52\145\163\x70\x6f\156\163\x65\75" . $L5 . "\46\122\x65\x6c\141\x79\x53\164\141\x74\x65\x3d" . urlencode($sB);
        header("\x4c\157\x63\141\164\151\x6f\x6e\72\x20" . $ib);
        exit;
        j7:
        XM:
    }
}
function mo_saml_create_logout_request($Mo, $UP, $GH, $q1, $CP)
{
    $Dn = get_site_option("\155\x6f\x5f\163\x61\155\x6c\137\x73\160\137\142\141\x73\145\x5f\165\x72\154");
    if (!empty($Dn)) {
        goto LE;
    }
    $Dn = get_network_site_url();
    LE:
    $DU = get_site_option("\155\157\x5f\x73\141\155\x6c\x5f\163\x70\x5f\x65\x6e\x74\x69\x74\171\x5f\x69\x64");
    if (!empty($DU)) {
        goto Mq;
    }
    $DU = $Dn . "\57\x77\160\x2d\x63\x6f\x6e\164\145\x6e\x74\x2f\x70\154\165\147\151\x6e\163\57\x6d\151\x6e\x69\x6f\x72\141\x6e\147\145\55\163\x61\155\154\55\x32\x30\x2d\163\x69\x6e\x67\154\145\55\163\151\x67\x6e\55\x6f\156\x2f";
    Mq:
    $b2 = $GH;
    $ve = $CP;
    if (!empty($ve)) {
        goto Dl;
    }
    $ve = saml_get_current_page_url();
    if (!strpos($ve, "\x3f")) {
        goto hN;
    }
    $ve = get_network_site_url();
    hN:
    Dl:
    $ve = mo_saml_relaystate_url($ve);
    $VH = Utilities::createLogoutRequest($Mo, $DU, $b2, $UP, $q1);
    if (empty($q1) || $q1 == "\x48\x74\x74\160\122\145\144\x69\162\145\143\164") {
        goto MU;
    }
    if (!(get_site_option("\163\x61\155\154\137\x72\x65\x71\165\145\163\x74\137\163\151\x67\156\x65\x64") == "\165\156\x63\x68\x65\x63\153\145\144")) {
        goto wd;
    }
    $LR = base64_encode($VH);
    Utilities::postSAMLRequest($GH, $LR, $ve);
    exit;
    wd:
    $Vr = '';
    $Je = '';
    $LR = Utilities::signXML($VH, "\x4e\141\x6d\x65\111\104\120\157\154\x69\x63\171");
    Utilities::postSAMLRequest($GH, $LR, $ve);
    goto pm;
    MU:
    $ib = $GH;
    if (strpos($GH, "\77") !== false) {
        goto bP;
    }
    $ib .= "\x3f";
    goto Oc;
    bP:
    $ib .= "\46";
    Oc:
    if (!(get_site_option("\x73\141\x6d\x6c\x5f\x72\145\x71\165\145\x73\164\x5f\x73\x69\x67\x6e\145\144") == "\165\x6e\143\150\x65\x63\153\145\144")) {
        goto WI;
    }
    $ib .= "\123\x41\x4d\x4c\x52\x65\161\x75\145\x73\x74\75" . $VH . "\x26\x52\x65\154\141\x79\x53\x74\x61\164\145\75" . urlencode($ve);
    header("\114\157\x63\x61\164\151\157\156\x3a\40" . $ib);
    exit;
    WI:
    $VH = "\123\x41\115\114\122\x65\x71\165\x65\x73\164\x3d" . $VH . "\x26\122\x65\x6c\141\171\123\164\141\x74\x65\x3d" . urlencode($ve) . "\46\x53\x69\x67\x41\x6c\x67\75" . urlencode(XMLSecurityKey::RSA_SHA256);
    $Oi = array("\164\x79\160\x65" => "\160\x72\x69\x76\x61\164\x65");
    $z5 = new XMLSecurityKey(XMLSecurityKey::RSA_SHA256, $Oi);
    $QL = get_site_option("\x6d\x6f\137\x73\141\x6d\154\137\x63\165\162\162\x65\x6e\164\137\x63\145\162\x74\x5f\x70\x72\x69\166\x61\164\145\x5f\x6b\x65\x79");
    $z5->loadKey($QL, FALSE);
    $mS = new XMLSecurityDSig();
    $m4 = $z5->signData($VH);
    $m4 = base64_encode($m4);
    $ib .= $VH . "\x26\x53\x69\147\x6e\141\164\x75\162\145\x3d" . urlencode($m4);
    header("\x4c\157\143\x61\x74\x69\157\156\72" . $ib);
    exit;
    pm:
}
function mo_login_validate()
{
    if (!(isset($_REQUEST["\157\x70\164\151\157\156"]) && $_REQUEST["\157\x70\164\151\x6f\x6e"] == "\x6d\157\x73\141\155\154\x5f\155\145\x74\141\x64\141\x74\x61")) {
        goto cU;
    }
    miniorange_generate_metadata();
    cU:
    if (!mo_saml_is_customer_license_verified()) {
        goto nE;
    }
    if (!(isset($_REQUEST["\157\160\x74\151\x6f\156"]) && $_REQUEST["\x6f\x70\164\151\157\x6e"] == "\163\141\155\x6c\137\165\x73\145\x72\137\154\x6f\147\151\156" || isset($_REQUEST["\157\x70\x74\151\x6f\x6e"]) && $_REQUEST["\x6f\160\x74\x69\157\156"] == "\164\145\x73\x74\x43\x6f\x6e\146\x69\x67" || isset($_REQUEST["\157\x70\164\x69\157\x6e"]) && $_REQUEST["\x6f\160\164\x69\157\x6e"] == "\147\145\164\163\x61\155\x6c\162\145\x71\x75\x65\x73\x74" || isset($_REQUEST["\x6f\x70\164\x69\157\x6e"]) && $_REQUEST["\x6f\x70\164\151\x6f\x6e"] == "\x67\145\164\x73\141\x6d\x6c\x72\x65\163\160\157\x6e\163\145")) {
        goto fP;
    }
    if (mo_saml_is_sp_configured()) {
        goto OO;
    }
    if (!is_user_logged_in()) {
        goto Wv;
    }
    if (!isset($_REQUEST["\x72\x65\144\151\162\x65\x63\164\x5f\x74\x6f"])) {
        goto b5;
    }
    $XX = htmlspecialchars($_REQUEST["\x72\145\x64\x69\162\145\143\x74\137\x74\x6f"]);
    header("\114\157\x63\141\x74\151\157\156\x3a\x20" . $XX);
    exit;
    b5:
    Wv:
    goto tZ;
    OO:
    if (!(is_user_logged_in() and $_REQUEST["\157\x70\164\x69\157\156"] == "\163\141\155\154\x5f\165\163\x65\162\137\154\x6f\147\x69\156")) {
        goto hF;
    }
    if (!isset($_REQUEST["\162\145\144\151\162\x65\143\x74\x5f\164\x6f"])) {
        goto ei;
    }
    $XX = htmlspecialchars($_REQUEST["\162\x65\x64\x69\x72\145\x63\164\137\164\157"]);
    header("\x4c\x6f\x63\x61\x74\x69\157\x6e\x3a\x20" . $XX);
    exit;
    ei:
    return;
    hF:
    $Dn = get_site_option("\x6d\x6f\137\x73\x61\155\x6c\x5f\163\x70\x5f\x62\x61\163\x65\137\165\162\x6c");
    if (!empty($Dn)) {
        goto kO;
    }
    $Dn = get_network_site_url();
    kO:
    $gh = get_site_option("\x73\x61\x6d\154\137\x73\x73\x6f\x5f\x73\x65\164\x74\151\156\x67\163");
    $GU = get_current_blog_id();
    $Ef = Utilities::get_active_sites();
    if (in_array($GU, $Ef)) {
        goto Gu;
    }
    return;
    Gu:
    if (!(empty($gh[$GU]) && !empty($gh["\104\x45\106\101\x55\114\x54"]))) {
        goto uy;
    }
    $gh[$GU] = $gh["\x44\105\106\101\x55\114\124"];
    uy:
    if ($_REQUEST["\157\x70\164\x69\x6f\156"] == "\164\145\x73\164\x43\157\156\146\151\147" and array_key_exists("\156\x65\167\x63\145\x72\x74", $_REQUEST)) {
        goto Jt;
    }
    if ($_REQUEST["\157\160\x74\151\157\156"] == "\x74\x65\x73\164\103\157\156\146\151\147") {
        goto TD;
    }
    if ($_REQUEST["\x6f\160\x74\x69\x6f\x6e"] == "\147\145\x74\x73\141\x6d\x6c\162\145\161\165\x65\x73\x74") {
        goto jb;
    }
    if ($_REQUEST["\x6f\x70\x74\x69\157\x6e"] == "\147\145\x74\163\x61\155\x6c\162\145\x73\x70\x6f\x6e\163\145") {
        goto VL;
    }
    if (!empty($gh[$GU]["\155\x6f\x5f\163\141\155\x6c\x5f\x72\x65\x6c\141\171\137\x73\164\141\x74\x65"])) {
        goto zl;
    }
    if (isset($_REQUEST["\x72\145\144\151\162\145\x63\164\x5f\x74\157"])) {
        goto FU;
    }
    $ve = saml_get_current_page_url();
    goto kG;
    FU:
    $ve = $_REQUEST["\x72\145\x64\x69\x72\145\143\164\x5f\164\x6f"];
    kG:
    goto hE;
    zl:
    $ve = $gh[$GU]["\x6d\x6f\x5f\x73\x61\155\x6c\x5f\162\145\154\141\171\x5f\163\x74\141\164\x65"];
    hE:
    goto Sd;
    VL:
    $ve = "\144\x69\x73\x70\x6c\141\x79\123\101\115\x4c\122\x65\x73\x70\x6f\156\163\x65";
    Sd:
    goto dj;
    jb:
    $ve = "\x64\x69\163\160\154\x61\171\x53\101\x4d\114\122\145\x71\165\145\x73\x74";
    dj:
    goto zk;
    TD:
    $ve = "\164\x65\x73\164\x56\141\154\x69\144\141\164\145";
    zk:
    goto LQ;
    Jt:
    $ve = "\164\145\163\x74\116\x65\167\x43\x65\x72\164\151\x66\x69\x63\141\164\x65";
    LQ:
    $le = get_site_option("\x73\141\x6d\x6c\x5f\x6c\x6f\x67\151\156\137\x75\x72\x6c");
    $St = !empty(get_site_option("\163\141\155\154\x5f\154\157\x67\x69\156\x5f\142\x69\x6e\144\x69\x6e\x67\137\x74\x79\x70\145")) ? get_site_option("\163\141\155\154\137\x6c\x6f\147\151\x6e\x5f\142\x69\156\144\x69\x6e\x67\x5f\x74\171\x70\x65") : "\x48\x74\x74\160\x50\157\163\x74";
    $gh = get_site_option("\163\141\155\154\137\163\x73\x6f\x5f\163\x65\164\x74\x69\156\147\x73");
    $GU = get_current_blog_id();
    $Ef = Utilities::get_active_sites();
    if (in_array($GU, $Ef)) {
        goto AM;
    }
    return;
    AM:
    if (!(empty($gh[$GU]) && !empty($gh["\104\105\x46\101\x55\x4c\x54"]))) {
        goto Od;
    }
    $gh[$GU] = $gh["\x44\x45\x46\x41\125\114\124"];
    Od:
    $do = isset($gh[$GU]["\155\157\137\x73\141\x6d\x6c\137\146\x6f\162\143\x65\137\141\x75\x74\150\145\156\x74\151\x63\141\x74\x69\157\156"]) ? $gh[$GU]["\x6d\x6f\x5f\x73\x61\x6d\154\x5f\x66\157\162\143\x65\x5f\141\x75\164\150\x65\156\164\151\x63\141\x74\x69\x6f\x6e"] : '';
    $Br = $Dn . "\x2f";
    $DU = get_site_option("\155\157\137\163\141\x6d\x6c\x5f\x73\160\137\145\156\x74\151\x74\x79\137\x69\x64");
    $G8 = get_site_option("\163\141\x6d\154\x5f\x6e\141\x6d\145\x69\x64\137\146\157\162\x6d\141\x74");
    if (!empty($G8)) {
        goto WO;
    }
    $G8 = "\61\x2e\x31\72\x6e\141\x6d\x65\151\144\x2d\x66\157\x72\155\141\x74\x3a\165\156\x73\160\145\x63\151\x66\x69\x65\144";
    WO:
    if (!empty($DU)) {
        goto sV;
    }
    $DU = $Dn . "\x2f\167\160\55\x63\157\156\164\145\x6e\x74\x2f\x70\154\x75\x67\151\156\x73\x2f\155\x69\x6e\x69\157\162\x61\x6e\147\145\55\163\141\155\x6c\55\62\60\55\163\x69\156\147\154\x65\x2d\x73\x69\x67\156\x2d\x6f\156\57";
    sV:
    $VH = Utilities::createAuthnRequest($Br, $DU, $le, $do, $St, $G8);
    if (!($ve == "\144\151\163\x70\x6c\141\171\123\x41\x4d\x4c\x52\145\161\x75\x65\163\164")) {
        goto n9;
    }
    mo_saml_show_SAML_log(Utilities::createAuthnRequest($Br, $DU, $le, $do, "\110\164\164\160\120\x6f\163\164", $G8), $ve);
    n9:
    $ib = htmlspecialchars_decode($le);
    if (strpos($le, "\x3f") !== false) {
        goto Ba;
    }
    $ib .= "\77";
    goto qU;
    Ba:
    $ib .= "\x26";
    qU:
    $ve = mo_saml_relaystate_url($ve);
    if ($St == "\x48\x74\164\x70\122\x65\144\x69\162\145\x63\x74") {
        goto p0;
    }
    if (!(get_site_option("\163\141\155\154\x5f\x72\145\161\x75\145\x73\164\137\x73\151\147\x6e\x65\x64") == "\x75\156\143\150\x65\x63\153\145\144")) {
        goto SJ;
    }
    $LR = base64_encode($VH);
    Utilities::postSAMLRequest($le, $LR, $ve);
    exit;
    SJ:
    $Vr = '';
    $Je = '';
    if ($_REQUEST["\x6f\x70\164\151\x6f\156"] == "\x74\145\x73\164\103\x6f\x6e\x66\151\147" && array_key_exists("\156\145\x77\143\x65\x72\x74", $_REQUEST)) {
        goto is;
    }
    $LR = Utilities::signXML($VH, "\x4e\x61\155\145\x49\104\120\x6f\x6c\151\x63\171");
    goto py;
    is:
    $LR = Utilities::signXML($VH, "\x4e\x61\x6d\145\x49\104\x50\x6f\x6c\151\143\x79", true);
    py:
    Utilities::postSAMLRequest($le, $LR, $ve);
    update_site_option("\155\157\x5f\163\141\x6d\x6c\x5f\x6e\145\x77\x5f\143\145\x72\x74\137\164\x65\x73\x74", true);
    goto YC;
    p0:
    if (!(get_site_option("\163\141\155\x6c\137\162\145\x71\x75\145\163\x74\x5f\x73\151\x67\156\145\144") == "\x75\156\x63\150\x65\143\153\x65\x64")) {
        goto K2;
    }
    $ib .= "\x53\101\115\114\x52\x65\161\165\145\163\x74\75" . $VH . "\46\122\145\x6c\141\171\x53\164\x61\x74\x65\x3d" . urlencode($ve);
    header("\x4c\157\x63\x61\164\151\x6f\x6e\72\40" . $ib);
    exit;
    K2:
    $VH = "\x53\101\115\114\x52\145\x71\165\x65\x73\164\x3d" . $VH . "\46\x52\x65\154\x61\x79\123\164\x61\164\x65\75" . urlencode($ve) . "\x26\123\151\147\101\154\x67\75" . urlencode(XMLSecurityKey::RSA_SHA256);
    $Oi = array("\164\x79\x70\145" => "\x70\162\x69\x76\x61\x74\x65");
    $z5 = new XMLSecurityKey(XMLSecurityKey::RSA_SHA256, $Oi);
    if ($_REQUEST["\157\x70\x74\x69\157\x6e"] == "\164\145\163\164\x43\x6f\156\x66\151\147" && array_key_exists("\156\x65\x77\x63\x65\x72\x74", $_REQUEST)) {
        goto h4;
    }
    $QL = get_site_option("\155\157\x5f\x73\141\155\x6c\137\143\165\162\x72\x65\x6e\164\137\143\145\x72\164\137\160\x72\x69\x76\x61\164\145\137\x6b\x65\x79");
    goto hv;
    h4:
    $QL = file_get_contents(plugin_dir_path(__FILE__) . "\x72\145\x73\157\165\162\143\x65\163" . DIRECTORY_SEPARATOR . mo_options_enum_default_sp_certificate::SP_Private_Key);
    hv:
    $z5->loadKey($QL, FALSE);
    $mS = new XMLSecurityDSig();
    $m4 = $z5->signData($VH);
    $m4 = base64_encode($m4);
    $ib .= $VH . "\x26\x53\151\x67\x6e\141\164\x75\x72\x65\x3d" . urlencode($m4);
    header("\114\x6f\143\x61\x74\151\157\x6e\x3a\x20" . $ib);
    exit;
    YC:
    tZ:
    fP:
    if (!(array_key_exists("\x53\101\115\x4c\x52\x65\163\160\157\156\x73\x65", $_REQUEST) && !empty($_REQUEST["\123\101\115\114\122\145\163\160\x6f\156\x73\x65"]))) {
        goto t8;
    }
    if (array_key_exists("\122\x65\x6c\141\171\x53\x74\141\164\x65", $_POST) && !empty($_POST["\122\145\x6c\x61\171\x53\x74\x61\164\145"]) && $_POST["\x52\145\154\141\171\123\x74\141\x74\x65"] != "\x2f") {
        goto KA;
    }
    $QY = '';
    goto LY;
    KA:
    $QY = $_POST["\122\x65\154\x61\x79\x53\x74\x61\164\145"];
    LY:
    $QY = mo_saml_parse_url($QY);
    $Dn = get_site_option("\155\157\137\163\141\x6d\x6c\137\x73\160\x5f\x62\x61\x73\145\137\x75\162\154");
    if (!empty($Dn)) {
        goto Av;
    }
    $Dn = get_network_site_url();
    Av:
    $oS = $_REQUEST["\123\x41\115\114\x52\145\x73\x70\x6f\156\x73\x65"];
    $oS = base64_decode($oS);
    if (!($QY == "\x64\x69\x73\x70\x6c\x61\171\123\x41\115\114\x52\145\163\x70\x6f\x6e\x73\x65")) {
        goto xq;
    }
    mo_saml_show_SAML_log($oS, $QY);
    xq:
    if (!(array_key_exists("\x53\x41\115\x4c\x52\x65\163\x70\157\156\x73\x65", $_GET) && !empty($_GET["\x53\x41\115\x4c\x52\x65\163\160\157\x6e\x73\x65"]))) {
        goto HT;
    }
    $oS = gzinflate($oS);
    HT:
    $AI = new DOMDocument();
    $AI->loadXML($oS);
    $f9 = $AI->firstChild;
    $YP = $AI->documentElement;
    $C1 = new DOMXpath($AI);
    $C1->registerNamespace("\163\141\155\x6c\x70", "\x75\x72\156\x3a\x6f\x61\163\x69\x73\x3a\156\141\x6d\x65\x73\72\x74\x63\x3a\x53\101\115\x4c\x3a\62\x2e\60\x3a\x70\x72\x6f\164\x6f\143\157\x6c");
    $C1->registerNamespace("\163\x61\x6d\x6c", "\165\x72\x6e\x3a\157\x61\163\151\163\x3a\156\x61\155\145\x73\x3a\164\x63\72\x53\x41\x4d\114\72\62\56\x30\x3a\x61\x73\163\x65\x72\164\x69\x6f\x6e");
    if ($f9->localName == "\x4c\157\147\157\165\164\x52\x65\163\x70\x6f\156\x73\145") {
        goto gG;
    }
    $lh = $C1->query("\x2f\163\141\155\x6c\160\72\122\145\x73\x70\157\x6e\163\x65\57\x73\141\x6d\154\160\x3a\123\x74\x61\x74\165\x73\57\x73\141\155\154\x70\72\123\164\141\164\x75\163\103\x6f\x64\145", $YP);
    $lL = isset($lh) ? $lh->item(0)->getAttribute("\126\x61\x6c\x75\x65") : '';
    $bM = explode("\x3a", $lL);
    if (!array_key_exists(7, $bM)) {
        goto qk;
    }
    $lh = $bM[7];
    qk:
    $pk = $C1->query("\x2f\x73\x61\x6d\x6c\x70\72\122\x65\163\x70\157\x6e\x73\x65\x2f\x73\x61\155\154\160\72\x53\164\x61\164\x75\163\57\163\141\155\x6c\x70\72\x53\164\141\164\165\163\115\x65\x73\x73\141\x67\145", $YP);
    $xm = isset($pk) ? $pk->item(0) : '';
    if (empty($xm)) {
        goto GQ;
    }
    $xm = $xm->nodeValue;
    GQ:
    if (array_key_exists("\x52\145\154\141\171\x53\164\141\x74\145", $_POST) && !empty($_POST["\x52\145\x6c\x61\x79\x53\x74\141\x74\145"]) && $_POST["\x52\145\154\x61\171\123\x74\141\x74\145"] != "\x2f") {
        goto tQ;
    }
    $QY = '';
    goto hf;
    tQ:
    $QY = $_POST["\x52\145\x6c\141\x79\x53\x74\141\x74\145"];
    $QY = mo_saml_parse_url($QY);
    hf:
    if (!($lh != "\x53\x75\x63\x63\x65\x73\163")) {
        goto FF;
    }
    show_status_error($lh, $QY, $xm);
    FF:
    if (!($QY !== "\x74\x65\163\x74\126\x61\154\151\144\x61\x74\145" && $QY !== "\x74\x65\163\164\116\x65\167\103\x65\x72\x74\x69\x66\x69\x63\x61\x74\x65")) {
        goto dJ;
    }
    $KJ = parse_url($QY, PHP_URL_HOST);
    $UE = parse_url($Dn, PHP_URL_HOST);
    $ip = parse_url(get_current_base_url(), PHP_URL_HOST);
    if (!empty($QY)) {
        goto SS;
    }
    $QY = "\57";
    goto n4;
    SS:
    $QY = mo_saml_parse_url($QY);
    n4:
    if (!(!empty($KJ) && $KJ != $ip)) {
        goto pV;
    }
    Utilities::postSAMLResponse($QY, $_REQUEST["\123\x41\x4d\114\x52\x65\163\x70\x6f\x6e\x73\x65"], mo_saml_relaystate_url($QY));
    pV:
    dJ:
    $MX = maybe_unserialize(get_site_option("\x73\141\x6d\x6c\x5f\170\65\60\x39\x5f\x63\x65\x72\x74\x69\x66\x69\143\x61\164\x65"));
    update_site_option("\x6d\157\137\x73\141\x6d\154\x5f\162\145\163\160\x6f\x6e\163\x65", base64_encode($oS));
    foreach ($MX as $z5 => $d1) {
        if (@openssl_x509_read($d1)) {
            goto Oz;
        }
        unset($MX[$z5]);
        Oz:
        iT:
    }
    sg:
    $Br = $Dn . "\x2f";
    if ($QY == "\x74\145\163\x74\x4e\145\x77\103\x65\x72\164\151\x66\151\x63\x61\164\145") {
        goto DQ;
    }
    $oS = new SAML2_Response($f9, get_site_option("\155\157\137\163\x61\x6d\154\x5f\x63\x75\162\162\x65\156\164\x5f\143\x65\162\164\137\x70\x72\151\x76\141\164\145\x5f\x6b\145\171"));
    goto bk;
    DQ:
    $lo = file_get_contents(plugin_dir_path(__FILE__) . "\162\145\x73\157\165\x72\x63\145\x73" . DIRECTORY_SEPARATOR . mo_options_enum_default_sp_certificate::SP_Private_Key);
    $oS = new SAML2_Response($f9, $lo);
    bk:
    $pZ = $oS->getSignatureData();
    $pj = current($oS->getAssertions())->getSignatureData();
    if (!(empty($pj) && empty($pZ))) {
        goto o_;
    }
    if ($QY == "\x74\145\x73\x74\x56\141\x6c\151\144\141\164\x65" or $QY == "\x74\145\163\x74\116\x65\x77\x43\145\162\164\x69\x66\151\143\x61\164\145") {
        goto Bt;
    }
    wp_die("\127\145\40\x63\x6f\x75\154\x64\40\156\x6f\164\40\x73\x69\147\156\x20\171\x6f\165\x20\x69\156\x2e\40\x50\x6c\x65\141\x73\145\40\143\157\156\164\x61\143\164\40\141\144\155\x69\156\151\x73\164\x72\141\164\157\162", "\105\162\x72\x6f\162\x3a\40\111\x6e\166\141\154\151\x64\40\x53\101\x4d\114\x20\122\145\163\x70\x6f\x6e\163\x65");
    goto yO;
    Bt:
    $lN = mo_options_error_constants::Error_no_certificate;
    $PR = mo_options_error_constants::Cause_no_certificate;
    echo "\x3c\144\151\x76\x20\163\164\x79\154\x65\75\42\x66\x6f\156\164\55\x66\x61\x6d\x69\x6c\x79\72\x43\141\x6c\x69\x62\x72\x69\x3b\x70\141\144\x64\151\x6e\x67\x3a\60\x20\63\x25\73\42\76\xd\xa\11\11\x9\11\x9\11\74\x64\151\x76\x20\x73\164\x79\154\x65\75\x22\143\157\154\x6f\162\x3a\x20\43\x61\x39\x34\x34\64\x32\73\142\x61\x63\153\x67\162\x6f\x75\156\144\x2d\x63\x6f\x6c\157\162\x3a\x20\43\146\62\x64\145\144\145\73\160\x61\x64\x64\151\156\147\x3a\x20\x31\65\x70\x78\x3b\x6d\141\162\147\x69\156\x2d\x62\x6f\x74\164\x6f\x6d\x3a\40\62\x30\x70\x78\73\x74\145\x78\x74\55\x61\154\151\x67\156\72\143\x65\x6e\164\x65\x72\73\142\157\162\x64\x65\x72\x3a\x31\x70\x78\40\163\x6f\x6c\151\144\40\x23\105\x36\102\63\x42\62\x3b\x66\157\156\x74\x2d\163\151\x7a\x65\72\x31\70\x70\164\73\x22\76\40\105\122\122\x4f\122\74\57\144\x69\x76\x3e\15\xa\11\x9\x9\11\11\11\x3c\x64\151\166\x20\163\x74\171\x6c\145\75\x22\x63\157\x6c\x6f\162\72\40\x23\141\71\x34\x34\64\62\73\146\x6f\156\164\55\163\151\x7a\145\x3a\x31\64\x70\x74\x3b\40\155\141\162\147\x69\156\x2d\142\x6f\164\164\x6f\155\72\62\60\160\x78\73\x22\76\74\x70\76\x3c\163\x74\x72\157\156\x67\x3e\105\x72\162\x6f\x72\40\x20\x3a" . $lN . "\40\x3c\x2f\x73\164\x72\x6f\x6e\147\x3e\x3c\57\160\x3e\xd\12\x9\x9\11\11\x9\x9\xd\xa\11\11\x9\x9\11\x9\x3c\x70\76\x3c\163\x74\x72\157\156\147\x3e\x50\157\x73\163\x69\x62\154\145\40\x43\x61\165\163\145\x3a\40" . $PR . "\74\x2f\x73\x74\x72\x6f\x6e\x67\76\74\57\x70\x3e\15\xa\11\11\x9\x9\x9\11\xd\12\x9\x9\11\x9\x9\11\x3c\57\x64\x69\166\76\x3c\57\x64\x69\x76\x3e";
    mo_saml_download_logs($lN, $PR);
    exit;
    yO:
    o_:
    $rn = '';
    if (is_array($MX)) {
        goto VF;
    }
    $wn = XMLSecurityKey::getRawThumbprint($MX);
    $wn = mo_saml_convert_to_windows_iconv($wn);
    $wn = preg_replace("\x2f\134\x73\x2b\x2f", '', $wn);
    if (empty($pZ)) {
        goto Ox;
    }
    $rn = Utilities::processResponse($Br, $wn, $pZ, $oS, 0, $QY);
    Ox:
    if (empty($pj)) {
        goto LJ;
    }
    $rn = Utilities::processResponse($Br, $wn, $pj, $oS, 0, $QY);
    LJ:
    goto ik;
    VF:
    foreach ($MX as $z5 => $d1) {
        $wn = XMLSecurityKey::getRawThumbprint($d1);
        $wn = mo_saml_convert_to_windows_iconv($wn);
        $wn = preg_replace("\57\x5c\x73\53\57", '', $wn);
        if (empty($pZ)) {
            goto aO;
        }
        $rn = Utilities::processResponse($Br, $wn, $pZ, $oS, $z5, $QY);
        aO:
        if (empty($pj)) {
            goto TO;
        }
        $rn = Utilities::processResponse($Br, $wn, $pj, $oS, $z5, $QY);
        TO:
        if (!$rn) {
            goto YW;
        }
        goto JU;
        YW:
        zZ:
    }
    JU:
    ik:
    if (empty($pZ)) {
        goto CQ;
    }
    $Us = $pZ["\x43\145\162\x74\151\x66\x69\x63\141\x74\145\163"][0];
    goto uV;
    CQ:
    $Us = $pj["\103\145\162\x74\x69\x66\x69\x63\x61\x74\145\163"][0];
    uV:
    if ($rn) {
        goto yR;
    }
    if ($QY == "\x74\145\163\164\x56\x61\154\151\144\141\164\145" or $QY == "\164\x65\x73\164\116\145\x77\x43\145\x72\164\151\146\151\x63\141\x74\145") {
        goto AL;
    }
    wp_die("\x57\145\x20\x63\157\165\154\x64\x20\156\157\x74\x20\x73\x69\147\x6e\x20\x79\x6f\165\40\151\x6e\x2e\x20\120\x6c\x65\141\x73\x65\x20\x63\x6f\x6e\x74\x61\143\164\x20\x79\x6f\165\x72\x20\101\x64\155\151\156\151\163\164\x72\141\x74\x6f\x72", "\x45\162\x72\x6f\x72\40\72\103\x65\162\x74\151\x66\x69\143\141\164\145\40\x6e\157\164\x20\146\x6f\x75\156\144");
    goto BL;
    AL:
    $lN = mo_options_error_constants::Error_wrong_certificate;
    $PR = mo_options_error_constants::Cause_wrong_certificate;
    $J8 = "\x2d\x2d\55\x2d\x2d\102\x45\107\x49\x4e\x20\x43\x45\x52\x54\111\106\x49\x43\x41\124\x45\x2d\x2d\55\x2d\x2d\74\142\x72\76" . chunk_split($Us, 64) . "\x3c\x62\162\x3e\55\55\x2d\55\x2d\105\116\x44\x20\x43\x45\x52\124\x49\106\111\x43\x41\x54\105\x2d\55\55\x2d\x2d";
    echo "\74\x64\151\x76\40\163\x74\171\x6c\145\75\x22\x66\x6f\156\164\55\x66\141\x6d\151\154\171\72\x43\141\154\x69\x62\x72\151\x3b\x70\x61\x64\144\151\x6e\147\72\60\40\63\45\x3b\x22\x3e";
    echo "\x3c\x64\151\x76\x20\163\164\x79\x6c\145\75\x22\x63\157\x6c\x6f\162\x3a\x20\x23\141\71\64\64\64\62\73\142\x61\x63\x6b\x67\x72\157\165\x6e\x64\x2d\143\x6f\154\x6f\162\x3a\40\43\146\x32\x64\x65\144\145\73\160\141\x64\x64\151\156\x67\x3a\40\x31\65\160\x78\73\155\141\x72\x67\x69\156\55\x62\x6f\x74\x74\157\155\x3a\x20\x32\x30\x70\170\x3b\x74\145\170\164\55\x61\154\x69\147\x6e\72\x63\145\x6e\x74\x65\162\73\142\x6f\x72\144\x65\x72\x3a\61\160\x78\x20\163\157\x6c\x69\x64\40\x23\105\x36\x42\x33\102\62\73\x66\157\x6e\x74\55\x73\x69\x7a\145\72\x31\70\160\x74\x3b\x22\76\x20\105\122\122\117\122\x3c\x2f\144\x69\x76\x3e\xd\xa\x20\x20\x20\x20\x20\40\40\x20\40\40\40\40\40\x20\x20\40\x20\40\x20\40\x20\x20\x20\40\x3c\x64\x69\x76\40\163\x74\x79\154\145\x3d\42\143\157\154\x6f\162\72\40\43\x61\x39\x34\x34\x34\x32\73\146\157\x6e\x74\55\163\151\x7a\x65\72\x31\x34\160\164\x3b\40\x6d\x61\x72\147\151\x6e\x2d\x62\157\164\164\x6f\x6d\x3a\62\60\160\170\73\x22\x3e\x3c\x70\x3e\x3c\163\x74\x72\157\x6e\147\76\105\x72\162\157\162\x3a\x20\x3c\57\163\x74\x72\157\156\x67\x3e\x55\156\x61\x62\154\x65\x20\x74\157\40\146\151\x6e\x64\40\x61\x20\x63\145\x72\164\151\146\x69\x63\x61\164\145\x20\155\141\x74\x63\x68\x69\x6e\x67\x20\164\150\x65\40\x63\157\156\x66\x69\x67\x75\x72\x65\144\x20\146\151\156\x67\145\162\160\162\151\156\x74\56\x3c\x2f\160\76\xd\xa\x20\40\x20\x20\x20\x20\x20\x20\x20\40\40\40\40\40\40\40\x20\40\x20\x20\40\40\x20\x20\40\40\40\40\x3c\160\76\120\154\145\141\163\x65\40\x63\157\156\164\141\x63\x74\x20\171\157\165\x72\x20\141\144\x6d\x69\x6e\151\x73\x74\x72\x61\164\x6f\x72\x20\x61\156\144\x20\x72\145\160\x6f\162\x74\x20\164\150\x65\40\x66\157\154\x6c\x6f\167\x69\156\147\40\145\x72\x72\157\x72\72\74\x2f\x70\76\xd\12\40\40\40\x20\x20\x20\x20\x20\40\40\x20\40\40\40\x20\x20\40\40\40\x20\40\x20\40\40\x20\x20\x20\x20\74\x70\x3e\x3c\x73\164\x72\x6f\x6e\x67\76\x50\157\x73\x73\x69\142\154\x65\40\x43\x61\165\x73\145\x3a\40\x3c\x2f\163\164\x72\x6f\156\x67\x3e\47\130\56\65\60\x39\40\x43\145\162\x74\151\x66\151\143\x61\x74\145\x27\x20\x66\151\x65\x6c\144\40\151\156\x20\160\154\165\147\151\x6e\x20\144\157\x65\x73\40\156\157\164\40\x6d\x61\164\x63\x68\40\164\x68\x65\40\143\145\x72\x74\x69\146\x69\143\x61\164\x65\40\x66\157\165\x6e\x64\x20\151\156\40\x53\x41\115\114\40\x52\x65\x73\160\157\x6e\x73\145\x2e\74\57\x70\76\xd\xa\40\x20\x20\x20\40\x20\x20\40\40\40\x20\40\x20\x20\40\40\x20\x20\40\40\40\40\x20\40\40\x20\x20\x20\74\160\76\74\163\x74\x72\x6f\156\x67\76\x43\145\x72\164\x69\146\x69\x63\141\x74\145\40\146\157\x75\x6e\x64\40\151\156\40\123\x41\x4d\x4c\x20\x52\x65\x73\160\x6f\156\x73\x65\72\x20\x3c\x2f\163\x74\x72\157\156\x67\76\x3c\146\157\156\x74\40\146\x61\x63\145\x3d\x22\x43\157\x75\x72\x69\x65\x72\x20\116\x65\167\x22\76\x3c\142\x72\76\74\142\162\76" . $J8 . "\74\57\160\76\74\x2f\x66\157\156\164\x3e\xd\12\x20\40\40\40\40\x20\40\40\x20\x20\x20\40\40\x20\x20\40\40\40\40\40\40\40\x20\40\40\x20\40\x20\74\x70\76\x3c\x73\164\x72\x6f\x6e\147\x3e\x53\x6f\154\165\x74\151\x6f\156\x3a\40\x3c\x2f\163\x74\x72\157\156\147\x3e\74\x2f\160\76\15\xa\x20\x20\x20\40\40\40\x20\x20\40\x20\x20\x20\40\40\40\x20\x20\40\x20\40\x20\x20\40\x20\40\40\x20\40\74\x6f\154\x3e\xd\12\x20\x20\40\x20\x20\x20\40\40\40\40\x20\40\x20\40\40\x20\x20\40\x20\40\x20\x20\40\40\x20\40\40\40\x20\40\40\x3c\154\x69\x3e\103\157\160\171\x20\x70\x61\163\164\x65\x20\x74\150\145\x20\x63\x65\x72\x74\151\x66\x69\x63\141\x74\145\40\x70\162\157\x76\151\x64\145\x64\40\x61\x62\x6f\166\x65\40\151\156\40\130\x35\60\x39\40\x43\145\162\164\x69\x66\x69\x63\141\x74\x65\x20\165\156\144\x65\x72\x20\x53\145\162\x76\x69\x63\x65\x20\x50\x72\x6f\x76\151\x64\145\162\40\x53\x65\x74\165\160\40\x74\x61\x62\56\x3c\x2f\154\x69\76\15\12\40\40\40\40\x20\40\40\x20\x20\40\40\x20\x20\x20\40\x20\40\x20\40\40\40\x20\x20\40\40\x20\40\40\40\x20\40\x3c\x6c\x69\x3e\111\146\40\151\x73\x73\165\x65\40\x70\145\162\x73\151\163\x74\163\x20\x64\151\163\141\x62\154\145\x20\74\x62\x3e\103\x68\141\162\x61\143\164\145\x72\40\x65\x6e\143\157\144\x69\156\147\x3c\x2f\x62\x3e\40\165\156\144\145\162\x20\x53\x65\162\x76\x69\143\145\40\x50\162\x6f\x76\144\145\162\x20\123\x65\164\165\x70\40\x74\x61\x62\56\74\x2f\154\x69\x3e\xd\xa\x20\x20\x20\x20\x20\40\x20\x20\x20\x20\x20\40\40\40\40\x20\x20\x20\40\x20\40\40\40\x20\x20\40\40\x20\74\x2f\x6f\x6c\x3e\xd\12\40\40\40\40\40\40\x20\x20\40\x20\40\40\40\40\40\40\40\40\x20\x20\40\40\40\40\40\40\x20\x20\x3c\x2f\x64\x69\166\76\15\12\x20\40\40\x20\x20\x20\40\40\x20\x20\x20\40\40\x20\40\40\40\x20\x20\x20\x20\x20\40\40\74\144\x69\x76\40\163\x74\x79\x6c\x65\75\x22\155\141\x72\x67\151\x6e\72\x33\45\x3b\144\151\x73\160\154\141\171\x3a\x62\154\x6f\x63\153\73\x74\145\170\x74\55\x61\154\x69\x67\156\72\143\x65\x6e\x74\x65\x72\73\42\x3e\xd\12\x20\x20\40\40\40\x20\x20\x20\x20\40\x20\x20\x20\40\x20\40\40\40\x20\40\x20\x20\40\40\40\x20\40\40\40\40\x20\40\74\x64\x69\166\40\163\164\x79\x6c\x65\75\42\x6d\x61\x72\x67\151\156\x3a\x33\45\73\x64\151\x73\x70\x6c\x61\x79\72\142\x6c\x6f\x63\153\73\164\x65\170\x74\x2d\x61\154\x69\x67\x6e\72\143\145\x6e\x74\145\162\x3b\x22\x3e\74\x69\156\160\165\x74\40\x73\x74\x79\x6c\145\75\x22\x70\x61\x64\x64\151\x6e\x67\x3a\61\45\x3b\167\151\x64\164\x68\72\x31\x30\x30\x70\x78\x3b\x62\141\x63\x6b\147\162\157\165\156\144\72\x20\x23\x30\60\x39\x31\x43\x44\40\156\x6f\156\x65\40\x72\145\x70\x65\141\164\x20\163\143\x72\x6f\154\x6c\40\x30\x25\x20\x30\45\73\x63\x75\162\163\x6f\162\x3a\x20\x70\x6f\x69\x6e\164\145\x72\73\x66\157\x6e\x74\x2d\x73\151\172\145\x3a\x31\65\160\170\73\142\157\x72\144\x65\x72\55\167\x69\x64\x74\150\x3a\40\x31\160\x78\x3b\142\157\x72\x64\x65\162\55\x73\164\171\x6c\x65\x3a\x20\163\157\x6c\151\x64\x3b\142\x6f\162\144\145\x72\x2d\162\141\x64\151\x75\163\72\40\x33\160\170\73\167\150\x69\x74\x65\x2d\x73\160\x61\143\145\72\x20\x6e\x6f\x77\x72\x61\160\x3b\142\157\170\x2d\x73\151\x7a\x69\156\x67\x3a\x20\142\x6f\162\x64\x65\x72\55\x62\x6f\170\73\142\x6f\162\x64\145\162\55\x63\x6f\154\157\x72\72\40\43\x30\x30\67\x33\101\101\x3b\142\157\170\55\163\150\x61\x64\x6f\167\x3a\40\x30\x70\x78\x20\x31\x70\170\x20\x30\x70\170\40\162\x67\x62\141\50\x31\x32\x30\x2c\40\x32\60\x30\x2c\x20\62\63\x30\54\x20\x30\x2e\66\51\x20\151\156\x73\x65\164\73\x63\x6f\154\157\162\x3a\x20\x23\x46\x46\x46\x3b\x22\164\171\x70\x65\75\x22\142\x75\x74\x74\x6f\156\x22\x20\x76\141\x6c\x75\x65\75\42\x44\157\x6e\145\42\x20\157\x6e\x43\154\151\x63\153\x3d\x22\163\145\154\x66\56\143\x6c\157\x73\x65\50\51\73\x22\76\x3c\57\144\x69\166\76";
    mo_saml_download_logs($lN, $PR);
    exit;
    BL:
    yR:
    $pr = get_site_option("\163\x61\x6d\x6c\137\151\163\163\165\x65\x72");
    $DU = get_site_option("\155\x6f\x5f\x73\141\155\x6c\137\x73\x70\137\145\x6e\164\151\164\171\x5f\151\x64");
    if (!empty($DU)) {
        goto NA;
    }
    $DU = $Dn . "\57\167\x70\55\x63\x6f\x6e\x74\145\156\x74\x2f\160\x6c\x75\147\151\x6e\x73\x2f\x6d\151\156\x69\157\x72\x61\156\147\x65\55\163\x61\155\154\55\62\x30\x2d\x73\151\156\147\154\145\x2d\163\151\147\156\55\x6f\156\57";
    NA:
    Utilities::validateIssuerAndAudience($oS, $DU, $pr, $QY);
    $Jq = current(current($oS->getAssertions())->getNameId());
    $jc = current($oS->getAssertions())->getAttributes();
    $jc["\116\141\155\145\x49\x44"] = array("\60" => $Jq);
    $UP = current($oS->getAssertions())->getSessionIndex();
    mo_saml_checkMapping($jc, $QY, $UP);
    goto UY;
    gG:
    if (!isset($_REQUEST["\122\x65\154\x61\x79\x53\164\141\x74\145"])) {
        goto QF;
    }
    $sB = $_REQUEST["\x52\145\154\x61\171\123\x74\141\164\145"];
    QF:
    if (!is_user_logged_in()) {
        goto SX;
    }
    wp_logout();
    SX:
    if (empty($sB)) {
        goto Pf;
    }
    $sB = mo_saml_parse_url($sB);
    goto M9;
    Pf:
    $sB = $Dn;
    M9:
    header("\x4c\157\143\141\164\151\x6f\x6e\72" . $sB);
    exit;
    UY:
    t8:
    if (!(array_key_exists("\x53\x41\115\x4c\x52\x65\161\165\x65\x73\x74", $_REQUEST) && !empty($_REQUEST["\123\x41\x4d\x4c\x52\145\161\165\x65\163\x74"]))) {
        goto sK;
    }
    $VH = $_REQUEST["\123\101\x4d\x4c\122\x65\x71\x75\x65\163\x74"];
    $QY = "\x2f";
    if (!array_key_exists("\122\x65\x6c\x61\x79\123\x74\x61\164\145", $_REQUEST)) {
        goto cq;
    }
    $QY = $_REQUEST["\122\x65\154\x61\171\x53\164\x61\x74\145"];
    cq:
    $VH = base64_decode($VH);
    if (!(array_key_exists("\x53\x41\115\x4c\x52\145\x71\165\x65\x73\x74", $_GET) && !empty($_GET["\x53\101\x4d\114\122\x65\x71\165\x65\163\164"]))) {
        goto tA;
    }
    $VH = gzinflate($VH);
    tA:
    $AI = new DOMDocument();
    $AI->loadXML($VH);
    $c6 = $AI->firstChild;
    if (!($c6->localName == "\x4c\157\x67\x6f\165\164\x52\145\161\x75\145\x73\x74")) {
        goto jh;
    }
    $yg = new SAML2_LogoutRequest($c6);
    if (!(!session_id() || session_id() == '' || !isset($_SESSION))) {
        goto KZ;
    }
    session_start();
    KZ:
    $_SESSION["\155\x6f\x5f\x73\x61\155\x6c\x5f\154\157\147\x6f\165\x74\x5f\x72\145\161\165\145\163\x74"] = $VH;
    $_SESSION["\155\157\x5f\163\141\155\154\137\x6c\157\147\x6f\165\164\137\x72\x65\x6c\x61\x79\137\163\x74\141\164\x65"] = $QY;
    wp_redirect(htmlspecialchars_decode(wp_logout_url()));
    exit;
    jh:
    sK:
    if (!(isset($_REQUEST["\157\160\164\x69\x6f\x6e"]) and !is_array($_REQUEST["\157\x70\x74\151\x6f\x6e"]) and strpos($_REQUEST["\x6f\x70\164\x69\x6f\156"], "\x72\145\141\144\163\x61\155\x6c\x6c\157\x67\151\x6e") !== false)) {
        goto pr;
    }
    require_once dirname(__FILE__) . "\x2f\151\156\x63\x6c\165\144\x65\163\57\x6c\x69\x62\x2f\x65\156\x63\x72\x79\160\x74\x69\x6f\x6e\56\x70\x68\160";
    if (isset($_POST["\x53\124\x41\124\x55\123"]) && $_POST["\x53\124\101\x54\125\x53"] == "\105\x52\122\117\x52") {
        goto nQ;
    }
    if (!(isset($_POST["\123\124\x41\124\x55\123"]) && $_POST["\x53\x54\101\x54\125\123"] == "\x53\x55\103\103\x45\x53\123")) {
        goto az;
    }
    $bE = '';
    if (!(isset($_REQUEST["\162\x65\x64\x69\x72\x65\143\164\137\x74\157"]) && !empty($_REQUEST["\162\145\x64\x69\x72\145\143\x74\x5f\x74\157"]) && $_REQUEST["\x72\145\144\151\162\x65\143\x74\137\164\157"] != "\x2f")) {
        goto Lx;
    }
    $bE = $_REQUEST["\x72\x65\x64\x69\162\x65\x63\x74\x5f\164\157"];
    Lx:
    delete_site_option("\x6d\157\137\163\141\x6d\x6c\137\162\145\144\151\x72\145\143\x74\137\x65\x72\x72\157\x72\137\x63\x6f\x64\145");
    delete_site_option("\x6d\157\x5f\x73\141\x6d\154\x5f\x72\145\144\151\162\x65\x63\164\137\145\x72\162\x6f\162\x5f\x72\145\141\163\157\x6e");
    try {
        $Wz = get_site_option("\x73\141\155\x6c\x5f\141\155\x5f\x65\155\141\151\154");
        $tx = get_site_option("\x73\x61\x6d\154\x5f\141\x6d\137\165\163\145\162\156\x61\x6d\x65");
        $o2 = get_site_option("\163\x61\x6d\154\137\x61\155\137\x66\x69\x72\x73\164\x5f\x6e\x61\x6d\145");
        $O6 = get_site_option("\x73\x61\x6d\x6c\137\x61\x6d\x5f\154\141\163\164\137\x6e\141\x6d\145");
        $Me = get_site_option("\x73\x61\x6d\x6c\137\x61\155\137\147\162\x6f\165\160\x5f\x6e\x61\x6d\145");
        $WA = get_site_option("\163\141\155\x6c\x5f\x61\x6d\137\144\x65\146\141\165\154\x74\x5f\165\x73\145\162\x5f\x72\157\154\x65");
        $dE = get_site_option("\x73\141\x6d\x6c\x5f\x61\155\x5f\144\157\156\164\137\x61\154\x6c\x6f\x77\x5f\x75\x6e\154\x69\163\164\x65\144\137\165\163\145\x72\x5f\162\157\154\x65");
        $aJ = get_site_option("\163\141\x6d\x6c\x5f\141\x6d\x5f\141\143\143\157\x75\156\164\137\155\x61\164\143\x68\145\x72");
        $O2 = '';
        $m0 = '';
        $o2 = str_replace("\x2e", "\137", $o2);
        $o2 = str_replace("\x20", "\x5f", $o2);
        if (!(!empty($o2) && array_key_exists($o2, $_POST))) {
            goto u4;
        }
        $o2 = $_POST[$o2];
        u4:
        $O6 = str_replace("\56", "\x5f", $O6);
        $O6 = str_replace("\40", "\x5f", $O6);
        if (!(!empty($O6) && array_key_exists($O6, $_POST))) {
            goto sw;
        }
        $O6 = $_POST[$O6];
        sw:
        $tx = str_replace("\56", "\137", $tx);
        $tx = str_replace("\x20", "\137", $tx);
        if (!empty($tx) && array_key_exists($tx, $_POST)) {
            goto oT;
        }
        $m0 = $_POST["\116\141\x6d\x65\111\104"];
        goto k8;
        oT:
        $m0 = $_POST[$tx];
        k8:
        $O2 = str_replace("\x2e", "\x5f", $Wz);
        $O2 = str_replace("\x20", "\x5f", $Wz);
        if (!empty($Wz) && array_key_exists($Wz, $_POST)) {
            goto WM;
        }
        $O2 = $_POST["\116\x61\155\145\x49\104"];
        goto bo;
        WM:
        $O2 = $_POST[$Wz];
        bo:
        $Me = str_replace("\56", "\137", $Me);
        $Me = str_replace("\x20", "\x5f", $Me);
        if (!(!empty($Me) && array_key_exists($Me, $_POST))) {
            goto vu;
        }
        $Me = $_POST[$Me];
        vu:
        if (!empty($aJ)) {
            goto xB;
        }
        $aJ = "\x65\155\141\151\x6c";
        xB:
        $z5 = get_site_option("\x6d\x6f\x5f\x73\x61\x6d\x6c\137\x63\165\x73\x74\157\155\x65\162\x5f\164\x6f\153\145\x6e");
        if (!(isset($z5) || trim($z5) != '')) {
            goto k3;
        }
        $Tx = AESEncryption::decrypt_data($O2, $z5);
        $O2 = $Tx;
        k3:
        if (!(!empty($o2) && !empty($z5))) {
            goto OF;
        }
        $GZ = AESEncryption::decrypt_data($o2, $z5);
        $o2 = $GZ;
        OF:
        if (!(!empty($O6) && !empty($z5))) {
            goto xF;
        }
        $wa = AESEncryption::decrypt_data($O6, $z5);
        $O6 = $wa;
        xF:
        if (!(!empty($m0) && !empty($z5))) {
            goto qA;
        }
        $Tz = AESEncryption::decrypt_data($m0, $z5);
        $m0 = $Tz;
        qA:
        if (!(!empty($Me) && !empty($z5))) {
            goto fL;
        }
        $KW = AESEncryption::decrypt_data($Me, $z5);
        $Me = $KW;
        fL:
    } catch (Exception $GC) {
        echo sprintf("\101\x6e\x20\145\162\162\157\x72\x20\x6f\143\x63\x75\x72\162\x65\x64\40\167\x68\x69\x6c\145\40\x70\162\x6f\143\145\163\163\151\156\147\40\x74\150\145\40\x53\x41\x4d\x4c\40\122\x65\163\160\x6f\156\163\145\x2e");
        exit;
    }
    $lG = array($Me);
    mo_saml_login_user($O2, $o2, $O6, $m0, $lG, $dE, $WA, $bE, $aJ);
    az:
    goto GK;
    nQ:
    update_site_option("\x6d\157\137\x73\x61\x6d\x6c\x5f\162\x65\x64\x69\162\145\x63\x74\x5f\145\162\162\x6f\162\x5f\x63\157\144\x65", $_POST["\105\122\122\117\122\x5f\122\105\101\123\x4f\x4e"]);
    update_site_option("\155\157\x5f\x73\x61\155\x6c\x5f\x72\145\x64\151\162\145\143\164\137\145\x72\162\157\162\x5f\x72\145\141\163\x6f\x6e", $_POST["\105\x52\x52\x4f\x52\x5f\x4d\x45\x53\x53\101\x47\x45"]);
    GK:
    pr:
    nE:
}
function mo_saml_relaystate_url($QY)
{
    $YK = parse_url($QY, PHP_URL_SCHEME);
    $QY = str_replace($YK . "\72\x2f\57", '', $QY);
    return $QY;
}
function mo_saml_hash_relaystate($QY)
{
    $YK = parse_url($QY, PHP_URL_SCHEME);
    $QY = str_replace($YK . "\x3a\x2f\x2f", '', $QY);
    $QY = base64_encode($QY);
    $n8 = cdjsurkhh($QY);
    $QY = $QY . "\56" . $n8;
    return $QY;
}
function mo_saml_get_relaystate($QY)
{
    if (!filter_var($QY, FILTER_VALIDATE_URL)) {
        goto bW;
    }
    return $QY;
    bW:
    $vC = strpos($QY, "\x2e");
    if ($vC) {
        goto JS;
    }
    wp_die("\101\x6e\x20\145\162\162\157\162\40\157\x63\x63\x75\162\145\144\x2e\x20\120\x6c\x65\x61\163\145\x20\x63\x6f\156\164\x61\143\164\40\x79\x6f\x75\x72\40\x61\x64\155\151\156\151\163\164\x72\141\x74\157\x72\56", "\105\x72\162\x6f\x72\40\x3a\40\116\x6f\x74\40\x61\x20\164\162\165\x73\x74\x65\x64\40\x73\157\x75\162\143\x65\40\157\x66\40\164\x68\145\40\x53\x41\x4d\x4c\40\162\145\163\160\x6f\156\163\145");
    exit;
    JS:
    $sB = substr($QY, 0, $vC);
    $KY = substr($QY, $vC + 1);
    $Vn = cdjsurkhh($sB);
    if (!($KY !== $Vn)) {
        goto bR;
    }
    wp_die("\101\156\40\145\162\x72\157\162\40\157\x63\x63\x75\162\x65\144\x2e\40\x50\154\x65\x61\163\145\40\143\157\156\x74\x61\x63\x74\x20\171\x6f\165\162\40\141\144\155\x69\x6e\x69\163\x74\x72\x61\164\x6f\x72\x2e", "\105\x72\x72\157\x72\x20\72\40\116\x6f\x74\x20\x61\x20\164\x72\165\163\164\145\144\40\x73\157\x75\x72\x63\x65\40\x6f\146\x20\x74\150\145\x20\123\x41\115\x4c\40\x72\x65\163\x70\x6f\x6e\x73\145");
    exit;
    bR:
    $sB = base64_decode($sB);
    return $sB;
}
function cdjsurkhh($mo)
{
    $n8 = hash("\x73\150\x61\x35\61\62", $mo);
    $cy = substr($n8, 7, 14);
    return $cy;
}
function mo_saml_parse_url($QY)
{
    if (!($QY != "\164\145\163\164\x56\141\154\151\144\141\164\145" && $QY != "\x74\x65\x73\164\116\x65\x77\x43\145\162\x74\x69\146\151\x63\141\164\145")) {
        goto Ak;
    }
    $Dn = get_site_option("\x6d\157\137\x73\141\155\154\x5f\x73\160\137\x62\x61\x73\145\x5f\x75\x72\x6c");
    if (!empty($Dn)) {
        goto gT;
    }
    $Dn = get_network_site_url();
    gT:
    $YK = parse_url($Dn, PHP_URL_SCHEME);
    if (filter_var($QY, FILTER_VALIDATE_URL)) {
        goto yJ;
    }
    $QY = $YK . "\x3a\x2f\x2f" . $QY;
    yJ:
    Ak:
    return $QY;
}
function mo_saml_is_subsite($QY)
{
    $GM = parse_url($QY, PHP_URL_HOST);
    $T_ = parse_url($QY, PHP_URL_PATH);
    if (is_subdomain_install()) {
        goto zX;
    }
    $UQ = strpos($T_, "\57", 1) != false ? strpos($T_, "\57", 1) : strlen($T_) - 1;
    $T_ = substr($T_, 0, $UQ + 1);
    $blog_id = get_blog_id_from_url($GM, $T_);
    goto rE;
    zX:
    $blog_id = get_blog_id_from_url($GM);
    rE:
    if ($blog_id !== 0) {
        goto G_;
    }
    return false;
    goto El;
    G_:
    return true;
    El:
}
function mo_saml_show_SAML_log($c6, $E8)
{
    header("\103\x6f\x6e\x74\145\x6e\x74\x2d\124\x79\160\x65\72\40\164\145\170\164\x2f\x68\164\x6d\x6c");
    $YP = new DOMDocument();
    $YP->preserveWhiteSpace = false;
    $YP->formatOutput = true;
    $YP->loadXML($c6);
    if ($E8 == "\x64\151\163\x70\x6c\141\x79\x53\101\115\114\x52\x65\161\165\x65\x73\x74") {
        goto Ky;
    }
    $gb = "\123\x41\115\114\x20\122\145\x73\160\x6f\x6e\163\x65";
    goto zo;
    Ky:
    $gb = "\123\x41\115\114\40\x52\145\x71\165\x65\x73\x74";
    zo:
    $bK = $YP->saveXML();
    $J7 = htmlentities($bK);
    $J7 = rtrim($J7);
    $aa = simplexml_load_string($bK);
    $cU = json_encode($aa);
    $tO = json_decode($cU);
    $x2 = plugins_url("\x69\x6e\x63\154\165\144\145\163\x2f\x63\163\x73\57\x73\x74\171\x6c\145\x5f\163\x65\x74\164\151\156\x67\163\56\143\163\163\77\x76\x65\162\x3d\x34\56\x38\x2e\64\60", __FILE__);
    echo "\x3c\x6c\x69\156\153\x20\162\x65\154\75\47\x73\164\171\154\x65\163\150\x65\145\x74\x27\40\151\x64\75\47\155\157\137\x73\x61\155\x6c\x5f\x61\x64\x6d\151\x6e\x5f\x73\x65\164\164\x69\156\147\x73\x5f\163\164\x79\x6c\x65\x2d\143\163\163\47\40\40\x68\x72\x65\146\75\47" . $x2 . "\47\40\x74\x79\x70\145\75\47\164\145\x78\x74\57\143\x73\163\x27\x20\x6d\145\144\151\141\75\x27\141\x6c\154\47\x20\x2f\76\15\12\15\xa\74\144\x69\x76\x20\143\x6c\x61\x73\163\75\42\x6d\x6f\55\144\151\163\x70\x6c\x61\171\55\154\x6f\147\163\42\x20\x3e\74\160\40\x74\x79\x70\x65\75\42\x74\x65\170\164\42\x20\40\40\151\x64\x3d\x22\123\101\x4d\114\137\164\171\x70\145\x22\x3e" . $gb . "\74\x2f\x70\x3e\x3c\57\144\x69\x76\x3e\xd\12\xd\xa\74\144\151\x76\x20\x74\171\x70\x65\75\42\164\x65\x78\164\x22\40\x69\144\x3d\x22\123\101\x4d\x4c\x5f\144\x69\x73\160\x6c\141\171\42\x20\x63\x6c\141\x73\x73\75\x22\155\x6f\x2d\x64\151\163\x70\x6c\141\171\55\142\154\x6f\143\153\x22\76\x3c\x70\162\x65\40\143\154\141\x73\163\75\47\142\162\165\163\x68\x3a\x20\x78\155\154\73\x27\x3e" . $J7 . "\74\x2f\160\x72\145\76\x3c\57\x64\x69\166\76\xd\xa\x3c\x62\x72\x3e\15\12\x3c\144\151\x76\x9\x20\x73\164\x79\154\x65\75\x22\155\141\162\x67\151\156\72\63\x25\x3b\144\x69\163\x70\x6c\141\171\72\x62\x6c\157\143\x6b\73\164\145\170\164\x2d\141\154\x69\x67\156\72\143\x65\x6e\x74\145\162\x3b\42\76\xd\xa\15\xa\x3c\x64\x69\x76\x20\163\x74\171\x6c\145\75\42\x6d\141\x72\x67\x69\156\x3a\63\45\73\144\x69\163\160\154\x61\171\72\x62\x6c\x6f\143\x6b\73\164\x65\x78\164\x2d\x61\x6c\151\x67\156\72\x63\x65\x6e\x74\x65\162\73\x22\40\76\xd\xa\15\12\74\x2f\144\151\166\76\xd\12\74\142\165\x74\164\157\x6e\x20\x69\x64\x3d\x22\x63\x6f\160\x79\x22\40\x6f\x6e\x63\x6c\x69\x63\153\x3d\x22\143\x6f\x70\171\104\x69\166\124\x6f\103\154\151\x70\x62\x6f\x61\x72\144\50\x29\42\x20\x20\x73\164\171\x6c\x65\75\x22\x70\141\x64\x64\151\x6e\147\72\61\45\x3b\167\151\144\x74\x68\72\61\x30\60\160\170\x3b\142\141\x63\153\x67\162\x6f\165\x6e\x64\x3a\x20\x23\60\x30\x39\61\103\104\40\x6e\157\156\145\x20\162\x65\160\x65\x61\x74\40\163\143\162\157\154\154\x20\x30\45\40\60\x25\x3b\143\165\162\x73\157\162\x3a\40\160\157\x69\x6e\164\145\162\73\x66\157\x6e\x74\x2d\x73\x69\172\145\x3a\61\65\160\x78\x3b\x62\157\x72\x64\x65\162\55\167\151\144\x74\x68\x3a\x20\61\x70\170\73\142\x6f\x72\x64\145\162\x2d\x73\x74\171\x6c\x65\72\40\x73\x6f\x6c\x69\x64\x3b\x62\x6f\162\144\145\162\x2d\162\x61\144\151\165\x73\x3a\40\63\x70\x78\x3b\x77\150\151\x74\145\55\x73\x70\x61\143\x65\x3a\x20\156\x6f\167\162\141\x70\x3b\x62\x6f\170\x2d\x73\151\172\151\156\147\72\x20\142\157\x72\x64\x65\162\55\142\x6f\x78\73\142\157\x72\x64\x65\x72\55\143\157\x6c\157\x72\72\40\43\x30\60\67\x33\x41\x41\x3b\x62\x6f\170\55\163\x68\141\x64\157\167\72\x20\x30\160\x78\40\x31\160\x78\40\x30\x70\170\x20\162\147\142\141\50\61\x32\x30\x2c\40\62\x30\x30\54\40\x32\x33\60\x2c\40\60\56\66\51\40\151\x6e\163\x65\x74\73\143\x6f\x6c\x6f\x72\72\40\x23\x46\106\x46\73\x22\40\76\x43\x6f\x70\171\74\x2f\x62\165\x74\x74\157\156\x3e\xd\12\x26\x6e\142\163\160\73\15\xa\74\151\x6e\x70\x75\x74\40\x69\x64\75\42\x64\167\156\55\142\164\156\x22\x20\x73\164\x79\154\x65\x3d\x22\160\x61\144\x64\151\x6e\x67\72\61\45\73\167\151\144\x74\x68\72\x31\60\60\160\170\73\142\x61\143\x6b\x67\x72\157\165\x6e\144\x3a\x20\x23\60\x30\x39\61\103\x44\x20\x6e\x6f\x6e\145\40\x72\145\x70\145\141\164\x20\163\143\162\157\154\154\40\60\x25\40\x30\45\x3b\143\x75\x72\x73\x6f\x72\72\x20\160\x6f\151\156\x74\x65\162\x3b\x66\157\x6e\x74\x2d\x73\151\172\145\x3a\61\x35\x70\x78\73\x62\x6f\x72\144\145\x72\x2d\167\x69\144\164\x68\x3a\40\61\x70\x78\73\x62\157\x72\x64\145\x72\x2d\163\x74\x79\154\145\x3a\40\x73\x6f\x6c\151\x64\x3b\x62\157\x72\144\145\x72\x2d\x72\141\x64\151\165\x73\x3a\x20\x33\x70\170\x3b\167\150\x69\164\145\x2d\x73\x70\x61\143\145\72\40\x6e\x6f\167\162\x61\x70\x3b\x62\x6f\x78\x2d\x73\151\172\151\156\x67\72\x20\x62\x6f\162\144\x65\162\55\x62\x6f\x78\73\142\x6f\162\144\x65\x72\55\x63\x6f\x6c\157\162\x3a\40\x23\x30\x30\67\x33\x41\101\73\142\157\x78\x2d\x73\x68\141\144\x6f\x77\72\x20\60\x70\170\40\x31\x70\170\40\60\160\170\x20\162\147\x62\141\x28\x31\62\x30\54\40\62\x30\x30\54\40\62\63\x30\54\x20\x30\x2e\66\x29\40\151\x6e\x73\x65\x74\73\143\x6f\154\157\x72\72\40\43\106\x46\x46\73\42\164\x79\x70\x65\75\42\142\165\164\164\x6f\x6e\x22\40\166\x61\154\165\x65\x3d\x22\104\157\x77\x6e\x6c\x6f\141\x64\42\x20\15\12\42\x3e\15\12\x3c\x2f\x64\x69\x76\x3e\15\12\x3c\57\x64\x69\166\x3e\xd\12\xd\xa\15\xa";
    ob_end_flush();
    echo "\xd\12\74\163\x63\x72\x69\160\164\76\15\12\xd\xa\x66\165\156\x63\164\x69\157\156\40\143\x6f\160\x79\x44\151\166\x54\157\x43\154\x69\x70\142\x6f\141\x72\x64\50\51\x20\x7b\xd\xa\166\x61\x72\40\141\x75\170\x20\x3d\40\144\157\x63\165\x6d\x65\x6e\x74\x2e\143\162\145\141\x74\145\x45\154\x65\155\145\x6e\164\50\x22\x69\x6e\x70\x75\x74\x22\51\x3b\15\xa\141\165\x78\56\x73\x65\x74\101\x74\164\x72\151\x62\165\x74\x65\50\x22\166\x61\x6c\165\x65\x22\54\40\144\x6f\143\165\155\x65\156\164\56\147\145\x74\105\x6c\145\x6d\x65\156\164\x42\x79\111\x64\50\x22\123\x41\x4d\114\137\144\x69\163\x70\x6c\141\x79\42\51\x2e\x74\145\x78\164\103\x6f\156\x74\145\156\x74\x29\x3b\15\12\144\157\x63\x75\x6d\x65\156\x74\x2e\142\157\144\171\x2e\x61\x70\x70\x65\x6e\144\103\150\151\x6c\144\50\x61\165\170\x29\x3b\15\xa\141\x75\x78\x2e\163\x65\154\145\x63\x74\x28\x29\73\xd\12\x64\157\x63\165\155\145\156\x74\56\x65\170\x65\143\x43\x6f\x6d\x6d\141\x6e\144\x28\42\143\157\160\x79\x22\x29\x3b\xd\xa\144\x6f\143\165\x6d\145\x6e\x74\56\x62\157\x64\x79\56\x72\x65\155\157\x76\145\103\150\x69\154\144\x28\x61\165\170\x29\73\xd\12\x64\x6f\x63\165\x6d\x65\156\x74\x2e\x67\x65\x74\105\x6c\x65\x6d\145\156\x74\x42\171\x49\144\x28\x27\x63\x6f\x70\x79\47\x29\56\x74\145\x78\164\103\157\156\x74\x65\156\164\x20\75\40\42\103\157\160\x69\x65\144\42\x3b\15\12\144\x6f\143\x75\x6d\x65\156\164\x2e\147\x65\164\105\x6c\145\155\x65\x6e\x74\102\x79\x49\x64\x28\x27\143\x6f\x70\171\x27\51\x2e\163\164\x79\x6c\x65\56\x62\141\143\x6b\147\x72\x6f\x75\x6e\x64\x20\x3d\x20\x22\147\x72\x65\x79\x22\x3b\xd\xa\167\x69\156\x64\x6f\x77\x2e\x67\145\x74\123\x65\154\x65\143\164\x69\x6f\x6e\50\51\x2e\163\x65\x6c\x65\x63\164\101\154\x6c\103\x68\x69\154\x64\x72\x65\x6e\50\40\x64\x6f\x63\165\x6d\145\156\x74\56\x67\145\164\x45\x6c\145\x6d\145\x6e\x74\102\171\x49\144\50\40\x22\x53\101\x4d\x4c\x5f\x64\x69\x73\160\x6c\x61\171\x22\x20\x29\40\51\x3b\xd\12\15\12\x7d\xd\xa\xd\xa\x66\165\156\143\x74\x69\x6f\x6e\40\x64\157\x77\156\154\x6f\x61\x64\50\x66\x69\x6c\145\x6e\x61\155\x65\x2c\x20\x74\145\170\164\51\40\x7b\xd\xa\166\x61\x72\40\145\154\x65\155\145\x6e\164\40\x3d\x20\x64\x6f\143\x75\155\x65\x6e\x74\56\x63\162\x65\141\164\145\105\x6c\145\x6d\x65\x6e\x74\x28\47\x61\47\x29\x3b\xd\12\x65\154\x65\155\145\156\164\56\163\x65\x74\x41\x74\164\x72\151\x62\x75\164\145\50\47\150\x72\145\x66\47\54\40\47\x64\141\x74\x61\72\x41\x70\160\x6c\151\x63\x61\164\x69\x6f\156\57\157\143\x74\145\164\x2d\163\x74\x72\145\141\155\73\143\x68\141\162\163\145\164\75\x75\x74\146\x2d\x38\54\47\40\x2b\40\145\x6e\x63\157\144\145\125\x52\x49\x43\157\x6d\x70\x6f\x6e\x65\x6e\164\x28\x74\x65\x78\164\x29\51\73\xd\12\x65\154\x65\155\x65\x6e\x74\56\x73\x65\x74\101\x74\x74\162\151\142\x75\x74\145\50\x27\144\x6f\x77\156\x6c\x6f\x61\x64\x27\x2c\40\146\x69\154\145\156\x61\155\145\x29\73\15\xa\15\xa\145\x6c\x65\x6d\x65\x6e\x74\x2e\163\164\x79\154\145\x2e\x64\151\163\160\x6c\x61\171\x20\x3d\40\47\x6e\157\x6e\x65\x27\x3b\xd\xa\x64\157\143\x75\x6d\145\x6e\164\56\142\x6f\x64\171\x2e\141\x70\160\145\x6e\144\x43\x68\x69\x6c\x64\50\x65\154\145\155\145\156\x74\51\x3b\xd\xa\15\xa\145\x6c\x65\155\x65\x6e\164\56\x63\x6c\x69\x63\153\x28\x29\73\xd\12\15\12\x64\157\x63\x75\x6d\x65\x6e\x74\x2e\x62\x6f\x64\x79\x2e\x72\x65\x6d\157\x76\145\x43\x68\151\154\x64\x28\145\x6c\145\155\x65\x6e\x74\51\73\15\xa\175\xd\12\15\12\x64\157\x63\x75\155\145\x6e\x74\56\x67\145\164\x45\154\x65\155\145\156\164\x42\171\x49\x64\50\42\144\167\156\55\x62\164\156\42\x29\56\x61\x64\x64\105\166\x65\x6e\164\x4c\x69\x73\164\x65\x6e\145\x72\50\x22\x63\154\151\143\x6b\42\54\40\146\x75\x6e\143\164\x69\x6f\x6e\40\50\x29\x20\173\15\xa\15\12\166\141\162\x20\x66\x69\154\145\156\141\x6d\x65\40\75\40\x64\157\143\165\155\x65\156\164\x2e\x67\145\164\105\154\x65\155\145\x6e\164\x42\x79\x49\x64\x28\x22\x53\x41\x4d\114\x5f\164\171\x70\145\42\x29\56\164\x65\x78\x74\103\x6f\156\x74\145\156\164\x2b\x22\x2e\x78\x6d\x6c\42\73\15\xa\166\x61\x72\40\156\x6f\x64\x65\x20\75\40\x64\157\143\x75\155\x65\156\164\56\147\x65\x74\x45\154\145\x6d\x65\156\164\102\171\111\144\50\42\123\x41\x4d\x4c\x5f\144\151\x73\160\x6c\x61\171\42\51\x3b\15\xa\150\x74\155\154\x43\157\x6e\164\145\156\x74\x20\x3d\x20\156\157\144\x65\x2e\x69\x6e\x6e\145\x72\x48\124\x4d\x4c\73\xd\xa\x74\145\170\x74\x20\x3d\40\x6e\157\144\x65\x2e\164\145\x78\x74\103\157\x6e\164\x65\x6e\164\73\15\xa\x63\157\156\163\157\x6c\145\56\x6c\x6f\x67\50\x74\145\170\x74\51\x3b\15\12\144\157\x77\x6e\x6c\x6f\x61\x64\50\x66\x69\x6c\145\x6e\x61\x6d\145\54\x20\x74\145\170\164\x29\x3b\xd\12\175\x2c\40\x66\141\x6c\163\145\51\x3b\15\12\15\12\15\12\15\12\xd\xa\xd\xa\74\57\x73\x63\162\151\160\x74\x3e\15\12";
    exit;
}
function mo_saml_checkMapping($jc, $QY, $UP)
{
    try {
        $Wz = get_site_option("\x73\x61\x6d\154\x5f\141\155\137\145\155\x61\x69\154");
        $tx = get_site_option("\163\141\x6d\154\137\141\x6d\x5f\x75\x73\x65\162\156\x61\x6d\x65");
        $o2 = get_site_option("\163\141\155\x6c\x5f\141\x6d\137\x66\151\162\163\x74\137\156\141\155\x65");
        $O6 = get_site_option("\163\141\155\154\x5f\x61\155\137\x6c\141\163\x74\x5f\156\141\x6d\145");
        $Me = get_site_option("\x73\x61\x6d\154\137\x61\155\x5f\147\162\157\x75\160\137\156\x61\155\145");
        $Wo = array();
        $Wo = maybe_unserialize(get_site_option("\163\141\x6d\154\137\141\x6d\x5f\x72\157\154\145\x5f\x6d\x61\160\160\151\156\147"));
        $aJ = get_site_option("\163\141\x6d\x6c\137\x61\155\137\141\x63\x63\157\165\156\164\137\x6d\x61\x74\143\x68\145\162");
        $O2 = '';
        $m0 = '';
        if (empty($jc)) {
            goto ki;
        }
        if (!empty($o2) && array_key_exists($o2, $jc)) {
            goto Jp;
        }
        $o2 = '';
        goto IR;
        Jp:
        $o2 = $jc[$o2][0];
        IR:
        if (!empty($O6) && array_key_exists($O6, $jc)) {
            goto MW;
        }
        $O6 = '';
        goto JM;
        MW:
        $O6 = $jc[$O6][0];
        JM:
        if (!empty($tx) && array_key_exists($tx, $jc)) {
            goto xn;
        }
        $m0 = $jc["\116\141\155\145\x49\104"][0];
        goto pg;
        xn:
        $m0 = $jc[$tx][0];
        pg:
        if (!empty($Wz) && array_key_exists($Wz, $jc)) {
            goto CD;
        }
        $O2 = $jc["\x4e\x61\155\x65\111\x44"][0];
        goto dD;
        CD:
        $O2 = $jc[$Wz][0];
        dD:
        if (!empty($Me) && array_key_exists($Me, $jc)) {
            goto EB;
        }
        $Me = array();
        goto K6;
        EB:
        $Me = $jc[$Me];
        K6:
        if (!empty($aJ)) {
            goto gv;
        }
        $aJ = "\x65\x6d\141\x69\x6c";
        gv:
        ki:
        if ($QY == "\164\x65\163\x74\x56\141\154\151\x64\141\164\x65") {
            goto Vc;
        }
        if ($QY == "\164\x65\163\164\x4e\x65\x77\x43\145\x72\x74\151\x66\151\x63\141\x74\x65") {
            goto f8;
        }
        mo_saml_login_user($O2, $o2, $O6, $m0, $Me, $Wo, $QY, $aJ, $UP, $jc["\116\x61\155\x65\111\x44"][0], $jc);
        goto Jx;
        Vc:
        update_site_option("\x6d\x6f\x5f\163\141\155\x6c\x5f\x74\145\163\164", "\x54\x65\163\164\x20\x53\165\143\143\145\x73\x73\x66\x75\154");
        mo_saml_show_test_result($o2, $O6, $O2, $Me, $jc, $QY);
        goto Jx;
        f8:
        update_site_option("\x6d\157\137\163\141\155\x6c\x5f\x74\x65\163\164\x5f\x6e\x65\x77\137\143\x65\162\x74", "\x54\x65\163\x74\40\x73\x75\x63\x63\x65\x73\163\146\165\154");
        mo_saml_show_test_result($o2, $O6, $O2, $Me, $jc, $QY);
        Jx:
    } catch (Exception $GC) {
        echo sprintf("\x41\x6e\x20\145\x72\x72\x6f\x72\x20\157\x63\143\165\162\x72\145\x64\x20\167\x68\151\x6c\145\40\x70\162\157\143\x65\x73\x73\151\156\x67\x20\x74\150\145\x20\123\x41\115\114\x20\122\x65\163\x70\157\156\163\x65\x2e");
        exit;
    }
}
function mo_saml_show_test_result($o2, $O6, $O2, $Me, $jc, $QY)
{
    echo "\74\x64\151\x76\x20\163\164\x79\x6c\x65\x3d\42\x66\x6f\156\164\55\146\x61\155\151\154\171\72\103\x61\154\x69\x62\162\x69\x3b\160\141\144\x64\151\156\x67\72\60\x20\63\x25\73\x22\76";
    if (!empty($O2)) {
        goto nX;
    }
    echo "\x3c\144\x69\x76\40\163\164\x79\154\145\x3d\42\x63\x6f\x6c\157\162\72\x20\43\x61\71\64\64\x34\x32\x3b\142\x61\143\x6b\x67\162\157\165\x6e\144\55\x63\157\154\x6f\x72\x3a\40\x23\146\x32\x64\145\x64\x65\73\160\x61\x64\x64\x69\156\x67\72\40\x31\65\x70\170\x3b\155\141\162\147\151\156\55\142\157\x74\164\x6f\155\72\40\x32\x30\160\170\x3b\164\x65\170\x74\x2d\141\x6c\x69\x67\156\x3a\x63\145\x6e\x74\145\162\73\x62\x6f\162\144\145\162\72\61\160\170\40\163\x6f\x6c\x69\x64\x20\x23\x45\x36\x42\x33\102\x32\73\x66\157\x6e\164\55\163\x69\x7a\145\72\61\70\160\164\x3b\42\76\124\105\123\x54\x20\106\x41\x49\x4c\x45\x44\x3c\x2f\144\151\x76\x3e\15\xa\40\x20\40\40\x20\40\x20\40\x3c\144\151\166\40\163\x74\171\x6c\145\x3d\42\x63\157\154\x6f\x72\72\x20\x23\x61\x39\64\x34\64\62\73\x66\157\156\164\55\163\151\172\145\72\x31\x34\x70\164\x3b\x20\155\x61\162\x67\151\x6e\x2d\x62\157\164\x74\157\x6d\72\x32\60\x70\170\73\42\x3e\x57\101\x52\x4e\x49\x4e\x47\72\40\123\x6f\155\x65\40\x41\x74\164\162\151\142\x75\164\145\x73\40\104\x69\x64\40\x4e\157\x74\40\x4d\x61\x74\143\150\56\74\57\144\x69\166\x3e\xd\12\40\40\x20\40\40\x20\x20\40\74\144\151\166\x20\x73\164\x79\x6c\x65\x3d\x22\x64\x69\163\160\154\x61\171\x3a\142\154\157\143\153\x3b\x74\x65\x78\164\x2d\141\154\151\x67\156\72\x63\145\156\164\x65\x72\x3b\x6d\141\x72\x67\151\x6e\x2d\142\157\164\164\x6f\x6d\x3a\64\x25\73\42\x3e\74\151\155\147\x20\163\x74\171\154\145\x3d\x22\167\151\x64\x74\x68\72\61\x35\45\73\42\163\162\x63\x3d\x22" . plugin_dir_url(__FILE__) . "\151\x6d\141\147\145\163\x2f\167\x72\157\156\147\x2e\160\156\x67\42\x3e\74\57\144\151\x76\76";
    goto zN;
    nX:
    update_site_option("\155\x6f\x5f\x73\x61\x6d\154\x5f\164\x65\163\x74\137\143\157\x6e\x66\x69\x67\x5f\x61\x74\164\162\x73", $jc);
    echo "\74\x64\x69\166\x20\163\164\171\154\145\x3d\x22\143\x6f\x6c\157\x72\x3a\x20\x23\63\x63\67\66\x33\x64\73\xd\12\x20\40\40\x20\x20\40\40\40\x62\x61\x63\x6b\147\162\157\165\x6e\144\55\143\x6f\154\x6f\x72\72\40\x23\144\x66\x66\60\x64\70\x3b\40\x70\x61\144\x64\151\156\x67\72\x32\x25\73\155\x61\x72\x67\x69\x6e\x2d\142\x6f\164\164\x6f\x6d\72\62\60\160\x78\73\164\145\x78\164\x2d\141\154\151\147\x6e\x3a\x63\145\x6e\x74\x65\162\x3b\x20\142\x6f\x72\x64\145\162\72\61\160\x78\40\163\x6f\x6c\x69\144\x20\43\101\x45\x44\102\x39\101\x3b\x20\x66\x6f\156\164\x2d\x73\x69\x7a\x65\x3a\61\x38\160\x74\x3b\42\76\124\105\123\124\x20\x53\x55\x43\103\105\x53\x53\106\125\x4c\x3c\57\x64\151\x76\x3e\15\xa\40\x20\x20\x20\x20\40\x20\40\74\144\x69\166\40\163\164\x79\154\145\75\x22\144\151\163\x70\x6c\x61\171\x3a\142\x6c\157\143\153\x3b\164\x65\170\x74\55\141\x6c\151\x67\x6e\x3a\143\145\x6e\164\x65\x72\73\155\141\162\147\151\156\x2d\142\157\x74\x74\x6f\155\x3a\64\45\x3b\x22\x3e\74\x69\x6d\x67\40\x73\x74\x79\x6c\145\75\x22\167\151\144\x74\x68\72\x31\65\x25\73\x22\x73\162\143\x3d\x22" . plugin_dir_url(__FILE__) . "\151\x6d\141\x67\145\x73\57\x67\162\145\145\156\137\143\x68\145\x63\x6b\56\x70\x6e\x67\x22\x3e\74\57\144\151\x76\x3e";
    zN:
    $l_ = $QY == "\x74\x65\163\164\116\x65\167\x43\145\x72\164\151\x66\x69\x63\141\x74\x65" ? "\x64\x69\x73\160\x6c\141\x79\x3a\156\157\x6e\145" : '';
    $yZ = get_site_option("\163\141\x6d\x6c\x5f\x61\x6d\137\x61\143\x63\157\x75\x6e\x74\x5f\155\x61\x74\x63\x68\145\162") ? get_site_option("\163\141\x6d\154\x5f\x61\155\x5f\141\143\x63\157\165\x6e\164\137\155\x61\x74\143\x68\x65\162") : "\145\155\141\151\x6c";
    if (!($yZ == "\x65\155\x61\151\x6c" && !filter_var($jc["\116\x61\155\x65\x49\x44"][0], FILTER_VALIDATE_EMAIL))) {
        goto oC;
    }
    echo "\74\160\x3e\x3c\x66\x6f\156\x74\40\x63\157\154\157\162\x3d\x22\x23\106\x46\x30\x30\60\60\x22\x20\x73\x74\171\154\145\75\42\146\x6f\x6e\164\55\x73\151\172\145\x3a\x31\64\160\164\42\x3e\50\x57\x61\x72\x6e\151\x6e\x67\72\x20\x54\150\145\40\x4e\x61\155\x65\111\x44\x20\166\141\154\x75\x65\40\151\163\40\x6e\x6f\164\x20\141\x20\x76\141\154\x69\144\x20\105\x6d\x61\151\x6c\40\111\x44\51\x3c\57\146\157\x6e\164\76\x3c\57\160\76";
    oC:
    echo "\x3c\163\x70\141\156\x20\163\164\171\154\145\x3d\42\146\157\x6e\x74\55\163\x69\x7a\145\x3a\61\x34\160\x74\x3b\42\x3e\x3c\142\76\110\x65\154\x6c\x6f\x3c\57\142\76\54\x20" . $O2 . "\74\57\163\160\x61\156\x3e\74\142\162\57\x3e\x3c\x70\x20\x73\164\x79\154\145\75\x22\146\157\156\164\x2d\167\145\151\147\150\x74\72\x62\157\x6c\x64\73\x66\157\x6e\x74\x2d\x73\x69\x7a\145\x3a\x31\x34\x70\x74\x3b\x6d\x61\162\147\x69\x6e\x2d\x6c\x65\x66\164\72\61\45\x3b\42\76\x41\124\124\x52\111\102\125\x54\105\123\40\122\105\x43\x45\x49\126\105\104\x3a\74\57\160\76\xd\12\x20\x20\40\x20\74\164\x61\x62\154\145\x20\163\164\x79\154\x65\x3d\42\142\157\x72\x64\x65\x72\x2d\143\157\x6c\154\x61\x70\163\x65\x3a\143\x6f\x6c\154\x61\x70\x73\x65\x3b\x62\157\162\x64\145\x72\x2d\163\x70\141\143\151\x6e\x67\x3a\60\73\x20\144\151\x73\x70\x6c\x61\171\72\x74\141\x62\x6c\145\73\167\x69\144\164\150\x3a\61\60\x30\x25\73\40\146\x6f\156\164\55\163\x69\x7a\145\x3a\x31\x34\160\164\x3b\142\x61\x63\x6b\x67\x72\x6f\x75\156\x64\55\143\x6f\x6c\x6f\x72\x3a\43\105\104\x45\x44\105\104\73\x22\x3e\15\12\40\x20\40\x20\x20\x20\40\x20\x3c\164\x72\40\x73\x74\x79\154\145\x3d\42\164\x65\x78\164\x2d\141\x6c\151\147\x6e\x3a\x63\x65\x6e\x74\x65\x72\x3b\42\x3e\74\164\144\x20\x73\x74\171\154\x65\x3d\x22\x66\x6f\x6e\x74\55\167\x65\151\x67\150\164\72\142\x6f\x6c\x64\73\x62\x6f\x72\144\x65\162\x3a\62\x70\170\40\163\x6f\154\151\144\x20\43\71\64\71\x30\71\x30\x3b\160\141\x64\144\151\x6e\x67\x3a\x32\45\73\x22\x3e\x41\124\124\122\x49\x42\125\x54\x45\x20\116\101\115\105\x3c\x2f\164\x64\x3e\74\x74\x64\40\163\x74\x79\154\x65\x3d\42\x66\157\x6e\x74\55\x77\145\151\x67\x68\164\x3a\x62\157\154\144\x3b\160\141\144\x64\151\156\147\x3a\x32\x25\x3b\x62\x6f\162\144\x65\x72\72\x32\160\x78\40\163\157\x6c\x69\x64\40\x23\x39\64\71\x30\71\x30\73\x20\167\x6f\x72\x64\x2d\x77\162\141\x70\72\x62\162\145\x61\x6b\x2d\167\x6f\162\x64\73\42\76\x41\x54\124\122\x49\x42\125\x54\105\40\x56\101\x4c\125\105\74\x2f\x74\x64\76\x3c\57\x74\162\76";
    if (!empty($jc)) {
        goto KV;
    }
    echo "\116\157\x20\101\x74\x74\x72\x69\142\165\x74\x65\x73\40\122\145\x63\145\x69\x76\145\x64\x2e";
    goto Pz;
    KV:
    foreach ($jc as $z5 => $d1) {
        echo "\x3c\164\162\x3e\74\164\144\40\x73\x74\171\154\145\x3d\47\x66\x6f\x6e\x74\55\x77\x65\x69\147\150\x74\x3a\142\x6f\154\x64\73\142\x6f\162\144\145\162\72\62\x70\x78\40\163\x6f\x6c\151\x64\x20\x23\71\64\x39\60\71\60\x3b\160\141\144\x64\151\x6e\x67\x3a\x32\45\73\x27\x3e" . $z5 . "\x3c\57\x74\144\x3e\74\164\x64\40\163\x74\171\154\x65\x3d\x27\160\141\x64\144\x69\x6e\x67\72\62\45\x3b\x62\157\x72\144\145\162\x3a\62\160\x78\40\x73\157\154\151\144\40\x23\71\64\x39\x30\71\x30\x3b\x20\167\x6f\162\x64\x2d\x77\162\x61\160\x3a\x62\x72\x65\141\153\55\x77\157\162\x64\73\x27\x3e" . implode("\74\150\162\57\x3e", $d1) . "\x3c\x2f\x74\144\76\74\x2f\164\162\76";
        oe:
    }
    GL:
    Pz:
    echo "\74\57\164\x61\x62\x6c\145\76\x3c\x2f\x64\x69\166\76";
    echo "\74\x64\151\166\40\x73\164\171\x6c\x65\x3d\42\155\x61\x72\147\x69\x6e\72\x33\x25\73\x64\151\x73\x70\154\141\x79\72\142\x6c\157\x63\153\73\x74\145\x78\x74\55\x61\x6c\151\x67\x6e\x3a\143\x65\156\x74\x65\162\73\x22\x3e\xd\xa\x20\40\40\x20\40\40\40\40\40\40\40\40\74\151\x6e\x70\x75\x74\40\x73\x74\x79\x6c\145\x3d\x22\160\141\x64\144\151\x6e\x67\x3a\x31\x25\73\167\x69\144\x74\150\72\x32\x35\60\160\170\x3b\x62\141\x63\x6b\x67\162\157\165\156\144\72\x20\x23\x30\60\71\x31\x43\104\40\156\x6f\x6e\x65\x20\x72\145\x70\x65\141\164\x20\163\143\162\x6f\154\x6c\x20\x30\45\x20\60\45\73\15\xa\40\x20\x20\x20\x20\x20\40\40\x20\40\40\40\143\x75\x72\163\x6f\162\x3a\40\160\157\x69\156\164\145\162\x3b\146\x6f\x6e\x74\55\163\151\172\x65\72\61\65\x70\x78\x3b\142\x6f\x72\144\x65\162\x2d\167\x69\x64\164\150\x3a\x20\x31\x70\x78\x3b\142\x6f\x72\x64\x65\x72\55\163\x74\x79\x6c\x65\x3a\40\163\x6f\x6c\x69\144\x3b\142\x6f\162\144\x65\162\55\x72\x61\x64\x69\x75\163\x3a\40\63\x70\x78\x3b\x77\x68\151\x74\x65\x2d\x73\x70\x61\143\145\72\15\xa\40\x20\x20\x20\40\40\x20\40\40\x20\40\40\x6e\157\x77\162\x61\160\x3b\x62\157\170\55\x73\x69\172\x69\x6e\147\x3a\x20\x62\157\x72\x64\x65\x72\55\142\x6f\x78\x3b\x62\157\x72\x64\145\x72\x2d\x63\157\154\x6f\x72\72\x20\43\x30\60\x37\63\x41\x41\73\x62\157\170\x2d\163\x68\x61\x64\x6f\x77\72\x20\60\160\170\40\61\160\x78\x20\x30\160\170\x20\x72\x67\142\141\50\61\x32\60\54\x20\x32\x30\60\54\x20\x32\63\x30\54\40\x30\56\66\x29\x20\151\156\163\x65\164\x3b\143\x6f\154\157\x72\x3a\40\x23\x46\106\x46\x3b" . $l_ . "\x22\xd\12\x20\40\x20\40\40\40\x20\40\x20\40\x20\40\x20\x20\40\x20\164\171\x70\x65\x3d\x22\x62\x75\x74\x74\157\156\x22\x20\x76\141\154\x75\x65\x3d\42\x43\157\156\x66\x69\x67\x75\162\145\x20\101\164\164\x72\x69\x62\x75\x74\x65\x2f\122\x6f\x6c\145\40\x4d\141\160\x70\x69\x6e\147\x22\40\x6f\x6e\x43\x6c\x69\143\153\x3d\42\143\154\x6f\163\145\x5f\x61\156\144\x5f\x72\145\x64\151\x72\x65\x63\x74\50\x29\73\x22\x3e\x20\46\x6e\142\x73\160\x3b\x20\xd\12\x20\x20\40\40\40\40\x20\40\40\40\x20\x20\x20\x20\40\x20\xd\12\40\40\x20\x20\x20\x20\x20\x20\x20\40\40\40\74\151\156\160\165\164\40\x73\164\x79\154\145\75\x22\160\x61\x64\x64\x69\x6e\147\72\61\x25\x3b\167\x69\x64\164\150\x3a\61\60\60\x70\170\73\x62\x61\x63\x6b\x67\x72\x6f\x75\x6e\144\x3a\40\43\60\60\x39\61\x43\104\x20\156\157\156\x65\x20\162\x65\160\145\x61\164\x20\163\x63\162\x6f\x6c\x6c\x20\x30\x25\x20\x30\45\x3b\x63\165\x72\x73\x6f\162\72\x20\160\x6f\x69\x6e\164\x65\x72\73\x66\x6f\156\164\x2d\x73\x69\x7a\145\72\61\x35\x70\x78\73\x62\x6f\x72\x64\x65\162\x2d\167\151\144\164\x68\x3a\40\61\x70\170\73\142\x6f\x72\x64\145\162\x2d\163\164\x79\x6c\x65\x3a\40\x73\x6f\154\151\x64\x3b\142\157\162\x64\145\162\x2d\162\141\x64\151\x75\x73\72\x20\x33\160\x78\x3b\167\x68\151\164\x65\55\163\x70\x61\143\145\x3a\40\156\x6f\167\x72\141\x70\73\142\x6f\170\55\x73\x69\x7a\x69\x6e\147\72\40\x62\157\162\144\145\x72\55\142\157\170\x3b\142\x6f\x72\144\x65\162\x2d\143\157\x6c\157\162\x3a\x20\43\x30\x30\x37\x33\x41\101\x3b\142\157\170\55\163\150\141\144\x6f\167\x3a\40\60\160\x78\x20\x31\x70\x78\x20\x30\160\170\x20\x72\147\142\141\50\61\x32\x30\x2c\x20\62\x30\60\54\40\62\x33\60\54\40\60\x2e\66\51\x20\151\x6e\163\145\x74\x3b\x63\157\154\x6f\162\x3a\x20\43\106\x46\x46\x3b\x22\x74\x79\x70\x65\x3d\42\x62\165\x74\x74\x6f\x6e\x22\40\166\x61\154\165\x65\x3d\42\x44\x6f\x6e\x65\x22\40\x6f\156\103\154\x69\143\x6b\x3d\x22\x73\145\x6c\146\56\x63\154\x6f\163\x65\x28\x29\73\42\x3e\74\x2f\x64\151\x76\76\xd\12\x20\40\x20\x20\x20\x20\40\x20\40\x20\x20\x20\x20\x20\40\40\x20\x20\x20\x20\x20\40\x20\40\x20\40\x20\x20\x20\x20\40\40\74\x73\143\x72\x69\160\x74\x3e\xd\12\xd\xa\40\40\x20\40\40\x20\40\40\x20\x20\x20\x20\x66\x75\x6e\143\164\151\x6f\x6e\40\x63\x6c\x6f\163\145\137\x61\x6e\x64\137\162\145\x64\x69\x72\x65\x63\164\50\51\173\15\xa\40\40\x20\40\x20\40\x20\40\x20\40\x20\x20\40\40\40\x20\x77\x69\x6e\x64\x6f\x77\x2e\x6f\160\145\156\x65\x72\x2e\162\x65\x64\x69\162\x65\x63\164\137\x74\157\x5f\x61\x74\x74\x72\x69\x62\x75\164\145\x5f\155\x61\x70\160\x69\156\147\50\51\x3b\xd\xa\40\x20\40\40\40\x20\x20\40\40\x20\x20\40\40\40\x20\40\x73\145\x6c\x66\56\x63\x6c\157\x73\145\50\51\x3b\xd\xa\x20\x20\x20\x20\40\x20\x20\x20\40\x20\x20\40\x7d\15\xa\40\40\40\40\40\40\40\x20\x20\x20\x20\x20\xd\12\x20\40\x20\40\40\x20\x20\40\x20\x20\x20\x20\x66\165\x6e\143\164\x69\x6f\x6e\40\162\145\146\162\x65\x73\x68\120\x61\x72\x65\x6e\164\50\51\40\173\xd\xa\40\40\x20\40\x20\x20\x20\x20\x20\x20\40\40\x20\40\x20\x20\x77\x69\156\144\x6f\167\56\x6f\x70\x65\156\x65\162\x2e\154\x6f\x63\141\x74\x69\x6f\156\56\162\145\x6c\x6f\141\144\50\x29\x3b\15\12\x20\40\x20\x20\x20\x20\x20\40\40\x20\x20\x20\175\xd\12\40\40\40\x20\40\x20\40\40\x20\40\x20\40\74\57\x73\x63\162\x69\160\x74\76";
    exit;
}
function mo_saml_convert_to_windows_iconv($wn)
{
    $aO = get_site_option("\x6d\x6f\137\x73\141\155\154\x5f\145\x6e\x63\157\x64\x69\156\x67\x5f\x65\x6e\x61\142\x6c\x65\x64");
    if (!($aO !== "\143\150\x65\143\x6b\x65\x64")) {
        goto K8;
    }
    return $wn;
    K8:
    return iconv("\x55\124\x46\55\70", "\x43\120\x31\x32\65\62\x2f\x2f\111\x47\x4e\x4f\122\x45", $wn);
}
function mo_saml_login_user($O2, $o2, $O6, $m0, $Me, $Wo, $QY, $aJ, $UP = '', $Mo = '', $jc = null)
{
    do_action("\155\x6f\x5f\141\142\162\137\x66\151\154\x74\x65\x72\x5f\154\x6f\147\x69\156", $jc);
    $m0 = mo_saml_sanitize_username($m0);
    if (get_site_option("\155\157\x5f\163\x61\x6d\x6c\137\x64\x69\163\141\142\x6c\x65\137\x72\157\154\x65\x5f\x6d\x61\x70\x70\x69\156\147")) {
        goto M8;
    }
    check_if_user_allowed_to_login_due_to_role_restriction($Me);
    M8:
    $Dn = get_site_option("\x6d\157\x5f\163\x61\x6d\x6c\137\163\160\x5f\142\141\x73\145\x5f\165\x72\x6c");
    mo_saml_restrict_users_based_on_domain($O2);
    if (!empty($Wo)) {
        goto zS;
    }
    $Wo["\x44\105\106\x41\x55\114\124"]["\144\145\146\141\x75\x6c\x74\137\162\x6f\x6c\145"] = "\x73\x75\142\x73\143\x72\151\x62\145\162";
    $Wo["\x44\x45\106\x41\125\114\x54"]["\144\157\x6e\x74\x5f\x61\154\154\x6f\167\x5f\165\156\154\151\163\164\145\x64\137\165\x73\145\x72"] = '';
    $Wo["\x44\105\x46\x41\125\x4c\124"]["\x64\x6f\156\x74\x5f\x63\x72\145\x61\x74\145\137\x75\163\145\162"] = '';
    $Wo["\104\105\106\x41\x55\114\x54"]["\x6b\x65\145\160\x5f\x65\170\x69\x73\x74\151\x6e\147\x5f\x75\x73\x65\x72\163\137\162\157\x6c\145"] = '';
    $Wo["\104\105\106\x41\125\114\x54"]["\155\x6f\137\163\141\x6d\x6c\x5f\144\x6f\x6e\x74\x5f\x61\154\154\x6f\x77\x5f\x75\163\x65\x72\x5f\164\157\x6c\x6f\147\151\x6e\137\143\162\x65\141\164\145\137\167\151\164\150\137\x67\151\166\x65\x6e\x5f\147\162\157\165\160\x73"] = '';
    $Wo["\104\x45\x46\x41\125\x4c\x54"]["\155\157\x5f\163\x61\x6d\154\137\x72\145\163\x74\162\151\x63\164\x5f\165\163\145\162\163\137\x77\151\x74\150\x5f\147\162\x6f\x75\160\x73"] = '';
    zS:
    global $wpdb;
    $Mp = get_current_blog_id();
    $cN = "\165\x6e\143\x68\145\143\x6b\x65\144";
    if (!empty($Dn)) {
        goto zA;
    }
    $Dn = get_network_site_url();
    zA:
    if (email_exists($O2) || username_exists($m0)) {
        goto wA;
    }
    $tE = Utilities::get_active_sites();
    $OV = get_site_option("\155\x6f\137\x61\x70\x70\154\171\x5f\x72\157\x6c\x65\x5f\x6d\x61\x70\160\x69\x6e\x67\137\146\157\162\137\x73\151\x74\x65\x73");
    if (!get_site_option("\155\157\x5f\163\141\155\x6c\x5f\144\151\163\141\142\x6c\145\137\162\x6f\x6c\x65\x5f\155\141\x70\x70\x69\156\x67")) {
        goto xY;
    }
    $xB = wp_generate_password(12, false);
    $XP = wpmu_create_user($m0, $xB, $O2);
    goto Vz;
    xY:
    $XP = mo_saml_assign_roles_to_new_user($tE, $OV, $Wo, $Me, $m0, $O2);
    Vz:
    switch_to_blog($Mp);
    if (!empty($XP)) {
        goto N1;
    }
    if (!get_site_option("\x6d\x6f\x5f\x73\141\155\x6c\137\144\x69\x73\x61\142\x6c\x65\137\x72\x6f\154\145\137\155\141\x70\x70\x69\x6e\x67")) {
        goto vf;
    }
    wp_die("\x57\x65\40\143\157\x75\x6c\144\40\x6e\157\x74\40\x73\151\x67\x6e\x20\171\x6f\x75\x20\x69\x6e\x2e\x20\x50\154\x65\141\163\x65\40\143\157\x6e\164\x61\143\164\40\141\x64\x6d\151\156\151\x73\164\162\141\164\x6f\162", "\x4c\x6f\x67\151\156\x20\106\x61\151\154\x65\144\x21");
    goto pl;
    vf:
    $HH = get_site_option("\x6d\157\x5f\163\141\x6d\x6c\137\x61\x63\x63\x6f\165\156\164\137\x63\162\145\x61\164\151\x6f\x6e\137\144\151\163\141\142\154\145\144\137\x6d\x73\147");
    if (!empty($HH)) {
        goto xX;
    }
    $HH = "\127\145\x20\143\x6f\165\154\x64\40\156\x6f\164\40\x73\x69\x67\x6e\x20\171\157\x75\x20\151\156\x2e\x20\x50\x6c\x65\x61\163\145\40\x63\x6f\156\x74\x61\143\164\x20\x79\x6f\x75\162\x20\101\144\155\151\156\151\x73\164\162\x61\164\x6f\x72\x2e";
    xX:
    wp_die($HH, "\x45\x72\x72\x6f\162\x3a\x20\x4e\x6f\x74\x20\141\x20\x57\157\x72\144\x50\162\145\x73\163\x20\115\x65\x6d\x62\145\x72");
    pl:
    N1:
    $user = get_user_by("\151\144", $XP);
    mo_saml_map_basic_attributes($user, $o2, $O6, $jc);
    mo_saml_map_custom_attributes($XP, $jc);
    $EU = mo_saml_get_redirect_url($Dn, $QY);
    do_action("\155\151\156\x69\157\162\x61\156\147\145\x5f\x70\157\x73\x74\137\x61\165\x74\x68\145\x6e\164\x69\143\x61\x74\x65\137\x75\x73\145\162\137\x6c\157\147\151\156", $user, null, $EU, true);
    mo_saml_set_auth_cookie($user, $UP, $Mo, true);
    do_action("\155\x6f\137\x73\x61\155\x6c\x5f\141\164\x74\x72\151\x62\x75\x74\145\x73", $m0, $O2, $o2, $O6, $Me, null, true);
    goto g4;
    wA:
    if (email_exists($O2)) {
        goto fX;
    }
    $user = get_user_by("\x6c\157\x67\151\156", $m0);
    goto A1;
    fX:
    $user = get_user_by("\x65\x6d\141\151\x6c", $O2);
    A1:
    $XP = $user->ID;
    if (!(!empty($O2) and strcasecmp($O2, $user->user_email) != 0)) {
        goto Cq;
    }
    $XP = wp_update_user(array("\111\104" => $XP, "\x75\x73\145\x72\x5f\x65\x6d\141\x69\x6c" => $O2));
    Cq:
    mo_saml_map_basic_attributes($user, $o2, $O6, $jc);
    mo_saml_map_custom_attributes($XP, $jc);
    $tE = Utilities::get_active_sites();
    $OV = get_site_option("\x6d\x6f\137\141\160\160\x6c\x79\137\x72\157\x6c\145\137\155\x61\x70\160\x69\156\147\137\x66\x6f\162\x5f\x73\151\x74\145\x73");
    if (get_site_option("\155\x6f\x5f\x73\141\155\x6c\x5f\x64\x69\x73\141\142\154\x65\137\162\x6f\154\145\137\155\141\x70\160\x69\156\147")) {
        goto v2;
    }
    foreach ($tE as $blog_id) {
        switch_to_blog($blog_id);
        $user = get_user_by("\x69\x64", $XP);
        $Ss = '';
        if ($OV) {
            goto u_;
        }
        $Ss = $blog_id;
        goto tg;
        u_:
        $Ss = 0;
        tg:
        if (empty($Wo)) {
            goto LI;
        }
        if (!empty($Wo[$Ss])) {
            goto Jb;
        }
        if (!empty($Wo["\104\x45\x46\101\x55\114\x54"])) {
            goto J0;
        }
        $WA = "\x73\165\142\163\143\x72\x69\142\x65\x72";
        $dE = '';
        $cN = '';
        $GX = '';
        goto Bp;
        J0:
        $WA = isset($Wo["\x44\x45\x46\101\x55\x4c\x54"]["\144\x65\x66\x61\x75\x6c\164\137\162\x6f\154\x65"]) ? $Wo["\104\105\106\101\125\114\x54"]["\x64\145\x66\x61\165\154\164\137\162\157\154\x65"] : "\163\165\x62\163\143\x72\151\142\x65\162";
        $dE = isset($Wo["\104\x45\106\101\125\x4c\124"]["\144\x6f\156\164\x5f\x61\154\x6c\157\x77\x5f\165\x6e\x6c\151\x73\164\x65\x64\137\x75\x73\x65\x72"]) ? $Wo["\x44\x45\x46\101\125\114\124"]["\x64\x6f\156\164\137\x61\x6c\154\x6f\x77\x5f\x75\x6e\x6c\x69\163\164\145\144\x5f\165\x73\x65\x72"] : '';
        $cN = isset($Wo["\104\x45\106\101\x55\114\124"]["\144\157\x6e\164\137\143\x72\145\141\x74\145\x5f\x75\x73\145\x72"]) ? $Wo["\104\105\106\x41\x55\114\124"]["\144\157\156\x74\x5f\143\162\x65\x61\164\x65\137\165\x73\x65\162"] : '';
        $GX = isset($Wo["\104\x45\x46\101\x55\x4c\124"]["\x6b\145\145\160\x5f\145\170\x69\163\164\x69\156\147\x5f\165\163\145\x72\163\x5f\162\x6f\x6c\145"]) ? $Wo["\x44\x45\106\101\x55\x4c\124"]["\x6b\x65\x65\x70\137\145\x78\x69\x73\x74\151\156\147\x5f\165\x73\145\x72\x73\x5f\162\157\154\145"] : '';
        Bp:
        goto Xs;
        Jb:
        $WA = isset($Wo[$Ss]["\x64\x65\x66\141\165\154\x74\x5f\x72\x6f\x6c\x65"]) ? $Wo[$Ss]["\144\x65\x66\141\x75\154\164\x5f\162\x6f\x6c\145"] : '';
        $dE = isset($Wo[$Ss]["\x64\x6f\156\164\137\141\x6c\x6c\157\167\x5f\x75\156\x6c\x69\163\164\x65\x64\x5f\165\x73\x65\162"]) ? $Wo[$Ss]["\x64\157\156\x74\137\141\x6c\x6c\157\x77\137\165\x6e\x6c\151\x73\x74\145\x64\x5f\165\163\145\x72"] : '';
        $cN = isset($Wo[$Ss]["\144\x6f\156\x74\x5f\143\x72\x65\141\x74\145\x5f\165\163\x65\162"]) ? $Wo[$Ss]["\x64\x6f\x6e\164\x5f\143\x72\x65\x61\164\145\137\165\163\x65\162"] : '';
        $GX = isset($Wo[$Ss]["\x6b\145\x65\160\137\x65\170\151\x73\164\x69\156\x67\137\165\x73\145\x72\x73\x5f\162\x6f\154\145"]) ? $Wo[$Ss]["\153\x65\x65\x70\x5f\145\170\x69\163\x74\151\x6e\147\x5f\x75\163\145\x72\163\137\x72\x6f\x6c\x65"] : '';
        Xs:
        LI:
        if (!is_user_member_of_blog($XP, $blog_id)) {
            goto Un;
        }
        if (isset($GX) && $GX == "\143\x68\x65\143\x6b\x65\x64") {
            goto pW;
        }
        $oL = assign_roles_to_user($user, $Wo, $blog_id, $Me, $Ss);
        goto nC;
        pW:
        $oL = false;
        nC:
        if (is_administrator_user($user)) {
            goto JY;
        }
        if (isset($GX) && $GX == "\143\150\145\x63\x6b\145\x64") {
            goto XW;
        }
        if ($oL !== true && !empty($dE) && $dE == "\x63\x68\145\143\x6b\145\144") {
            goto UD;
        }
        if ($oL !== true && !empty($WA) && $WA !== "\x66\x61\x6c\x73\x65") {
            goto h7;
        }
        if ($oL !== true && is_user_member_of_blog($XP, $blog_id)) {
            goto H8;
        }
        goto uq;
        XW:
        goto uq;
        UD:
        $XP = wp_update_user(array("\x49\x44" => $XP, "\x72\x6f\x6c\145" => false));
        goto uq;
        h7:
        $XP = wp_update_user(array("\111\x44" => $XP, "\x72\157\x6c\145" => $WA));
        goto uq;
        H8:
        $dc = get_site_option("\x64\x65\x66\141\165\x6c\164\137\x72\x6f\154\145");
        $XP = wp_update_user(array("\111\104" => $XP, "\x72\x6f\x6c\x65" => $dc));
        uq:
        JY:
        goto bD;
        Un:
        $LW = TRUE;
        $gh = get_site_option("\163\141\155\154\137\x73\x73\x6f\x5f\x73\x65\x74\164\x69\156\x67\x73");
        if (!empty($gh[$blog_id])) {
            goto dx;
        }
        $gh[$blog_id] = $gh["\104\105\106\101\125\114\124"];
        dx:
        if (empty($Wo)) {
            goto km;
        }
        if (array_key_exists($Ss, $Wo)) {
            goto VH;
        }
        if (!array_key_exists("\104\105\106\101\x55\114\x54", $Wo)) {
            goto hq;
        }
        $fN = get_saml_roles_to_assign($Wo, $Ss, $Me);
        if (!(empty($fN) && strcmp($Wo["\104\105\x46\101\125\x4c\x54"]["\144\157\x6e\164\x5f\143\x72\x65\x61\164\x65\137\165\163\x65\x72"], "\143\x68\x65\x63\x6b\145\144") == 0)) {
            goto Mu;
        }
        $LW = FALSE;
        Mu:
        hq:
        goto aT;
        VH:
        $fN = get_saml_roles_to_assign($Wo, $Ss, $Me);
        if (!(empty($fN) && strcmp($Wo[$Ss]["\x64\157\156\164\x5f\x63\x72\145\x61\164\x65\137\x75\x73\145\x72"], "\x63\150\145\143\153\145\x64") == 0)) {
            goto pC;
        }
        $LW = FALSE;
        pC:
        aT:
        km:
        if (!$LW) {
            goto Lw;
        }
        add_user_to_blog($blog_id, $XP, false);
        $oL = assign_roles_to_user($user, $Wo, $blog_id, $Me, $Ss);
        if ($oL !== true && !empty($dE) && $dE == "\x63\x68\145\143\x6b\x65\x64") {
            goto qV;
        }
        if ($oL !== true && !empty($WA) && $WA !== "\x66\141\154\163\x65") {
            goto Mg;
        }
        if ($oL !== true) {
            goto Ex;
        }
        goto Ur;
        qV:
        $XP = wp_update_user(array("\111\x44" => $XP, "\x72\157\154\145" => false));
        goto Ur;
        Mg:
        $XP = wp_update_user(array("\111\104" => $XP, "\162\157\x6c\145" => $WA));
        goto Ur;
        Ex:
        $dc = get_site_option("\x64\x65\146\141\x75\x6c\164\137\x72\157\154\145");
        $XP = wp_update_user(array("\x49\x44" => $XP, "\162\x6f\154\145" => $dc));
        Ur:
        Lw:
        bD:
        mD:
    }
    xV:
    v2:
    switch_to_blog($Mp);
    if ($XP) {
        goto O5;
    }
    wp_die("\111\156\166\141\x6c\x69\144\40\x75\x73\x65\162\56\40\120\154\x65\x61\163\145\40\164\x72\171\40\141\147\x61\151\156\x2e");
    O5:
    $user = get_user_by("\151\x64", $XP);
    mo_saml_set_auth_cookie($user, $UP, $Mo, true);
    do_action("\155\157\137\163\x61\155\x6c\137\x61\x74\164\162\x69\142\165\164\145\x73", $m0, $O2, $o2, $O6, $Me);
    g4:
    mo_saml_post_login_redirection($Dn, $QY);
}
function mo_saml_add_user_to_blog($O2, $m0, $blog_id = 0)
{
    if (email_exists($O2)) {
        goto vb;
    }
    if (!empty($m0)) {
        goto nr;
    }
    $XP = mo_saml_create_user($O2, $O2, $blog_id);
    goto rl;
    nr:
    $XP = mo_saml_create_user($m0, $O2, $blog_id);
    rl:
    goto Lm;
    vb:
    $user = get_user_by("\x65\155\x61\x69\x6c", $O2);
    $XP = $user->ID;
    if (empty($blog_id)) {
        goto oH;
    }
    add_user_to_blog($blog_id, $XP, false);
    oH:
    Lm:
    return $XP;
}
function mo_saml_create_user($m0, $O2, $blog_id)
{
    $rw = wp_generate_password(10, false);
    if (username_exists($m0)) {
        goto St;
    }
    $XP = wp_create_user($m0, $rw, $O2);
    goto ZX;
    St:
    $user = get_user_by("\154\157\147\x69\x6e", $m0);
    $XP = $user->ID;
    if (!$blog_id) {
        goto HN;
    }
    add_user_to_blog($blog_id, $XP, false);
    HN:
    ZX:
    if (!is_wp_error($XP)) {
        goto xI;
    }
    echo "\x3c\x73\x74\162\157\156\x67\76\105\122\x52\x4f\122\74\57\x73\164\x72\x6f\x6e\x67\76\x3a\40\105\155\160\x74\x79\40\125\163\x65\x72\x20\116\x61\x6d\145\40\141\156\x64\40\105\x6d\141\x69\x6c\56\40\x50\154\x65\141\x73\x65\40\x63\x6f\156\164\x61\143\x74\40\171\157\165\x72\40\141\144\x6d\x69\x6e\151\x73\x74\x72\x61\x74\157\162\x2e";
    exit;
    xI:
    return $XP;
}
function mo_saml_assign_roles_to_new_user($tE, $OV, $Wo, $Me, $m0, $O2)
{
    global $wpdb;
    $user = NULL;
    $Gb = false;
    foreach ($tE as $blog_id) {
        $HF = TRUE;
        $Ss = '';
        if ($OV) {
            goto HS;
        }
        $Ss = $blog_id;
        goto gh;
        HS:
        $Ss = 0;
        gh:
        $gh = get_site_option("\163\141\x6d\x6c\137\163\163\x6f\x5f\x73\x65\164\164\151\156\147\163");
        if (!empty($gh[$blog_id])) {
            goto xc;
        }
        $gh[$blog_id] = $gh["\x44\105\x46\x41\x55\x4c\124"];
        xc:
        if (empty($Wo)) {
            goto O6;
        }
        if (!empty($Wo[$Ss])) {
            goto ew;
        }
        if (!empty($Wo["\x44\105\106\x41\x55\114\x54"])) {
            goto IY;
        }
        $WA = "\163\165\x62\163\x63\162\x69\142\145\x72";
        $dE = '';
        $GX = '';
        $fN = '';
        goto se;
        IY:
        $WA = isset($Wo["\x44\105\x46\x41\125\x4c\124"]["\x64\x65\146\x61\x75\154\x74\137\x72\157\x6c\x65"]) ? $Wo["\104\x45\106\101\x55\114\124"]["\144\145\x66\x61\x75\154\x74\x5f\162\157\x6c\145"] : '';
        $dE = isset($Wo["\x44\105\x46\x41\x55\x4c\124"]["\x64\x6f\x6e\164\x5f\141\154\x6c\157\x77\137\x75\x6e\154\151\x73\164\x65\144\137\165\163\x65\162"]) ? $Wo["\104\105\x46\x41\x55\x4c\x54"]["\x64\x6f\x6e\164\x5f\x61\x6c\x6c\x6f\x77\x5f\165\x6e\154\151\163\x74\x65\144\137\x75\x73\x65\162"] : '';
        $GX = array_key_exists("\153\x65\145\x70\137\145\x78\x69\163\x74\151\x6e\147\x5f\x75\163\x65\x72\163\137\162\x6f\154\145", $Wo["\x44\105\x46\101\125\114\124"]) ? $Wo["\x44\105\106\x41\x55\x4c\x54"]["\153\145\x65\160\x5f\x65\170\151\x73\x74\151\156\x67\x5f\x75\163\x65\162\163\137\162\x6f\x6c\145"] : '';
        $fN = get_saml_roles_to_assign($Wo, $Ss, $Me);
        if (!(empty($fN) && strcmp($Wo["\104\105\x46\101\125\x4c\124"]["\x64\x6f\156\164\x5f\x63\162\145\141\x74\145\137\x75\163\x65\x72"], "\143\150\x65\x63\x6b\145\144") == 0)) {
            goto OE;
        }
        $HF = FALSE;
        OE:
        se:
        goto ip;
        ew:
        $WA = isset($Wo[$Ss]["\x64\145\146\x61\165\x6c\164\x5f\162\x6f\154\145"]) ? $Wo[$Ss]["\x64\x65\x66\141\165\x6c\x74\x5f\x72\x6f\154\x65"] : '';
        $dE = isset($Wo[$Ss]["\x64\157\156\x74\x5f\141\x6c\154\x6f\x77\x5f\x75\x6e\x6c\x69\163\x74\145\144\137\x75\163\x65\x72"]) ? $Wo[$Ss]["\x64\x6f\156\164\137\x61\154\154\x6f\167\x5f\x75\156\x6c\151\x73\164\x65\x64\x5f\x75\x73\x65\x72"] : '';
        $GX = array_key_exists("\153\145\145\160\137\145\x78\x69\163\x74\151\156\147\x5f\165\163\145\162\163\137\162\157\x6c\x65", $Wo[$Ss]) ? $Wo[$Ss]["\153\x65\145\160\x5f\145\170\x69\163\x74\x69\x6e\x67\137\165\x73\145\162\163\x5f\x72\x6f\154\145"] : '';
        $fN = get_saml_roles_to_assign($Wo, $Ss, $Me);
        if (!(empty($fN) && strcmp($Wo[$Ss]["\x64\x6f\156\x74\x5f\x63\x72\x65\141\x74\x65\x5f\165\163\x65\x72"], "\143\x68\145\143\153\145\144") == 0)) {
            goto cc;
        }
        $HF = FALSE;
        cc:
        ip:
        O6:
        if (!$HF) {
            goto xM;
        }
        $XP = NULL;
        switch_to_blog($blog_id);
        $XP = mo_saml_add_user_to_blog($O2, $m0, $blog_id);
        $user = get_user_by("\x69\144", $XP);
        $oL = assign_roles_to_user($user, $Wo, $blog_id, $Me, $Ss);
        if ($oL !== true && !empty($dE) && $dE == "\143\x68\145\x63\153\x65\144") {
            goto ct;
        }
        if ($oL !== true && !empty($WA) && $WA !== "\146\141\154\163\x65") {
            goto oY;
        }
        if ($oL !== true) {
            goto PH;
        }
        goto Gz;
        ct:
        $XP = wp_update_user(array("\111\x44" => $XP, "\162\157\x6c\145" => false));
        goto Gz;
        oY:
        $XP = wp_update_user(array("\x49\104" => $XP, "\162\157\x6c\x65" => $WA));
        goto Gz;
        PH:
        $dc = get_site_option("\x64\145\x66\x61\165\154\x74\x5f\162\157\154\x65");
        $XP = wp_update_user(array("\111\x44" => $XP, "\162\x6f\x6c\145" => $dc));
        Gz:
        $mA = $user->{$wpdb->prefix . "\x63\141\x70\141\x62\x69\x6c\x69\164\x69\x65\163"};
        if (isset($wp_roles)) {
            goto cF;
        }
        $wp_roles = new WP_Roles($Ss);
        cF:
        xM:
        Zb:
    }
    Rl:
    if (!empty($user)) {
        goto Wz;
    }
    return;
    goto p7;
    Wz:
    return $user->ID;
    p7:
}
function mo_saml_sanitize_username($m0)
{
    $A_ = sanitize_user($m0, true);
    $tY = apply_filters("\x70\x72\x65\x5f\165\163\x65\162\x5f\154\x6f\x67\151\156", $A_);
    $m0 = trim($tY);
    return $m0;
}
function mo_saml_map_basic_attributes($user, $o2, $O6, $jc)
{
    $XP = $user->ID;
    if (empty($o2)) {
        goto c_;
    }
    $XP = wp_update_user(array("\111\x44" => $XP, "\x66\x69\x72\163\x74\137\x6e\141\x6d\x65" => $o2));
    c_:
    if (empty($O6)) {
        goto Kc;
    }
    $XP = wp_update_user(array("\111\x44" => $XP, "\154\141\163\164\x5f\x6e\x61\155\x65" => $O6));
    Kc:
    if (is_null($jc)) {
        goto RL;
    }
    update_user_meta($XP, "\155\157\x5f\163\x61\x6d\x6c\137\x75\163\x65\162\x5f\141\164\164\x72\x69\x62\x75\x74\x65\x73", $jc);
    $Sk = get_site_option("\163\141\155\x6c\x5f\141\155\137\144\151\163\160\154\x61\x79\x5f\x6e\x61\155\145");
    if (empty($Sk)) {
        goto Ao;
    }
    if (strcmp($Sk, "\x55\x53\x45\x52\x4e\x41\x4d\x45") == 0) {
        goto Tw;
    }
    if (strcmp($Sk, "\x46\x4e\x41\x4d\x45") == 0 && !empty($o2)) {
        goto rh;
    }
    if (strcmp($Sk, "\x4c\x4e\x41\x4d\x45") == 0 && !empty($O6)) {
        goto er;
    }
    if (strcmp($Sk, "\x46\x4e\101\x4d\x45\137\x4c\x4e\x41\115\105") == 0 && !empty($O6) && !empty($o2)) {
        goto MP;
    }
    if (!(strcmp($Sk, "\114\x4e\x41\115\x45\x5f\106\116\101\115\105") == 0 && !empty($O6) && !empty($o2))) {
        goto iH;
    }
    $XP = wp_update_user(array("\111\104" => $XP, "\144\x69\163\x70\x6c\x61\x79\x5f\x6e\141\155\145" => $O6 . "\40" . $o2));
    iH:
    goto jY;
    MP:
    $XP = wp_update_user(array("\111\x44" => $XP, "\144\x69\163\x70\x6c\141\171\137\156\141\155\145" => $o2 . "\x20" . $O6));
    jY:
    goto DL;
    er:
    $XP = wp_update_user(array("\x49\104" => $XP, "\144\x69\163\160\x6c\141\171\x5f\x6e\141\155\x65" => $O6));
    DL:
    goto Hj;
    rh:
    $XP = wp_update_user(array("\x49\104" => $XP, "\x64\151\163\160\154\x61\171\x5f\x6e\141\155\x65" => $o2));
    Hj:
    goto VZ;
    Tw:
    $XP = wp_update_user(array("\x49\x44" => $XP, "\144\x69\x73\x70\x6c\x61\x79\x5f\x6e\141\x6d\x65" => $user->user_login));
    VZ:
    Ao:
    RL:
}
function mo_saml_map_custom_attributes($XP, $jc)
{
    if (!get_site_option("\x6d\x6f\x5f\x73\141\x6d\x6c\137\x63\x75\163\164\157\x6d\x5f\141\x74\x74\162\x73\x5f\x6d\141\160\160\151\156\147")) {
        goto AU;
    }
    $yr = maybe_unserialize(get_site_option("\x6d\157\x5f\x73\141\x6d\x6c\x5f\143\x75\x73\x74\157\155\x5f\x61\x74\x74\162\163\x5f\155\x61\x70\160\x69\156\x67"));
    foreach ($yr as $z5 => $d1) {
        if (!array_key_exists($d1, $jc)) {
            goto ju;
        }
        $oT = false;
        if (!(count($jc[$d1]) == 1)) {
            goto Rf;
        }
        $oT = true;
        Rf:
        if (!$oT) {
            goto a9;
        }
        update_user_meta($XP, $z5, $jc[$d1][0]);
        goto hQ;
        a9:
        $Yr = array();
        foreach ($jc[$d1] as $EZ) {
            array_push($Yr, $EZ);
            aM:
        }
        Sv:
        update_user_meta($XP, $z5, $Yr);
        hQ:
        ju:
        W7:
    }
    tK:
    AU:
}
function mo_saml_restrict_users_based_on_domain($O2)
{
    $w7 = get_site_option("\155\x6f\137\163\x61\155\154\x5f\145\156\x61\x62\x6c\145\x5f\x64\157\155\141\151\156\x5f\162\x65\163\x74\x72\151\143\x74\151\157\156\137\154\157\147\151\x6e");
    if (!$w7) {
        goto KG;
    }
    $ps = get_site_option("\x73\141\x6d\154\137\141\x6d\x5f\145\x6d\x61\151\x6c\x5f\144\x6f\155\x61\151\x6e\163");
    $EE = explode("\73", $ps);
    $pU = explode("\x40", $O2);
    $cS = array_key_exists("\x31", $pU) ? $pU[1] : '';
    $Ur = get_site_option("\x6d\157\x5f\x73\141\155\x6c\137\141\154\154\157\167\x5f\x64\145\156\x79\137\165\x73\145\x72\x5f\x77\x69\164\x68\x5f\144\157\x6d\x61\151\x6e");
    $HH = get_site_option("\x6d\157\x5f\163\141\x6d\154\137\x72\145\163\164\162\x69\x63\x74\145\x64\137\x64\157\x6d\x61\x69\156\137\145\x72\x72\157\162\x5f\x6d\163\147");
    if (!empty($HH)) {
        goto AG;
    }
    $HH = "\x59\157\165\40\141\x72\145\x20\156\x6f\x74\x20\x61\x6c\x6c\157\x77\145\144\x20\164\157\x20\154\157\147\151\156\x2e\x20\x50\x6c\145\141\163\145\x20\x63\157\156\x74\x61\x63\x74\x20\171\157\165\162\x20\101\x64\155\151\x6e\151\163\x74\x72\141\164\157\162\x2e";
    AG:
    if (!empty($Ur) && $Ur == "\144\x65\x6e\171") {
        goto PF;
    }
    if (in_array($cS, $EE)) {
        goto Jl;
    }
    wp_die($HH, "\x50\145\x72\155\151\x73\x73\151\x6f\156\40\104\145\x6e\151\x65\x64\x20\105\x72\x72\157\x72\x20\x2d\40\x32");
    Jl:
    goto UH;
    PF:
    if (!in_array($cS, $EE)) {
        goto Pm;
    }
    wp_die($HH, "\x50\x65\162\x6d\x69\163\x73\x69\157\x6e\x20\x44\145\x6e\x69\145\144\40\105\162\x72\157\x72\x20\x2d\40\61");
    Pm:
    UH:
    KG:
}
function mo_saml_set_auth_cookie($user, $UP, $Mo, $o3)
{
    $XP = $user->ID;
    do_action("\x77\x70\137\154\x6f\147\151\x6e", $user->user_login, $user);
    if (empty($UP)) {
        goto RZ;
    }
    update_user_meta($XP, "\x6d\x6f\137\x73\x61\155\154\x5f\x73\x65\163\x73\x69\157\156\137\x69\x6e\x64\x65\x78", $UP);
    RZ:
    if (empty($Mo)) {
        goto VG;
    }
    update_user_meta($XP, "\x6d\157\137\163\141\155\154\137\156\141\x6d\145\x5f\x69\x64", $Mo);
    VG:
    if (!(!session_id() || session_id() == '' || !isset($_SESSION))) {
        goto vG;
    }
    session_start();
    vG:
    $_SESSION["\x6d\x6f\x5f\163\141\x6d\154"]["\x6c\x6f\x67\x67\145\x64\137\x69\x6e\x5f\x77\x69\164\x68\x5f\x69\144\x70"] = TRUE;
    update_user_meta($XP, "\155\x6f\137\x73\x61\x6d\x6c\x5f\x69\144\160\137\x6c\157\147\x69\156", "\x74\x72\x75\x65");
    wp_set_current_user($XP);
    $YJ = false;
    $YJ = apply_filters("\155\157\x5f\162\x65\155\x65\x6d\142\x65\162\x5f\155\x65", $YJ);
    wp_set_auth_cookie($XP, $YJ);
    if (!$o3) {
        goto l9;
    }
    do_action("\165\x73\x65\x72\x5f\x72\145\147\x69\x73\164\x65\x72", $XP);
    l9:
}
function mo_saml_post_login_redirection($Dn, $QY)
{
    $XX = mo_saml_get_redirect_url($Dn, $QY);
    wp_redirect($XX);
    exit;
}
function mo_saml_get_redirect_url($Dn, $QY)
{
    $EU = '';
    $gh = get_site_option("\x73\141\x6d\x6c\x5f\x73\x73\157\137\163\145\164\164\151\156\147\163");
    $GU = get_current_blog_id();
    if (!(empty($gh[$GU]) && !empty($gh["\x44\x45\x46\x41\125\114\x54"]))) {
        goto i6;
    }
    $gh[$GU] = $gh["\x44\x45\x46\101\x55\x4c\124"];
    i6:
    $rV = isset($gh[$GU]["\155\157\137\x73\x61\155\x6c\137\162\145\154\x61\x79\x5f\163\164\141\x74\x65"]) ? $gh[$GU]["\155\157\x5f\x73\x61\x6d\x6c\137\162\145\x6c\141\x79\137\163\164\x61\x74\x65"] : '';
    if (!empty($rV)) {
        goto it;
    }
    if (!empty($QY)) {
        goto sD;
    }
    $EU = $Dn;
    goto g3;
    sD:
    $EU = $QY;
    g3:
    goto FL;
    it:
    $EU = $rV;
    FL:
    return $EU;
}
function check_if_user_allowed_to_login($user, $Dn)
{
    $XP = $user->ID;
    global $wpdb;
    if (get_user_meta($XP, "\x6d\157\137\163\141\155\154\x5f\x75\x73\145\162\137\164\x79\160\x65", true)) {
        goto KF;
    }
    if (get_site_option("\x6d\157\x5f\163\x61\x6d\x6c\x5f\x75\x73\x72\x5f\x6c\155\x74")) {
        goto JO;
    }
    update_user_meta($XP, "\x6d\157\137\x73\x61\x6d\154\137\x75\x73\145\x72\x5f\x74\171\x70\x65", "\x73\x73\x6f\x5f\x75\163\x65\162");
    goto vP;
    JO:
    $z5 = get_site_option("\x6d\157\x5f\163\x61\155\x6c\x5f\x63\165\x73\164\x6f\155\145\x72\137\x74\x6f\153\x65\156");
    $ru = AESEncryption::decrypt_data(get_site_option("\155\x6f\x5f\x73\141\x6d\154\137\165\163\162\137\x6c\155\x74"), $z5);
    $Lb = "\123\105\114\105\x43\x54\40\x43\117\x55\116\124\x28\52\51\x20\x46\x52\117\115\x20" . $wpdb->prefix . "\165\163\145\x72\155\x65\x74\x61\40\127\110\x45\x52\105\40\155\145\x74\141\x5f\x6b\145\171\75\47\155\x6f\x5f\163\141\x6d\154\137\165\x73\145\x72\x5f\x74\x79\x70\x65\x27";
    $KF = $wpdb->get_var($Lb);
    if ($KF >= $ru) {
        goto zt;
    }
    update_user_meta($XP, "\x6d\x6f\137\x73\x61\155\154\x5f\165\163\145\162\x5f\164\171\160\145", "\163\163\157\137\x75\163\145\162");
    goto kE;
    zt:
    if (get_site_option("\165\x73\x65\x72\x5f\141\x6c\x65\162\x74\137\x65\155\x61\x69\x6c\x5f\163\145\156\164")) {
        goto We;
    }
    $a5 = new Customersaml();
    $a5->mo_saml_send_user_exceeded_alert_email($ru, $this);
    We:
    if (is_administrator_user($user)) {
        goto eG;
    }
    wp_redirect($Dn);
    exit;
    goto yL;
    eG:
    update_user_meta($XP, "\155\x6f\x5f\x73\x61\155\x6c\x5f\x75\163\145\x72\137\164\x79\160\145", "\163\163\157\137\x75\x73\145\162");
    yL:
    kE:
    vP:
    KF:
}
function check_if_user_allowed_to_login_due_to_role_restriction($Me)
{
    $Wo = maybe_unserialize(get_site_option("\163\x61\x6d\154\x5f\x61\x6d\x5f\x72\x6f\154\145\x5f\x6d\x61\160\x70\151\x6e\x67"));
    $tE = Utilities::get_active_sites();
    $OV = get_site_option("\x6d\x6f\137\141\160\160\154\171\137\162\157\154\145\137\x6d\x61\x70\x70\x69\x6e\147\x5f\x66\157\x72\137\x73\151\x74\x65\x73");
    if ($Wo) {
        goto mx;
    }
    $Wo = array();
    mx:
    if (array_key_exists("\104\105\x46\101\125\x4c\x54", $Wo)) {
        goto tJ;
    }
    $Wo["\104\x45\106\x41\x55\114\x54"] = array();
    tJ:
    foreach ($tE as $blog_id) {
        if ($OV) {
            goto IO;
        }
        $Ss = $blog_id;
        goto rX;
        IO:
        $Ss = 0;
        rX:
        if (isset($Wo[$Ss])) {
            goto qM;
        }
        $nt = $Wo["\x44\105\106\101\x55\x4c\x54"];
        goto yt;
        qM:
        $nt = $Wo[$Ss];
        yt:
        if (empty($nt)) {
            goto ye;
        }
        $l5 = isset($nt["\155\x6f\137\163\x61\x6d\x6c\137\x64\x6f\156\x74\x5f\141\154\154\x6f\x77\x5f\165\x73\x65\x72\x5f\x74\157\x6c\x6f\147\151\x6e\137\143\162\145\141\164\145\x5f\167\151\x74\x68\137\x67\x69\166\x65\156\x5f\147\x72\157\165\x70\163"]) ? $nt["\x6d\x6f\x5f\163\x61\155\154\x5f\x64\157\x6e\x74\137\141\x6c\154\x6f\167\137\x75\x73\145\162\x5f\x74\x6f\x6c\157\x67\151\x6e\137\143\162\x65\141\164\x65\x5f\x77\151\x74\x68\x5f\x67\151\166\x65\x6e\137\x67\162\x6f\165\x70\163"] : '';
        if (!($l5 == "\143\150\x65\x63\153\145\x64")) {
            goto ja;
        }
        if (empty($Me)) {
            goto cr;
        }
        $hS = $nt["\155\x6f\x5f\x73\x61\x6d\154\x5f\162\145\x73\x74\x72\151\x63\164\x5f\165\163\145\162\163\137\x77\x69\x74\x68\x5f\x67\x72\x6f\x75\160\163"];
        $JL = explode("\73", $hS);
        foreach ($JL as $F9) {
            foreach ($Me as $BE) {
                $BE = trim($BE);
                if (!(!empty($BE) && $BE == $F9)) {
                    goto NH;
                }
                wp_die("\x59\x6f\x75\x20\141\x72\x65\40\x6e\157\x74\40\x61\165\164\150\157\x72\151\x7a\145\144\40\x74\x6f\40\154\x6f\147\x69\156\56\x20\120\x6c\145\x61\163\x65\x20\x63\157\x6e\164\141\143\164\x20\171\157\165\162\x20\141\x64\155\x69\x6e\x69\x73\164\162\x61\164\157\x72\56", "\x45\x72\162\x6f\162");
                NH:
                nA:
            }
            Z9:
            oX:
        }
        UI:
        cr:
        ja:
        ye:
        hS:
    }
    oQ:
}
function assign_roles_to_user($user, $Wo, $blog_id, $Me, $Ss)
{
    $oL = false;
    if (!(!empty($Me) && !empty($Wo) && !is_administrator_user($user) && is_user_member_of_blog($user->ID, $blog_id))) {
        goto ES;
    }
    if (!empty($Wo[$Ss])) {
        goto Yy;
    }
    if (empty($Wo["\104\x45\106\101\x55\x4c\124"])) {
        goto qm;
    }
    $nt = $Wo["\x44\x45\x46\101\x55\114\x54"];
    qm:
    goto RQ;
    Yy:
    $nt = $Wo[$Ss];
    RQ:
    if (empty($nt)) {
        goto Zg;
    }
    $user->set_role(false);
    $Rc = '';
    $lH = false;
    unset($nt["\144\145\x66\x61\x75\154\x74\137\x72\x6f\x6c\145"]);
    unset($nt["\x64\157\x6e\x74\137\x63\162\x65\x61\164\x65\137\165\163\145\162"]);
    unset($nt["\x64\157\156\x74\x5f\x61\x6c\x6c\157\167\x5f\165\x6e\154\151\x73\164\x65\x64\137\x75\x73\145\162"]);
    unset($nt["\153\x65\x65\160\137\145\x78\151\x73\164\x69\156\x67\x5f\165\163\145\x72\x73\x5f\x72\x6f\154\145"]);
    unset($nt["\155\157\x5f\x73\141\155\x6c\x5f\144\157\x6e\164\137\x61\154\154\157\x77\x5f\x75\163\x65\162\x5f\x74\x6f\154\157\147\x69\156\137\143\162\x65\x61\x74\145\137\x77\x69\x74\x68\137\x67\151\166\145\x6e\x5f\147\162\157\x75\160\163"]);
    unset($nt["\155\157\137\163\x61\x6d\154\137\162\x65\163\164\162\x69\143\x74\x5f\x75\163\145\162\x73\137\167\151\164\x68\x5f\x67\x72\157\x75\160\163"]);
    foreach ($nt as $KN => $CB) {
        $JL = explode("\73", $CB);
        foreach ($JL as $F9) {
            if (!(!empty($F9) && in_array($F9, $Me))) {
                goto qs;
            }
            $oL = true;
            $user->add_role($KN);
            qs:
            e1:
        }
        jg:
        Z5:
    }
    pn:
    Zg:
    ES:
    $JR = get_site_option("\x6d\x6f\137\x73\x61\155\154\x5f\x73\165\x70\x65\x72\x5f\141\144\x6d\151\156\137\x72\157\154\x65\x5f\x6d\141\x70\x70\x69\x6e\147");
    $iN = array();
    if (empty($JR)) {
        goto Wy;
    }
    $iN = explode("\73", $JR);
    Wy:
    if (!(!empty($Me) && !empty($iN))) {
        goto Af;
    }
    foreach ($iN as $F9) {
        if (!in_array($F9, $Me)) {
            goto qZ;
        }
        grant_super_admin($user->ID);
        qZ:
        W3:
    }
    OV:
    Af:
    return $oL;
}
function get_saml_roles_to_assign($Wo, $blog_id, $Me)
{
    $fN = array();
    if (!(!empty($Me) && !empty($Wo))) {
        goto dr;
    }
    if (!empty($Wo[$blog_id])) {
        goto LB;
    }
    if (empty($Wo["\x44\105\x46\x41\x55\x4c\124"])) {
        goto B_;
    }
    $nt = $Wo["\x44\105\x46\x41\x55\x4c\x54"];
    B_:
    goto F6;
    LB:
    $nt = $Wo[$blog_id];
    F6:
    if (empty($nt)) {
        goto Q6;
    }
    unset($nt["\144\x65\x66\141\x75\154\x74\137\x72\157\x6c\145"]);
    unset($nt["\x64\x6f\x6e\x74\137\x63\162\x65\x61\164\x65\137\165\x73\145\x72"]);
    unset($nt["\x64\157\x6e\164\137\x61\154\x6c\157\167\137\x75\x6e\154\x69\x73\x74\x65\144\137\x75\x73\145\162"]);
    unset($nt["\x6b\x65\x65\x70\137\x65\170\x69\x73\x74\x69\x6e\x67\x5f\165\x73\x65\x72\x73\x5f\x72\x6f\154\x65"]);
    unset($nt["\x6d\157\x5f\x73\141\x6d\154\137\x64\157\x6e\x74\x5f\141\x6c\x6c\x6f\167\x5f\x75\163\x65\x72\x5f\164\x6f\x6c\157\x67\151\156\x5f\143\162\145\141\164\x65\x5f\167\x69\164\x68\x5f\147\151\166\145\156\x5f\147\162\157\165\160\x73"]);
    unset($nt["\155\157\x5f\163\141\x6d\x6c\x5f\x72\x65\163\x74\x72\x69\143\x74\137\x75\163\x65\162\163\x5f\x77\151\164\x68\x5f\x67\162\x6f\165\160\163"]);
    foreach ($nt as $KN => $CB) {
        $JL = explode("\x3b", $CB);
        foreach ($JL as $F9) {
            if (!(!empty($F9) and in_array($F9, $Me))) {
                goto qQ;
            }
            array_push($fN, $KN);
            qQ:
            PJ:
        }
        k6:
        gt:
    }
    Mw:
    Q6:
    dr:
    return $fN;
}
function is_administrator_user($user)
{
    $zG = $user->roles;
    if (!is_null($zG) && in_array("\141\144\155\151\156\151\x73\x74\x72\x61\x74\x6f\162", $zG)) {
        goto we;
    }
    return false;
    goto fW;
    we:
    return true;
    fW:
}
function mo_saml_is_customer_registered()
{
    return 1;
    $p1 = get_site_option("\155\157\137\163\141\x6d\x6c\137\x61\144\155\x69\156\x5f\145\x6d\x61\x69\x6c");
    $ih = get_site_option("\x6d\157\x5f\x73\x61\155\x6c\x5f\x61\x64\x6d\x69\156\x5f\143\165\x73\x74\157\155\x65\162\x5f\x6b\x65\x79");
    if (!$p1 || !$ih || !is_numeric(trim($ih))) {
        goto BJ;
    }
    return 1;
    goto H_;
    BJ:
    return 0;
    H_:
}
function mo_saml_is_customer_license_verified()
{
    $uu = mo_saml_get_plugin_details();
    if ($uu !== true) {
        goto bi;
    }
    return 1;
    goto Ny;
    bi:
    return 0;
    Ny:
    $z5 = get_site_option("\x6d\157\137\163\141\155\x6c\137\x63\165\x73\164\x6f\155\x65\162\x5f\x74\157\x6b\x65\156");
    $ua = AESEncryption::decrypt_data(get_site_option("\164\x5f\x73\151\164\145\x5f\163\164\x61\164\165\x73"), $z5);
    $cF = get_site_option("\x73\155\x6c\137\x6c\x6b");
    $p1 = get_site_option("\155\157\137\163\x61\x6d\x6c\x5f\x61\144\155\151\156\x5f\145\155\x61\151\154");
    $ih = get_site_option("\x6d\157\137\163\x61\155\x6c\137\x61\x64\155\151\156\137\143\165\163\x74\x6f\155\x65\162\x5f\x6b\x65\x79");
    $Vb = AESEncryption::decrypt_data(get_site_option("\x6e\157\137\163\142\163"), $z5);
    $TQ = false;
    if (!get_site_option("\x6e\157\x5f\x73\142\x73")) {
        goto Pr;
    }
    $zA = Utilities::get_sites();
    $TQ = $Vb < count($zA);
    Pr:
    if ($ua != "\164\x72\165\145" && !$cF || !$p1 || !$ih || !is_numeric(trim($ih)) || $TQ) {
        goto i2;
    }
    return 1;
    goto nB;
    i2:
    return 0;
    nB:
}
function show_status_error($ER, $QY)
{
    if ($QY == "\164\145\163\x74\126\141\x6c\151\x64\x61\164\145" or $QY == "\x74\x65\163\x74\x4e\145\167\103\x65\x72\164\x69\x66\151\143\x61\x74\145") {
        goto EJ;
    }
    wp_die("\x57\145\40\x63\157\x75\154\x64\40\x6e\x6f\164\40\163\151\x67\156\40\x79\157\165\x20\151\x6e\56\x20\x50\154\x65\x61\x73\145\x20\x63\x6f\156\x74\141\x63\164\40\x79\157\x75\x72\x20\x41\x64\155\151\x6e\x69\x73\x74\162\x61\x74\157\x72\x2e", "\105\x72\162\157\162\x3a\40\111\x6e\166\x61\154\x69\x64\x20\x53\101\115\114\x20\122\145\x73\x70\x6f\156\163\145\40\123\x74\x61\164\165\163");
    goto OZ;
    EJ:
    echo "\x3c\144\151\166\x20\163\164\171\x6c\145\x3d\x22\146\157\x6e\x74\x2d\x66\141\155\151\x6c\171\x3a\103\x61\x6c\x69\142\x72\x69\x3b\160\141\144\x64\151\x6e\147\72\60\40\x33\45\73\x22\76";
    echo "\74\x64\151\x76\40\x73\164\x79\x6c\145\75\42\x63\x6f\154\157\x72\72\x20\x23\x61\x39\x34\x34\x34\62\x3b\142\141\x63\x6b\x67\162\157\x75\x6e\144\55\x63\157\154\157\x72\x3a\40\x23\146\62\144\x65\144\x65\73\x70\141\144\x64\151\156\147\x3a\40\x31\x35\160\170\73\155\141\162\147\151\x6e\55\142\157\164\x74\x6f\155\72\40\62\60\x70\170\73\x74\x65\x78\x74\x2d\x61\x6c\x69\x67\156\x3a\143\x65\156\x74\x65\162\73\x62\157\162\x64\x65\162\x3a\61\160\x78\40\x73\x6f\x6c\x69\x64\x20\43\105\66\x42\x33\x42\62\73\x66\157\156\164\55\163\151\172\145\x3a\x31\70\160\x74\73\x22\76\x20\x45\x52\122\x4f\122\x3c\x2f\144\151\x76\x3e\xd\12\40\x20\x20\40\40\x20\x20\40\x3c\144\x69\x76\40\163\164\171\x6c\x65\75\42\143\157\x6c\x6f\162\72\40\43\x61\x39\x34\x34\64\62\x3b\146\157\x6e\x74\x2d\x73\x69\172\x65\72\x31\64\x70\x74\73\40\155\141\162\147\151\x6e\55\x62\157\x74\x74\157\x6d\x3a\62\60\160\x78\x3b\42\76\x3c\x70\76\74\163\x74\x72\x6f\x6e\x67\x3e\x45\x72\x72\x6f\162\72\x20\74\x2f\163\x74\162\157\x6e\x67\x3e\x20\111\x6e\x76\x61\154\x69\x64\40\x53\101\115\x4c\x20\122\x65\163\160\157\x6e\163\x65\x20\x53\x74\x61\x74\x75\x73\56\x3c\x2f\x70\x3e\15\xa\x20\x20\x20\x20\x20\x20\40\40\40\40\40\40\74\160\x3e\74\163\x74\162\x6f\x6e\147\76\103\141\x75\x73\145\163\74\57\163\x74\162\x6f\156\x67\76\72\40\111\144\145\156\164\x69\164\171\40\x50\x72\157\166\151\144\x65\162\x20\x68\141\x73\x20\163\x65\x6e\x74\40\x27" . $ER . "\x27\x20\x73\x74\x61\x74\165\x73\x20\x63\157\144\x65\x20\x69\156\x20\x53\101\115\114\40\x52\145\163\x70\157\x6e\x73\x65\56\40\x3c\x2f\160\x3e\15\xa\x20\x20\40\40\x20\40\40\x20\40\x20\x20\x20\x3c\160\x3e\74\163\164\x72\157\156\147\x3e\x52\145\141\x73\157\156\x3c\57\x73\164\162\157\x6e\x67\76\x3a\x20" . get_status_message($ER) . "\74\57\x70\76\x3c\142\162\x3e";
    if (empty($IP)) {
        goto yb;
    }
    echo "\x3c\x70\76\74\163\x74\162\x6f\156\x67\x3e\x53\x74\x61\164\165\163\x20\x4d\145\x73\163\x61\x67\x65\x20\151\x6e\40\164\150\145\40\123\x41\115\x4c\x20\122\145\163\160\157\156\x73\145\72\74\x2f\x73\x74\x72\x6f\x6e\147\x3e\40\x3c\142\x72\57\x3e" . $IP . "\74\x2f\x70\76\74\142\x72\76";
    yb:
    echo "\15\xa\x20\x20\40\40\x20\x20\40\40\x3c\57\x64\151\166\x3e\xd\xa\xd\xa\40\x20\x20\x20\x20\40\x20\40\74\144\151\x76\x20\163\x74\171\x6c\145\x3d\42\x6d\141\162\147\x69\156\72\x33\45\73\x64\151\x73\x70\154\x61\x79\x3a\x62\x6c\157\143\x6b\73\164\145\x78\x74\55\141\154\151\x67\x6e\72\143\x65\x6e\x74\145\x72\73\42\76\xd\12\x20\x20\x20\40\x20\x20\x20\x20\x20\x20\40\40\74\144\151\166\x20\x73\164\171\x6c\145\x3d\x22\155\x61\162\x67\151\x6e\72\63\x25\73\x64\151\163\x70\x6c\x61\x79\x3a\142\154\157\143\x6b\73\164\x65\x78\x74\x2d\141\154\151\x67\156\x3a\143\x65\x6e\164\x65\162\73\x22\76\x3c\x69\x6e\160\165\x74\x20\x73\x74\x79\154\x65\x3d\x22\160\141\x64\144\151\156\147\x3a\61\x25\x3b\x77\x69\144\164\150\72\x31\x30\x30\160\x78\x3b\142\x61\x63\x6b\x67\162\157\165\156\x64\72\x20\x23\60\x30\x39\61\x43\x44\40\x6e\x6f\x6e\145\40\162\x65\x70\x65\x61\164\40\x73\x63\162\x6f\x6c\154\40\x30\45\x20\x30\x25\x3b\x63\165\x72\163\x6f\162\72\40\x70\x6f\x69\x6e\164\145\162\73\x66\x6f\x6e\x74\x2d\x73\151\172\145\x3a\x31\65\160\x78\x3b\x62\x6f\162\x64\145\162\55\167\x69\144\164\150\72\x20\x31\160\170\73\142\x6f\162\x64\x65\162\x2d\163\x74\171\154\x65\x3a\x20\x73\157\154\x69\144\x3b\x62\x6f\x72\144\x65\x72\x2d\x72\x61\144\x69\x75\163\x3a\40\63\x70\170\73\x77\150\151\x74\145\55\x73\160\141\143\x65\72\x20\156\157\167\162\141\160\x3b\142\157\170\55\163\151\172\x69\x6e\x67\72\x20\x62\157\162\x64\145\162\55\x62\x6f\170\73\142\x6f\162\144\145\162\55\143\157\154\x6f\162\x3a\x20\x23\60\x30\x37\63\101\x41\x3b\142\157\170\x2d\x73\150\141\144\157\x77\x3a\x20\x30\160\x78\x20\x31\x70\x78\x20\x30\x70\170\x20\162\x67\142\x61\50\61\x32\60\x2c\40\62\x30\60\x2c\x20\62\63\x30\x2c\40\x30\x2e\66\x29\40\151\156\x73\145\164\73\x63\x6f\x6c\x6f\162\x3a\40\43\106\106\106\x3b\x22\x74\x79\160\x65\75\42\x62\x75\164\164\x6f\156\42\40\166\x61\x6c\x75\x65\x3d\42\x44\157\x6e\145\x22\40\157\x6e\x43\x6c\151\143\x6b\x3d\42\x73\x65\x6c\146\56\x63\154\x6f\163\x65\x28\51\x3b\x22\76\74\x2f\144\x69\166\x3e";
    exit;
    OZ:
}
function addLink($A6, $KR)
{
    $W6 = "\x3c\x61\x20\150\x72\145\x66\75\x22" . $KR . "\42\x3e" . $A6 . "\x3c\x2f\x61\76";
    return $W6;
}
function get_status_message($ER)
{
    switch ($ER) {
        case "\122\145\161\x75\x65\x73\164\x65\x72":
            return "\124\150\x65\40\162\x65\x71\x75\145\x73\x74\40\143\x6f\x75\154\144\40\156\157\x74\x20\142\145\x20\160\145\x72\x66\157\162\155\145\x64\x20\144\x75\x65\40\x74\157\x20\x61\156\x20\145\x72\x72\157\x72\40\x6f\156\40\x74\x68\x65\40\x70\141\162\x74\x20\157\146\40\x74\150\x65\x20\x72\x65\161\165\x65\x73\164\145\x72\x2e";
            goto Yl;
        case "\x52\145\163\160\x6f\x6e\144\145\x72":
            return "\124\x68\145\40\x72\x65\x71\165\145\x73\164\x20\143\x6f\165\154\x64\x20\x6e\x6f\164\x20\142\x65\x20\160\145\162\146\x6f\x72\155\x65\x64\40\x64\x75\145\x20\164\157\x20\141\x6e\x20\x65\162\162\x6f\162\40\x6f\x6e\40\164\x68\145\x20\x70\x61\162\x74\40\x6f\x66\x20\164\150\x65\x20\123\101\x4d\114\40\x72\x65\x73\x70\157\x6e\144\145\x72\x20\157\162\40\123\101\115\114\x20\x61\165\x74\150\157\162\x69\x74\x79\x2e";
            goto Yl;
        case "\126\145\x72\163\151\157\x6e\115\x69\163\155\x61\x74\x63\150":
            return "\x54\150\145\40\x53\101\x4d\114\x20\x72\145\163\x70\157\156\144\145\162\x20\143\157\165\x6c\144\x20\156\x6f\164\40\160\162\157\x63\145\163\163\40\164\150\145\x20\x72\145\161\x75\x65\163\164\40\142\x65\143\141\165\x73\x65\x20\x74\x68\x65\40\166\x65\162\x73\x69\x6f\156\x20\157\146\40\x74\x68\x65\x20\162\145\161\165\x65\x73\x74\x20\155\145\163\x73\141\x67\x65\40\x77\x61\163\x20\x69\156\x63\x6f\162\x72\145\143\x74\x2e";
            goto Yl;
        default:
            return "\125\x6e\x6b\156\157\167\x6e";
    }
    gM:
    Yl:
}
function saml_get_current_page_url()
{
    $kC = $_SERVER["\110\x54\124\120\x5f\110\x4f\x53\x54"];
    if (!(substr($kC, -1) == "\x2f")) {
        goto Tg;
    }
    $kC = substr($kC, 0, -1);
    Tg:
    $wS = $_SERVER["\x52\105\x51\125\x45\123\124\x5f\125\122\x49"];
    if (!(substr($wS, 0, 1) == "\57")) {
        goto UW;
    }
    $wS = substr($wS, 1);
    UW:
    $Wa = isset($_SERVER["\x48\124\x54\x50\x53"]) && strcasecmp($_SERVER["\110\x54\x54\120\123"], "\x6f\x6e") == 0;
    $sB = "\x68\164\x74\x70" . ($Wa ? "\163" : '') . "\x3a\x2f\57" . $kC . "\x2f" . $wS;
    return $sB;
}
function get_network_site_url()
{
    $x2 = network_site_url();
    if (!(substr($x2, -1) == "\57")) {
        goto OC;
    }
    $x2 = substr($x2, 0, -1);
    OC:
    return $x2;
}
function get_current_base_url()
{
    return sprintf("\45\x73\x3a\x2f\57\x25\163\57", isset($_SERVER["\110\124\124\x50\123"]) && $_SERVER["\110\124\124\x50\123"] != "\x6f\x66\x66" ? "\x68\164\x74\160\x73" : "\x68\164\164\x70", $_SERVER["\x48\x54\x54\120\x5f\x48\117\x53\x54"]);
}
add_action("\167\151\144\147\145\x74\x73\x5f\151\156\151\x74", function () {
    register_widget("\x6d\x6f\x5f\154\157\x67\x69\x6e\137\x77\151\144");
});
add_action("\x69\156\151\x74", "\155\x6f\137\154\157\147\151\156\x5f\x76\141\x6c\x69\x64\141\x74\145");
