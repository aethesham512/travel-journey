<?php


include_once "\x55\x74\151\x6c\x69\164\151\145\x73\x2e\x70\150\x70";
include_once "\x78\155\x6c\x73\x65\x63\154\x69\142\x73\56\x70\x68\160";
use RobRichards\XMLSecLibs\XMLSecurityKey;
use RobRichards\XMLSecLibs\XMLSecurityDSig;
use RobRichards\XMLSecLibs\XMLSecEnc;
class SAML2_Assertion
{
    private $id;
    private $issueInstant;
    private $issuer;
    private $nameId;
    private $encryptedNameId;
    private $encryptedAttribute;
    private $encryptionKey;
    private $notBefore;
    private $notOnOrAfter;
    private $validAudiences;
    private $sessionNotOnOrAfter;
    private $sessionIndex;
    private $authnInstant;
    private $authnContextClassRef;
    private $authnContextDecl;
    private $authnContextDeclRef;
    private $AuthenticatingAuthority;
    private $attributes;
    private $nameFormat;
    private $signatureKey;
    private $certificates;
    private $signatureData;
    private $requiredEncAttributes;
    private $SubjectConfirmation;
    private $privateKeyUrl;
    protected $wasSignedAtConstruction = FALSE;
    public function __construct(DOMElement $aa = NULL, $zq)
    {
        $this->id = Utilities::generateId();
        $this->issueInstant = Utilities::generateTimestamp();
        $this->issuer = '';
        $this->authnInstant = Utilities::generateTimestamp();
        $this->attributes = array();
        $this->nameFormat = "\165\162\156\72\157\141\x73\151\x73\72\x6e\141\155\x65\x73\72\x74\143\72\x53\101\x4d\114\x3a\x31\x2e\61\72\x6e\141\155\145\x69\x64\x2d\146\x6f\x72\x6d\141\164\x3a\165\156\x73\x70\145\x63\x69\x66\x69\x65\x64";
        $this->certificates = array();
        $this->AuthenticatingAuthority = array();
        $this->SubjectConfirmation = array();
        if (!($aa === NULL)) {
            goto F3;
        }
        return;
        F3:
        if (!($aa->localName === "\105\x6e\143\162\171\x70\164\x65\x64\101\163\163\145\x72\x74\x69\157\x6e")) {
            goto bT;
        }
        $P9 = Utilities::xpQuery($aa, "\x2e\x2f\170\x65\156\143\72\x45\x6e\143\162\x79\x70\164\x65\144\104\141\x74\x61");
        $dk = Utilities::xpQuery($aa, "\x2e\57\170\x65\x6e\x63\x3a\x45\156\x63\x72\171\x70\x74\x65\144\104\141\164\x61\x2f\144\163\x3a\113\x65\x79\x49\156\146\x6f\57\x78\145\156\143\x3a\x45\x6e\143\x72\x79\160\x74\145\x64\113\145\171");
        $Pk = '';
        if (empty($dk)) {
            goto Ys;
        }
        $Pk = $dk[0]->firstChild->getAttribute("\101\154\147\x6f\x72\x69\x74\x68\x6d");
        goto EU;
        Ys:
        $dk = Utilities::xpQuery($aa, "\56\57\x78\145\x6e\x63\x3a\x45\x6e\x63\162\171\x70\164\x65\144\113\145\x79\x2f\170\x65\156\x63\x3a\105\156\x63\x72\x79\x70\164\x69\x6f\x6e\x4d\x65\x74\x68\x6f\x64");
        $Pk = $dk[0]->getAttribute("\x41\154\x67\157\162\151\x74\150\155");
        EU:
        $y5 = Utilities::getEncryptionAlgorithm($Pk);
        if (count($P9) === 0) {
            goto mF;
        }
        if (count($P9) > 1) {
            goto vp;
        }
        goto gE;
        mF:
        throw new Exception("\x4d\x69\163\163\151\x6e\147\40\x65\156\143\162\171\160\164\145\x64\x20\144\x61\x74\x61\x20\x69\156\40\74\163\141\155\154\x3a\x45\x6e\143\x72\171\160\164\x65\144\x41\163\x73\x65\x72\x74\x69\157\156\x3e\x2e");
        goto gE;
        vp:
        throw new Exception("\x4d\x6f\x72\145\40\164\150\x61\156\x20\x6f\156\x65\x20\x65\x6e\143\162\171\x70\164\x65\144\x20\x64\141\x74\x61\40\145\x6c\x65\x6d\145\x6e\164\40\x69\x6e\x20\x3c\x73\141\x6d\x6c\72\105\156\x63\162\x79\160\164\x65\x64\101\x73\x73\x65\x72\x74\151\x6f\x6e\x3e\x2e");
        gE:
        $z5 = new XMLSecurityKey($y5, array("\164\171\x70\145" => "\x70\x72\x69\166\141\x74\145"));
        $x2 = get_site_option("\155\x6f\137\x73\141\x6d\x6c\x5f\x63\x75\162\162\145\x6e\164\x5f\143\x65\162\164\x5f\160\162\151\166\x61\164\x65\137\x6b\145\171");
        $z5->loadKey($zq, FALSE);
        $BC = array();
        $aa = Utilities::decryptElement($P9[0], $z5, $BC);
        bT:
        if ($aa->hasAttribute("\111\x44")) {
            goto cy;
        }
        throw new Exception("\115\151\163\163\x69\156\147\40\111\104\40\141\164\x74\x72\x69\142\x75\x74\x65\x20\157\156\40\123\x41\115\114\x20\x61\163\x73\145\162\164\x69\x6f\x6e\56");
        cy:
        $this->id = $aa->getAttribute("\x49\104");
        if (!($aa->getAttribute("\126\x65\162\163\151\x6f\156") !== "\62\x2e\60")) {
            goto Lu;
        }
        throw new Exception("\x55\156\163\x75\160\160\x6f\162\164\x65\x64\x20\166\145\162\163\151\x6f\156\72\40" . $aa->getAttribute("\x56\145\x72\163\x69\x6f\156"));
        Lu:
        $this->issueInstant = Utilities::xsDateTimeToTimestamp($aa->getAttribute("\x49\163\x73\x75\145\111\x6e\163\x74\x61\x6e\x74"));
        $pr = Utilities::xpQuery($aa, "\x2e\x2f\163\141\155\154\137\141\x73\163\x65\162\x74\x69\157\x6e\x3a\x49\163\x73\x75\x65\x72");
        if (!empty($pr)) {
            goto d6;
        }
        throw new Exception("\115\151\163\x73\x69\x6e\x67\x20\x3c\163\141\x6d\x6c\72\111\163\163\165\x65\x72\x3e\40\x69\x6e\40\x61\x73\163\x65\162\164\151\x6f\156\56");
        d6:
        $this->issuer = trim($pr[0]->textContent);
        $this->parseConditions($aa);
        $this->parseAuthnStatement($aa);
        $this->parseAttributes($aa);
        $this->parseEncryptedAttributes($aa);
        $this->parseSignature($aa);
        $this->parseSubject($aa);
    }
    private function parseSubject(DOMElement $aa)
    {
        $Hb = Utilities::xpQuery($aa, "\x2e\57\163\x61\x6d\x6c\137\141\163\x73\x65\162\x74\151\157\x6e\x3a\123\x75\x62\x6a\x65\143\164");
        if (empty($Hb)) {
            goto EH;
        }
        if (count($Hb) > 1) {
            goto qa;
        }
        goto SC;
        EH:
        return;
        goto SC;
        qa:
        throw new Exception("\x4d\157\x72\145\x20\x74\150\x61\x6e\x20\157\x6e\x65\40\x3c\x73\141\155\154\x3a\123\x75\x62\152\x65\143\x74\x3e\x20\151\156\40\74\163\141\x6d\x6c\x3a\101\x73\x73\145\x72\164\151\157\156\x3e\x2e");
        SC:
        $Hb = $Hb[0];
        $Mo = Utilities::xpQuery($Hb, "\56\x2f\x73\141\155\x6c\137\141\x73\163\x65\x72\164\x69\x6f\x6e\72\x4e\x61\x6d\145\111\x44\x20\174\x20\56\57\163\x61\x6d\x6c\137\141\x73\163\145\x72\x74\151\157\156\x3a\105\156\x63\162\171\160\x74\x65\144\111\104\57\x78\145\156\143\72\105\x6e\x63\162\x79\160\x74\145\144\104\141\164\x61");
        if (empty($Mo)) {
            goto dN;
        }
        if (count($Mo) > 1) {
            goto zF;
        }
        goto MI;
        dN:
        if ($_POST["\x52\x65\154\141\171\123\164\x61\164\145"] == "\x74\145\x73\x74\126\x61\154\151\x64\141\x74\145" or $_POST["\x52\145\x6c\141\171\x53\x74\x61\x74\x65"] == "\164\145\x73\x74\x4e\145\x77\103\x65\x72\164\x69\x66\x69\143\x61\x74\145") {
            goto A_;
        }
        wp_die("\x57\145\40\143\x6f\165\x6c\x64\40\156\x6f\164\x20\163\x69\147\x6e\x20\171\x6f\x75\40\x69\x6e\56\x20\x50\x6c\145\141\x73\x65\x20\143\x6f\156\x74\141\x63\x74\x20\171\157\x75\x72\x20\141\x64\x6d\151\x6e\151\163\164\x72\x61\164\157\x72");
        goto vU;
        A_:
        echo "\x3c\144\x69\x76\x20\163\164\x79\x6c\145\75\42\x66\x6f\156\x74\55\x66\141\155\x69\x6c\171\x3a\103\141\154\x69\x62\x72\x69\x3b\160\x61\144\144\x69\x6e\x67\72\x30\x20\x33\x25\73\x22\x3e";
        echo "\x3c\144\x69\166\40\x73\164\x79\154\x65\x3d\x22\x63\157\154\157\x72\x3a\40\x23\x61\71\x34\x34\64\62\73\x62\141\x63\153\x67\x72\157\x75\156\x64\55\x63\x6f\154\157\162\x3a\x20\x23\146\x32\x64\145\x64\145\x3b\160\141\x64\144\151\156\x67\72\x20\61\x35\160\170\73\155\x61\162\147\151\156\55\142\x6f\x74\x74\157\x6d\x3a\x20\x32\x30\x70\170\x3b\x74\x65\x78\164\x2d\x61\154\x69\x67\x6e\72\x63\x65\x6e\x74\x65\x72\73\x62\157\162\144\x65\162\x3a\x31\160\x78\x20\x73\157\154\151\x64\x20\x23\105\66\102\x33\x42\62\x3b\146\157\x6e\x74\55\x73\151\x7a\x65\72\61\x38\x70\x74\73\42\76\40\105\x52\122\117\x52\74\57\144\151\166\76\15\12\x20\x20\x20\40\x20\40\40\40\40\40\x20\x3c\144\x69\166\40\163\164\171\x6c\145\75\x22\x63\x6f\154\157\162\x3a\40\x23\x61\71\x34\x34\x34\x32\73\146\x6f\x6e\x74\55\163\x69\172\145\x3a\x31\64\x70\164\x3b\x20\x6d\141\x72\147\151\x6e\55\x62\x6f\x74\164\x6f\x6d\x3a\x32\x30\160\x78\73\x22\76\74\x70\x3e\74\x73\164\x72\157\156\147\76\x45\162\x72\x6f\x72\x3a\x20\x3c\57\163\164\162\157\156\147\x3e\x4d\151\x73\163\x69\156\147\x20\x20\x4e\141\155\x65\x49\104\40\x6f\162\x20\x45\156\143\162\x79\x70\164\145\144\111\104\40\x69\156\x20\x53\x41\x4d\114\40\122\x65\x73\x70\x6f\156\163\x65\x3c\x2f\160\x3e\15\12\40\x20\40\40\x20\40\x20\40\x20\40\40\x20\x20\40\40\40\x3c\x70\76\x50\154\x65\x61\163\x65\x20\x63\x6f\x6e\164\x61\x63\164\x20\171\157\x75\162\40\141\144\155\151\x6e\x69\x73\164\162\x61\x74\x6f\x72\x20\x61\156\x64\x20\x72\145\160\x6f\162\x74\40\x74\x68\x65\x20\146\157\x6c\x6c\157\167\151\x6e\x67\40\145\162\162\x6f\162\72\x3c\x2f\160\76\xd\xa\40\x20\40\40\x20\40\x20\40\x20\x20\40\40\40\x20\x20\40\x3c\x70\x3e\x3c\x73\164\162\157\x6e\x67\76\x50\x6f\163\x73\151\x62\x6c\x65\x20\103\141\x75\x73\145\72\74\x2f\x73\164\162\x6f\156\147\76\x20\x4e\141\155\145\111\104\40\156\x6f\164\40\x66\157\165\x6e\x64\x20\x69\x6e\x20\x53\x41\x4d\114\x20\x52\145\163\x70\157\x6e\163\x65\x20\163\165\142\x6a\x65\x63\164\74\57\x70\76\15\xa\40\x20\x20\x20\x20\x20\40\40\x20\x20\40\x20\40\x20\40\x20\x3c\57\x64\151\x76\76\xd\12\40\x20\40\x20\40\x20\x20\x20\40\x20\40\x20\40\x20\x20\x20\x3c\x64\x69\166\x20\x73\x74\x79\154\x65\x3d\42\155\141\162\147\x69\156\72\x33\x25\73\x64\x69\163\160\154\x61\171\72\x62\x6c\x6f\143\x6b\x3b\x74\145\170\164\55\x61\x6c\x69\147\x6e\72\x63\x65\x6e\164\145\162\x3b\x22\76\15\12\x20\40\40\x20\40\x20\40\x20\40\40\40\40\x20\40\x20\40\x3c\x64\x69\x76\40\x73\x74\171\x6c\145\75\x22\155\x61\x72\x67\151\156\72\63\45\73\x64\x69\x73\160\154\141\x79\72\x62\x6c\x6f\143\153\x3b\164\x65\170\164\55\x61\x6c\x69\147\156\x3a\x63\145\x6e\x74\x65\162\x3b\42\x3e\x3c\x69\x6e\160\x75\164\40\163\164\x79\x6c\x65\x3d\x22\160\141\144\x64\x69\x6e\147\x3a\61\x25\73\167\151\x64\164\150\x3a\x31\x30\60\160\x78\x3b\x62\141\x63\153\147\x72\x6f\x75\x6e\x64\72\40\43\60\60\71\x31\103\x44\40\156\x6f\x6e\x65\40\162\145\160\145\141\x74\40\x73\143\x72\x6f\154\x6c\x20\60\45\x20\x30\x25\x3b\143\165\x72\x73\157\x72\72\40\160\x6f\x69\x6e\x74\x65\x72\73\x66\157\156\164\x2d\x73\151\172\145\72\61\x35\x70\x78\x3b\x62\x6f\x72\144\145\x72\55\x77\x69\144\164\150\x3a\x20\61\160\170\x3b\x62\x6f\x72\x64\x65\162\55\163\164\171\x6c\145\72\x20\x73\x6f\x6c\x69\x64\73\x62\x6f\162\x64\x65\162\55\162\x61\144\x69\165\163\x3a\40\63\x70\170\x3b\167\x68\x69\x74\145\55\163\x70\x61\x63\145\x3a\40\x6e\x6f\x77\162\141\160\73\142\157\170\55\163\151\172\151\x6e\x67\72\40\x62\x6f\162\x64\145\162\x2d\x62\x6f\x78\73\142\157\162\144\x65\x72\55\143\157\x6c\x6f\162\72\x20\43\60\60\67\63\101\101\x3b\x62\157\x78\55\163\x68\141\144\x6f\167\x3a\40\60\x70\170\x20\x31\160\170\40\x30\x70\170\x20\x72\x67\142\141\x28\x31\62\x30\54\40\62\60\60\x2c\x20\x32\63\60\54\40\x30\56\x36\x29\40\151\156\x73\145\164\73\x63\x6f\154\x6f\162\72\x20\43\106\x46\x46\73\42\164\x79\160\145\75\42\x62\x75\164\164\157\156\42\40\166\141\154\x75\x65\75\42\x44\157\x6e\x65\x22\40\x6f\156\103\x6c\151\x63\x6b\75\x22\x73\145\154\x66\56\143\x6c\157\163\145\50\51\x3b\42\x3e\x3c\x2f\144\151\x76\x3e";
        exit;
        vU:
        goto MI;
        zF:
        throw new Exception("\115\x6f\162\x65\x20\x74\150\x61\156\40\157\x6e\x65\40\x3c\163\141\x6d\x6c\x3a\x4e\141\x6d\x65\x49\104\76\40\157\x72\40\74\163\141\x6d\154\x3a\105\156\x63\x72\171\160\x74\x65\144\104\76\x20\x69\x6e\40\x3c\163\141\155\154\x3a\x53\165\x62\x6a\x65\x63\164\76\56");
        MI:
        $Mo = $Mo[0];
        if ($Mo->localName === "\x45\156\x63\x72\x79\x70\x74\x65\x64\104\141\x74\141") {
            goto wv;
        }
        $this->nameId = Utilities::parseNameId($Mo);
        goto jR;
        wv:
        $this->encryptedNameId = $Mo;
        jR:
    }
    private function parseConditions(DOMElement $aa)
    {
        $Bm = Utilities::xpQuery($aa, "\x2e\57\163\x61\x6d\154\x5f\141\163\163\145\x72\x74\151\157\x6e\x3a\103\x6f\156\144\x69\x74\x69\157\x6e\163");
        if (empty($Bm)) {
            goto DW;
        }
        if (count($Bm) > 1) {
            goto Qo;
        }
        goto NB;
        DW:
        return;
        goto NB;
        Qo:
        throw new Exception("\115\157\162\145\x20\164\x68\141\156\x20\x6f\x6e\145\x20\74\x73\141\x6d\x6c\x3a\103\x6f\x6e\144\x69\x74\x69\x6f\x6e\x73\x3e\40\151\x6e\x20\74\x73\x61\x6d\154\72\101\x73\163\x65\x72\x74\151\157\156\x3e\56");
        NB:
        $Bm = $Bm[0];
        if (!$Bm->hasAttribute("\x4e\x6f\x74\102\145\x66\x6f\x72\x65")) {
            goto Iw;
        }
        $oo = Utilities::xsDateTimeToTimestamp($Bm->getAttribute("\x4e\x6f\x74\102\145\x66\x6f\162\x65"));
        if (!($this->notBefore === NULL || $this->notBefore < $oo)) {
            goto Fw;
        }
        $this->notBefore = $oo;
        Fw:
        Iw:
        if (!$Bm->hasAttribute("\116\157\x74\117\156\117\x72\101\x66\164\x65\x72")) {
            goto OW;
        }
        $VG = Utilities::xsDateTimeToTimestamp($Bm->getAttribute("\116\x6f\x74\x4f\x6e\117\x72\101\146\164\x65\162"));
        if (!($this->notOnOrAfter === NULL || $this->notOnOrAfter > $VG)) {
            goto zT;
        }
        $this->notOnOrAfter = $VG;
        zT:
        OW:
        $oe = $Bm->firstChild;
        D_:
        if (!($oe !== NULL)) {
            goto zK;
        }
        if (!$oe instanceof DOMText) {
            goto va;
        }
        goto TI;
        va:
        if (!($oe->namespaceURI !== "\x75\162\x6e\x3a\x6f\141\x73\151\x73\72\156\x61\155\145\x73\72\164\143\x3a\123\101\x4d\114\72\x32\56\x30\72\141\x73\163\145\x72\164\x69\157\156")) {
            goto MD;
        }
        throw new Exception("\x55\156\x6b\x6e\x6f\x77\x6e\x20\156\x61\155\145\163\x70\141\x63\145\40\157\146\40\x63\157\156\x64\x69\x74\x69\157\156\x3a\x20" . var_export($oe->namespaceURI, TRUE));
        MD:
        switch ($oe->localName) {
            case "\101\165\x64\x69\145\x6e\143\145\x52\145\x73\x74\x72\151\143\x74\151\x6f\x6e":
                $Lp = Utilities::extractStrings($oe, "\165\162\156\72\157\141\x73\151\x73\x3a\x6e\141\x6d\145\163\72\164\x63\72\x53\101\x4d\114\x3a\x32\56\x30\72\x61\163\163\145\x72\164\151\157\x6e", "\x41\165\144\151\x65\x6e\143\x65");
                if ($this->validAudiences === NULL) {
                    goto N3;
                }
                $this->validAudiences = array_intersect($this->validAudiences, $Lp);
                goto a0;
                N3:
                $this->validAudiences = $Lp;
                a0:
                goto fe;
            case "\x4f\x6e\x65\124\x69\155\x65\125\163\145":
                goto fe;
            case "\120\162\157\170\171\x52\x65\x73\164\x72\x69\143\x74\151\157\x6e":
                goto fe;
            default:
                throw new Exception("\125\x6e\x6b\156\x6f\x77\156\x20\143\x6f\156\x64\151\x74\151\x6f\156\72\40" . var_export($oe->localName, TRUE));
        }
        R1:
        fe:
        TI:
        $oe = $oe->nextSibling;
        goto D_;
        zK:
    }
    private function parseAuthnStatement(DOMElement $aa)
    {
        $AO = Utilities::xpQuery($aa, "\56\x2f\x73\141\x6d\x6c\137\141\x73\163\x65\162\164\151\x6f\x6e\72\101\x75\164\150\156\x53\x74\141\x74\x65\155\145\x6e\164");
        if (empty($AO)) {
            goto Cc;
        }
        if (count($AO) > 1) {
            goto mj;
        }
        goto st;
        Cc:
        $this->authnInstant = NULL;
        return;
        goto st;
        mj:
        throw new Exception("\x4d\157\x72\x65\40\164\150\x61\164\x20\x6f\156\145\40\x3c\x73\141\155\x6c\x3a\x41\x75\164\150\x6e\123\164\141\164\145\155\x65\156\x74\76\x20\x69\x6e\x20\74\163\x61\155\x6c\x3a\101\x73\x73\x65\x72\x74\151\157\156\x3e\40\x6e\157\x74\x20\x73\165\160\x70\x6f\162\164\145\x64\56");
        st:
        $Am = $AO[0];
        if ($Am->hasAttribute("\x41\165\x74\150\156\x49\156\x73\164\x61\x6e\164")) {
            goto yr;
        }
        throw new Exception("\115\151\163\163\x69\156\147\x20\x72\x65\161\x75\x69\162\x65\144\x20\101\x75\x74\x68\156\111\156\x73\164\x61\156\x74\40\x61\164\x74\x72\x69\142\165\164\145\x20\x6f\156\40\x3c\x73\141\155\x6c\x3a\x41\165\164\x68\156\123\x74\141\164\x65\155\x65\156\x74\x3e\x2e");
        yr:
        $this->authnInstant = Utilities::xsDateTimeToTimestamp($Am->getAttribute("\x41\x75\x74\x68\x6e\x49\x6e\x73\x74\141\156\164"));
        if (!$Am->hasAttribute("\x53\x65\x73\x73\151\x6f\156\x4e\x6f\x74\117\156\x4f\x72\101\x66\164\x65\162")) {
            goto LL;
        }
        $this->sessionNotOnOrAfter = Utilities::xsDateTimeToTimestamp($Am->getAttribute("\123\x65\x73\x73\151\157\156\116\157\164\117\156\117\162\101\x66\x74\x65\162"));
        LL:
        if (!$Am->hasAttribute("\x53\145\163\x73\151\x6f\x6e\111\156\144\x65\170")) {
            goto oa;
        }
        $this->sessionIndex = $Am->getAttribute("\x53\145\x73\163\151\x6f\156\x49\156\x64\x65\170");
        oa:
        $this->parseAuthnContext($Am);
    }
    private function parseAuthnContext(DOMElement $IT)
    {
        $sX = Utilities::xpQuery($IT, "\56\x2f\163\x61\155\154\137\141\x73\163\145\162\x74\151\x6f\x6e\72\101\x75\164\x68\x6e\103\x6f\156\x74\x65\170\x74");
        if (count($sX) > 1) {
            goto PI;
        }
        if (empty($sX)) {
            goto P0;
        }
        goto rn;
        PI:
        throw new Exception("\x4d\x6f\162\x65\x20\164\x68\141\156\x20\157\156\145\40\x3c\163\x61\155\x6c\72\x41\x75\164\x68\156\103\x6f\x6e\164\145\170\164\76\x20\x69\156\x20\74\163\141\x6d\154\72\x41\165\x74\x68\156\x53\164\141\164\x65\x6d\145\156\x74\x3e\56");
        goto rn;
        P0:
        throw new Exception("\115\x69\x73\163\x69\156\x67\x20\162\145\x71\x75\x69\162\145\x64\x20\x3c\163\x61\155\154\x3a\x41\165\164\150\156\x43\157\x6e\164\x65\x78\164\76\x20\x69\156\40\x3c\163\141\x6d\x6c\72\x41\x75\x74\x68\156\123\164\141\164\145\x6d\x65\156\164\76\x2e");
        rn:
        $tT = $sX[0];
        $U1 = Utilities::xpQuery($tT, "\56\x2f\163\x61\155\154\x5f\x61\x73\x73\145\162\164\151\157\156\72\x41\165\164\x68\156\x43\x6f\156\x74\145\170\x74\104\x65\143\154\x52\x65\x66");
        if (count($U1) > 1) {
            goto OI;
        }
        if (count($U1) === 1) {
            goto Sq;
        }
        goto ak;
        OI:
        throw new Exception("\115\157\x72\145\40\x74\x68\141\156\40\157\x6e\x65\x20\x3c\x73\x61\x6d\154\x3a\x41\x75\164\150\156\x43\157\x6e\164\145\170\x74\x44\x65\143\x6c\122\145\x66\76\x20\x66\157\165\156\144\77");
        goto ak;
        Sq:
        $this->setAuthnContextDeclRef(trim($U1[0]->textContent));
        ak:
        $lM = Utilities::xpQuery($tT, "\x2e\x2f\163\141\155\154\137\x61\163\163\x65\x72\164\x69\157\x6e\x3a\x41\x75\x74\x68\x6e\103\157\156\x74\x65\170\164\x44\145\x63\x6c");
        if (count($lM) > 1) {
            goto wx;
        }
        if (count($lM) === 1) {
            goto lO;
        }
        goto sy;
        wx:
        throw new Exception("\x4d\x6f\162\145\40\x74\150\141\x6e\x20\x6f\156\x65\x20\74\163\141\155\x6c\x3a\101\x75\x74\x68\156\x43\157\x6e\x74\145\x78\164\104\x65\143\x6c\x3e\x20\146\157\165\x6e\144\x3f");
        goto sy;
        lO:
        $this->setAuthnContextDecl(new SAML2_XML_Chunk($lM[0]));
        sy:
        $Ke = Utilities::xpQuery($tT, "\x2e\x2f\x73\141\155\154\137\x61\163\x73\145\162\x74\x69\x6f\156\72\x41\x75\x74\150\156\103\x6f\156\x74\145\170\164\x43\154\141\163\163\x52\145\x66");
        if (count($Ke) > 1) {
            goto Fc;
        }
        if (count($Ke) === 1) {
            goto t1;
        }
        goto NX;
        Fc:
        throw new Exception("\115\x6f\162\145\x20\x74\150\141\x6e\40\x6f\156\x65\40\74\163\141\x6d\x6c\72\x41\x75\164\x68\156\x43\157\x6e\x74\145\x78\164\103\x6c\141\x73\x73\x52\145\x66\76\40\x69\156\x20\74\163\x61\x6d\x6c\x3a\101\165\x74\x68\x6e\103\x6f\156\x74\145\x78\x74\x3e\56");
        goto NX;
        t1:
        $this->setAuthnContextClassRef(trim($Ke[0]->textContent));
        NX:
        if (!(empty($this->authnContextClassRef) && empty($this->authnContextDecl) && empty($this->authnContextDeclRef))) {
            goto iR;
        }
        throw new Exception("\x4d\151\163\163\151\156\147\x20\145\x69\164\x68\x65\x72\x20\x3c\163\x61\155\x6c\x3a\101\165\164\150\x6e\103\x6f\x6e\164\x65\170\164\103\x6c\x61\163\163\x52\145\146\x3e\x20\x6f\x72\x20\x3c\163\x61\155\154\x3a\x41\x75\164\150\156\103\157\x6e\x74\x65\x78\x74\104\145\x63\x6c\122\145\146\76\x20\x6f\162\x20\74\163\141\x6d\x6c\x3a\101\x75\164\x68\156\103\x6f\156\x74\145\x78\x74\104\145\x63\154\x3e");
        iR:
        $this->AuthenticatingAuthority = Utilities::extractStrings($tT, "\x75\162\156\72\157\141\163\x69\x73\72\x6e\141\x6d\x65\x73\72\164\143\x3a\x53\x41\115\x4c\x3a\62\x2e\x30\x3a\141\163\163\145\x72\x74\151\x6f\156", "\101\165\x74\x68\145\156\x74\151\143\141\x74\151\x6e\147\x41\x75\x74\150\157\162\151\164\x79");
    }
    private function parseAttributes(DOMElement $aa)
    {
        $fG = TRUE;
        $mk = Utilities::xpQuery($aa, "\x2e\x2f\163\141\x6d\x6c\x5f\x61\x73\163\145\162\164\x69\157\x6e\x3a\x41\x74\164\162\151\142\x75\x74\x65\123\x74\x61\x74\145\x6d\x65\x6e\164\57\x73\x61\x6d\x6c\137\x61\163\x73\x65\162\164\151\x6f\x6e\72\x41\164\x74\x72\151\142\165\x74\145");
        foreach ($mk as $QP) {
            if ($QP->hasAttribute("\x4e\141\x6d\145")) {
                goto iP;
            }
            throw new Exception("\x4d\151\163\163\151\x6e\147\x20\156\141\155\x65\40\157\156\x20\74\163\141\155\154\x3a\101\164\x74\162\151\142\165\164\x65\76\x20\x65\x6c\x65\x6d\145\156\164\56");
            iP:
            $vT = $QP->getAttribute("\116\x61\x6d\145");
            if ($QP->hasAttribute("\116\x61\155\x65\106\157\x72\x6d\141\164")) {
                goto z_;
            }
            $QG = "\x75\162\156\x3a\157\x61\x73\x69\x73\x3a\x6e\141\155\x65\x73\x3a\164\x63\x3a\x53\x41\115\x4c\72\x31\x2e\61\x3a\156\x61\x6d\145\151\x64\x2d\x66\x6f\x72\x6d\141\x74\72\165\x6e\x73\160\145\x63\151\x66\151\145\144";
            goto U4;
            z_:
            $QG = $QP->getAttribute("\116\141\155\145\x46\x6f\162\155\141\x74");
            U4:
            if ($fG) {
                goto lo;
            }
            if (!($this->nameFormat !== $QG)) {
                goto Wt;
            }
            $this->nameFormat = "\x75\162\x6e\x3a\x6f\141\x73\151\x73\72\156\141\x6d\x65\x73\x3a\x74\143\x3a\123\101\x4d\114\72\61\56\x31\x3a\x6e\x61\x6d\x65\x69\x64\x2d\146\157\162\x6d\141\x74\72\165\156\163\x70\x65\x63\151\146\151\145\144";
            Wt:
            goto qy;
            lo:
            $this->nameFormat = $QG;
            $fG = FALSE;
            qy:
            if (array_key_exists($vT, $this->attributes)) {
                goto hz;
            }
            $this->attributes[$vT] = array();
            hz:
            $Fs = Utilities::xpQuery($QP, "\56\x2f\x73\141\155\x6c\x5f\141\163\x73\145\x72\164\151\157\x6e\72\101\x74\x74\x72\x69\142\x75\x74\x65\x56\x61\154\x75\x65");
            foreach ($Fs as $d1) {
                $this->attributes[$vT][] = trim($d1->textContent);
                kZ:
            }
            ab:
            PN:
        }
        F5:
    }
    private function parseEncryptedAttributes(DOMElement $aa)
    {
        $this->encryptedAttribute = Utilities::xpQuery($aa, "\x2e\x2f\163\x61\155\154\137\x61\x73\x73\x65\x72\x74\151\157\156\72\101\164\x74\x72\151\142\165\164\x65\x53\x74\141\x74\145\x6d\x65\156\x74\57\x73\141\x6d\154\137\x61\163\x73\145\x72\164\x69\x6f\x6e\72\x45\156\x63\x72\x79\x70\164\145\144\x41\164\164\x72\151\142\165\164\145");
    }
    private function parseSignature(DOMElement $aa)
    {
        $p0 = Utilities::validateElement($aa);
        if (!($p0 !== FALSE)) {
            goto Uy;
        }
        $this->wasSignedAtConstruction = TRUE;
        $this->certificates = $p0["\x43\145\x72\164\x69\x66\x69\143\x61\164\145\163"];
        $this->signatureData = $p0;
        Uy:
    }
    public function validate(XMLSecurityKey $z5)
    {
        if (!($this->signatureData === NULL)) {
            goto X3;
        }
        return FALSE;
        X3:
        Utilities::validateSignature($this->signatureData, $z5);
        return TRUE;
    }
    public function getId()
    {
        return $this->id;
    }
    public function setId($Z_)
    {
        $this->id = $Z_;
    }
    public function getIssueInstant()
    {
        return $this->issueInstant;
    }
    public function setIssueInstant($Gx)
    {
        $this->issueInstant = $Gx;
    }
    public function getIssuer()
    {
        return $this->issuer;
    }
    public function setIssuer($pr)
    {
        $this->issuer = $pr;
    }
    public function getNameId()
    {
        if (!($this->encryptedNameId !== NULL)) {
            goto gq;
        }
        throw new Exception("\x41\164\x74\x65\155\160\164\x65\x64\40\164\x6f\x20\x72\x65\x74\162\x69\145\x76\x65\40\145\x6e\x63\162\x79\160\x74\x65\x64\40\x4e\141\x6d\145\111\104\x20\x77\151\164\x68\x6f\165\x74\x20\144\x65\x63\162\x79\x70\x74\x69\156\x67\40\x69\164\40\146\151\162\x73\x74\56");
        gq:
        return $this->nameId;
    }
    public function setNameId($Mo)
    {
        $this->nameId = $Mo;
    }
    public function isNameIdEncrypted()
    {
        if (!($this->encryptedNameId !== NULL)) {
            goto sv;
        }
        return TRUE;
        sv:
        return FALSE;
    }
    public function encryptNameId(XMLSecurityKey $z5)
    {
        $YP = new DOMDocument();
        $FC = $YP->createElement("\162\x6f\x6f\x74");
        $YP->appendChild($FC);
        Utilities::addNameId($FC, $this->nameId);
        $Mo = $FC->firstChild;
        Utilities::getContainer()->debugMessage($Mo, "\x65\156\143\x72\x79\x70\164");
        $Cb = new XMLSecEnc();
        $Cb->setNode($Mo);
        $Cb->type = XMLSecEnc::Element;
        $i5 = new XMLSecurityKey(XMLSecurityKey::AES128_CBC);
        $i5->generateSessionKey();
        $Cb->encryptKey($z5, $i5);
        $this->encryptedNameId = $Cb->encryptNode($i5);
        $this->nameId = NULL;
    }
    public function decryptNameId(XMLSecurityKey $z5, array $BC = array())
    {
        if (!($this->encryptedNameId === NULL)) {
            goto MR;
        }
        return;
        MR:
        $Mo = Utilities::decryptElement($this->encryptedNameId, $z5, $BC);
        Utilities::getContainer()->debugMessage($Mo, "\144\145\x63\x72\x79\160\x74");
        $this->nameId = Utilities::parseNameId($Mo);
        $this->encryptedNameId = NULL;
    }
    public function decryptAttributes(XMLSecurityKey $z5, array $BC = array())
    {
        if (!($this->encryptedAttribute === NULL)) {
            goto SD;
        }
        return;
        SD:
        $fG = TRUE;
        $mk = $this->encryptedAttribute;
        foreach ($mk as $xF) {
            $QP = Utilities::decryptElement($xF->getElementsByTagName("\105\156\143\x72\171\x70\164\x65\144\104\141\164\141")->item(0), $z5, $BC);
            if ($QP->hasAttribute("\116\x61\x6d\x65")) {
                goto nf;
            }
            throw new Exception("\x4d\x69\x73\x73\x69\x6e\147\x20\156\141\x6d\x65\40\157\x6e\40\x3c\x73\141\x6d\x6c\72\x41\x74\164\162\151\x62\x75\164\145\x3e\x20\145\x6c\145\x6d\145\x6e\x74\56");
            nf:
            $vT = $QP->getAttribute("\116\141\x6d\x65");
            if ($QP->hasAttribute("\x4e\141\155\145\x46\x6f\162\x6d\x61\164")) {
                goto fO;
            }
            $QG = "\165\162\156\72\157\141\163\151\163\x3a\x6e\x61\155\145\163\72\x74\x63\x3a\x53\x41\115\x4c\72\62\x2e\60\x3a\141\x74\x74\x72\x6e\x61\x6d\x65\x2d\146\x6f\x72\x6d\141\x74\x3a\x75\156\x73\160\x65\143\151\146\x69\145\144";
            goto cY;
            fO:
            $QG = $QP->getAttribute("\116\141\155\x65\x46\157\162\x6d\x61\164");
            cY:
            if ($fG) {
                goto Zv;
            }
            if (!($this->nameFormat !== $QG)) {
                goto Yj;
            }
            $this->nameFormat = "\x75\162\x6e\x3a\157\x61\x73\151\x73\x3a\x6e\x61\155\x65\163\x3a\164\143\72\123\x41\115\114\72\x32\x2e\60\72\x61\x74\164\162\156\141\155\145\55\x66\157\x72\x6d\141\x74\x3a\165\x6e\x73\160\x65\143\151\x66\x69\145\144";
            Yj:
            goto pq;
            Zv:
            $this->nameFormat = $QG;
            $fG = FALSE;
            pq:
            if (array_key_exists($vT, $this->attributes)) {
                goto Zt;
            }
            $this->attributes[$vT] = array();
            Zt:
            $Fs = Utilities::xpQuery($QP, "\56\57\x73\x61\x6d\154\137\x61\163\163\145\162\x74\x69\157\156\72\x41\x74\164\x72\x69\x62\165\x74\x65\126\x61\x6c\x75\145");
            foreach ($Fs as $d1) {
                $this->attributes[$vT][] = trim($d1->textContent);
                um:
            }
            LT:
            QW:
        }
        KW:
    }
    public function getNotBefore()
    {
        return $this->notBefore;
    }
    public function setNotBefore($oo)
    {
        $this->notBefore = $oo;
    }
    public function getNotOnOrAfter()
    {
        return $this->notOnOrAfter;
    }
    public function setNotOnOrAfter($VG)
    {
        $this->notOnOrAfter = $VG;
    }
    public function setEncryptedAttributes($ex)
    {
        $this->requiredEncAttributes = $ex;
    }
    public function getValidAudiences()
    {
        return $this->validAudiences;
    }
    public function setValidAudiences(array $Jy = NULL)
    {
        $this->validAudiences = $Jy;
    }
    public function getAuthnInstant()
    {
        return $this->authnInstant;
    }
    public function setAuthnInstant($Al)
    {
        $this->authnInstant = $Al;
    }
    public function getSessionNotOnOrAfter()
    {
        return $this->sessionNotOnOrAfter;
    }
    public function setSessionNotOnOrAfter($gm)
    {
        $this->sessionNotOnOrAfter = $gm;
    }
    public function getSessionIndex()
    {
        return $this->sessionIndex;
    }
    public function setSessionIndex($UP)
    {
        $this->sessionIndex = $UP;
    }
    public function getAuthnContext()
    {
        if (empty($this->authnContextClassRef)) {
            goto IH;
        }
        return $this->authnContextClassRef;
        IH:
        if (empty($this->authnContextDeclRef)) {
            goto Zw;
        }
        return $this->authnContextDeclRef;
        Zw:
        return NULL;
    }
    public function setAuthnContext($Ve)
    {
        $this->setAuthnContextClassRef($Ve);
    }
    public function getAuthnContextClassRef()
    {
        return $this->authnContextClassRef;
    }
    public function setAuthnContextClassRef($iQ)
    {
        $this->authnContextClassRef = $iQ;
    }
    public function setAuthnContextDecl(SAML2_XML_Chunk $BQ)
    {
        if (empty($this->authnContextDeclRef)) {
            goto QV;
        }
        throw new Exception("\x41\165\164\150\156\x43\x6f\x6e\x74\145\x78\164\104\x65\143\154\x52\x65\x66\40\151\x73\40\141\154\x72\145\141\x64\171\x20\x72\145\x67\151\x73\x74\x65\x72\x65\x64\41\40\115\141\171\40\157\156\x6c\171\40\150\x61\x76\x65\40\145\x69\164\x68\145\162\40\x61\40\x44\x65\x63\154\40\x6f\x72\40\141\x20\104\x65\143\x6c\x52\x65\146\54\x20\x6e\157\164\40\142\x6f\164\x68\41");
        QV:
        $this->authnContextDecl = $BQ;
    }
    public function getAuthnContextDecl()
    {
        return $this->authnContextDecl;
    }
    public function setAuthnContextDeclRef($Fc)
    {
        if (empty($this->authnContextDecl)) {
            goto YJ;
        }
        throw new Exception("\x41\x75\x74\x68\156\x43\x6f\x6e\164\145\x78\x74\104\145\143\x6c\40\151\163\40\x61\154\x72\x65\x61\144\171\40\162\x65\147\x69\163\164\x65\162\145\144\x21\40\115\141\171\x20\157\x6e\154\x79\x20\150\141\x76\x65\x20\145\151\x74\150\x65\162\x20\141\x20\104\145\x63\154\40\157\x72\40\x61\x20\104\145\x63\154\x52\x65\x66\x2c\x20\156\157\164\40\x62\157\x74\x68\41");
        YJ:
        $this->authnContextDeclRef = $Fc;
    }
    public function getAuthnContextDeclRef()
    {
        return $this->authnContextDeclRef;
    }
    public function getAuthenticatingAuthority()
    {
        return $this->AuthenticatingAuthority;
    }
    public function setAuthenticatingAuthority($DG)
    {
        $this->AuthenticatingAuthority = $DG;
    }
    public function getAttributes()
    {
        return $this->attributes;
    }
    public function setAttributes(array $mk)
    {
        $this->attributes = $mk;
    }
    public function getAttributeNameFormat()
    {
        return $this->nameFormat;
    }
    public function setAttributeNameFormat($QG)
    {
        $this->nameFormat = $QG;
    }
    public function getSubjectConfirmation()
    {
        return $this->SubjectConfirmation;
    }
    public function setSubjectConfirmation(array $VL)
    {
        $this->SubjectConfirmation = $VL;
    }
    public function getSignatureKey()
    {
        return $this->signatureKey;
    }
    public function setSignatureKey(XMLsecurityKey $bY = NULL)
    {
        $this->signatureKey = $bY;
    }
    public function getEncryptionKey()
    {
        return $this->encryptionKey;
    }
    public function setEncryptionKey(XMLSecurityKey $Xr = NULL)
    {
        $this->encryptionKey = $Xr;
    }
    public function setCertificates(array $mn)
    {
        $this->certificates = $mn;
    }
    public function getCertificates()
    {
        return $this->certificates;
    }
    public function getSignatureData()
    {
        return $this->signatureData;
    }
    public function getWasSignedAtConstruction()
    {
        return $this->wasSignedAtConstruction;
    }
    public function toXML(DOMNode $lq = NULL)
    {
        if ($lq === NULL) {
            goto hb;
        }
        $AI = $lq->ownerDocument;
        goto t7;
        hb:
        $AI = new DOMDocument();
        $lq = $AI;
        t7:
        $FC = $AI->createElementNS("\x75\x72\156\x3a\x6f\141\163\151\163\72\x6e\x61\x6d\x65\x73\x3a\x74\x63\x3a\x53\101\115\x4c\72\x32\56\x30\x3a\x61\163\x73\x65\x72\164\x69\x6f\156", "\163\141\x6d\x6c\72" . "\101\163\x73\x65\162\164\x69\x6f\x6e");
        $lq->appendChild($FC);
        $FC->setAttributeNS("\x75\162\x6e\x3a\157\141\163\151\163\x3a\156\x61\155\145\x73\72\x74\x63\x3a\123\x41\115\x4c\72\62\x2e\60\x3a\x70\x72\x6f\x74\x6f\143\x6f\x6c", "\x73\x61\155\x6c\160\72\x74\x6d\x70", "\164\155\x70");
        $FC->removeAttributeNS("\x75\x72\156\72\157\x61\163\151\x73\72\156\141\155\x65\x73\72\x74\x63\72\x53\x41\115\114\72\62\56\x30\72\160\x72\157\x74\157\x63\157\154", "\x74\x6d\160");
        $FC->setAttributeNS("\150\164\164\160\72\x2f\57\x77\167\167\56\167\x33\x2e\x6f\x72\x67\57\62\x30\60\61\x2f\x58\x4d\x4c\123\x63\x68\145\155\141\x2d\x69\156\x73\x74\x61\156\143\145", "\170\x73\x69\x3a\164\155\160", "\164\155\160");
        $FC->removeAttributeNS("\x68\164\164\160\x3a\57\57\167\x77\x77\x2e\167\63\56\x6f\162\x67\x2f\62\60\x30\x31\57\130\x4d\114\x53\143\x68\145\155\x61\55\151\x6e\163\164\x61\156\x63\145", "\x74\x6d\x70");
        $FC->setAttributeNS("\150\x74\164\x70\72\57\57\x77\x77\167\56\167\63\56\x6f\162\147\x2f\x32\x30\x30\61\57\x58\115\114\x53\143\150\145\155\x61", "\170\163\72\x74\155\x70", "\164\155\x70");
        $FC->removeAttributeNS("\x68\x74\164\x70\x3a\x2f\x2f\167\167\x77\x2e\167\63\x2e\157\162\147\57\x32\60\60\x31\x2f\130\115\114\x53\x63\150\145\155\141", "\164\155\x70");
        $FC->setAttribute("\111\x44", $this->id);
        $FC->setAttribute("\x56\145\x72\x73\151\x6f\156", "\62\x2e\60");
        $FC->setAttribute("\111\x73\163\x75\x65\x49\x6e\163\164\141\156\164", gmdate("\x59\x2d\x6d\55\144\134\x54\x48\72\x69\72\163\134\132", $this->issueInstant));
        $pr = Utilities::addString($FC, "\165\162\x6e\72\157\141\163\151\x73\x3a\x6e\141\155\145\163\x3a\x74\x63\x3a\x53\x41\x4d\x4c\x3a\x32\56\x30\x3a\x61\x73\163\x65\x72\164\x69\157\x6e", "\163\x61\155\x6c\72\x49\163\x73\x75\x65\162", $this->issuer);
        $this->addSubject($FC);
        $this->addConditions($FC);
        $this->addAuthnStatement($FC);
        if ($this->requiredEncAttributes == FALSE) {
            goto cH;
        }
        $this->addEncryptedAttributeStatement($FC);
        goto oU;
        cH:
        $this->addAttributeStatement($FC);
        oU:
        if (!($this->signatureKey !== NULL)) {
            goto jx;
        }
        Utilities::insertSignature($this->signatureKey, $this->certificates, $FC, $pr->nextSibling);
        jx:
        return $FC;
    }
    private function addSubject(DOMElement $FC)
    {
        if (!($this->nameId === NULL && $this->encryptedNameId === NULL)) {
            goto Jm;
        }
        return;
        Jm:
        $Hb = $FC->ownerDocument->createElementNS("\165\162\156\72\x6f\x61\x73\151\x73\x3a\156\141\x6d\145\163\x3a\164\143\72\x53\101\x4d\114\x3a\x32\x2e\60\x3a\x61\163\x73\x65\162\x74\151\x6f\156", "\163\x61\155\154\72\x53\x75\x62\x6a\145\143\x74");
        $FC->appendChild($Hb);
        if ($this->encryptedNameId === NULL) {
            goto N6;
        }
        $hZ = $Hb->ownerDocument->createElementNS("\165\162\x6e\72\x6f\x61\163\x69\x73\72\156\x61\155\145\x73\72\x74\143\72\x53\x41\x4d\114\72\62\x2e\60\x3a\141\x73\x73\145\x72\164\x69\x6f\156", "\163\x61\x6d\154\x3a" . "\x45\x6e\x63\x72\171\x70\x74\x65\x64\x49\x44");
        $Hb->appendChild($hZ);
        $hZ->appendChild($Hb->ownerDocument->importNode($this->encryptedNameId, TRUE));
        goto aj;
        N6:
        Utilities::addNameId($Hb, $this->nameId);
        aj:
        foreach ($this->SubjectConfirmation as $Ga) {
            $Ga->toXML($Hb);
            J5:
        }
        Qt:
    }
    private function addConditions(DOMElement $FC)
    {
        $AI = $FC->ownerDocument;
        $Bm = $AI->createElementNS("\x75\162\156\72\x6f\x61\163\151\x73\x3a\x6e\x61\155\145\163\72\x74\143\72\123\101\115\114\72\x32\x2e\x30\72\x61\x73\163\145\162\x74\151\x6f\156", "\x73\x61\155\154\x3a\x43\x6f\156\144\151\x74\151\x6f\156\x73");
        $FC->appendChild($Bm);
        if (!($this->notBefore !== NULL)) {
            goto LP;
        }
        $Bm->setAttribute("\x4e\157\x74\x42\x65\146\x6f\162\x65", gmdate("\x59\55\155\55\144\x5c\124\110\x3a\x69\72\163\134\132", $this->notBefore));
        LP:
        if (!($this->notOnOrAfter !== NULL)) {
            goto Rx;
        }
        $Bm->setAttribute("\x4e\157\x74\117\x6e\x4f\x72\101\146\164\x65\162", gmdate("\131\x2d\155\x2d\x64\134\124\110\x3a\151\x3a\163\134\x5a", $this->notOnOrAfter));
        Rx:
        if (!($this->validAudiences !== NULL)) {
            goto Rd;
        }
        $BS = $AI->createElementNS("\x75\x72\156\x3a\157\141\163\151\163\72\x6e\141\x6d\145\x73\x3a\x74\x63\x3a\x53\x41\x4d\x4c\72\x32\56\60\72\141\163\x73\145\162\164\x69\157\x6e", "\x73\141\155\x6c\x3a\x41\165\144\151\145\x6e\143\x65\x52\145\163\164\162\151\143\164\x69\157\x6e");
        $Bm->appendChild($BS);
        Utilities::addStrings($BS, "\x75\x72\156\72\x6f\x61\163\151\163\72\x6e\x61\155\145\163\x3a\x74\143\x3a\x53\x41\x4d\x4c\x3a\62\x2e\x30\x3a\x61\x73\x73\x65\x72\164\151\x6f\156", "\x73\141\x6d\154\72\x41\x75\x64\151\x65\156\143\x65", FALSE, $this->validAudiences);
        Rd:
    }
    private function addAuthnStatement(DOMElement $FC)
    {
        if (!($this->authnInstant === NULL || $this->authnContextClassRef === NULL && $this->authnContextDecl === NULL && $this->authnContextDeclRef === NULL)) {
            goto vc;
        }
        return;
        vc:
        $AI = $FC->ownerDocument;
        $IT = $AI->createElementNS("\x75\162\x6e\72\x6f\x61\x73\151\163\72\156\x61\155\145\x73\72\x74\x63\x3a\x53\x41\115\114\72\62\56\x30\72\141\x73\x73\145\x72\164\151\x6f\156", "\163\x61\x6d\154\72\x41\165\164\150\x6e\x53\x74\141\x74\x65\x6d\x65\x6e\164");
        $FC->appendChild($IT);
        $IT->setAttribute("\101\x75\x74\150\156\x49\x6e\x73\164\x61\156\164", gmdate("\x59\55\155\x2d\144\x5c\x54\x48\x3a\151\x3a\163\x5c\x5a", $this->authnInstant));
        if (!($this->sessionNotOnOrAfter !== NULL)) {
            goto F0;
        }
        $IT->setAttribute("\123\145\163\x73\x69\157\156\116\157\164\x4f\x6e\x4f\162\101\x66\x74\145\x72", gmdate("\x59\55\155\x2d\144\x5c\124\110\x3a\x69\72\163\134\x5a", $this->sessionNotOnOrAfter));
        F0:
        if (!($this->sessionIndex !== NULL)) {
            goto G6;
        }
        $IT->setAttribute("\123\x65\x73\x73\x69\x6f\156\x49\156\144\x65\170", $this->sessionIndex);
        G6:
        $tT = $AI->createElementNS("\165\x72\x6e\72\x6f\141\x73\x69\x73\x3a\156\x61\x6d\x65\163\x3a\x74\x63\x3a\x53\101\115\x4c\72\x32\56\x30\72\141\163\x73\x65\162\164\151\x6f\156", "\x73\x61\155\154\x3a\x41\x75\164\150\x6e\103\x6f\x6e\x74\145\170\x74");
        $IT->appendChild($tT);
        if (empty($this->authnContextClassRef)) {
            goto xO;
        }
        Utilities::addString($tT, "\x75\162\156\72\157\x61\163\x69\x73\x3a\156\x61\155\x65\x73\72\164\143\72\x53\x41\x4d\114\72\62\x2e\x30\x3a\x61\x73\x73\145\x72\x74\151\157\x6e", "\x73\x61\x6d\x6c\72\101\165\x74\x68\x6e\103\x6f\156\164\x65\170\164\103\x6c\x61\x73\x73\x52\x65\x66", $this->authnContextClassRef);
        xO:
        if (empty($this->authnContextDecl)) {
            goto MB;
        }
        $this->authnContextDecl->toXML($tT);
        MB:
        if (empty($this->authnContextDeclRef)) {
            goto HU;
        }
        Utilities::addString($tT, "\165\162\x6e\x3a\157\x61\163\x69\x73\72\156\x61\x6d\x65\x73\x3a\x74\x63\x3a\123\x41\x4d\114\x3a\x32\56\60\x3a\x61\x73\x73\145\x72\164\151\157\x6e", "\x73\x61\x6d\154\x3a\x41\x75\164\x68\156\x43\x6f\156\x74\145\170\164\104\145\143\154\x52\145\x66", $this->authnContextDeclRef);
        HU:
        Utilities::addStrings($tT, "\x75\x72\x6e\x3a\157\x61\x73\x69\163\72\x6e\x61\x6d\x65\x73\x3a\x74\143\72\x53\x41\x4d\x4c\72\62\x2e\60\x3a\141\x73\x73\x65\162\164\x69\157\156", "\x73\x61\x6d\154\72\x41\x75\164\x68\145\x6e\164\x69\143\x61\164\151\x6e\147\x41\x75\x74\150\157\162\151\x74\x79", FALSE, $this->AuthenticatingAuthority);
    }
    private function addAttributeStatement(DOMElement $FC)
    {
        if (!empty($this->attributes)) {
            goto T4;
        }
        return;
        T4:
        $AI = $FC->ownerDocument;
        $TA = $AI->createElementNS("\165\x72\x6e\x3a\157\141\163\x69\163\72\156\x61\155\145\163\x3a\x74\143\72\x53\x41\x4d\x4c\72\62\x2e\x30\x3a\x61\x73\163\x65\x72\164\x69\x6f\156", "\x73\141\155\x6c\72\x41\x74\164\162\151\x62\165\164\x65\x53\164\x61\164\x65\x6d\x65\156\164");
        $FC->appendChild($TA);
        foreach ($this->attributes as $vT => $Fs) {
            $QP = $AI->createElementNS("\165\162\156\72\x6f\x61\x73\151\x73\72\x6e\141\155\145\x73\x3a\164\x63\x3a\x53\101\115\114\x3a\62\x2e\60\72\x61\163\163\x65\162\164\151\157\x6e", "\x73\141\x6d\154\72\x41\x74\x74\x72\x69\142\x75\164\x65");
            $TA->appendChild($QP);
            $QP->setAttribute("\x4e\x61\x6d\145", $vT);
            if (!($this->nameFormat !== "\x75\x72\156\x3a\x6f\141\163\151\163\72\x6e\141\155\x65\x73\x3a\164\143\72\x53\101\x4d\114\72\62\56\60\x3a\141\164\164\162\x6e\141\155\145\55\x66\x6f\x72\x6d\x61\164\x3a\165\156\163\160\145\143\151\x66\151\145\x64")) {
                goto D8;
            }
            $QP->setAttribute("\116\x61\x6d\x65\106\x6f\x72\155\x61\164", $this->nameFormat);
            D8:
            foreach ($Fs as $d1) {
                if (is_string($d1)) {
                    goto n2;
                }
                if (is_int($d1)) {
                    goto s9;
                }
                $E8 = NULL;
                goto Hr;
                n2:
                $E8 = "\170\x73\72\x73\164\162\x69\x6e\x67";
                goto Hr;
                s9:
                $E8 = "\x78\163\x3a\x69\x6e\x74\x65\x67\x65\162";
                Hr:
                $S3 = $AI->createElementNS("\165\162\156\72\157\x61\x73\x69\x73\x3a\156\141\155\x65\x73\72\164\143\72\x53\101\x4d\114\x3a\62\56\x30\x3a\141\163\163\x65\x72\164\x69\157\x6e", "\x73\141\x6d\154\72\101\164\x74\162\151\x62\x75\x74\x65\126\141\x6c\165\145");
                $QP->appendChild($S3);
                if (!($E8 !== NULL)) {
                    goto h5;
                }
                $S3->setAttributeNS("\150\164\x74\160\x3a\57\57\167\x77\167\56\167\63\56\x6f\x72\147\x2f\x32\60\x30\61\x2f\x58\115\x4c\123\x63\150\x65\155\141\x2d\151\156\x73\164\141\x6e\143\145", "\170\163\x69\x3a\x74\171\x70\145", $E8);
                h5:
                if (!is_null($d1)) {
                    goto BK;
                }
                $S3->setAttributeNS("\x68\164\164\x70\72\57\57\x77\167\x77\56\x77\63\56\x6f\x72\147\57\62\60\x30\61\57\130\115\114\123\x63\150\145\x6d\x61\55\151\156\x73\x74\x61\156\x63\x65", "\170\163\151\x3a\156\x69\x6c", "\x74\162\165\x65");
                BK:
                if ($d1 instanceof DOMNodeList) {
                    goto Kx;
                }
                $S3->appendChild($AI->createTextNode($d1));
                goto vj;
                Kx:
                $Nw = 0;
                bB:
                if (!($Nw < $d1->length)) {
                    goto Dd;
                }
                $oe = $AI->importNode($d1->item($Nw), TRUE);
                $S3->appendChild($oe);
                sW:
                $Nw++;
                goto bB;
                Dd:
                vj:
                NS:
            }
            ky:
            jJ:
        }
        GO:
    }
    private function addEncryptedAttributeStatement(DOMElement $FC)
    {
        if (!($this->requiredEncAttributes == FALSE)) {
            goto cP;
        }
        return;
        cP:
        $AI = $FC->ownerDocument;
        $TA = $AI->createElementNS("\x75\x72\156\x3a\157\141\163\x69\x73\72\x6e\x61\x6d\x65\x73\x3a\x74\x63\x3a\123\101\x4d\x4c\x3a\x32\56\60\72\x61\x73\x73\145\x72\x74\x69\157\x6e", "\x73\x61\x6d\x6c\72\101\164\164\x72\x69\142\165\x74\x65\x53\x74\141\x74\145\155\145\x6e\164");
        $FC->appendChild($TA);
        foreach ($this->attributes as $vT => $Fs) {
            $DY = new DOMDocument();
            $QP = $DY->createElementNS("\165\162\x6e\72\157\141\x73\151\163\72\x6e\141\155\x65\163\72\164\143\72\x53\x41\x4d\114\x3a\62\56\x30\x3a\x61\163\x73\145\162\164\151\x6f\x6e", "\163\x61\x6d\154\x3a\101\x74\x74\x72\x69\x62\x75\x74\145");
            $QP->setAttribute("\116\x61\x6d\x65", $vT);
            $DY->appendChild($QP);
            if (!($this->nameFormat !== "\x75\x72\156\x3a\157\x61\x73\x69\x73\x3a\156\x61\x6d\x65\x73\x3a\x74\x63\x3a\x53\x41\x4d\x4c\x3a\x32\56\60\x3a\141\164\x74\x72\x6e\141\x6d\x65\55\x66\x6f\162\x6d\x61\164\x3a\165\156\x73\x70\x65\143\151\146\x69\x65\x64")) {
                goto hL;
            }
            $QP->setAttribute("\116\141\155\x65\106\157\162\x6d\141\x74", $this->nameFormat);
            hL:
            foreach ($Fs as $d1) {
                if (is_string($d1)) {
                    goto nl;
                }
                if (is_int($d1)) {
                    goto ro;
                }
                $E8 = NULL;
                goto KJ;
                nl:
                $E8 = "\x78\163\x3a\163\164\162\151\x6e\147";
                goto KJ;
                ro:
                $E8 = "\170\x73\x3a\x69\x6e\164\145\x67\x65\x72";
                KJ:
                $S3 = $DY->createElementNS("\x75\x72\156\72\157\141\x73\x69\x73\x3a\x6e\x61\x6d\x65\x73\x3a\x74\x63\72\x53\101\115\114\72\x32\x2e\x30\72\x61\163\x73\x65\162\x74\151\x6f\156", "\x73\x61\155\x6c\72\101\164\164\x72\x69\x62\165\164\145\126\141\x6c\x75\x65");
                $QP->appendChild($S3);
                if (!($E8 !== NULL)) {
                    goto x1;
                }
                $S3->setAttributeNS("\x68\x74\x74\160\72\57\x2f\167\x77\x77\x2e\x77\63\x2e\x6f\x72\x67\x2f\62\x30\60\x31\57\x58\x4d\x4c\x53\143\150\145\155\141\55\x69\x6e\163\164\x61\156\x63\145", "\170\163\x69\x3a\x74\x79\160\145", $E8);
                x1:
                if ($d1 instanceof DOMNodeList) {
                    goto Tl;
                }
                $S3->appendChild($DY->createTextNode($d1));
                goto oK;
                Tl:
                $Nw = 0;
                Qd:
                if (!($Nw < $d1->length)) {
                    goto vr;
                }
                $oe = $DY->importNode($d1->item($Nw), TRUE);
                $S3->appendChild($oe);
                DT:
                $Nw++;
                goto Qd;
                vr:
                oK:
                gx:
            }
            QS:
            $BA = new XMLSecEnc();
            $BA->setNode($DY->documentElement);
            $BA->type = "\x68\x74\164\x70\72\x2f\x2f\167\x77\x77\56\x77\x33\56\x6f\162\x67\x2f\x32\x30\x30\61\57\60\64\x2f\x78\x6d\x6c\145\x6e\x63\x23\x45\x6c\x65\x6d\145\x6e\164";
            $i5 = new XMLSecurityKey(XMLSecurityKey::AES256_CBC);
            $i5->generateSessionKey();
            $BA->encryptKey($this->encryptionKey, $i5);
            $z3 = $BA->encryptNode($i5);
            $Kx = $AI->createElementNS("\165\162\156\72\157\x61\x73\x69\163\x3a\156\141\155\145\x73\72\x74\143\72\x53\101\x4d\x4c\x3a\62\56\x30\x3a\x61\x73\163\145\x72\164\151\157\156", "\163\x61\155\x6c\72\105\156\143\162\171\160\164\145\144\101\x74\x74\x72\151\x62\165\x74\x65");
            $TA->appendChild($Kx);
            $eE = $AI->importNode($z3, TRUE);
            $Kx->appendChild($eE);
            fA:
        }
        uN:
    }
    public function getPrivateKeyUrl()
    {
        return $this->privateKeyUrl;
    }
    public function setPrivateKeyUrl($zq)
    {
        $this->privateKeyUrl = $zq;
    }
}
