<?php


if (defined("\x57\x50\111\116\103")) {
    goto u3;
}
die;
u3:
