<?php


if (defined("\x57\120\x49\116\x43")) {
    goto Xb;
}
die;
Xb:
