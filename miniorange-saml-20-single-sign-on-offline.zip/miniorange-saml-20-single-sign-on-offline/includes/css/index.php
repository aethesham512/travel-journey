<?php


if (defined("\x57\x50\x49\x4e\103")) {
    goto Oi;
}
die;
Oi:
