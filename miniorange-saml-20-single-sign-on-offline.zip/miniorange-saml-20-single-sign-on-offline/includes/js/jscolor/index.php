<?php


if (defined("\x57\120\111\x4e\103")) {
    goto f3;
}
die;
f3:
