<?php


if (defined("\127\120\111\116\103")) {
    goto Ci;
}
die;
Ci:
