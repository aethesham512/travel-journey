<?php


abstract class BasicEnum
{
    private static $constCacheArray = NULL;
    public static function getConstants()
    {
        if (!(self::$constCacheArray == NULL)) {
            goto nd;
        }
        self::$constCacheArray = array();
        nd:
        $PC = get_called_class();
        if (array_key_exists($PC, self::$constCacheArray)) {
            goto Q_;
        }
        $lB = new ReflectionClass($PC);
        self::$constCacheArray[$PC] = $lB->getConstants();
        Q_:
        return self::$constCacheArray[$PC];
    }
    public static function isValidName($vT, $iz = false)
    {
        $ND = self::getConstants();
        if (!$iz) {
            goto IP;
        }
        return array_key_exists($vT, $ND);
        IP:
        $e_ = array_map("\x73\x74\162\164\x6f\x6c\x6f\167\x65\162", array_keys($ND));
        return in_array(strtolower($vT), $e_);
    }
    public static function isValidValue($d1, $iz = true)
    {
        $Fs = array_values(self::getConstants());
        return in_array($d1, $Fs, $iz);
    }
}
