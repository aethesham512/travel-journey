<?php


if (defined("\x57\120\111\x4e\x43")) {
    goto Pj;
}
die;
Pj:
