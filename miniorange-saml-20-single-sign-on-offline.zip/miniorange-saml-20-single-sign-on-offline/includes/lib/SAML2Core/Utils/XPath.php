<?php


namespace RobRichards\XMLSecLibs\Utils;

class XPath
{
    const ALPHANUMERIC = "\134\x77\x5c\x64";
    const NUMERIC = "\134\x64";
    const LETTERS = "\x5c\167";
    const EXTENDED_ALPHANUMERIC = "\134\167\x5c\x64\x5c\163\x5c\x2d\x5f\72\134\56";
    const SINGLE_QUOTE = "\47";
    const DOUBLE_QUOTE = "\x22";
    const ALL_QUOTES = "\x5b\x27\x22\x5d";
    public static function filterAttrValue($d1, $wW = self::ALL_QUOTES)
    {
        return preg_replace("\43" . $wW . "\x23", '', $d1);
    }
    public static function filterAttrName($vT, $PH = self::EXTENDED_ALPHANUMERIC)
    {
        return preg_replace("\43\133\x5e" . $PH . "\135\43", '', $vT);
    }
}
