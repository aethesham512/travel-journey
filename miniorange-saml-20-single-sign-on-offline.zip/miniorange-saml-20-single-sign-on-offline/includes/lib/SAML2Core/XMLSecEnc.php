<?php


namespace RobRichards\XMLSecLibs;

use DOMDocument;
use DOMNode;
use DOMXPath;
use Exception;
use RobRichards\XMLSecLibs\Utils\XPath as XPath;
class XMLSecEnc
{
    const template = "\74\x78\145\x6e\143\x3a\x45\156\x63\162\x79\160\x74\x65\x64\x44\141\164\141\x20\170\155\x6c\156\x73\72\170\145\x6e\143\x3d\x27\x68\x74\164\160\72\x2f\57\x77\167\167\x2e\167\x33\56\157\162\147\57\62\60\x30\61\x2f\x30\64\57\x78\x6d\154\145\x6e\x63\x23\x27\x3e\xd\12\40\x20\x20\x3c\170\x65\x6e\x63\72\x43\x69\x70\150\x65\162\104\141\x74\141\76\xd\xa\40\40\x20\40\40\x20\74\x78\145\156\143\x3a\x43\x69\160\x68\x65\162\126\141\x6c\x75\x65\76\74\57\170\145\156\x63\x3a\x43\x69\x70\x68\x65\x72\126\141\154\x75\145\x3e\15\12\x20\40\40\74\57\170\145\156\143\72\x43\x69\x70\x68\x65\162\104\x61\x74\141\x3e\xd\xa\x3c\57\x78\145\x6e\143\x3a\105\156\x63\x72\x79\160\164\x65\x64\104\141\164\x61\76";
    const Element = "\150\x74\x74\160\x3a\x2f\x2f\167\167\x77\56\x77\x33\x2e\x6f\162\147\57\62\60\x30\61\x2f\60\64\x2f\x78\x6d\x6c\x65\x6e\x63\43\x45\154\x65\155\145\x6e\x74";
    const Content = "\150\164\x74\x70\72\x2f\57\167\167\167\x2e\167\x33\x2e\157\162\x67\x2f\62\x30\x30\x31\57\x30\64\57\170\155\154\x65\156\x63\x23\103\x6f\x6e\x74\145\156\164";
    const URI = 3;
    const XMLENCNS = "\150\x74\x74\x70\72\57\57\167\167\x77\x2e\x77\63\x2e\157\162\147\x2f\62\x30\60\x31\57\60\x34\x2f\x78\155\154\x65\156\143\x23";
    private $encdoc = null;
    private $rawNode = null;
    public $type = null;
    public $encKey = null;
    private $references = array();
    public function __construct()
    {
        $this->_resetTemplate();
    }
    private function _resetTemplate()
    {
        $this->encdoc = new DOMDocument();
        $this->encdoc->loadXML(self::template);
    }
    public function addReference($vT, $oe, $E8)
    {
        if ($oe instanceof DOMNode) {
            goto em;
        }
        throw new Exception("\x24\x6e\x6f\x64\145\40\x69\x73\40\x6e\157\x74\x20\157\x66\x20\164\171\x70\x65\x20\104\x4f\115\x4e\x6f\x64\145");
        em:
        $BD = $this->encdoc;
        $this->_resetTemplate();
        $Rf = $this->encdoc;
        $this->encdoc = $BD;
        $YZ = XMLSecurityDSig::generateGUID();
        $rJ = $Rf->documentElement;
        $rJ->setAttribute("\x49\144", $YZ);
        $this->references[$vT] = array("\x6e\x6f\144\x65" => $oe, "\164\x79\160\145" => $E8, "\x65\x6e\143\156\157\x64\145" => $Rf, "\162\145\146\165\x72\x69" => $YZ);
    }
    public function setNode($oe)
    {
        $this->rawNode = $oe;
    }
    public function encryptNode($hk, $Ft = true)
    {
        $P9 = '';
        if (!empty($this->rawNode)) {
            goto yH;
        }
        throw new Exception("\x4e\x6f\144\x65\40\x74\157\x20\x65\x6e\143\x72\171\160\x74\x20\150\x61\x73\40\x6e\x6f\x74\x20\142\145\145\156\x20\x73\145\164");
        yH:
        if ($hk instanceof XMLSecurityKey) {
            goto Lh;
        }
        throw new Exception("\111\156\x76\x61\x6c\x69\x64\x20\x4b\145\171");
        Lh:
        $YP = $this->rawNode->ownerDocument;
        $d2 = new DOMXPath($this->encdoc);
        $KS = $d2->query("\57\170\x65\x6e\143\72\x45\x6e\x63\162\x79\160\164\145\144\104\x61\x74\x61\x2f\170\145\156\143\72\x43\x69\x70\150\x65\162\104\x61\164\141\x2f\x78\145\x6e\x63\72\103\151\160\x68\145\162\126\141\154\165\x65");
        $Oa = $KS->item(0);
        if (!($Oa == null)) {
            goto Dg;
        }
        throw new Exception("\105\162\x72\157\162\x20\x6c\x6f\x63\x61\164\x69\156\147\x20\103\151\x70\x68\x65\x72\126\141\154\165\145\x20\x65\x6c\145\x6d\x65\x6e\x74\40\x77\x69\164\x68\x69\156\40\164\145\x6d\160\154\141\164\x65");
        Dg:
        switch ($this->type) {
            case self::Element:
                $P9 = $YP->saveXML($this->rawNode);
                $this->encdoc->documentElement->setAttribute("\124\171\160\145", self::Element);
                goto HE;
            case self::Content:
                $Zr = $this->rawNode->childNodes;
                foreach ($Zr as $cz) {
                    $P9 .= $YP->saveXML($cz);
                    U1:
                }
                Ld:
                $this->encdoc->documentElement->setAttribute("\124\x79\x70\x65", self::Content);
                goto HE;
            default:
                throw new Exception("\x54\x79\160\145\40\151\163\40\x63\165\162\x72\x65\156\164\x6c\x79\x20\156\157\x74\x20\x73\x75\x70\160\157\162\164\x65\x64");
        }
        Q1:
        HE:
        $HD = $this->encdoc->documentElement->appendChild($this->encdoc->createElementNS(self::XMLENCNS, "\170\145\x6e\143\72\105\x6e\143\162\171\160\x74\x69\157\x6e\115\145\164\150\157\144"));
        $HD->setAttribute("\101\x6c\147\x6f\x72\151\x74\x68\155", $hk->getAlgorithm());
        $Oa->parentNode->parentNode->insertBefore($HD, $Oa->parentNode->parentNode->firstChild);
        $jx = base64_encode($hk->encryptData($P9));
        $d1 = $this->encdoc->createTextNode($jx);
        $Oa->appendChild($d1);
        if ($Ft) {
            goto Fm;
        }
        return $this->encdoc->documentElement;
        goto KD;
        Fm:
        switch ($this->type) {
            case self::Element:
                if (!($this->rawNode->nodeType == XML_DOCUMENT_NODE)) {
                    goto Ag;
                }
                return $this->encdoc;
                Ag:
                $jH = $this->rawNode->ownerDocument->importNode($this->encdoc->documentElement, true);
                $this->rawNode->parentNode->replaceChild($jH, $this->rawNode);
                return $jH;
            case self::Content:
                $jH = $this->rawNode->ownerDocument->importNode($this->encdoc->documentElement, true);
                Pe:
                if (!$this->rawNode->firstChild) {
                    goto qp;
                }
                $this->rawNode->removeChild($this->rawNode->firstChild);
                goto Pe;
                qp:
                $this->rawNode->appendChild($jH);
                return $jH;
        }
        A2:
        ni:
        KD:
    }
    public function encryptReferences($hk)
    {
        $rF = $this->rawNode;
        $WU = $this->type;
        foreach ($this->references as $vT => $Eq) {
            $this->encdoc = $Eq["\x65\156\143\156\157\144\145"];
            $this->rawNode = $Eq["\x6e\x6f\144\145"];
            $this->type = $Eq["\164\x79\160\x65"];
            try {
                $mt = $this->encryptNode($hk);
                $this->references[$vT]["\145\x6e\143\x6e\x6f\144\x65"] = $mt;
            } catch (Exception $GC) {
                $this->rawNode = $rF;
                $this->type = $WU;
                throw $GC;
            }
            vV:
        }
        Cv:
        $this->rawNode = $rF;
        $this->type = $WU;
    }
    public function getCipherValue()
    {
        if (!empty($this->rawNode)) {
            goto uB;
        }
        throw new Exception("\x4e\x6f\144\145\x20\164\157\40\144\145\x63\x72\171\x70\164\x20\150\141\x73\x20\x6e\157\164\40\x62\145\x65\156\x20\163\145\x74");
        uB:
        $YP = $this->rawNode->ownerDocument;
        $d2 = new DOMXPath($YP);
        $d2->registerNamespace("\170\155\154\x65\156\x63\162", self::XMLENCNS);
        $Lb = "\x2e\x2f\x78\155\x6c\145\x6e\x63\162\x3a\x43\x69\x70\x68\145\x72\x44\x61\x74\141\57\170\x6d\x6c\x65\x6e\x63\162\x3a\103\x69\160\150\145\x72\126\x61\154\165\x65";
        $au = $d2->query($Lb, $this->rawNode);
        $oe = $au->item(0);
        if ($oe) {
            goto ev;
        }
        return null;
        ev:
        return base64_decode($oe->nodeValue);
    }
    public function decryptNode($hk, $Ft = true)
    {
        if ($hk instanceof XMLSecurityKey) {
            goto YN;
        }
        throw new Exception("\111\x6e\166\x61\x6c\x69\144\40\x4b\145\x79");
        YN:
        $GO = $this->getCipherValue();
        if ($GO) {
            goto Iy;
        }
        throw new Exception("\103\141\x6e\156\x6f\164\x20\x6c\x6f\x63\x61\164\x65\40\145\x6e\x63\x72\171\160\164\145\144\x20\144\141\x74\141");
        goto E3;
        Iy:
        $gx = $hk->decryptData($GO);
        if ($Ft) {
            goto YB;
        }
        return $gx;
        goto EG;
        YB:
        switch ($this->type) {
            case self::Element:
                $Aj = new DOMDocument();
                $Aj->loadXML($gx);
                if (!($this->rawNode->nodeType == XML_DOCUMENT_NODE)) {
                    goto wF;
                }
                return $Aj;
                wF:
                $jH = $this->rawNode->ownerDocument->importNode($Aj->documentElement, true);
                $this->rawNode->parentNode->replaceChild($jH, $this->rawNode);
                return $jH;
            case self::Content:
                if ($this->rawNode->nodeType == XML_DOCUMENT_NODE) {
                    goto R0;
                }
                $YP = $this->rawNode->ownerDocument;
                goto ox;
                R0:
                $YP = $this->rawNode;
                ox:
                $X0 = $YP->createDocumentFragment();
                $X0->appendXML($gx);
                $qq = $this->rawNode->parentNode;
                $qq->replaceChild($X0, $this->rawNode);
                return $qq;
            default:
                return $gx;
        }
        Kt:
        fT:
        EG:
        E3:
    }
    public function encryptKey($Q7, $x5, $To = true)
    {
        if (!(!$Q7 instanceof XMLSecurityKey || !$x5 instanceof XMLSecurityKey)) {
            goto IU;
        }
        throw new Exception("\x49\x6e\166\x61\x6c\x69\x64\40\x4b\x65\171");
        IU:
        $Hy = base64_encode($Q7->encryptData($x5->key));
        $FC = $this->encdoc->documentElement;
        $fz = $this->encdoc->createElementNS(self::XMLENCNS, "\x78\145\156\143\x3a\105\156\143\162\171\x70\164\145\x64\113\x65\171");
        if ($To) {
            goto Fd;
        }
        $this->encKey = $fz;
        goto ay;
        Fd:
        $dp = $FC->insertBefore($this->encdoc->createElementNS("\150\164\164\x70\72\x2f\x2f\167\x77\x77\56\167\x33\x2e\157\162\147\57\x32\60\60\x30\x2f\60\x39\57\170\x6d\154\x64\x73\x69\x67\x23", "\144\163\x69\147\x3a\113\145\171\111\x6e\146\157"), $FC->firstChild);
        $dp->appendChild($fz);
        ay:
        $HD = $fz->appendChild($this->encdoc->createElementNS(self::XMLENCNS, "\x78\145\156\143\x3a\x45\x6e\143\x72\x79\x70\164\x69\x6f\x6e\115\x65\x74\150\157\144"));
        $HD->setAttribute("\x41\x6c\x67\x6f\162\x69\x74\x68\x6d", $Q7->getAlgorith());
        if (empty($Q7->name)) {
            goto Qc;
        }
        $dp = $fz->appendChild($this->encdoc->createElementNS("\x68\x74\x74\x70\72\x2f\x2f\x77\x77\167\x2e\167\x33\56\157\162\x67\x2f\62\60\60\x30\x2f\x30\x39\x2f\x78\155\x6c\144\163\151\x67\43", "\x64\163\151\147\x3a\x4b\145\171\x49\156\146\157"));
        $dp->appendChild($this->encdoc->createElementNS("\150\x74\164\160\72\57\57\167\x77\167\56\x77\x33\56\157\162\x67\57\x32\60\60\x30\57\60\71\57\170\155\154\x64\x73\x69\x67\43", "\x64\x73\x69\147\72\113\145\171\116\141\x6d\145", $Q7->name));
        Qc:
        $GT = $fz->appendChild($this->encdoc->createElementNS(self::XMLENCNS, "\170\145\156\143\x3a\103\151\160\150\145\162\104\141\164\x61"));
        $GT->appendChild($this->encdoc->createElementNS(self::XMLENCNS, "\x78\145\x6e\x63\72\103\151\160\150\145\x72\126\x61\x6c\x75\145", $Hy));
        if (!(is_array($this->references) && count($this->references) > 0)) {
            goto KX;
        }
        $l3 = $fz->appendChild($this->encdoc->createElementNS(self::XMLENCNS, "\x78\x65\156\x63\x3a\122\x65\146\145\x72\145\x6e\x63\145\x4c\151\x73\x74"));
        foreach ($this->references as $vT => $Eq) {
            $YZ = $Eq["\x72\145\146\165\x72\151"];
            $TR = $l3->appendChild($this->encdoc->createElementNS(self::XMLENCNS, "\x78\145\156\x63\x3a\x44\141\x74\x61\122\145\x66\x65\162\x65\x6e\143\145"));
            $TR->setAttribute("\125\122\111", "\43" . $YZ);
            T3:
        }
        nG:
        KX:
        return;
    }
    public function decryptKey($fz)
    {
        if ($fz->isEncrypted) {
            goto nz;
        }
        throw new Exception("\113\145\171\40\151\163\40\x6e\157\x74\x20\x45\x6e\x63\162\x79\160\164\x65\x64");
        nz:
        if (!empty($fz->key)) {
            goto Nq;
        }
        throw new Exception("\113\145\x79\40\151\x73\x20\x6d\151\x73\x73\x69\x6e\147\x20\x64\x61\x74\x61\x20\x74\157\x20\160\x65\162\x66\x6f\162\x6d\40\164\150\145\x20\144\x65\143\162\x79\160\164\151\x6f\x6e");
        Nq:
        return $this->decryptNode($fz, false);
    }
    public function locateEncryptedData($rJ)
    {
        if ($rJ instanceof DOMDocument) {
            goto tY;
        }
        $YP = $rJ->ownerDocument;
        goto vv;
        tY:
        $YP = $rJ;
        vv:
        if (!$YP) {
            goto NU;
        }
        $C1 = new DOMXPath($YP);
        $Lb = "\x2f\x2f\x2a\133\x6c\157\143\x61\x6c\x2d\x6e\x61\x6d\x65\x28\51\75\x27\105\156\x63\x72\x79\x70\x74\145\144\x44\x61\x74\x61\47\x20\x61\x6e\x64\x20\x6e\x61\x6d\145\x73\160\141\143\x65\55\165\162\x69\50\51\75\47" . self::XMLENCNS . "\47\135";
        $au = $C1->query($Lb);
        return $au->item(0);
        NU:
        return null;
    }
    public function locateKey($oe = null)
    {
        if (!empty($oe)) {
            goto wh;
        }
        $oe = $this->rawNode;
        wh:
        if ($oe instanceof DOMNode) {
            goto xJ;
        }
        return null;
        xJ:
        if (!($YP = $oe->ownerDocument)) {
            goto jX;
        }
        $C1 = new DOMXPath($YP);
        $C1->registerNamespace("\170\x6d\x6c\163\145\x63\145\156\143", self::XMLENCNS);
        $Lb = "\x2e\57\57\x78\155\x6c\x73\x65\x63\145\156\x63\72\105\156\x63\x72\x79\160\164\151\x6f\x6e\115\x65\x74\150\x6f\x64";
        $au = $C1->query($Lb, $oe);
        if (!($zj = $au->item(0))) {
            goto wi;
        }
        $Gd = $zj->getAttribute("\x41\154\147\157\162\151\x74\x68\x6d");
        try {
            $hk = new XMLSecurityKey($Gd, array("\164\x79\160\x65" => "\x70\x72\151\166\141\164\x65"));
        } catch (Exception $GC) {
            return null;
        }
        return $hk;
        wi:
        jX:
        return null;
    }
    public static function staticLocateKeyInfo($v8 = null, $oe = null)
    {
        if (!(empty($oe) || !$oe instanceof DOMNode)) {
            goto O9;
        }
        return null;
        O9:
        $YP = $oe->ownerDocument;
        if ($YP) {
            goto wu;
        }
        return null;
        wu:
        $C1 = new DOMXPath($YP);
        $C1->registerNamespace("\x78\155\154\x73\145\x63\x65\x6e\143", self::XMLENCNS);
        $C1->registerNamespace("\170\x6d\154\163\145\143\144\163\x69\x67", XMLSecurityDSig::XMLDSIGNS);
        $Lb = "\56\57\x78\x6d\x6c\x73\145\143\x64\163\x69\x67\72\x4b\x65\171\x49\156\146\157";
        $au = $C1->query($Lb, $oe);
        $zj = $au->item(0);
        if ($zj) {
            goto rc;
        }
        return $v8;
        rc:
        foreach ($zj->childNodes as $cz) {
            switch ($cz->localName) {
                case "\113\x65\171\x4e\x61\155\145":
                    if (empty($v8)) {
                        goto QI;
                    }
                    $v8->name = $cz->nodeValue;
                    QI:
                    goto ey;
                case "\113\145\x79\126\x61\x6c\165\145":
                    foreach ($cz->childNodes as $qc) {
                        switch ($qc->localName) {
                            case "\x44\x53\101\113\145\x79\x56\x61\x6c\165\x65":
                                throw new Exception("\x44\x53\x41\113\145\x79\x56\x61\x6c\x75\145\x20\143\165\162\x72\x65\x6e\164\x6c\x79\40\x6e\157\164\x20\x73\165\160\160\157\x72\164\x65\x64");
                            case "\x52\123\101\113\x65\171\x56\x61\154\165\145":
                                $t0 = null;
                                $cf = null;
                                if (!($Ap = $qc->getElementsByTagName("\x4d\157\144\x75\154\165\x73")->item(0))) {
                                    goto Hx;
                                }
                                $t0 = base64_decode($Ap->nodeValue);
                                Hx:
                                if (!($Bc = $qc->getElementsByTagName("\x45\x78\x70\157\x6e\145\x6e\x74")->item(0))) {
                                    goto he;
                                }
                                $cf = base64_decode($Bc->nodeValue);
                                he:
                                if (!(empty($t0) || empty($cf))) {
                                    goto wB;
                                }
                                throw new Exception("\x4d\151\163\163\x69\156\x67\40\x4d\157\x64\165\x6c\165\x73\x20\157\162\x20\x45\170\x70\x6f\x6e\145\156\164");
                                wB:
                                $Hz = XMLSecurityKey::convertRSA($t0, $cf);
                                $v8->loadKey($Hz);
                                goto AE;
                        }
                        Ko:
                        AE:
                        fv:
                    }
                    YQ:
                    goto ey;
                case "\x52\145\164\162\x69\145\x76\141\154\x4d\145\x74\x68\157\x64":
                    $E8 = $cz->getAttribute("\x54\171\160\x65");
                    if (!($E8 !== "\x68\x74\x74\x70\72\57\x2f\167\x77\x77\x2e\x77\63\x2e\157\x72\x67\x2f\62\60\60\61\x2f\x30\64\57\x78\155\154\x65\x6e\x63\43\105\156\x63\162\x79\x70\164\x65\x64\113\145\171")) {
                        goto ui;
                    }
                    goto ey;
                    ui:
                    $C8 = $cz->getAttribute("\x55\x52\x49");
                    if (!($C8[0] !== "\43")) {
                        goto Lr;
                    }
                    goto ey;
                    Lr:
                    $Z_ = substr($C8, 1);
                    $Lb = "\57\x2f\170\155\154\163\x65\143\x65\156\x63\x3a\105\156\143\x72\171\160\x74\x65\144\113\145\x79\133\100\111\x64\75\x22" . XPath::filterAttrValue($Z_, XPath::DOUBLE_QUOTE) . "\x22\x5d";
                    $ht = $C1->query($Lb)->item(0);
                    if ($ht) {
                        goto yI;
                    }
                    throw new Exception("\x55\x6e\141\x62\154\145\40\x74\157\40\x6c\157\143\141\x74\x65\x20\105\156\143\x72\x79\x70\x74\x65\x64\x4b\x65\171\40\x77\x69\164\x68\40\x40\x49\144\x3d\x27{$Z_}\x27\x2e");
                    yI:
                    return XMLSecurityKey::fromEncryptedKeyElement($ht);
                case "\x45\x6e\x63\162\x79\x70\164\145\144\113\145\171":
                    return XMLSecurityKey::fromEncryptedKeyElement($cz);
                case "\130\65\x30\71\104\x61\x74\x61":
                    if (!($g3 = $cz->getElementsByTagName("\130\x35\60\71\x43\x65\x72\x74\151\x66\151\x63\x61\164\x65"))) {
                        goto rP;
                    }
                    if (!($g3->length > 0)) {
                        goto TV;
                    }
                    $sF = $g3->item(0)->textContent;
                    $sF = str_replace(array("\xd", "\12", "\40"), '', $sF);
                    $sF = "\x2d\55\x2d\x2d\55\x42\105\107\x49\x4e\40\x43\105\x52\124\x49\106\x49\103\x41\x54\x45\x2d\x2d\x2d\x2d\55\12" . chunk_split($sF, 64, "\xa") . "\55\x2d\55\55\x2d\x45\x4e\x44\40\103\x45\122\124\x49\x46\x49\x43\x41\x54\105\55\55\55\55\55\xa";
                    $v8->loadKey($sF, false, true);
                    TV:
                    rP:
                    goto ey;
            }
            qf:
            ey:
            kF:
        }
        lz:
        return $v8;
    }
    public function locateKeyInfo($v8 = null, $oe = null)
    {
        if (!empty($oe)) {
            goto hy;
        }
        $oe = $this->rawNode;
        hy:
        return self::staticLocateKeyInfo($v8, $oe);
    }
}
