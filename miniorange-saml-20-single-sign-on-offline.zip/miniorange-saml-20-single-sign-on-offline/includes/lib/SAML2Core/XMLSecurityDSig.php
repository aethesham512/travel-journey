<?php


namespace RobRichards\XMLSecLibs;

use DOMDocument;
use DOMElement;
use DOMNode;
use DOMXPath;
use Exception;
use RobRichards\XMLSecLibs\Utils\XPath as XPath;
class XMLSecurityDSig
{
    const XMLDSIGNS = "\150\164\x74\x70\x3a\x2f\57\x77\x77\167\56\x77\63\x2e\157\x72\x67\x2f\x32\60\60\60\x2f\x30\x39\57\x78\155\154\144\x73\x69\x67\x23";
    const SHA1 = "\150\x74\x74\x70\72\x2f\x2f\x77\167\x77\x2e\x77\x33\x2e\x6f\x72\147\57\x32\x30\x30\60\57\60\71\x2f\x78\x6d\154\144\x73\151\x67\x23\x73\x68\141\x31";
    const SHA256 = "\x68\x74\164\x70\x3a\x2f\57\167\x77\x77\x2e\x77\x33\56\x6f\x72\x67\x2f\x32\x30\60\61\x2f\x30\64\57\x78\x6d\x6c\x65\x6e\x63\43\163\x68\141\62\x35\x36";
    const SHA384 = "\x68\164\x74\x70\x3a\57\x2f\x77\167\x77\56\x77\x33\56\157\162\x67\57\x32\60\x30\61\57\60\x34\x2f\x78\155\154\x64\163\x69\x67\55\x6d\x6f\x72\145\43\x73\150\141\x33\70\64";
    const SHA512 = "\150\x74\164\160\x3a\x2f\57\167\167\x77\x2e\x77\63\56\157\x72\x67\57\x32\60\x30\x31\57\x30\64\x2f\170\155\154\145\x6e\143\43\x73\x68\141\x35\x31\x32";
    const RIPEMD160 = "\150\164\164\160\x3a\57\x2f\167\x77\x77\56\167\x33\x2e\x6f\x72\x67\57\62\60\60\61\x2f\x30\x34\x2f\x78\x6d\x6c\x65\156\x63\43\162\x69\x70\x65\x6d\144\x31\x36\x30";
    const C14N = "\x68\164\x74\x70\72\x2f\57\x77\167\167\x2e\x77\63\x2e\157\162\147\57\124\122\57\62\60\x30\61\x2f\x52\105\x43\x2d\170\x6d\x6c\55\x63\61\64\156\x2d\x32\60\60\61\60\63\x31\x35";
    const C14N_COMMENTS = "\150\164\164\160\72\x2f\x2f\167\167\167\x2e\167\x33\56\157\162\147\x2f\x54\x52\57\x32\x30\60\x31\57\122\x45\x43\55\x78\155\154\55\143\x31\x34\156\x2d\62\60\60\x31\x30\63\61\x35\43\x57\151\x74\150\103\157\x6d\155\x65\x6e\164\x73";
    const EXC_C14N = "\x68\164\x74\x70\x3a\57\57\x77\167\167\56\167\x33\x2e\157\x72\147\57\x32\60\x30\61\57\x31\x30\57\170\155\x6c\x2d\145\170\x63\x2d\143\x31\x34\156\43";
    const EXC_C14N_COMMENTS = "\x68\x74\x74\160\x3a\57\57\x77\x77\x77\x2e\x77\63\56\157\162\x67\57\x32\60\60\61\57\61\x30\x2f\170\155\154\x2d\145\170\x63\x2d\x63\x31\x34\156\x23\127\x69\x74\150\x43\157\x6d\155\x65\156\x74\163";
    const template = "\x3c\144\x73\72\x53\151\x67\x6e\x61\x74\165\x72\145\x20\170\155\154\x6e\163\72\x64\x73\75\x22\x68\164\164\x70\x3a\57\x2f\x77\167\x77\56\x77\63\x2e\157\162\147\x2f\x32\x30\x30\x30\x2f\60\x39\x2f\x78\155\x6c\144\x73\x69\x67\43\42\x3e\xd\xa\40\x20\74\144\163\x3a\x53\x69\147\156\x65\144\111\156\146\157\x3e\xd\xa\x20\x20\x20\40\74\x64\x73\72\123\x69\x67\156\141\x74\165\x72\x65\115\x65\164\150\x6f\x64\40\57\76\15\12\40\40\74\x2f\144\x73\72\123\x69\x67\x6e\x65\144\x49\156\x66\157\x3e\xd\xa\x3c\57\144\x73\72\123\x69\147\x6e\x61\x74\x75\162\x65\x3e";
    const BASE_TEMPLATE = "\74\123\151\147\156\x61\x74\x75\x72\x65\40\x78\x6d\154\x6e\x73\x3d\x22\150\164\x74\160\x3a\x2f\x2f\x77\167\167\56\x77\63\x2e\157\x72\x67\x2f\x32\x30\x30\60\57\x30\x39\x2f\170\155\x6c\144\x73\x69\147\43\42\76\15\12\40\x20\74\x53\x69\147\156\145\144\111\156\x66\x6f\x3e\15\12\x20\40\40\40\x3c\x53\x69\147\x6e\141\x74\165\162\x65\115\145\164\x68\x6f\x64\x20\57\x3e\15\xa\x20\40\x3c\x2f\x53\151\147\156\x65\x64\x49\156\x66\157\76\xd\12\74\x2f\123\x69\147\156\141\164\x75\162\x65\76";
    public $sigNode = null;
    public $idKeys = array();
    public $idNS = array();
    private $signedInfo = null;
    private $xPathCtx = null;
    private $canonicalMethod = null;
    private $prefix = '';
    private $searchpfx = "\163\x65\x63\x64\x73\151\147";
    private $validatedNodes = null;
    public function __construct($mY = "\144\x73")
    {
        $ud = self::BASE_TEMPLATE;
        if (empty($mY)) {
            goto eC;
        }
        $this->prefix = $mY . "\72";
        $tR = array("\74\123", "\74\x2f\x53", "\170\155\154\x6e\163\x3d");
        $Ft = array("\x3c{$mY}\72\x53", "\x3c\x2f{$mY}\72\123", "\x78\155\154\156\163\72{$mY}\x3d");
        $ud = str_replace($tR, $Ft, $ud);
        eC:
        $wC = new DOMDocument();
        $wC->loadXML($ud);
        $this->sigNode = $wC->documentElement;
    }
    private function resetXPathObj()
    {
        $this->xPathCtx = null;
    }
    private function getXPathObj()
    {
        if (!(empty($this->xPathCtx) && !empty($this->sigNode))) {
            goto Ks;
        }
        $C1 = new DOMXPath($this->sigNode->ownerDocument);
        $C1->registerNamespace("\163\x65\x63\144\163\x69\x67", self::XMLDSIGNS);
        $this->xPathCtx = $C1;
        Ks:
        return $this->xPathCtx;
    }
    public static function generateGUID($mY = "\x70\146\x78")
    {
        $ub = md5(uniqid(mt_rand(), true));
        $l1 = $mY . substr($ub, 0, 8) . "\55" . substr($ub, 8, 4) . "\x2d" . substr($ub, 12, 4) . "\x2d" . substr($ub, 16, 4) . "\x2d" . substr($ub, 20, 12);
        return $l1;
    }
    public static function generate_GUID($mY = "\x70\146\170")
    {
        return self::generateGUID($mY);
    }
    public function locateSignature($vv, $uQ = 0)
    {
        if ($vv instanceof DOMDocument) {
            goto Ir;
        }
        $YP = $vv->ownerDocument;
        goto Th;
        Ir:
        $YP = $vv;
        Th:
        if (!$YP) {
            goto ok;
        }
        $C1 = new DOMXPath($YP);
        $C1->registerNamespace("\x73\x65\143\x64\x73\151\x67", self::XMLDSIGNS);
        $Lb = "\56\x2f\x2f\x73\145\143\144\x73\x69\x67\72\x53\151\147\x6e\x61\x74\x75\x72\145";
        $au = $C1->query($Lb, $vv);
        $this->sigNode = $au->item($uQ);
        return $this->sigNode;
        ok:
        return null;
    }
    public function createNewSignNode($vT, $d1 = null)
    {
        $YP = $this->sigNode->ownerDocument;
        if (!is_null($d1)) {
            goto bM;
        }
        $oe = $YP->createElementNS(self::XMLDSIGNS, $this->prefix . $vT);
        goto sf;
        bM:
        $oe = $YP->createElementNS(self::XMLDSIGNS, $this->prefix . $vT, $d1);
        sf:
        return $oe;
    }
    public function setCanonicalMethod($Pk)
    {
        switch ($Pk) {
            case "\x68\164\164\160\x3a\57\57\167\167\x77\56\x77\63\x2e\157\x72\x67\x2f\124\x52\57\x32\x30\60\61\x2f\122\105\x43\55\x78\x6d\x6c\55\x63\61\x34\156\55\62\60\x30\x31\x30\x33\x31\x35":
            case "\150\164\x74\160\72\57\57\167\167\167\x2e\167\63\x2e\x6f\x72\147\57\124\122\57\x32\60\x30\x31\57\x52\x45\x43\55\x78\155\154\55\143\61\x34\x6e\x2d\62\x30\60\x31\60\63\x31\x35\43\127\x69\164\x68\103\x6f\x6d\x6d\x65\x6e\164\163":
            case "\150\x74\x74\160\x3a\x2f\57\167\167\x77\56\x77\x33\x2e\157\162\147\x2f\62\60\x30\61\57\x31\x30\57\170\155\154\55\x65\x78\143\55\x63\61\x34\x6e\43":
            case "\150\x74\164\160\72\57\x2f\167\167\167\x2e\x77\x33\56\157\x72\x67\x2f\62\x30\60\x31\x2f\x31\x30\x2f\170\x6d\x6c\55\x65\170\143\x2d\x63\x31\x34\x6e\x23\127\x69\x74\150\103\x6f\155\x6d\x65\156\164\x73":
                $this->canonicalMethod = $Pk;
                goto Yt;
            default:
                throw new Exception("\x49\156\166\141\x6c\151\144\x20\103\x61\x6e\x6f\x6e\x69\x63\141\154\x20\x4d\145\164\150\x6f\144");
        }
        Qi:
        Yt:
        if (!($C1 = $this->getXPathObj())) {
            goto ZA;
        }
        $Lb = "\x2e\x2f" . $this->searchpfx . "\72\123\151\147\x6e\145\144\x49\x6e\x66\157";
        $au = $C1->query($Lb, $this->sigNode);
        if (!($d6 = $au->item(0))) {
            goto UR;
        }
        $Lb = "\x2e\57" . $this->searchpfx . "\x43\x61\156\157\156\x69\143\x61\x6c\x69\172\141\164\151\x6f\x6e\x4d\145\x74\x68\x6f\x64";
        $au = $C1->query($Lb, $d6);
        if ($xV = $au->item(0)) {
            goto Rr;
        }
        $xV = $this->createNewSignNode("\x43\x61\156\157\x6e\151\x63\141\154\151\172\x61\x74\x69\157\x6e\115\145\164\150\x6f\x64");
        $d6->insertBefore($xV, $d6->firstChild);
        Rr:
        $xV->setAttribute("\x41\154\147\x6f\162\x69\x74\x68\x6d", $this->canonicalMethod);
        UR:
        ZA:
    }
    private function canonicalizeData($oe, $OH, $RA = null, $wB = null)
    {
        $kE = false;
        $xQ = false;
        switch ($OH) {
            case "\x68\164\x74\x70\72\57\x2f\x77\167\x77\56\x77\63\x2e\x6f\x72\x67\x2f\124\122\57\x32\x30\x30\x31\x2f\122\x45\103\55\x78\155\x6c\55\143\x31\x34\x6e\x2d\x32\60\60\61\x30\x33\61\65":
                $kE = false;
                $xQ = false;
                goto g7;
            case "\x68\164\164\x70\72\x2f\x2f\x77\x77\x77\x2e\x77\63\x2e\157\x72\x67\57\124\122\57\62\x30\60\61\x2f\122\x45\103\55\x78\155\154\x2d\x63\61\x34\x6e\x2d\62\60\60\x31\60\63\x31\65\x23\x57\151\x74\x68\x43\157\x6d\155\x65\156\x74\163":
                $xQ = true;
                goto g7;
            case "\x68\x74\164\x70\72\x2f\57\x77\167\167\x2e\167\63\56\x6f\162\x67\57\62\x30\x30\x31\57\61\x30\x2f\x78\155\x6c\55\145\170\x63\55\x63\x31\64\156\x23":
                $kE = true;
                goto g7;
            case "\x68\164\x74\x70\72\57\57\167\167\x77\56\167\x33\x2e\x6f\x72\x67\x2f\x32\60\x30\61\57\61\60\57\x78\x6d\x6c\55\x65\x78\x63\x2d\x63\x31\64\156\x23\127\151\x74\150\x43\x6f\155\x6d\145\156\x74\x73":
                $kE = true;
                $xQ = true;
                goto g7;
        }
        PR:
        g7:
        if (!(is_null($RA) && $oe instanceof DOMNode && $oe->ownerDocument !== null && $oe->isSameNode($oe->ownerDocument->documentElement))) {
            goto Li;
        }
        $rJ = $oe;
        Oe:
        if (!($lW = $rJ->previousSibling)) {
            goto Mo;
        }
        if (!($lW->nodeType == XML_PI_NODE || $lW->nodeType == XML_COMMENT_NODE && $xQ)) {
            goto Wh;
        }
        goto Mo;
        Wh:
        $rJ = $lW;
        goto Oe;
        Mo:
        if (!($lW == null)) {
            goto fw;
        }
        $oe = $oe->ownerDocument;
        fw:
        Li:
        return $oe->C14N($kE, $xQ, $RA, $wB);
    }
    public function canonicalizeSignedInfo()
    {
        $YP = $this->sigNode->ownerDocument;
        $OH = null;
        if (!$YP) {
            goto C3;
        }
        $C1 = $this->getXPathObj();
        $Lb = "\x2e\x2f\x73\x65\x63\x64\163\x69\147\72\123\x69\147\156\145\144\111\156\146\157";
        $au = $C1->query($Lb, $this->sigNode);
        if (!($zN = $au->item(0))) {
            goto wU;
        }
        $Lb = "\56\x2f\163\x65\143\x64\163\151\147\72\x43\x61\x6e\157\x6e\x69\x63\141\x6c\x69\172\x61\x74\x69\x6f\x6e\115\x65\164\150\157\x64";
        $au = $C1->query($Lb, $zN);
        if (!($xV = $au->item(0))) {
            goto UJ;
        }
        $OH = $xV->getAttribute("\x41\154\x67\x6f\x72\x69\164\x68\x6d");
        UJ:
        $this->signedInfo = $this->canonicalizeData($zN, $OH);
        return $this->signedInfo;
        wU:
        C3:
        return null;
    }
    public function calculateDigest($pQ, $P9, $Fk = true)
    {
        switch ($pQ) {
            case self::SHA1:
                $O3 = "\163\150\x61\61";
                goto Gg;
            case self::SHA256:
                $O3 = "\x73\x68\141\x32\65\66";
                goto Gg;
            case self::SHA384:
                $O3 = "\163\x68\x61\x33\x38\64";
                goto Gg;
            case self::SHA512:
                $O3 = "\163\150\x61\x35\x31\x32";
                goto Gg;
            case self::RIPEMD160:
                $O3 = "\162\x69\160\x65\155\144\61\x36\60";
                goto Gg;
            default:
                throw new Exception("\103\141\x6e\x6e\x6f\x74\x20\x76\141\154\x69\x64\141\x74\145\40\144\151\x67\x65\163\164\x3a\40\x55\x6e\x73\165\x70\x70\x6f\162\164\x65\x64\x20\x41\x6c\x67\x6f\x72\x69\x74\150\155\40\74{$pQ}\76");
        }
        iy:
        Gg:
        $ZX = hash($O3, $P9, true);
        if (!$Fk) {
            goto kA;
        }
        $ZX = base64_encode($ZX);
        kA:
        return $ZX;
    }
    public function validateDigest($th, $P9)
    {
        $C1 = new DOMXPath($th->ownerDocument);
        $C1->registerNamespace("\163\145\x63\144\163\x69\x67", self::XMLDSIGNS);
        $Lb = "\163\164\162\151\156\x67\50\x2e\x2f\x73\x65\x63\x64\163\151\x67\x3a\x44\151\x67\145\163\164\x4d\x65\164\x68\x6f\144\x2f\100\101\x6c\147\x6f\162\x69\164\x68\x6d\51";
        $pQ = $C1->evaluate($Lb, $th);
        $HE = $this->calculateDigest($pQ, $P9, false);
        $Lb = "\x73\x74\162\x69\x6e\147\x28\x2e\57\163\145\x63\144\163\151\x67\x3a\104\151\147\x65\163\x74\126\141\x6c\165\x65\51";
        $ie = $C1->evaluate($Lb, $th);
        return $HE === base64_decode($ie);
    }
    public function processTransforms($th, $QA, $Nv = true)
    {
        $P9 = $QA;
        $C1 = new DOMXPath($th->ownerDocument);
        $C1->registerNamespace("\x73\x65\143\x64\x73\x69\147", self::XMLDSIGNS);
        $Lb = "\56\57\x73\x65\143\x64\x73\x69\147\72\x54\x72\141\156\163\x66\x6f\162\155\163\x2f\163\x65\143\144\163\x69\x67\x3a\124\162\x61\x6e\x73\x66\x6f\162\155";
        $Bt = $C1->query($Lb, $th);
        $M0 = "\150\164\164\x70\72\x2f\x2f\x77\x77\x77\x2e\x77\63\56\157\x72\x67\x2f\124\x52\57\x32\60\x30\x31\57\x52\x45\x43\x2d\170\x6d\154\x2d\143\x31\64\x6e\55\62\x30\60\61\x30\x33\x31\x35";
        $RA = null;
        $wB = null;
        foreach ($Bt as $YC) {
            $dz = $YC->getAttribute("\x41\x6c\x67\x6f\162\151\x74\150\x6d");
            switch ($dz) {
                case "\150\164\x74\x70\72\57\x2f\x77\x77\x77\x2e\167\63\56\157\x72\147\x2f\x32\x30\60\x31\x2f\x31\x30\57\x78\x6d\x6c\x2d\x65\x78\143\x2d\x63\x31\x34\156\43":
                case "\150\164\x74\160\x3a\x2f\x2f\167\x77\x77\x2e\x77\x33\56\157\162\x67\57\x32\x30\x30\x31\57\61\x30\x2f\x78\155\154\x2d\145\x78\x63\x2d\143\x31\x34\156\43\127\151\164\x68\103\157\155\155\145\156\x74\x73":
                    if (!$Nv) {
                        goto Xw;
                    }
                    $M0 = $dz;
                    goto kc;
                    Xw:
                    $M0 = "\x68\164\164\160\x3a\x2f\57\167\x77\x77\56\167\x33\x2e\x6f\x72\147\57\62\60\x30\61\x2f\61\x30\x2f\170\155\x6c\x2d\145\x78\x63\55\x63\x31\x34\x6e\43";
                    kc:
                    $oe = $YC->firstChild;
                    KT:
                    if (!$oe) {
                        goto xE;
                    }
                    if (!($oe->localName == "\x49\156\143\x6c\165\163\151\166\145\x4e\141\155\x65\x73\x70\x61\143\145\163")) {
                        goto sx;
                    }
                    if (!($aY = $oe->getAttribute("\x50\162\x65\146\151\x78\x4c\151\163\164"))) {
                        goto hZ;
                    }
                    $Bu = array();
                    $In = explode("\x20", $aY);
                    foreach ($In as $aY) {
                        $tK = trim($aY);
                        if (empty($tK)) {
                            goto ib;
                        }
                        $Bu[] = $tK;
                        ib:
                        gl:
                    }
                    Ye:
                    if (!(count($Bu) > 0)) {
                        goto ZE;
                    }
                    $wB = $Bu;
                    ZE:
                    hZ:
                    goto xE;
                    sx:
                    $oe = $oe->nextSibling;
                    goto KT;
                    xE:
                    goto wN;
                case "\x68\x74\x74\x70\72\57\x2f\x77\167\x77\x2e\167\x33\56\157\x72\147\57\x54\122\57\62\60\x30\61\57\122\x45\103\55\170\x6d\x6c\55\x63\x31\64\156\x2d\62\x30\60\61\60\x33\61\65":
                case "\x68\x74\164\160\72\x2f\57\x77\x77\167\56\167\x33\56\157\x72\x67\57\124\x52\x2f\x32\x30\60\x31\x2f\x52\105\103\x2d\170\x6d\x6c\x2d\143\61\64\x6e\55\62\x30\60\x31\60\x33\61\65\x23\x57\151\164\x68\103\x6f\x6d\155\x65\x6e\x74\163":
                    if (!$Nv) {
                        goto Zh;
                    }
                    $M0 = $dz;
                    goto MN;
                    Zh:
                    $M0 = "\x68\164\x74\x70\72\57\57\167\x77\167\x2e\167\63\x2e\157\x72\x67\57\x54\122\57\62\60\x30\x31\57\x52\x45\x43\55\170\155\x6c\x2d\143\61\64\x6e\55\x32\60\60\61\60\x33\61\65";
                    MN:
                    goto wN;
                case "\x68\164\164\x70\x3a\x2f\x2f\167\x77\167\x2e\167\63\56\x6f\x72\x67\57\x54\122\x2f\61\x39\71\x39\x2f\122\x45\103\x2d\x78\x70\141\x74\150\x2d\x31\71\x39\71\61\x31\61\x36":
                    $oe = $YC->firstChild;
                    cG:
                    if (!$oe) {
                        goto Jj;
                    }
                    if (!($oe->localName == "\x58\120\x61\x74\150")) {
                        goto a4;
                    }
                    $RA = array();
                    $RA["\x71\x75\145\x72\x79"] = "\x28\x2e\x2f\57\56\x20\174\40\x2e\57\57\x40\52\x20\x7c\40\56\x2f\x2f\x6e\x61\155\x65\x73\x70\x61\143\x65\x3a\x3a\x2a\51\x5b" . $oe->nodeValue . "\x5d";
                    $q0["\x6e\x61\x6d\x65\x73\160\x61\x63\x65\x73"] = array();
                    $eV = $C1->query("\x2e\57\x6e\x61\x6d\145\x73\160\141\143\145\72\x3a\x2a", $oe);
                    foreach ($eV as $La) {
                        if (!($La->localName != "\x78\x6d\x6c")) {
                            goto Ro;
                        }
                        $RA["\156\141\x6d\145\x73\x70\141\x63\145\x73"][$La->localName] = $La->nodeValue;
                        Ro:
                        RC:
                    }
                    L7:
                    goto Jj;
                    a4:
                    $oe = $oe->nextSibling;
                    goto cG;
                    Jj:
                    goto wN;
            }
            Dk:
            wN:
            V1:
        }
        Hv:
        if (!$P9 instanceof DOMNode) {
            goto oW;
        }
        $P9 = $this->canonicalizeData($QA, $M0, $RA, $wB);
        oW:
        return $P9;
    }
    public function processRefNode($th)
    {
        $Xp = null;
        $Nv = true;
        if ($C8 = $th->getAttribute("\125\x52\x49")) {
            goto pQ;
        }
        $Nv = false;
        $Xp = $th->ownerDocument;
        goto gJ;
        pQ:
        $bx = parse_url($C8);
        if (!empty($bx["\160\x61\x74\x68"])) {
            goto kM;
        }
        if ($fn = $bx["\146\162\141\x67\155\x65\156\x74"]) {
            goto e_;
        }
        $Xp = $th->ownerDocument;
        goto mn;
        e_:
        $Nv = false;
        $d2 = new DOMXPath($th->ownerDocument);
        if (!($this->idNS && is_array($this->idNS))) {
            goto Q4;
        }
        foreach ($this->idNS as $v6 => $Sw) {
            $d2->registerNamespace($v6, $Sw);
            AX:
        }
        xg:
        Q4:
        $r0 = "\100\x49\x64\75\42" . XPath::filterAttrValue($fn, XPath::DOUBLE_QUOTE) . "\x22";
        if (!is_array($this->idKeys)) {
            goto K0;
        }
        foreach ($this->idKeys as $qW) {
            $r0 .= "\40\x6f\x72\40\100" . XPath::filterAttrName($qW) . "\x3d\x22" . XPath::filterAttrValue($fn, XPath::DOUBLE_QUOTE) . "\x22";
            ek:
        }
        BD:
        K0:
        $Lb = "\x2f\x2f\x2a\133" . $r0 . "\x5d";
        $Xp = $d2->query($Lb)->item(0);
        mn:
        kM:
        gJ:
        $P9 = $this->processTransforms($th, $Xp, $Nv);
        if ($this->validateDigest($th, $P9)) {
            goto d0;
        }
        return false;
        d0:
        if (!$Xp instanceof DOMNode) {
            goto BP;
        }
        if (!empty($fn)) {
            goto SE;
        }
        $this->validatedNodes[] = $Xp;
        goto HC;
        SE:
        $this->validatedNodes[$fn] = $Xp;
        HC:
        BP:
        return true;
    }
    public function getRefNodeID($th)
    {
        if (!($C8 = $th->getAttribute("\125\x52\111"))) {
            goto B0;
        }
        $bx = parse_url($C8);
        if (!empty($bx["\160\141\164\x68"])) {
            goto DG;
        }
        if (!($fn = $bx["\x66\x72\141\x67\155\145\x6e\x74"])) {
            goto b2;
        }
        return $fn;
        b2:
        DG:
        B0:
        return null;
    }
    public function getRefIDs()
    {
        $tg = array();
        $C1 = $this->getXPathObj();
        $Lb = "\56\x2f\x73\145\143\x64\x73\x69\x67\x3a\123\151\x67\156\x65\x64\111\156\x66\157\x2f\163\145\x63\144\163\x69\147\72\122\x65\146\145\162\x65\156\143\145";
        $au = $C1->query($Lb, $this->sigNode);
        if (!($au->length == 0)) {
            goto nS;
        }
        throw new Exception("\122\x65\x66\x65\162\x65\156\x63\145\x20\156\157\x64\145\x73\40\156\157\x74\40\x66\x6f\x75\x6e\144");
        nS:
        foreach ($au as $th) {
            $tg[] = $this->getRefNodeID($th);
            kb:
        }
        fz:
        return $tg;
    }
    public function validateReference()
    {
        $IK = $this->sigNode->ownerDocument->documentElement;
        if ($IK->isSameNode($this->sigNode)) {
            goto Hm;
        }
        if (!($this->sigNode->parentNode != null)) {
            goto H4;
        }
        $this->sigNode->parentNode->removeChild($this->sigNode);
        H4:
        Hm:
        $C1 = $this->getXPathObj();
        $Lb = "\56\57\x73\x65\143\144\x73\x69\x67\x3a\x53\151\x67\x6e\x65\x64\x49\156\146\157\x2f\x73\145\x63\x64\163\151\147\x3a\122\x65\x66\x65\162\x65\156\x63\x65";
        $au = $C1->query($Lb, $this->sigNode);
        if (!($au->length == 0)) {
            goto D5;
        }
        throw new Exception("\122\x65\x66\x65\x72\145\156\x63\145\x20\x6e\x6f\x64\145\x73\40\156\157\164\x20\x66\x6f\x75\x6e\x64");
        D5:
        $this->validatedNodes = array();
        foreach ($au as $th) {
            if ($this->processRefNode($th)) {
                goto Aa;
            }
            $this->validatedNodes = null;
            throw new Exception("\122\145\146\145\162\145\156\x63\145\40\166\x61\154\151\144\x61\x74\x69\x6f\156\x20\x66\x61\151\x6c\145\144");
            Aa:
            j5:
        }
        Gx:
        return true;
    }
    private function addRefInternal($Gl, $oe, $dz, $NC = null, $kQ = null)
    {
        $mY = null;
        $VE = null;
        $JF = "\111\x64";
        $kZ = true;
        $yw = false;
        if (!is_array($kQ)) {
            goto jB;
        }
        $mY = empty($kQ["\x70\162\x65\x66\x69\x78"]) ? null : $kQ["\160\x72\x65\146\151\170"];
        $VE = empty($kQ["\x70\162\x65\146\151\x78\137\x6e\x73"]) ? null : $kQ["\x70\x72\145\146\151\x78\x5f\156\163"];
        $JF = empty($kQ["\151\144\x5f\x6e\x61\155\x65"]) ? "\x49\144" : $kQ["\151\x64\137\156\141\155\x65"];
        $kZ = !isset($kQ["\x6f\166\145\162\167\162\151\164\145"]) ? true : (bool) $kQ["\x6f\166\x65\x72\x77\162\151\x74\x65"];
        $yw = !isset($kQ["\x66\x6f\162\143\145\x5f\165\162\x69"]) ? false : (bool) $kQ["\146\x6f\162\x63\145\x5f\165\162\151"];
        jB:
        $SN = $JF;
        if (empty($mY)) {
            goto Y_;
        }
        $SN = $mY . "\72" . $SN;
        Y_:
        $th = $this->createNewSignNode("\x52\x65\x66\x65\x72\x65\156\143\145");
        $Gl->appendChild($th);
        if (!$oe instanceof DOMDocument) {
            goto sA;
        }
        if ($yw) {
            goto L0;
        }
        goto At;
        sA:
        $C8 = null;
        if ($kZ) {
            goto Ta;
        }
        $C8 = $VE ? $oe->getAttributeNS($VE, $JF) : $oe->getAttribute($JF);
        Ta:
        if (!empty($C8)) {
            goto ez;
        }
        $C8 = self::generateGUID();
        $oe->setAttributeNS($VE, $SN, $C8);
        ez:
        $th->setAttribute("\125\x52\111", "\x23" . $C8);
        goto At;
        L0:
        $th->setAttribute("\x55\x52\x49", '');
        At:
        $GJ = $this->createNewSignNode("\x54\x72\x61\156\163\x66\x6f\162\155\x73");
        $th->appendChild($GJ);
        if (is_array($NC)) {
            goto hM;
        }
        if (!empty($this->canonicalMethod)) {
            goto lM;
        }
        goto La;
        hM:
        foreach ($NC as $YC) {
            $Ac = $this->createNewSignNode("\x54\162\x61\156\x73\146\157\162\155");
            $GJ->appendChild($Ac);
            if (is_array($YC) && !empty($YC["\x68\164\x74\160\x3a\x2f\x2f\167\x77\x77\56\x77\63\56\157\162\147\x2f\x54\x52\57\61\x39\x39\x39\57\x52\105\103\x2d\170\x70\x61\x74\150\x2d\61\x39\x39\x39\x31\x31\61\x36"]) && !empty($YC["\x68\x74\x74\x70\x3a\x2f\x2f\x77\x77\167\56\167\x33\x2e\157\162\147\x2f\x54\122\57\61\x39\x39\x39\x2f\x52\x45\x43\x2d\x78\x70\141\x74\x68\55\61\71\71\x39\61\61\61\66"]["\161\x75\145\162\171"])) {
                goto bh;
            }
            $Ac->setAttribute("\x41\154\x67\x6f\162\x69\x74\150\x6d", $YC);
            goto lq;
            bh:
            $Ac->setAttribute("\101\154\x67\157\x72\151\x74\150\155", "\x68\x74\164\160\x3a\x2f\x2f\167\167\x77\56\x77\x33\56\x6f\162\x67\57\x54\x52\x2f\x31\71\x39\71\57\122\x45\103\55\x78\160\141\x74\150\x2d\x31\x39\x39\71\61\x31\x31\x36");
            $HL = $this->createNewSignNode("\130\120\141\x74\150", $YC["\x68\164\x74\160\x3a\57\x2f\x77\167\x77\x2e\167\63\56\x6f\x72\147\x2f\x54\x52\57\x31\x39\x39\x39\x2f\122\x45\103\55\170\160\x61\x74\150\x2d\x31\71\x39\x39\61\61\x31\x36"]["\161\165\145\x72\171"]);
            $Ac->appendChild($HL);
            if (empty($YC["\150\x74\164\160\72\x2f\x2f\167\167\167\56\x77\x33\56\x6f\162\147\x2f\x54\x52\57\61\71\x39\71\x2f\x52\x45\x43\55\170\160\x61\164\x68\55\61\71\x39\x39\61\61\61\66"]["\156\x61\155\145\x73\x70\x61\x63\145\163"])) {
                goto dd;
            }
            foreach ($YC["\x68\164\x74\160\72\57\x2f\167\x77\167\x2e\x77\63\56\x6f\162\x67\57\x54\122\x2f\61\71\71\71\x2f\x52\105\x43\x2d\170\160\141\x74\x68\x2d\x31\x39\71\x39\x31\61\61\66"]["\156\141\155\145\163\160\141\143\145\163"] as $mY => $K6) {
                $HL->setAttributeNS("\150\164\164\160\72\57\57\x77\167\x77\x2e\167\63\x2e\x6f\162\x67\x2f\x32\60\x30\x30\57\x78\x6d\154\x6e\x73\x2f", "\170\x6d\x6c\156\163\x3a{$mY}", $K6);
                Qm:
            }
            XL:
            dd:
            lq:
            i0:
        }
        WD:
        goto La;
        lM:
        $Ac = $this->createNewSignNode("\124\x72\141\156\x73\146\x6f\x72\155");
        $GJ->appendChild($Ac);
        $Ac->setAttribute("\x41\154\x67\157\x72\x69\x74\150\155", $this->canonicalMethod);
        La:
        $rb = $this->processTransforms($th, $oe);
        $HE = $this->calculateDigest($dz, $rb);
        $ng = $this->createNewSignNode("\x44\x69\x67\x65\x73\x74\x4d\145\164\x68\157\x64");
        $th->appendChild($ng);
        $ng->setAttribute("\x41\154\x67\x6f\162\x69\x74\x68\x6d", $dz);
        $ie = $this->createNewSignNode("\104\x69\147\x65\163\x74\x56\x61\154\165\145", $HE);
        $th->appendChild($ie);
    }
    public function addReference($oe, $dz, $NC = null, $kQ = null)
    {
        if (!($C1 = $this->getXPathObj())) {
            goto iZ;
        }
        $Lb = "\56\x2f\163\x65\143\144\163\x69\x67\72\123\x69\x67\156\x65\144\x49\156\x66\x6f";
        $au = $C1->query($Lb, $this->sigNode);
        if (!($tW = $au->item(0))) {
            goto M5;
        }
        $this->addRefInternal($tW, $oe, $dz, $NC, $kQ);
        M5:
        iZ:
    }
    public function addReferenceList($Gs, $dz, $NC = null, $kQ = null)
    {
        if (!($C1 = $this->getXPathObj())) {
            goto IZ;
        }
        $Lb = "\x2e\57\x73\145\143\144\x73\151\147\72\x53\151\147\x6e\x65\x64\x49\x6e\x66\x6f";
        $au = $C1->query($Lb, $this->sigNode);
        if (!($tW = $au->item(0))) {
            goto Qg;
        }
        foreach ($Gs as $oe) {
            $this->addRefInternal($tW, $oe, $dz, $NC, $kQ);
            Uw:
        }
        xs:
        Qg:
        IZ:
    }
    public function addObject($P9, $nB = null, $Kb = null)
    {
        $Kq = $this->createNewSignNode("\117\x62\152\x65\143\164");
        $this->sigNode->appendChild($Kq);
        if (empty($nB)) {
            goto il;
        }
        $Kq->setAttribute("\115\x69\155\145\x54\x79\x70\145", $nB);
        il:
        if (empty($Kb)) {
            goto y_;
        }
        $Kq->setAttribute("\105\156\x63\x6f\x64\151\x6e\147", $Kb);
        y_:
        if ($P9 instanceof DOMElement) {
            goto Mf;
        }
        $se = $this->sigNode->ownerDocument->createTextNode($P9);
        goto RB;
        Mf:
        $se = $this->sigNode->ownerDocument->importNode($P9, true);
        RB:
        $Kq->appendChild($se);
        return $Kq;
    }
    public function locateKey($oe = null)
    {
        if (!empty($oe)) {
            goto nM;
        }
        $oe = $this->sigNode;
        nM:
        if ($oe instanceof DOMNode) {
            goto gD;
        }
        return null;
        gD:
        if (!($YP = $oe->ownerDocument)) {
            goto eJ;
        }
        $C1 = new DOMXPath($YP);
        $C1->registerNamespace("\x73\x65\x63\x64\163\x69\x67", self::XMLDSIGNS);
        $Lb = "\x73\x74\x72\151\x6e\x67\x28\56\57\163\x65\143\144\163\151\x67\x3a\123\151\147\x6e\x65\x64\111\x6e\146\x6f\57\163\145\143\x64\x73\x69\147\72\x53\x69\147\x6e\141\164\165\162\x65\x4d\x65\164\x68\x6f\x64\x2f\x40\x41\154\x67\x6f\162\x69\x74\x68\155\x29";
        $dz = $C1->evaluate($Lb, $oe);
        if (!$dz) {
            goto tS;
        }
        try {
            $hk = new XMLSecurityKey($dz, array("\x74\171\x70\x65" => "\160\x75\x62\x6c\x69\143"));
        } catch (Exception $GC) {
            return null;
        }
        return $hk;
        tS:
        eJ:
        return null;
    }
    public function verify($hk)
    {
        $YP = $this->sigNode->ownerDocument;
        $C1 = new DOMXPath($YP);
        $C1->registerNamespace("\x73\x65\x63\144\163\151\x67", self::XMLDSIGNS);
        $Lb = "\163\x74\x72\151\156\147\x28\56\57\163\145\x63\144\163\151\x67\x3a\x53\x69\147\x6e\141\x74\x75\x72\145\126\x61\154\165\145\51";
        $ry = $C1->evaluate($Lb, $this->sigNode);
        if (!empty($ry)) {
            goto rb;
        }
        throw new Exception("\x55\156\141\x62\154\x65\x20\x74\x6f\40\154\157\143\141\164\x65\x20\123\151\x67\x6e\141\x74\x75\162\145\x56\x61\154\x75\x65");
        rb:
        return $hk->verifySignature($this->signedInfo, base64_decode($ry));
    }
    public function signData($hk, $P9)
    {
        return $hk->signData($P9);
    }
    public function sign($hk, $SZ = null)
    {
        if (!($SZ != null)) {
            goto kn;
        }
        $this->resetXPathObj();
        $this->appendSignature($SZ);
        $this->sigNode = $SZ->lastChild;
        kn:
        if (!($C1 = $this->getXPathObj())) {
            goto TS;
        }
        $Lb = "\x2e\57\x73\x65\143\x64\163\x69\x67\72\123\x69\147\x6e\145\x64\x49\x6e\x66\157";
        $au = $C1->query($Lb, $this->sigNode);
        if (!($tW = $au->item(0))) {
            goto Oa;
        }
        $Lb = "\x2e\57\x73\x65\143\144\163\x69\147\72\x53\151\x67\x6e\141\x74\165\162\x65\x4d\x65\164\x68\157\144";
        $au = $C1->query($Lb, $tW);
        $I6 = $au->item(0);
        $I6->setAttribute("\101\x6c\147\157\162\x69\164\150\155", $hk->type);
        $P9 = $this->canonicalizeData($tW, $this->canonicalMethod);
        $ry = base64_encode($this->signData($hk, $P9));
        $fU = $this->createNewSignNode("\x53\x69\x67\156\141\164\x75\x72\x65\126\x61\x6c\x75\145", $ry);
        if ($jC = $tW->nextSibling) {
            goto IW;
        }
        $this->sigNode->appendChild($fU);
        goto AB;
        IW:
        $jC->parentNode->insertBefore($fU, $jC);
        AB:
        Oa:
        TS:
    }
    public function appendCert()
    {
    }
    public function appendKey($hk, $qq = null)
    {
        $hk->serializeKey($qq);
    }
    public function insertSignature($oe, $SI = null)
    {
        $AI = $oe->ownerDocument;
        $bJ = $AI->importNode($this->sigNode, true);
        if ($SI == null) {
            goto iN;
        }
        return $oe->insertBefore($bJ, $SI);
        goto R9;
        iN:
        return $oe->insertBefore($bJ);
        R9:
    }
    public function appendSignature($pl, $Y7 = false)
    {
        $SI = $Y7 ? $pl->firstChild : null;
        return $this->insertSignature($pl, $SI);
    }
    public static function get509XCert($A9, $QZ = true)
    {
        $Dd = self::staticGet509XCerts($A9, $QZ);
        if (empty($Dd)) {
            goto TR;
        }
        return $Dd[0];
        TR:
        return '';
    }
    public static function staticGet509XCerts($Dd, $QZ = true)
    {
        if ($QZ) {
            goto jS;
        }
        return array($Dd);
        goto Ix;
        jS:
        $P9 = '';
        $uj = array();
        $IE = explode("\12", $Dd);
        $vq = false;
        foreach ($IE as $Gf) {
            if (!$vq) {
                goto YD;
            }
            if (!(strncmp($Gf, "\x2d\55\x2d\x2d\55\105\x4e\104\x20\103\x45\122\124\x49\106\111\x43\101\124\x45", 20) == 0)) {
                goto Pv;
            }
            $vq = false;
            $uj[] = $P9;
            $P9 = '';
            goto e0;
            Pv:
            $P9 .= trim($Gf);
            goto ai;
            YD:
            if (!(strncmp($Gf, "\55\x2d\x2d\55\55\x42\105\107\111\x4e\40\x43\105\x52\124\x49\x46\x49\103\101\124\x45", 22) == 0)) {
                goto Kr;
            }
            $vq = true;
            Kr:
            ai:
            e0:
        }
        Bx:
        return $uj;
        Ix:
    }
    public static function staticAdd509Cert($Ez, $A9, $QZ = true, $H3 = false, $C1 = null, $kQ = null)
    {
        if (!$H3) {
            goto c1;
        }
        $A9 = file_get_contents($A9);
        c1:
        if ($Ez instanceof DOMElement) {
            goto kV;
        }
        throw new Exception("\111\x6e\166\x61\x6c\151\144\40\x70\141\162\145\156\164\40\x4e\x6f\x64\145\40\x70\141\x72\141\155\145\164\x65\x72");
        kV:
        $vI = $Ez->ownerDocument;
        if (!empty($C1)) {
            goto rL;
        }
        $C1 = new DOMXPath($Ez->ownerDocument);
        $C1->registerNamespace("\163\145\143\x64\x73\151\x67", self::XMLDSIGNS);
        rL:
        $Lb = "\x2e\57\163\x65\143\x64\x73\151\x67\72\113\145\x79\x49\x6e\x66\157";
        $au = $C1->query($Lb, $Ez);
        $dp = $au->item(0);
        $Fi = '';
        if (!$dp) {
            goto Up;
        }
        $aY = $dp->lookupPrefix(self::XMLDSIGNS);
        if (empty($aY)) {
            goto sq;
        }
        $Fi = $aY . "\x3a";
        sq:
        goto dg;
        Up:
        $aY = $Ez->lookupPrefix(self::XMLDSIGNS);
        if (empty($aY)) {
            goto xv;
        }
        $Fi = $aY . "\72";
        xv:
        $nf = false;
        $dp = $vI->createElementNS(self::XMLDSIGNS, $Fi . "\x4b\x65\x79\111\156\x66\x6f");
        $Lb = "\56\57\x73\x65\x63\x64\x73\151\147\72\x4f\x62\x6a\145\x63\x74";
        $au = $C1->query($Lb, $Ez);
        if (!($zn = $au->item(0))) {
            goto sT;
        }
        $zn->parentNode->insertBefore($dp, $zn);
        $nf = true;
        sT:
        if ($nf) {
            goto b3;
        }
        $Ez->appendChild($dp);
        b3:
        dg:
        $Dd = self::staticGet509XCerts($A9, $QZ);
        $xs = $vI->createElementNS(self::XMLDSIGNS, $Fi . "\x58\x35\60\71\104\x61\164\x61");
        $dp->appendChild($xs);
        $OD = false;
        $tf = false;
        if (!is_array($kQ)) {
            goto Xg;
        }
        if (empty($kQ["\x69\163\163\165\x65\162\123\145\x72\x69\x61\154"])) {
            goto GB;
        }
        $OD = true;
        GB:
        if (empty($kQ["\163\165\x62\x6a\x65\x63\164\x4e\x61\x6d\145"])) {
            goto lb;
        }
        $tf = true;
        lb:
        Xg:
        foreach ($Dd as $DB) {
            if (!($OD || $tf)) {
                goto fI;
            }
            if (!($gS = openssl_x509_parse("\55\x2d\55\55\x2d\x42\x45\x47\111\x4e\x20\x43\x45\122\x54\x49\x46\111\x43\x41\x54\105\55\x2d\55\55\x2d\xa" . chunk_split($DB, 64, "\xa") . "\55\55\55\x2d\55\x45\116\x44\x20\103\105\x52\x54\x49\x46\x49\103\101\x54\105\x2d\55\x2d\x2d\55\12"))) {
                goto ho;
            }
            if (!($tf && !empty($gS["\x73\x75\x62\152\x65\143\x74"]))) {
                goto eR;
            }
            if (is_array($gS["\x73\165\x62\x6a\145\143\164"])) {
                goto r3;
            }
            $aW = $gS["\151\163\163\x75\x65\x72"];
            goto g6;
            r3:
            $Y5 = array();
            foreach ($gS["\163\165\x62\152\145\143\x74"] as $z5 => $d1) {
                if (is_array($d1)) {
                    goto hW;
                }
                array_unshift($Y5, "{$z5}\x3d{$d1}");
                goto DS;
                hW:
                foreach ($d1 as $LO) {
                    array_unshift($Y5, "{$z5}\75{$LO}");
                    hD:
                }
                R8:
                DS:
                x3:
            }
            Z7:
            $aW = implode("\x2c", $Y5);
            g6:
            $MA = $vI->createElementNS(self::XMLDSIGNS, $Fi . "\x58\65\60\71\x53\165\142\152\x65\143\164\116\x61\155\145", $aW);
            $xs->appendChild($MA);
            eR:
            if (!($OD && !empty($gS["\x69\163\163\165\145\x72"]) && !empty($gS["\163\x65\x72\x69\x61\x6c\116\x75\155\x62\145\x72"]))) {
                goto Sf;
            }
            if (is_array($gS["\151\163\163\x75\x65\x72"])) {
                goto u0;
            }
            $qU = $gS["\151\x73\x73\165\x65\x72"];
            goto ZH;
            u0:
            $Y5 = array();
            foreach ($gS["\151\x73\163\165\145\x72"] as $z5 => $d1) {
                array_unshift($Y5, "{$z5}\75{$d1}");
                ig:
            }
            ku:
            $qU = implode("\x2c", $Y5);
            ZH:
            $QN = $vI->createElementNS(self::XMLDSIGNS, $Fi . "\130\x35\x30\71\111\163\x73\x75\145\162\123\x65\x72\151\x61\x6c");
            $xs->appendChild($QN);
            $Lj = $vI->createElementNS(self::XMLDSIGNS, $Fi . "\x58\65\60\71\x49\x73\x73\165\x65\x72\x4e\141\155\x65", $qU);
            $QN->appendChild($Lj);
            $Lj = $vI->createElementNS(self::XMLDSIGNS, $Fi . "\130\65\60\71\x53\145\x72\151\x61\154\x4e\165\x6d\142\145\162", $gS["\x73\x65\162\151\x61\154\116\165\x6d\142\145\x72"]);
            $QN->appendChild($Lj);
            Sf:
            ho:
            fI:
            $YA = $vI->createElementNS(self::XMLDSIGNS, $Fi . "\130\65\x30\x39\103\x65\x72\x74\151\146\151\143\x61\164\x65", $DB);
            $xs->appendChild($YA);
            yT:
        }
        SW:
    }
    public function add509Cert($A9, $QZ = true, $H3 = false, $kQ = null)
    {
        if (!($C1 = $this->getXPathObj())) {
            goto NL;
        }
        self::staticAdd509Cert($this->sigNode, $A9, $QZ, $H3, $C1, $kQ);
        NL:
    }
    public function appendToKeyInfo($oe)
    {
        $Ez = $this->sigNode;
        $vI = $Ez->ownerDocument;
        $C1 = $this->getXPathObj();
        if (!empty($C1)) {
            goto vA;
        }
        $C1 = new DOMXPath($Ez->ownerDocument);
        $C1->registerNamespace("\163\x65\143\144\x73\x69\x67", self::XMLDSIGNS);
        vA:
        $Lb = "\x2e\57\163\x65\x63\144\163\x69\147\72\113\x65\x79\x49\x6e\x66\x6f";
        $au = $C1->query($Lb, $Ez);
        $dp = $au->item(0);
        if ($dp) {
            goto im;
        }
        $Fi = '';
        $aY = $Ez->lookupPrefix(self::XMLDSIGNS);
        if (empty($aY)) {
            goto Cb;
        }
        $Fi = $aY . "\72";
        Cb:
        $nf = false;
        $dp = $vI->createElementNS(self::XMLDSIGNS, $Fi . "\x4b\x65\171\111\156\x66\157");
        $Lb = "\x2e\x2f\x73\145\x63\x64\x73\151\147\x3a\117\142\x6a\145\143\x74";
        $au = $C1->query($Lb, $Ez);
        if (!($zn = $au->item(0))) {
            goto wn;
        }
        $zn->parentNode->insertBefore($dp, $zn);
        $nf = true;
        wn:
        if ($nf) {
            goto Xk;
        }
        $Ez->appendChild($dp);
        Xk:
        im:
        $dp->appendChild($oe);
        return $dp;
    }
    public function getValidatedNodes()
    {
        return $this->validatedNodes;
    }
}
