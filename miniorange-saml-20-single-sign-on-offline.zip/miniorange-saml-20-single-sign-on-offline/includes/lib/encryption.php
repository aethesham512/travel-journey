<?php


class AESEncryption
{
    public static function encrypt_data($P9, $z5)
    {
        $z5 = openssl_digest($z5, "\x73\x68\141\x32\65\x36");
        $Pk = "\x61\x65\x73\55\x31\x32\70\x2d\145\143\142";
        $Jj = openssl_encrypt($P9, $Pk, $z5, OPENSSL_RAW_DATA || OPENSSL_ZERO_PADDING);
        return base64_encode($Jj);
    }
    public static function decrypt_data($P9, $z5)
    {
        $uN = base64_decode($P9);
        $z5 = openssl_digest($z5, "\163\x68\x61\62\65\66");
        $Pk = "\x41\x45\x53\x2d\x31\x32\70\x2d\105\x43\102";
        $I1 = openssl_cipher_iv_length($Pk);
        $p8 = substr($uN, 0, $I1);
        $P9 = substr($uN, $I1);
        $Xn = openssl_decrypt($P9, $Pk, $z5, OPENSSL_RAW_DATA || OPENSSL_ZERO_PADDING, $p8);
        return $Xn;
    }
}
