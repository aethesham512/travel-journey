<?php


if (defined("\127\120\111\116\103")) {
    goto kr;
}
die;
kr:
